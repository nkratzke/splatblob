package de.fhluebeck.lockemar;

public class IntegerUtils
{
	public static int add(int a, int b)
	{
		return a + b;
	}
	
	public static int addBetrag(int a, int b)
	{
		return Math.abs(a) + Math.abs(b);
	}
}
