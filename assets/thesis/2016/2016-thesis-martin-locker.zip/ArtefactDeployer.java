package de.fhluebeck.lockemar.autotest.environment.deployment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

/**
 * @author Martin Locker
 */
public final class ArtefactDeployer
{
    private static final Log sm_Log = LogFactory.getLog(ArtefactDeployer.class);

    private final Map<String, Path> m_fileNamePathMap = new HashMap<>();

    private ArtefactDeployer(final String directoryFilesToCopy, final String targetDirectory)
    {
        final Vector<String> componentNames = getComponentNames();
        try
        {
            UpdateService.shutdownInstances(componentNames);
        }
        catch( final Exception e )
        {
            e.printStackTrace();
        }

        final Path artefactPath = Paths.get(directoryFilesToCopy);
        final List<Path> filesToCopy = FileListUtil.fileList(artefactPath);
        fillFileNameMap(filesToCopy);

        final Path startDirectory = Paths.get(targetDirectory);
        final boolean hasWritePermission = FileListUtil.hasWritePermission(startDirectory);
        if(!hasWritePermission)
        {
            System.out.println("No write permission to " + startDirectory.toString());
        }

        final Map<String, List<Path>> fileReplaceMap = FileIndexer.createIndex(m_fileNamePathMap.keySet(), startDirectory);

        copyFilesToTarget(fileReplaceMap);

        try
        {
        	UpdateService.startInstances(componentNames);
        }
        catch( final Exception e )
        {
            e.printStackTrace();
        }
    }

    private static Vector<String> getComponentNames()
    {
        final Vector<String> names = new Vector<String>();
        Map<ComponentInfo, String> componentsAndStatus = null;
        try
        {
            componentsAndStatus = SuperVisorAccess.getComponentsAndStatus();
            final Set<ComponentInfo> components = componentsAndStatus.keySet();
            for( final ComponentInfo component : components )
            {
                names.add(component.getName());
            }
        }
        catch( InterruptedException | TimeoutException e )
        {
            e.printStackTrace();
        }


        return names;
    }

    private void copyFilesToTarget(final Map<String, List<Path>> fileReplaceMap)
    {
        final Set<Entry<String, List<Path>>> entrySet = fileReplaceMap.entrySet();
        for( final Entry<String, List<Path>> entry : entrySet )
        {
            final String fileName = entry.getKey();
            final Path sourcePath = m_fileNamePathMap.get(fileName);
            copy(sourcePath, entry.getValue());
        }
    }

    private static void copy(final Path srcPath, final List<Path> targets)
    {
        for( final Path targetPath : targets )
        {
            try
            {
                Files.copy(srcPath, targetPath, StandardCopyOption.REPLACE_EXISTING);
            }
            catch( final IOException e )
            {
                sm_Log.error("Error at copy file ", e);
            }
        }
    }

    private void fillFileNameMap(final List<Path> filesToCopy)
    {
        if(filesToCopy != null)
        {
            for( final Path path : filesToCopy )
            {
                final String fileName = path.getFileName().toString();
                m_fileNamePathMap.put(fileName, path);
            }
        }
    }

    public static void main(final String[] args)
    {
        new ArtefactDeployer(args[0], args[1]);
    }

}
