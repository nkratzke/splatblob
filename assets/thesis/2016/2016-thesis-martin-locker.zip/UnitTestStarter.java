import org.apache.log4j.Logger;
import com.heidelberg.printready.autotest.util.logging.HTMLReport;
import com.heidelberg.printready.autotest.util.logging.JUnitLogger;

public final class UnitTestStarter
{
    private UnitTestStarter() {}

    private static final Logger sm_Log = Logger.getLogger(UnitTestStarter.class);

    public static void startTest(final String fullQualifiedClassname, final HTMLReport htmlReport, final String fileName)
    {
        JUnitLogger.init(htmlReport, fileName);
        JUnitLogger.logInfo("Start JUnit", "Starting test with class " + fullQualifiedClassname);
        try
        {
            UnitTestInvoker.runUnitTest(fullQualifiedClassname);
        }
        catch (final Throwable e)
        {
            sm_Log.error("startTest(): Exception caught!", e);
            JUnitLogger.logWarn("Start JUnit", "Starting test failed: "+e.getMessage());
        }
    }
}
