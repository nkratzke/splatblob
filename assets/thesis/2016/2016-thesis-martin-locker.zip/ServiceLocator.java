package de.fhluebeck.lockemar.services;

public class ServiceLocator implements IServiceLocator
{
	@Override
	public <T extends IService> T getService(Class<T> serviceClass)
	{
		return ServiceRegistry.getService(serviceClass);
	}

}
