package de.fhluebeck.lockemar.services;

public class TestWithService
{
	public void callFromTest()
	{
		.
		.
		ISomeService service = ServiceRegistry.getService(ISomeService.class);
		service.doSomething();
		.
		.
	}
	
	public void callFromTestWithDI(ISomeService service)
	{
		.
		.
		service.doSomething();
		.
		.
	}
}
