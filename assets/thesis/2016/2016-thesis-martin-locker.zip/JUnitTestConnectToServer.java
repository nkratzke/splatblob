package de.fhluebeck.lockemar.junitautotest;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class JUnitTestConnectToServer
{
	@BeforeClass
	public static void connectToServer()
	{
		EclipseEnv.connectIfNotServer();
	}
	
	@Test
	public void test()
	{
		// Code des Tests
	}

}
