package de.fhluebeck.lockemar;

public class IntegerAdder
{
	private boolean m_isBetragModus;

	public IntegerAdder(boolean betrag)
	{
		setBetragModus(betrag);
	}

	public boolean isBetragModus()
	{
		return m_isBetragModus;
	}

	public void setBetragModus(boolean isBetragModus)
	{
		m_isBetragModus = isBetragModus;
	}
	
	public int add(int a, int b)
	{
		if(isBetragModus())
		{
			return Math.abs(a) + Math.abs(b);
		}
		else
		{
			return a + b;
		}
	}
}
