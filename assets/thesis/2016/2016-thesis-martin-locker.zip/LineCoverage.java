package de.fhluebeck.lockemar.coverage;

public class LineCoverage
{
	public String convertIntToPositiveString(int i)
	{
		Integer posVal = null;
		if(i >= 0)
		{
			posVal = Integer.valueOf(i);
		}
		return posVal.toString();
	}
}
