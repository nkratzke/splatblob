package de.fhluebeck.lockemar.mutex;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
*
* @author Martin Locker
*
*/
public class FileMutex
{
    private static final Log sm_Log = LogFactory.getLog( FileMutex.class );

    private final Path m_pathForMutex;

    public FileMutex( final Path pathForMutex )
    {
        super();
        m_pathForMutex = pathForMutex;
    }

    /**
     *
     * @return null wenn es Probleme beim Zugriff auf das File gibt
     */
    public FileLock lock()
    {
        FileLock fileLock = null;
        final boolean check = checkAndCreateFile(m_pathForMutex);
        if(check)
        {
            final FileChannel fileChannel;

            try
            {
                sm_Log.info("Try to get mutex for " + m_pathForMutex.toAbsolutePath());
                fileChannel = FileChannel.open(m_pathForMutex, StandardOpenOption.WRITE);
                fileLock = fileChannel.lock(); // Wenn Lock von anderem Programm, dann bleibt Thread hier stehen
                sm_Log.info("Get mutex for " + m_pathForMutex.toAbsolutePath());
            }
            catch (final IOException e)
            {
                sm_Log.error("Error at lock File '" + m_pathForMutex.toAbsolutePath() + "'. ", e);
            }
        }
        return fileLock;
    }

    public void unlock(final FileLock lock)
    {
        if(lock != null)
        {
            try
            {
                sm_Log.info("Release lock for File '" + m_pathForMutex.toAbsolutePath() + "'. ");
                lock.release();
            }
            catch( final IOException e )
            {
                sm_Log.error( "Error at release the lock ", e );
            }
        }
    }

    private boolean checkAndCreateFile(final Path path)
    {
        boolean isOK = false;

        if(path != null)
        {
            final boolean exists = Files.exists( path );
            if(exists)
            {
                isOK = true;
            }
            else
            {
                try
                {
                    final Path createdFile = Files.createFile( path );
                    if(createdFile != null)
                    {
                        sm_Log.info( "Mutex file '" + createdFile.toAbsolutePath() + "' created" );
                        isOK = true;
                    }
                }
                catch( final Throwable t )
                {
                    sm_Log.error( "Can't create File " + path.toAbsolutePath(), t );
                }

            }
        }
        return isOK;
    }
}
