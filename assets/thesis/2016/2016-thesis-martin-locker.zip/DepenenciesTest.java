package de.fhluebeck.lockemar.dependencies;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Collection;

import jdepend.framework.DependencyConstraint;
import jdepend.framework.JDepend;
import jdepend.framework.JavaPackage;
import jdepend.framework.PackageFilter;

import org.junit.BeforeClass;
import org.junit.Test;

public class DepenenciesTest
{
    private JDepend m_jdepend;
	
	@BeforeClass
    private void setUp() throws IOException 
    {
        m_jdepend = new JDepend();
        m_jdepend.addDirectory("bin/classes");
    }
	
	@Test
	public void testDependencies()
	{
        DependencyConstraint constraint = new DependencyConstraint();

        JavaPackage gui = constraint.addPackage("de.fhluebeck.lockerma.gui");
        JavaPackage is = constraint.addPackage("de.fhluebeck.lockerma.infrastructure");
        JavaPackage serviceinterface = constraint.addPackage("de.fhluebeck.lockerma.serviceinterface");
    
        gui.dependsUpon(serviceinterface);
        is.dependsUpon(serviceinterface);
    
        m_jdepend.analyze();    

		assertEquals("Dependency mismatch", true, m_jdepend.dependencyMatch(constraint));
    }
	
    public void testCycles() 
    {
        Collection packages = m_jdepend.analyze();
        assertEquals("Cycles exist", false, m_jdepend.containsCycles());
    }
}
