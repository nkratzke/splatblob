package de.fhluebeck.lockemar.autotest.environment.testanalyser;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.List;

/**
 * 
 * @author Martin Locker
 *
 */
public class TestAnalyser
{
	private static final String FINISHED_SUFFIX = ".finished";
	
	public TestAnalyser(String autoTestDirectory, String waitFileName)
	{
		final Path path = Paths.get(autoTestDirectory);
		try
		{
			WatchService watchService = path.getFileSystem().newWatchService();
			WatchKey watchKey = path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
			boolean endFileFound = false;
			
			while(!endFileFound)
			{
				try
				{
					Thread.sleep(1000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				
				List<WatchEvent<?>> pollEvents = watchKey.pollEvents();
				if(pollEvents != null)
				{
					for (WatchEvent<?> watchEvent : pollEvents)
					{
						Path createdPath = (Path)watchEvent.context();
						String fileName = createdPath.getFileName().toString();
						endFileFound = isFinishedFileCreated(waitFileName, fileName);
					}
				}
			}
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		int exitCode = checkIfAllTestsOK(autoTestDirectory) ? 0 : -1;
		System.exit(exitCode); // Wenn alle Tests ok mit ReturnValue 0 das Programm beendnen
	}
	
	private boolean isFinishedFileCreated(String waitFileName, String newCreatedName)
	{
		// Nur Start und Ende ber�cksichten. Datumsangabe in der Mitte ausblenden.
		if(newCreatedName.startsWith(waitFileName) || newCreatedName.endsWith(FINISHED_SUFFIX))
		{
			return true;
		}
		return false;
	}

	private boolean checkIfAllTestsOK(String autoTestDirectory)
	{
		return new TestReportReader().checkReports(autoTestDirectory);
	}
	
	public static void main(final String[] args)
    {
    	new TestAnalyser(args[0], args[1]);
    }
}
