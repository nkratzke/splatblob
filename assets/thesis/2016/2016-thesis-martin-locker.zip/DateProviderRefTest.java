package de.fhluebeck.lockemar.date;

import java.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;

public class DateProviderTest
{
	@Test
	public void testGetDateAsString() throws Exception
	{
		LocalDate dateStub = LocalDate.of(2016, 5, 15);
		String dateStr = DateProvider.getDateAsString(dateStub);
		Assert.assertEquals("15.5.2016", dateStr);
	}
}
