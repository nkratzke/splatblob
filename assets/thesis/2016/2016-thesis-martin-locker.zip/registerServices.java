public static <T extends IService> void registerService(final Class<T> serviceClass, final T serviceToRegister)
{
   // Parameter serviceToRegister muss von IService abgeleitet sein	
}

