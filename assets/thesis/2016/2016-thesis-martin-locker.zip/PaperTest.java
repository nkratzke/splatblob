package de.fhluebeck.lockemar.paper.impl;

import org.easymock.EasyMock;
import org.junit.Test;
import de.fhluebeck.lockemar.paper.IPaper;

public class PaperTest
{
	@Test
	public void testGetElement() throws Exception
	{
		// Erzeugen des Mock-Objekts
		IPaper iPaperMock = EasyMock.createNiceMock(IPaper.class);
		
		// Antworten aufzeichnen
		EasyMock.expect(iPaperMock.getHeight()).andStubReturn(29.7);
		EasyMock.expect(iPaperMock.getWidth()).andStubReturn(21.0);
		
		// Vom Record-Modus in den Replay-Modus wechseln
		EasyMock.replay(iPaperMock);
	}
}
