package de.fhluebeck.lockemar.mutex;

import java.io.File;
import java.nio.channels.FileLock;

import com.heidelberg.prinect.baselayer.utils.file.mutex.FileMutex;
import com.heidelberg.prinect.utils.CommonUtils;
import com.heidelberg.printready.autotest.util.connector.IJDFConnectorAccess;

/**
 * @author Martin Locker
 *
 */
class JDFConnectorAccess implements IJDFConnectorAccess
{
    private static final String MUTEXT_FILENAME = "JDFConnector.mutex";

    private static FileMutex sm_fileMutex;

    private FileLock m_lock;

    static
    {
        final File mutextFile = new File(CommonUtils.getTempDir(), MUTEXT_FILENAME);
        sm_fileMutex = new FileMutex( mutextFile.toPath() );
    }

    @Override
    public void getConfigAccess( )
    {
        m_lock = sm_fileMutex.lock(); // Auf Lock warten
    }

    @Override
    public void unlockConfigAccess( )
    {
        if(m_lock != null)
        {
            sm_fileMutex.unlock( m_lock );
            m_lock = null;
        }
    }

}
