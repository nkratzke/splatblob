
private static FileAppender createFileAppender(final File file)
{
    final FileAppender fileApp = new FileAppender();

    final Path logPath = getLogPath();
    final LocalDateTime now = LocalDateTime.now();
    final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TIME_FORMAT_PATTERN);
    final String formattedDateTime = now.format(formatter);
    final File logFile = new File(logPath.toFile(), getTestName(file) +  formattedDateTime + "_" + getScriptServerName() + LOGFILE_SUFFIX );

    try
    {
        fileApp.setFile( logFile.getCanonicalPath() );
        sm_Log.info( "Set Path for LogFile: " + logFile.getCanonicalPath() );
    }
    catch( final IOException e )
    {
        sm_Log.error("Can get getCanonicalPath. " , e);
    }

    fileApp.setLayout(new DebugTraceLog4jLayout());
    fileApp.activateOptions();
    fileApp.setThreshold(Level.DEBUG);
    fileApp.setAppend( true );

    return fileApp;
}

