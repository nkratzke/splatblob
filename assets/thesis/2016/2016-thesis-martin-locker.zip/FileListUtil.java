package de.fhluebeck.lockemar.autotest.environment.deployment;

import java.io.FilePermission;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author Martin Locker
 *
 */
public final class FileListUtil
{
    private static final Log sm_Log = LogFactory.getLog(FileListUtil.class);

    private FileListUtil()
    {
        super();
        // Utility class
    }

    public static List<Path> fileList(final Path directory)
    {
        final List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(directory))
        {
            for (final Path path : directoryStream)
            {
                if(Files.isDirectory(path))
                {
                    final List<Path> fileList = fileList(path);
                    if(!fileList.isEmpty())
                    {
                        files.addAll(fileList);
                    }
                }
                else
                {
                    files.add(path);
                }
            }
        }
        catch (final IOException ex)
        {
            sm_Log.error("IOException occurred ", ex);
        }
        return files;
    }

    static boolean hasWritePermission(final Path path)
    {
        boolean hasPermission = true;
        try
        {
            AccessController.checkPermission(new FilePermission(path.toString(), "read,write"));
            // Has permission
        }
        catch (final SecurityException e)
        {
            hasPermission = false;
        }
        return hasPermission;
    }
}
