package de.fhluebeck.lockemar.unittest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.Runner;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.junit.runners.model.InitializationError;

import com.heidelberg.prinect.common.status.IPrinectResult;
import com.heidelberg.prinect.common.status.PrinectResult;
import com.heidelberg.printready.autotest.util.logging.JUnitLogger;
import com.heidelberg.printready.error.PrinectMessage;

/**
 *
 * @author Martin Locker
 *
 */
public final class UnitTestInvoker
{
    private static final Logger sm_Log = Logger.getLogger(UnitTestInvoker.class);

    private static Collection<String> sm_Failures = new ArrayList<String>();
    
    private UnitTestInvoker() {}

    public static void runUnitTest(final String fullQualifiedClassname) throws PrinectResult
    {
        if(fullQualifiedClassname != null)
        {
            try
            {
                final Class<?> unitTestClass = Class.forName(fullQualifiedClassname);
                runUnitTest(unitTestClass);
            }
            catch (final ClassNotFoundException | InitializationError e)
            {
                if (e instanceof ClassNotFoundException)
                {
                    sm_Log.warn("Class " + fullQualifiedClassname + " not found. ", e);
                }
                else
                {
                    sm_Log.warn("Class " + fullQualifiedClassname + " can not be initialized. ", e);
                }
                JUnitLogger.logWarn("Start JUnit", "Starting test "+fullQualifiedClassname+" failed: "+e.getMessage());
            }
        }
    }

    private static void runUnitTest(final Class<?> unitTestClass)
            throws InitializationError, Result
    {
        sm_Failures.clear();
        final JUnitCore junitCore = new JUnitCore();
        junitCore.addListener(new UnitRunListener());
        final Runner runner = new JUnit4EnhancedTimeoutClassRunner(unitTestClass);
        junitCore.run(runner);
        if(!sm_Failures.isEmpty())
        {
            final String failures = Arrays.toString(sm_Failures.toArray(new String [sm_Failures.size()]));
            throw new Result(new Message(failures), IResult.ERROR);
        }
    }

    public static class UnitRunListener extends RunListener
    {

        @Override
        public void testFinished(final Description description) throws Exception
        {
            JUnitLogger.logInfo("testFinished", description.getMethodName());
            super.testFinished(description);
        }

        @Override
        public void testIgnored(final Description description) throws Exception
        {
            JUnitLogger.logInfo("testIgnored", description.getMethodName());
            super.testIgnored(description);
        }

        @Override
        public void testRunFinished(final Result result) throws Exception
        {
            if(result.getFailureCount() > 0)
            {
                final List<Failure> failures = result.getFailures();
                for (final Failure failure : failures)
                {
                    final String message = failure.getDescription().getMethodName() + " " + failure.getMessage();
                    final Throwable exception = failure.getException();
                    if( exception != null )
                    {
                        sm_Log.error( "testRunFinished(): exception during test ",exception );
                    }
                    sm_Failures.add(message);
                    JUnitLogger.logError("test Failed", message );
                }
            }
            JUnitLogger.logInfo("testRunFinished", "RunCount: " + result.getRunCount() + " RunTime: " + result.getRunTime() + " ms");
            super.testRunFinished(result);
        }

        @Override
        public void testRunStarted(final Description description) throws Exception
        {
            JUnitLogger.logInfo("testRunStarted", description.getMethodName());
            super.testRunStarted(description);
        }

        @Override
        public void testStarted(final Description description) throws Exception
        {
            JUnitLogger.logInfo("testStarted", description.getMethodName());
            super.testStarted(description);
        }

    }
}
