public double getPaperWeight(IPaper ipaper)
{
	double paper_weight = -1.0;
	if(ipaper instanceof Paper)
	{
		Element element = ((Paper)ipaper).getElement();
		String attribut = element.getAttribute("WEIGTH");
		paper_weight = Double.valueOf(attribut);
	}
	return paper_weight;
}
