package de.fhluebeck.lockemar.date;

import org.junit.Assert;
import org.junit.Test;

public class DateProviderTest
{
	@Test
	public void testGetDateAsString() throws Exception
	{
		String dateStr = DateProvider.getDateAsString();
		Assert.assertEquals("15.5.2016", dateStr);
	}
}
