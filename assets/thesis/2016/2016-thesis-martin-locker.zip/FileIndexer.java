package de.fhluebeck.lockemar.autotest.environment.deployment;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Martin Locker
 *
 */
final class FileIndexer
{
    private FileIndexer()
    {
        super();
        // Utility class
    }

    /**
     * @return Enth�lt f�r jedes zur ersetzendes File ein oder mehr m�gliche Ziele zum Kopieren
     */
    static Map<String, List<Path>> createIndex(final Collection<String> fileNamesToReplace, final Path startIndexDirectory)
    {
        final Map<String, List<Path>> replacingFileToPaths = new HashMap<>();

        final Set<String> fileNames = new HashSet<>(fileNamesToReplace);
        final List<Path> fileList = FileListUtil.fileList(startIndexDirectory);

        for( final Path filePathInReplaceDir : fileList )
        {
            final String fileName = filePathInReplaceDir.getFileName().toString();
            if(fileNames.contains(fileName)) // Ist es ein zu ersetzendes File
            {
                List<Path> list = replacingFileToPaths.get(fileName);
                if(list == null)
                {
                    list = new ArrayList<Path>();
                    replacingFileToPaths.put(fileName, list);
                }
                list.add(filePathInReplaceDir);
            }
        }

        return replacingFileToPaths;
    }
}
