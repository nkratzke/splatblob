package de.fhluebeck.lockemar.services;

public interface IServiceLocator
{
	<T extends IService> T getService(final Class<T> serviceClass);
}
