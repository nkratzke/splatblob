package de.fhluebeck.lockemar.services;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ServiceRegistry
{
	private static Map<Class<? extends IService>, Object> sm_services = new ConcurrentHashMap<>();
	
	public static <T extends IService> void registerService(final Class<T> serviceClass, final T service)
	{
		if(serviceClass.isInterface())
		{
			sm_services.put(serviceClass, service);
		}
		else
		{
			throw new UnsupportedOperationException("Class " + serviceClass + " ist kein Interface");
		}
	}
	
	public static <T extends IService> T getService(final Class<T> serviceClass)
	{
		return (T) sm_services.get(serviceClass);
	}
}
