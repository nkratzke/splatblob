RELAXX YOUR FACE ! 

Game Concept

The motivation of creating this game is to relax usere's face by a mobile game. With the development of society, more and more people work in the office rather than outside. After a long period of work, people need to have a relax. And this game can give users physical and mental relaxaion. 

The procedures are listed below. 

Firstly, users open this mobile game by a phone with HTML5 web browser. This is a single page game. The page is divided into three parts, the upper part is the game's name, "Relax your face!" and a text line which shows some commands orderly. And the middle part is a the main part, which is a window and shows the user's face through mobile front camera. And the lower part is a dynamic table which shows user's emotion and the next line is a "relaxx now" button.

Before playing this game, he should click the "relaxx" button.

If he clicks the "Relaxx Now" button, there is a pop-up box which asks for the permission of using front camera. After clicking the "Yes", he will enters the main part of this game. 

Then the middle window shows the user's face and tries to detetc it by the dynamic green line. The green line can dynamically recognize and track user's face, on the other hand, the accuracy of recognition and tracking is affected by illumination, gestures, the espressions of test subjects and so on. 

Then in the upper part, the text line shows different commands orderly. User can show any emotions after read the command and will get different reactions. For example, the text line shows "After a long time work, you should feel ...". And when users  show a "sad" expression, the command will change to "endless work, more pressure. So.. COOL!" but if users show a "happy" expression, the command will show "Unexpectedly happy..." 

The basic procedures are listed and the game is designed and developed to relax users. 
