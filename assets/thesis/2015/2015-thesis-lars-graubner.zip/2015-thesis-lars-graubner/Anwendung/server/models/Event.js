var mongoose = require("mongoose");

var eventSchema = mongoose.Schema({
    // Zeitstempel
    timestamp: {
        type: Date,
        default: Date.now
    },
    // Koordinaten relativ zu Ziel-Element
    coordinates: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    // eindeutige Session-ID
    session_id: {
        type: String,
        required: true
    },
    // Original User-Agent-String
    user_agent: {
        type: String,
        required: true
    },
    // geparster User-Agent-String
    parsed_user_agent: {
        type: mongoose.Schema.Types.Mixed,
        required: false
    },
    // original Seiten-URL
    page_url: {
        type: String,
        required: true
    },
    // geparste Seiten-URL
    parsed_page_url: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    // Aufloesung
    resolution: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    // Referrer-URL
    referrer_url: {
        type: String
    },
    // DOM-Element des Ziels
    element: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    // Art des Mausevents
    type: {
        type: String,
        required: true
    }
},
{
    versionKey: false
});

module.exports = mongoose.model('Event', eventSchema);
