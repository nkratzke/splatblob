var page = require("webpage").create(),
    system = require("system");

// Viewport Groesse setzen
page.viewportSize = {
    width: system.args[3],
    height: system.args[4]
};

// Seite oeffnen
page.open(system.args[1], function(status) {
    var data = JSON.parse(system.args[2]);

    // lodash laden
    var injected = page.injectJs("./public/bower_components/lodash/lodash.min.js");

    if (injected) {
        var events = page.evaluate(function(data) {
            var ret = [], el, xpathres, i;

            // Hilfsmethode um Position eines Elements herauszufinden
            var _getElementPosition = function(el) {
                var box = el.getBoundingClientRect(),
                    docElem = document.documentElement;

                return {
                    top: box.top + window.pageYOffset - docElem.clientTop,
                    left: box.left + window.pageXOffset - docElem.clientLeft
                };
            };

            // Daten durchlaufen
            _.forEach(data, function(n, key) {
                // XPATH aufloesen
                xpathres = document.evaluate(n.element.path, document.body, null, XPathResult.ANY_TYPE, null);
                el = xpathres.iterateNext();

                if (el !== null) {
                    var elPos = _getElementPosition(el);

                    // Koordinaten berechnen
                    var pos = {
                        x: Math.round(elPos.left + n.coordinates.x),
                        y: Math.round(elPos.top + n.coordinates.y)
                    };

                    // Daten zu Array hinzufuegen
                    var search = _.findIndex(ret, pos);
                    if (search === -1) {
                        ret.push(_.merge(pos, {
                            value: 1
                        }));
                    } else {
                        ret[search].value = ret[search].value + 1;
                    }
                }
            });
            return ret;
        }, data);

        // Daten zurueckgeben
        console.log(JSON.stringify(events));
    }
    // PhantomJS beenden
    phantom.exit();
});
