var request = require('supertest'),
    express = require('express'),
    assert = require("chai").assert,
    mongoose = require('mongoose');

// Routen
describe('Routes', function() {
    this.timeout(10000);
    
    var app, agent;

    before(function(done) {
        app = require('../server.js').app;
        agent = request.agent(app);
        setTimeout(function() {
            done();
        }, 2000);
    });

    after(function(done) {
        mongoose.disconnect();
        done();
    });

    // Route /
    describe('GET /', function() {
        it('returns HTML with status 200', function(done) {
            agent.get('/').end(function(err, res) {
                assert.isNull(err);
                assert.strictEqual(res.status, 200);
                assert.match(res.header['content-type'], /text\/html/);
                assert.equal(res.header['x-powered-by'], 'Express');

                done();
            });
        });
    });

    // Route /site
    describe('GET /site', function() {
        it('returns 404 if no site specified', function(done) {
            agent.get('/site').end(function(err, res) {
                assert.isNull(err);
                assert.strictEqual(res.status, 404);
                done();
            });
        });
    });

    // Route /collect
    describe('GET /collect', function() {
        it('returns webbug image with status 200', function(done) {
            agent.get('/collect').end(function(err, res) {
                assert.isNull(err);
                assert.strictEqual(res.status, 200);
                assert.match(res.header['content-type'], /image\/gif/);
                done();
            });
        });

        it('invalid json query should not throw an error', function(done) {
            agent.get('/collect?event={invalid-json}').end(function(err, res) {
                assert.isNull(err);
                assert.strictEqual(res.status, 200);
                assert.match(res.header['content-type'], /image\/gif/);
                done();
            });
        });

        it('with query returns status code 200', function(done) {
            agent.get('/collect?data={"type":"click","data":{"x":372,"y":588,"xpath":"/HTML/BODY","sessid":"5k6Zc7y7xK"},"r":"Swu9e"}').end(function(err, res) {
                assert.isNull(err);
                assert.strictEqual(res.status, 200);
                assert.match(res.header['content-type'], /image\/gif/);
                done();
            });
        });
    });

    // Route /api/heatmap
    describe('GET /api/heatmap', function() {
        it('returns gzipped json with message success', function(done) {
            agent.get('/api/heatmap').end(function(err, res) {
                assert.isNull(err);
                assert.match(res.header['content-type'], /json/);
                assert.strictEqual(res.status, 200);
                assert.equal(res.header['content-encoding'], 'gzip');
                assert.propertyVal(JSON.parse(res.text), 'status', 'ok');
                done();
            });
        });
    });

    // Route /api/count
    describe('GET /api/count', function() {
        it('returns gzipped json with message success', function(done) {
            agent.get('/api/count').end(function(err, res) {
                assert.isNull(err);
                assert.match(res.header['content-type'], /json/);
                assert.strictEqual(res.status, 200);
                assert.equal(res.header['content-encoding'], 'gzip');
                assert.propertyVal(JSON.parse(res.text), 'status', 'ok');
                done();
            });
        });
    });

    // Route /api/history
    describe('GET /api/history', function() {
        it('returns gzipped json with message success', function(done) {
            agent.get('/api/history').end(function(err, res) {
                assert.isNull(err);
                assert.match(res.header['content-type'], /json/);
                assert.strictEqual(res.status, 200);
                assert.equal(res.header['content-encoding'], 'gzip');
                assert.propertyVal(JSON.parse(res.text), 'status', 'ok');
                done();
            });
        });
    });
});
