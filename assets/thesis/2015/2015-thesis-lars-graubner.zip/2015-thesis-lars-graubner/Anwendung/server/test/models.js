var assert = require("chai").assert,
    mongoose = require("mongoose"),
    Event = require('../models/Event.js');

// Modell
describe("Models", function() {
    describe("Event", function() {
        it('is defined', function() {
            assert.isDefined(Event);
        });
    });
});
