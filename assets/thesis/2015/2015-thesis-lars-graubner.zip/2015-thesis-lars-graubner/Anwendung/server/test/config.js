var assert = require("chai").assert;

// Konfiguration
describe('Config', function() {
    it('should load local configurations', function() {
        var config = require("../config");
        assert.isDefined(config.server);
    });
});
