var assert = require("chai").assert,
    utils = require('../utils');

// Helfer-Funktionen
describe('Helper functions', function() {
    // Funktion formatJSONStr()
    describe('#formatJSONStr()', function() {
        it('is a function', function() {
            assert.isFunction(utils.formatJSONStr);
        });

        it('returns a string', function() {
            assert.isString(utils.formatJSONStr({ test: 1 }));
        });

        it('indents the result string if second argument true', function() {
            var wo = utils.formatJSONStr({ test: 1 }),
            w = utils.formatJSONStr({ test: 1 }, true);
            assert.operator(wo.length, '<', w.length);
        });

        it('does not indent the result string if second argument false', function() {
            var wo = utils.formatJSONStr({ test: 1 }),
            w = utils.formatJSONStr({ test: 1 }, false);
            assert.equal(wo.length, w.length);
        });
    });

    // Funktion parseDate()
    describe('#parseDate()', function() {
        it('is a function', function() {
            assert.isFunction(utils.parseDate);
        });

        it('returns date object with invalid date string argument', function() {
            assert.ok(isNaN(utils.parseDate("test").getTime()));
        });

        it('returns date object with valid date string argument', function() {
            assert.instanceOf(utils.parseDate("2015-02-22"), Date);
        });
    });

    // Funktion beautifyURL()
    describe('#beautifyURL()', function() {
        it('is a function', function() {
            assert.isFunction(utils.beautifyURL);
        });

        var testURL = "https://www.example.com/";
        it('removes protocol fragment', function() {
            assert.notMatch(utils.beautifyURL(testURL), /^http:\/\/.+$/);
            assert.notMatch(utils.beautifyURL(testURL), /^https:\/\/.+$/);
        });

        it('removes www fragment', function() {
            assert.notMatch(utils.beautifyURL(testURL), /^.*www\..+$/);
        });

        it('removes trailing slash', function() {
            assert.notMatch(utils.beautifyURL(testURL), /^.+\/$/);
        });
    });
});
