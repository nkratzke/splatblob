var assert = require("chai").assert,
    mongoose = require('mongoose'),
    config = require('../config');

describe('Server', function() {
    after(function(done) {
        mongoose.disconnect();
        done();
    });

    it('connects to MongoDB', function(done) {
        mongoose.connect('mongodb://' + config.mongodb.host + '/' + config.mongodb.database, function(err) {
            assert.isUndefined(err);
            done();
        });
    });
});
