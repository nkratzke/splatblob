var Heatmap = (function(window, document, $, undefined) {
    "use strict";

    var _heatmap,
        _config = {},
        _params = {};

    // Daten vom Server laden und Heatmap aktualisieren
    var update = function() {
        // Status setzen
        Portal.isloading = true;

        // jQuery promise zurueckliefern
        return $.getJSON(Portal.generateURL("heatmap"), function(res) {
            // Daten der Visualisierung setzen
            _heatmap.map.setData({
                max: res.max,
                data: res.data
            });

            // Legende aktualisieren
            $(".legend .max").text(res.max);
            // Status setzen
            Portal.isloading = false;
        });
    };

    // iFrame fuer die Visualisierung erstellen
    var _createIframe = function(url, cont) {
        return $("<iframe />", {
            src: url,
            frameborder: 0,
            width: _config.devices[_params.device],
            height: 700
        });
    };

    // Heatmap erstellen
    var _createHeatmap = function(el) {
        return {
            map: h337.create({
                container: el,
                backgroundColor: "rgba(0,0,0,.1)"
            }),
            el: $(el).parent("div")
        };
    };

    // Visualisierung erstellen
    var create = function(wrapper) {
        // Ladeanimation anzeigen
        GUI.loader("show");
        // Status setzen
        Portal.isloading = true;
        var $wrapper = $(wrapper),
            $iframe = _createIframe("http://" + _params.page_url).appendTo($wrapper),
            $heatmapWrap = $('<div id="heatmap" style="width:100%;height:100%;" />').appendTo(wrapper);

        // Breite der Heatmap setzen
        $(".heatmap-wrapper").width(_config.devices[_params.device]);

        // Groesse des iFrame-Wrappers abhaengig von der iFrame-Groesse setzen
        $(window).one("message onmessage", function(e) {
            var height = e.originalEvent.data;
            $iframe.height(height);
            $wrapper.height(height);

            _heatmap = _createHeatmap($heatmapWrap.get(0));

            Heatmap.update().done(function() {
                GUI.loader("hide");
            });
        });

        // warten bis iFrame geladen ist
        $iframe.load(function() {
            this.contentWindow.postMessage("size", "*");
            Portal.isloading = false;
        });
    };

    // Heatmap entfernen
    var remove = function() {
        _heatmap = [];
        $(".heatmap-wrapper").empty();
    };

    // Heatmap initialisieren
    var init = function() {
        // Einstellungen laden
        _config = Portal.getConfig();
        // Parameter laden
        _params = Portal.getParams();

        if ($(".heatmap-wrapper").length > 0) {
            Heatmap.create(".heatmap-wrapper");
        }
    };

    // oeffentliche Methoden zurueckliefern
    return {
        update: update,
        create: create,
        remove: remove,
        init: init
    };

})(this, document, jQuery);
