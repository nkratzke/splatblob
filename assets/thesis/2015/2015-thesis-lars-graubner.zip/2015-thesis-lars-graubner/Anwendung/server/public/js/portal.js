var Portal = (function(window, document, $, undefined) {
	'use strict';

	var _baseURL = "http://192.168.59.103:7623/api/",
		_config = {
			devices: {
	            desktop: 1024,
	            tablet: 960,
	            mobile: 768
	        }
		},
		_params = {
			type: "click",
			device: "desktop"
		},
		isloading = false;

	// Base-URL zurueckliefern
	var getBaseURL = function() {
		return _baseURL;
	};

	// Konfiguration zurueckliefern
	var getConfig = function() {
		return _config;
	};

	// Werte in Konfiguration schreiben
	var setConfig = function(config) {
		return _.assign(_config, config);
	};

	// Parameter zurueckliefern
	var getParams = function() {
		return _params;
	};

	// Parameter anpassen
	var setParams = function(params) {
		return _.assign(_params, params);
	};

	// URL zur Datenabfrage generieren
	var generateURL = function(path) {
		var url = _baseURL + path;

		_.forIn(Portal.getParams(), function(val, key) {
			if (url.indexOf("?") == -1) {
				url += "?";
			} else {
				url += "&";
			}
			url += encodeURIComponent(key) + "=" + encodeURIComponent(val);
		});
		return url;
	};

	// Alle Visualisierungen und GUI neu laden
	var refresh = function() {
		GUI.loader("show");
		GUI.update();
		Chart.update();
		Heatmap.update().done(function() {
			GUI.loader("hide");
		});
	};

	// Portal initialisieren
	var init = function() {
		Portal.setParams({
			page_url: $('#site').val(),
		});

		Portal.setConfig({
			startDate: $('#start').val()
		});

		Heatmap.init();
		Chart.init();
		GUI.init();
	};

	// Oeffentliche Methoden zurueckliefern
	return {
		getBaseURL: getBaseURL,
		getConfig: getConfig,
		setConfig: setConfig,
		getParams: getParams,
		setParams: setParams,
		generateURL: generateURL,
		init: init,
		refresh: refresh,
		isloading: isloading
	};

})(this, document, jQuery);
