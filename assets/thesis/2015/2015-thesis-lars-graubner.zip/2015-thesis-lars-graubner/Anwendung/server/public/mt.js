var __mt = (function(window, document, undefined) {
    "use strict";

    var _sessId = "",
        _res = "",
        _ref = document.referrer || null;

    // Query Fragment entfernen
    if (_ref !== null && _ref.indexOf("?") > 0) {
        _ref = _ref.substring(0, _ref.indexOf("?"));
    }

    // Fehler bei fehlender Konsole unterbinden
    if (!window.console) console = { log: function() {} };

    // cross Browser add EventListener
    // http://youmightnotneedjquery.com/
    var _addEventListener = function(el, eventName, handler, capture) {
        if (el.addEventListener) {
            el.addEventListener(eventName, handler, capture);
        } else if (el.attachEvent) {
            el.attachEvent('on' + eventName, handler);
        }
    };

    // cross Browser remove EventListener
    var _removeEventListener = function(el, eventName, handler) {
        if (el.removeEventListener) {
            el.removeEventListener(eventName, handler, false);
        } else if (el.detachEvent) {
            el.detachEvent('on' + eventName, handler);
        }
    };

    // source: http://davidwalsh.name/javascript-debounce-function
    // debounce position event handler
    var _debounce = function(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    };

    // aktuelle Aufloesung zurueckliefern
    var _getResolution = function() {
        var docElem = document && document.documentElement;

        var a = docElem.clientWidth,
            b = window.innerWidth,
            width = a < b ? b : a;

        var c = docElem.clientHeight,
            d = window.innerHeight,
            height = c < d ? d : c;

        return {w: width, h: height};
    };

    // Hoehe des Dokuments zurueckliefern
    var _getDocHeight = function(e) {
        var docElem = document && document.documentElement,
            body = document.body;

        if (e.origin == 'http://192.168.59.103:7623') {
            if (e.data == "size") {
                var height = Math.max(body.scrollHeight, body.offsetHeight, docElem.clientHeight, docElem.scrollHeight, docElem.offsetHeight);

                e.source.postMessage(height, e.origin);
            }
        }
    };

    // Bei resize des Fensters Auflösung aktualisieren
    var _setResolution = _debounce(function() {
        _res = _getResolution();
        console.log("[mt][settings] resolution changed to " + _res.w + "x" + _res.h);
    }, 500);

    // Position eines Elements herausfinden
    var _getElementPosition = function(el) {
        var box = el.getBoundingClientRect(),
            docElem = document.documentElement;

        return {
            top: box.top + window.pageYOffset - docElem.clientTop,
            left: box.left + window.pageXOffset - docElem.clientLeft
        };
    };

    // relative Mauskoordinaten zu Zielelement zurueckliefern
    var _getRelMouseCoords = function(e) {

        if ( e.pageX === null && e.clientX !== null ) {
            var doc = document.documentElement, body = document.body;
            e.pageX = e.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
            e.pageY = e.clientY + (doc && doc.scrollTop  || body && body.scrollTop  || 0) - (doc   && doc.clientTop  || body && body.clientTop  || 0);
        }

        var elPos = _getElementPosition(e.target);

        var x = Math.round(e.pageX - elPos.left),
            y = Math.round(e.pageY - elPos.top);

        return {x: x, y: y};
    };

    // EIne zufaellige Zeichenfolge generieren
    var _genRandStr = function(length) {
        var rand = "",
            charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for(var i = 0; i < length; i++) {
            rand += charset.charAt(Math.floor(Math.random() * charset.length));
        }

        return rand;
    };

    // XPath eines ELements generieren
    var _createXPathFromElement = function(elm) {
        var allNodes = document.getElementsByTagName('*');
        for (var segs = []; elm && elm.nodeType == 1; elm = elm.parentNode)
        {
            if (elm.hasAttribute('id')) {
                    var uniqueIdCount = 0;
                    for (var n=0;n < allNodes.length;n++) {
                        if (allNodes[n].hasAttribute('id') && allNodes[n].id == elm.id) uniqueIdCount++;
                        if (uniqueIdCount > 1) break;
                    }
                    if ( uniqueIdCount == 1) {
                        segs.unshift('id("' + elm.getAttribute('id') + '")');
                        return segs.join('/');
                    } else {
                        segs.unshift(elm.localName.toLowerCase() + '[@id="' + elm.getAttribute('id') + '"]');
                    }
            } else if (elm.hasAttribute('class')) {
                segs.unshift(elm.localName.toLowerCase() + '[@class="' + elm.getAttribute('class') + '"]');
            } else {
                for (var i = 1, sib = elm.previousSibling; sib; sib = sib.previousSibling) {
                    if (sib.localName == elm.localName)  i++; }
                    segs.unshift(elm.localName.toLowerCase() + '[' + i + ']');
            }
        }
        return segs.length ? '/' + segs.join('/') : null;
    };

    // Datem zum Portal senden
    var _send = function(data) {
        if (!data) return false;

        var img = new Image(1, 1),
        url = "http://192.168.59.103:7623/collect?event=",
        sendObj = {
            data: data,
            _: _genRandStr(5)
        };

        img.src = url + JSON.stringify(sendObj);

        return sendObj;
    };

    // proxy fuer debouncing positions
    var _proxy = _debounce(function(e) {
        __mt.event.apply(this, [e]);
    }, 250);

    // event listener fuer Mausevents
    var event = function(e) {
        if (!e) return false;

        var coords = _getRelMouseCoords(e);
        console.log('[mt][event] ' + e.type + ' at ' + coords.x + ',' + coords.y);

        var target = e.target || e.srcElement;
        return _send({
            coordinates: coords,
            resolution: _res,
            session_id: _sessId,
            referrer_url: _ref,
            page_url: window.location.href,
            element: {
                tagName: target.tagName,
                text: target.innerText,
                id: target.id,
                classes: target.className,
                path: _createXPathFromElement(target)
            },
            type: e.type
        });
    };

    // Tracking initialisieren
    var init = function() {

        if (typeof window.__mtCallback === "function") {
            window.__mtCallback();
        }
        // Session-ID generieren
        _sessId = _genRandStr(10);
        // Aufloesung ermittlen
        _res = _getResolution();

        // Event Listener erstellen
        _addEventListener(window, 'click', __mt.event);
        _addEventListener(window, 'mousemove', _proxy);

        _addEventListener(window, 'resize', _setResolution);

        _addEventListener(window, 'message', _getDocHeight, false);

        return true;
    };

    var destroy = function() {
        // Event Listener entfernen
        _removeEventListener(window, 'click', __mt.event);
        _removeEventListener(window, 'mousemove', _proxy);

        _removeEventListener(window, 'resize', _setResolution);

        _removeEventListener(window, 'message', _getDocHeight);
    };

    // Oeffentliche Funktione zurueckliefern
    return {
        event: event,
        init: init,
        destroy: destroy
    };

})(this, document);

// Tracking initialiseren
try {
    __mt.init();
} catch (e) {}
