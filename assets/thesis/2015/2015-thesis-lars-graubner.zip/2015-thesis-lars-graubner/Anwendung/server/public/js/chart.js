var Chart = (function(window, document, jQuery, undefined) {
    'use strict';

    var _chart;

    // Daten vom Server laden und Diagramm aktualisieren
    var update = function() {
        // URL generieren
        var url = Portal.generateURL("history").replace("mousemove", "click");
        // jQuery promise zureuckliefern
        return $.getJSON(url, function(timestamps) {
            _chart.load({
                json: timestamps.data,
                keys: {
                    x: "_id",
                    value: ["value"]
                },
                axis: {
                    min: {
                        y: 0
                    }
                }
            });
        });
    };

    // Diagramme initialisieren
    var init = function() {
        if ($("#chart").length > 0) {
            // Diagramm generieren
            _chart = c3.generate({
                bindto: '#chart',
                data: {
                    json: [],
                    keys: {
                        x: "_id",
                        value: ["value"]
                    },
                    names: {
                        value: "Klicks"
                    }
                },
                axis: {
                    x: {
                        type: 'timeseries',
                        tick: {
                            format: "%d.%m.%Y"
                        }
                    },
                    min: {
                        y: 0
                    }
                }
            });

            // Daten laden
            update();
        }
    };

    // Oeffentliche Methoden zureuckliefern
    return {
        init: init,
        update: update
    };

})(this, document, jQuery);
