var GUI = (function(window, document, $, undefined) {
    'use strict';

    var _config = {},
        _params = {};

        // Datepicker initialisieren
    var _initDatepickers = function() {
        $.datepicker.setDefaults({
            dateFormat: "dd.mm.y",
            altFormat: "yy-mm-dd",
            minDate: new Date(_config.startDate),
            maxDate: 0,
            firstDay: 1
        });

        // Datepicker lokalisieren
        $.datepicker.setDefaults($.datepicker.regional["de"]);

        $("#start-input").datepicker({
            altField: "#start",
            onSelect: function() {
                $('#start').change();
            }
        });

        $("#start-input").datepicker("setDate", new Date(_config.startDate));

        $("#end-input").datepicker({
            altField: "#end",
            onSelect: function() {
                $('#end').change();
            }
        });

        $("#end-input").datepicker("setDate", new Date());
    };

    // Ripple-Link Effekt
    var _rippleEffect = function() {
        // Source: http://codepen.io/440design/pen/iEztk
        var ink, d, x, y;
        $(".ripplelink").click(function(e){
            if($(this).find(".ink").length === 0){
                $(this).prepend("<span class='ink'></span>");
            }

            ink = $(this).find(".ink");
            ink.removeClass("animate");

            if(!ink.height() && !ink.width()){
                d = Math.max($(this).outerWidth(), $(this).outerHeight());
                ink.css({height: d, width: d});
            }

            x = e.pageX - $(this).offset().left - ink.width()/2;
            y = e.pageY - $(this).offset().top - ink.height()/2;

            ink.css({top: y+'px', left: x+'px'}).addClass("animate");
        });
    };

    // Daten vom Server laden und GUI aktualisieren
    var update = function() {
        // jQuery promise zurueckliefern
        return $.getJSON(Portal.getBaseURL() + "count?page_url=" + _params.page_url + "&device=" + _params.device, function(count) {
            $('.big-num strong').text(count.data);
        });
    };

    // Methode um Ladeanimation ein-/auszublenden
    var loader = function(method) {
        var $loader = $('#loader');

        if (method) {
            switch (method) {
                case "show":
                    $loader.fadeIn(200);
                    break;
                case "hide":
                    $loader.fadeOut(200);
                    break;
            }
        } else {
            $loader.fadeToggle(200);
        }

    };

    // GUI initialisieren
    var init = function() {
        _config = Portal.getConfig();
        _params = Portal.getParams();

        // Parameter aktualisieren und Visualisierungen anpassen, wenn Bedienelemente betaetigt
        $('.param').change(function() {
            var $el = $(this),
                key = $el.attr('data-param');
            _params[key] = $el.val();

            Portal.refresh();
        });

        // Buttons fuer Endgeraet-Auswahl
        $("button.param").click(function() {
            if (Portal.isloading || $(this).hasClass('active')) return false;
            var $el = $(this),
                key = $el.attr('data-param');
            _params[key] = $el.attr('data-param-value');

            $("button.param").removeClass('active');
            $el.addClass('active');

            GUI.update();
            Chart.update();

            Heatmap.remove();
            Heatmap.create(".heatmap-wrapper");
            Heatmap.update();
        });

        // Tracking-Code automatisch auswaehlen
        // Quelle: http://stackoverflow.com/a/5797700/2536697
        $("textarea").focus(function() {
            var $el = $(this);
            $el.select();

            $el.mouseup(function() {
                $el.unbind("mouseup");
                return false;
            });
        });

        // Refresh-Button
        $('#refresh').click(function() {
            Portal.refresh();
        });

        // Tooltips initialisieren
        $('[data-toggle="tooltip"]').tooltip();

        _initDatepickers();
        _rippleEffect();
    };

    // Oeffentliche Methoden zurueckliefern
    return {
        loader: loader,
        update: update,
        init: init
    };

})(this, document, jQuery);
