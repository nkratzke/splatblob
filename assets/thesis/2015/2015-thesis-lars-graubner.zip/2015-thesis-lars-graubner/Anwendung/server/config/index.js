// Konfiguration
module.exports = {
    // Server
    server: {
        port: 7623
    },
    // MongoDB
    mongodb: {
        host: "192.168.59.103",
        port: 27017,
        database: "mt"
    },
    // Endgeraete Breakpoints
    devices: {
        desktop: 1024,
        tablet: 960,
        mobile: 768
    },
    // Cluster
    cluster: false
};
