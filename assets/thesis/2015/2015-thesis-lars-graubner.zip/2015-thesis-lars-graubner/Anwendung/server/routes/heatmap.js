module.exports = function(app) {
    var path = require('path'),
        childProcess = require('child_process'),
        phantomjs = require('phantomjs'),
        binPath = phantomjs.path,
        utils = require('../utils.js'),
        _ = require('lodash'),
        Event = require('../models/Event.js'),
        moment = require('moment'),
        devices = require('../config').devices;

    app.get('/api/heatmap', function(req, res) {
        var query = req.query,
            pretty = false,
            filter = {},
            key,
            fields,
            sort,
            start,
            end,
            windowWidth = 1024,
            windowHeight = 700;

        // Query durchlaufen
        for (key in query) {
            switch (key) {
                // Sortierung
                case "sort":
                    sort = query.sort;
                    break;
                // verschoenerte Ausgabe
                case "pretty":
                    pretty = query.pretty;
                    break;
                // Startdatum
                case "start":
                    start = utils.parseDate(query.start);
                    break;
                // Enddatum
                case "end":
                    end = utils.parseDate(query.end);
                    break;
                // Endgeraet
                case "device":
                    windowWidth = devices[query.device];

                    switch (query.device) {
                        case "desktop":
                            filter.$where = "this.resolution.w >= " + devices.desktop;
                            break;
                        case "tablet":
                            filter.$where = "this.resolution.w < " + devices.desktop + " && this.resolution.w >= " + devices.tablet;
                            break;
                        case "mobile":
                            filter.$where = "this.resolution.w <= " + devices.mobile;
                            break;
                    }
                    break;
                // Hoehe
                case "height":
                    windowHeight = query.height;
                    break;
                // Referrer
                case "referrer":
                    switch (query[key]) {
                        case "direkt":
                            filter[key] = null;
                            break;
                        case "alle":

                            break;
                    }
                    break;
                // Sonstige Filter
                default:
                    if (query.hasOwnProperty(key) && key in Event.schema.paths) {
                        filter[key] = query[key];
                    }
            }
        }

        // Ergebnisse filtern
        var event = Event.find(filter);

        // nach Startdatum filtenr
        if (start) {
            event.find({
                timestamp: {
                    $gt: start
                }
            });
        }

        // nach Enddatum filtern
        if (end) {
            var d = moment(end).add(1, 'days').format("YYYY-MM-DD");
            event.find({
                timestamp: {
                    $lt: d
                }
            });
        }

        // ausfuehren
        event.select(fields).sort(sort).exec(function(err, clicks) {
            if (err) {
                // Fehler mit Status 500 zurueckliefern
                res.status(500).write(utils.formatJSONStr({
                    status: "error",
                    message: err
                }, pretty));
            } else {

                var childArgs = [
                    path.join(__dirname, '../phantom-calculate.js'),
                    "http://" + filter.page_url,
                    JSON.stringify(clicks),
                    windowWidth,
                    windowHeight
                ];

                // Koordinaten mit PhantomJS berechnen
                var child = childProcess.execFile(binPath, childArgs, function(err, stdout, stderr) {

                    if (err) {
                        res.status(500).write(utils.formatJSONStr({
                            status: "error",
                            message: err
                        }, pretty));
                    } else {
                        var max = 0,
                            data = JSON.parse(stdout);
                        // maximale Anzahl Datenpunkte ermitteln
                        _.forEach(data, function(n, key) {
                            max = Math.max(max, n.value);
                        });

                        // Dateum zurueckliefern
                        res.write(utils.formatJSONStr({
                            status: "ok",
                            data: data,
                            max: max
                        }, pretty));
                    }

                    // Anfrage beenden
                    res.end();
                });
            }
        });

    });
};
