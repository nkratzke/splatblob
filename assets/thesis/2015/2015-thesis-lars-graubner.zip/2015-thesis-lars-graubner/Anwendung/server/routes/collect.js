module.exports = function(app) {
    var useragent = require('useragent'),
        path = require('path'),
        _ = require('lodash'),
        Event = require('../models/Event.js'),
        url = require('url');

    app.get('/collect', function(req, res) {
        var event, model, ua, data, site;
        try {
            // gesendete Daten als JSON parsen
            event = JSON.parse(req.query.event);
        } catch (e) {}

        // Pruefen, ob valides JSON gesendet wurde
        if (typeof event === "object") {
            // lookup fuer bessere Performance (https://www.npmjs.com/package/useragent)
            ua = useragent.lookup(req.headers['user-agent']);
            site = url.parse(event.data.page_url, true);

            // Client + Server Daten zusammenfuehren
            data = _.merge(event.data, {
                user_agent: req.headers['user-agent'],
                parsed_user_agent: ua.toJSON(),
                page_url: site.host + site.pathname,
                parsed_page_url: {
                    protocol: site.protocol,
                    host: site.host,
                    path: site.pathname,
                    query: site.query,
                    hash: site.hash
                }
            });

            // neues Event-Objekt erstellen
            model = new Event(data);
            // in der Datenbank speichern
            model.save(function(err) {
                if (err) {
                    // Fehler in der Konsole ausgeben
                    console.log(err);
                }
            });

            console.log(data);
        }

        // HTTP Status 200 und Bild zurueckgeben
        res.status(200).sendFile(path.join(__dirname, '../collect.gif'));
    });
};
