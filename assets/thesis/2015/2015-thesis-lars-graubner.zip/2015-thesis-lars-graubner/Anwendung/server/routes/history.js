module.exports = function(app) {
    var path = require('path'),
        utils = require('../utils.js'),
        Event = require('../models/Event.js'),
        devices = require('../config').devices;

    app.get('/api/history', function(req, res) {
        var query = req.query,
            fields = "-_id",
            sort = "",
            pretty = false,
            filter = {},
            key,
            distinct,
            start,
            end;

        for (key in query) {
            switch (key) {
                case "sort":
                    sort = query.sort;
                    break;
                case "pretty":
                    pretty = query.pretty;
                    break;
                case "start":
                    start = utils.parseDate(query.start);
                    break;
                case "end":
                    end = utils.parseDate(query.end);
                    break;
                case "device":
                    windowWidth = devices[query.device];

                    switch (query.device) {
                        case "desktop":
                            filter["resolution.w"] = {
                                "$gte": devices.desktop
                            };
                            break;
                        case "tablet":
                            filter["$and"] = [
                                {
                                    "resolution.w": {
                                        "$lt": devices.desktop
                                    }
                                },
                                {
                                    "resolution.w": {
                                        "$gte": devices.tablet
                                    }
                                }
                            ];
                            break;
                        case "mobile":
                            filter["resolution.w"] = {
                                "$lte": devices.mobile
                            };
                            break;
                    }
                    break;
                case "height":
                    windowHeight = query.height;
                    break;
                case "referrer":
                    switch (query[key]) {
                        case "direkt":
                            filter[key] = null;
                            break;
                        case "alle":

                            break;
                    }
                    break;
                default:
                    if (query.hasOwnProperty(key) && key in Event.schema.paths) {
                        filter[key] = query[key];
                    }
            }
        }

        // Aggregation
        var aggr = Event.aggregate();
        // Ergbenisse filtenr
        aggr.match(filter);

        // nach Startdatum filtern
        if (start) {
            aggr.match({
                timestamp: {
                    $gt: start
                }
            });
        }

        // nach Enddatum filtern
        if (end) {
            aggr.match({
                timestamp: {
                    $lt: end
                }
            });
        }

        // Ausgabe formatieren
        aggr.project({
            timestamp: {
                $dateToString: {
                    format: "%Y-%m-%d",
                    date: "$timestamp"
                }
            },

        });

        aggr.group({
            _id: "$timestamp",
            value: {
                $sum: 1
            }
        });

        // ausfuehren
        aggr.exec(function(err, results) {
            if (err) {
                res.status(500).write(utils.formatJSONStr({
                    status: "error",
                    message: err
                }, pretty));
            } else {
                res.write(utils.formatJSONStr({
                    status: "ok",
                    data: results
                }, pretty));
            }

            // Anfrage beenden
            res.end();
        });

    });
};
