module.exports = function(app) {
    var utils = require('../utils.js'),
        Event = require('../models/Event.js'),
        devices = require('../config').devices;

    app.get("/api/count", function(req, res) {

        var query = req.query,
            where;

        // Daten nach Endgeraet filtern
        switch (query.device) {
            case "tablet":
                where = "this.resolution.w < " + devices.desktop + " && this.resolution.w >= " + devices.tablet;
                break;
            case "mobile":
                where = "this.resolution.w <= " + devices.mobile;
                break;
            default:
                where = "this.resolution.w >= " + devices.desktop;
        }

        // Klicks zaehlen
        var count = Event.count({ type: "click", page_url: query.page_url, $where: where }, function(err, count) {
            if (err) throw err;

            // Daten zuerueckliefern
            res.write(utils.formatJSONStr({
                status: "ok",
                data: count
            }, query.pretty));

            res.end();
        });
    });

};
