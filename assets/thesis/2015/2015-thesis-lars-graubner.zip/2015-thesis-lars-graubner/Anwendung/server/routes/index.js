var fs = require("fs"),
    path = require("path");

module.exports = function(app) {
    // Alle Routen im Verzeichnis automatisch auslesen
    fs.readdirSync(path.join(__dirname, '/')).forEach(function(file) {
        if(file.match(/.+\.js/g) !== null && file != 'index.js' && file.charAt(0) != "_") {
            require(path.join(__dirname, file))(app);
        }
    });
};
