var path = require("path"),
    _ = require("lodash"),
    mongoose = require("mongoose"),
    Event = require("../models/Event.js"),
    utils = require("../utils.js"),
    moment = require("moment"),
    Promise = require("promise"),
    devices = require("../config").devices;

module.exports = function(app) {
    // dynamisches Query-Fragment "url"
    app.get('/site/:url', function(req, res) {

        // Alle Seiten auslesen
        var sites = new Promise(function(resolve, reject) {
            Event.distinct('page_url').exec(function(err, urls) {
                if (err) reject(err);

                var sts = {};
                // URLs verschoenern
                _.forEachRight(urls, function(value, key) {
                    sts["http://192.168.59.103:7623/site/" + encodeURIComponent(value)] = utils.beautifyURL(value);
                });

                resolve(sts);
            });
        });

        // Alle referrer auslesen
        var referrer = new Promise(function(resolve, reject) {
            Event.distinct('referrer_url', { page_url: req.params.page_url}).exec(function(err, ref) {
                if (err) reject(err);

                var refs = {};

                if (typeof ref !== null) {
                    _.forEach(ref, function(value, key) {
                        if (value !== null) {
                            refs[value] = utils.beautifyURL(value);
                        }
                    });
                }

                resolve(refs);
            });
        });

        // Startdatum mittels erstem Datensatz ermitteln
        var startdate = new Promise(function(resolve, reject) {
            Event.findOne({ page_url: req.params.url }).select("-_id timestamp").sort('+timestamp').exec(function(err, event) {
                if (err) throw err;

                if (event === null) {
                    reject("Not found");
                }

                resolve(event);
            });
        });

        // Anzahl Klicks auslesen
        var clickCount = new Promise(function(resolve, reject) {
            Event.count({ type: "click", page_url: req.params.url, $where: "this.resolution.w >= " + devices.desktop }, function(err, count) {
                if (err) throw err;

                resolve(count);
            });
        });

        // Promises aufloesen
        Promise.all([sites, referrer, startdate, clickCount]).then(function(promise) {
            // Jade-Template kompilieren
            res.render('site', {
                current: req.params.url,
                sites: promise[0],
                referrer: promise[1],
                startDate: moment(promise[2].timestamp).format("YYYY-MM-DD"),
                clickCount: promise[3]
            });
        }, function(err) {

            if (err === "Not found") {
                res.sendStatus(404);
            }

            res.sendStatus(500);
        });

    });
};
