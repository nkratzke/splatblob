var _ = require("lodash"),
    Event = require("../models/Event.js"),
    utils = require("../utils.js");

module.exports = function(app) {
    app.get('/', function(req, res) {
        var sites;

        // Alle URL Vorkommen aus der Datenbank auslesen
        Event.distinct('page_url').exec(function(err, urls) {

            var sites = {};
            // verschoenerte URL Version generieren
            _.forEachRight(urls, function(value, key) {
                sites["http://192.168.59.103:7623/site/" + encodeURIComponent(value)] = utils.beautifyURL(value);
            });

            // Jade-Template komilieren
            res.render('index', {
                sites: sites
            });
        });
    });
};
