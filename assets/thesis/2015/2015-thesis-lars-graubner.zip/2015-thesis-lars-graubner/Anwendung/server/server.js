var express = require('express'),
	path = require('path'),
	serveStatic = require('serve-static'),
	fs = require("fs"),
	mongoose = require('mongoose'),
	bodyparser = require('body-parser'),
	compression = require('compression'),
	cluster = require('cluster'),
	_ = require('lodash'),
	errorhandler = require('errorhandler');

// Konfiguration laden
var config = require(path.join(__dirname, 'config'));

// pruefen ob cluster aktiviert und Master-Prozess aktiv ist
if (config.cluster && cluster.isMaster) {
	// Anzahl CPU-Kerne
	var cpuCount = require('os').cpus().length,
		i;

		// Worker starten
	for (i = 0; i < cpuCount; i++) {
		cluster.fork();
	}

	console.log('Tracking server started, using ' + _.size(cluster.workers) + ' workers.');

	// Worker neu starten, wenn abgestuerzt
	cluster.on('exit', function(worker) {
		console.log('Worker #' + worker.id + ' crashed. Restarting...');
		cluster.fork();
	});

} else {
	// Express initialisieren
	var app = exports.app = express();

	// Server Port setzen
	app.set('port', config.server.port);
	// Error handler setzen
	if (app.get('env') === 'development' || app.get('env') === 'test') {
		app.use(errorhandler());
	}
	// View Engine setzen
	app.set('view engine', 'jade');
	app.set('views', path.join(__dirname, 'views'));
	// Statische Dateiausgabe aktivieren
	app.use(serveStatic(path.join(__dirname, 'public')));

	// Bodyparser, JSON und Kompression aktivieren
	app.use(bodyparser.urlencoded({ extended: true }));
	app.use(bodyparser.json());
	app.use(compression());

	app.use(function(err, req, res, next){
		console.error(err.stack);
		res.status(500).send('Something broke!');
	});

	// Speziellen File-Type fuer API Antworten setzen
	app.use(function(req, res, next) {
		if (/api/.test(req.url)) {
			res.type('application/vnd.mt+json; version=1.0');
		}
		next();
	});

	// Mit MongoDB verbinden
	mongoose.connect('mongodb://' + config.mongodb.host + '/' + config.mongodb.database, function(err) {
		if (err) {
			console.log(err);
			console.log('Connection to MongoDB failed!');
		} else {
			if (!config.cluster && app.get('env') !== 'test') console.log('Connected to mongodb://' + config.mongodb.host + '/' + config.mongodb.database + "!");

			// Alle Routen laden
			require(path.join(__dirname, 'routes'))(app);

			// Server starten
			app.listen(app.get('port'), function() {
				if (!config.cluster && app.get('env') !== 'test') console.log('Tracking server is listening on port ' + app.get('port') + '...');
			});
		}
	});
}
