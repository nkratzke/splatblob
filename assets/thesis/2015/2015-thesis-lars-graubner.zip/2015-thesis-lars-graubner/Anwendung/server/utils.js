module.exports = {
    // JSON String mit Einrueckung und Zeilenumbruechen verschoenern
    formatJSONStr: function(obj, enabled) {
        if (enabled == true) {
            return JSON.stringify(obj, null, 4);
        }

        return JSON.stringify(obj);
    },

    // Date String parsen
    parseDate: function(str) {
        var parts = str.split('-');

        try {
            return new Date(parts[0], parts[1]-1, parts[2]);
        } catch (e) {}
    },

    // URL verschoenern durch entfernen des Protokolls und www
    beautifyURL: function(str) {
        var ret = str.replace('http://', '').replace('https://', '').replace('www.', ''),
            strlen = ret.length-1;

        if (ret.indexOf('/') == strlen) {
            ret = ret.substr(0, strlen);
        }

        return ret;
    }
};
