var express = require('express'),
path = require('path'),
http = require('http'),
serveStatic = require('serve-static'),
fs = require("fs");

var app = express();

app.set('port', 7000);
app.use(serveStatic(path.join(__dirname, 'public')));

app.server = http.createServer(app).listen(app.get('port'), function() {
    console.log('Testclient server listening on port ' + app.get('port') + '...');
});
