var assert = require("chai").assert,
    webdriver = require('selenium-webdriver'),
    test = require('selenium-webdriver/testing'),
    By = require('selenium-webdriver').By,
    driver;

// Client
test.describe('Client', function(done) {
    this.timeout(20000);

    test.before(function(done) {
        driver = new webdriver.Builder().usingServer().withCapabilities({ 'driverName': 'chrome', 'browserName': 'chromium' }).forBrowser('chrome').build();
        var handle = driver.getWindowHandle();
        done();
    });

    test.after(function(done) {
        driver.quit();
        done();
    });

    test.it("adds tracking script to dom", function(done) {
        driver.get("http://192.168.59.103:7000/").then(function() {
            driver.isElementPresent(By.css('script[src="//192.168.59.103:7623/mt.js"]')).then(function(el) {
                assert.ok(el);
                done();
            });
        });
    });
});
