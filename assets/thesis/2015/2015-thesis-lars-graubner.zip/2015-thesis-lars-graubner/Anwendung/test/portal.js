var assert = require("chai").assert,
    webdriver = require('selenium-webdriver'),
    test = require('selenium-webdriver/testing'),
    By = require('selenium-webdriver').By,
    until = require('selenium-webdriver').until,
    driver,
    url = "http://192.168.59.103:7623/";

// Portal
test.describe("Portal", function(done) {
    this.timeout(30000);

    test.before(function(done) {
        driver = new webdriver.Builder().usingServer().withCapabilities({ 'driverName': 'chrome', 'browserName': 'chromium' }).forBrowser('chrome').build();
        var handle = driver.getWindowHandle();
        done();
    });

    test.after(function(done) {
        driver.quit();
        done();
    });

    test.it("shows loading animation", function(done) {
        driver.get("http://192.168.59.103:7623/site/192.168.59.103%3A7000%2F").then(function() {
            driver.wait(function() {
                return driver.findElement(By.id("loader"));
            }, 1000).then(function(el) {
                return el.isDisplayed();
            }).then(function(visible) {
                assert.ok(visible);
                done();
            });
        });
    });

    test.it("displays datepicker", function(done) {
        driver.get("http://192.168.59.103:7623/site/192.168.59.103%3A7000%2F").then(function() {
            driver.findElement(By.id("start-input")).then(function(el) {
                el.click();
            }).then(function() {
                return driver.findElement(By.id("ui-datepicker-div"));
            }).then(function(el) {
                return el.isDisplayed();
            }).then(function(visible) {
                assert.ok(visible);
                done();
            });
        });
    });

    test.it("changes tab content", function(done) {
        driver.get(url).then(function() {
            driver.findElement(By.css(".tab-control li:nth-child(2) a")).then(function(el) {
                el.click();
            }).then(function() {
                return driver.findElement(By.id("code"));
            }).then(function(el) {
                return el.isDisplayed();
            }).then(function(visible) {
                assert.ok(visible);
                done();
            });
        });
    });

    test.it("changes site on page element click", function(done) {
        driver.get(url).then(function() {
            driver.findElement(By.css(".site:first-child a")).then(function(el) {
                el.click();
            }).then(function() {
                return driver.getCurrentUrl();
            }).then(function(target) {
                assert.notEqual(target, url);
                done();
            });
        });
    });

    test.it("updates heatmap accordingly", function(done) {
        driver.get("http://192.168.59.103:7623/site/192.168.59.103%3A7000%2F").then(function() {
            driver.findElement(By.id("buttonTablet")).then(function(el) {
                el.click();
            }).then(function() {
                driver.wait(function() {
                    return driver.findElement(By.css("#heatmap canvas"));
                }, 2000).then(function(el) {
                    return el.isDisplayed();
                }).then(function(visible) {
                    assert.ok(visible);
                    done();
                });
            });
        });
    });
});
