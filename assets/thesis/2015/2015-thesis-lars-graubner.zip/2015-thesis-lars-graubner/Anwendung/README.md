BA: Analyse von Mausdaten
=================

## Docker Images erstellen ##

```SHELL
docker build -t mousetracking/server PATHTOFILES
docker build -t mousetracking/database PATHTOFILES
docker build -t mousetracking/client PATHTOFILES
```

## Docker Images starten ##

```SHELL
docker run -p 27017:27017 mousetracking/database --smallfiles --noprealloc
docker run -itp 7623:7623 mousetracking/server start
docker run -itp 7000:7000 mousetracking/client start
```

## Server Tests starten ##

```SHELL
docker run mousetracking/server test
```

## Client Tests starten ##

### Unittests ###

Server starten und lokal folgenden Befehl ausführen.

```SHELL
npm install
npm run test_client
```

### Systemtests ###

```SHELL
npm test
```

## Anwendung öffnen ##

Portal:

http://192.168.59.103:7623/

Testclient:

http://192.168.59.103:7000/
