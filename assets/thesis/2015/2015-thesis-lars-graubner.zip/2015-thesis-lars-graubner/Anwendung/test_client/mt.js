// Tracking-Script
describe("__mt", function() {
    beforeEach(function(done) {
        window.__mtCallback = function() {
            done();
        };

        (function(d, s, u) {
            t = d.createElement(s), f = d.getElementsByTagName(s)[0];
            t.async = 1; t.src = u; f.parentNode.insertBefore(t, f);
        })(document, 'script', 'http://192.168.59.103:7623/mt.js');
    });

    afterEach(function() {
        __mt.destroy();
        $('script').first().remove();
    });

    describe("Object", function() {
        it("tracking script is a global object", function() {
            assert.strictEqual(typeof __mt, "object");
        });
    });

    describe("#init()", function() {
        it("is a function", function() {
            assert.isFunction(__mt.init);
        });

        it("tracking script gets successfully initialized", function() {
            window.__mtCallback = undefined;
            __mt.destroy();
            assert.ok(__mt.init());
        });
    });

    describe("#event()", function() {
        it("is a function", function() {
            assert.isFunction(__mt.event);
        });

        it("function call without arguments returns false", function() {
            assert.strictEqual(__mt.event(), false);
        });

        /*var el = document.createElement('div'),
            event = new Event('click', {
                'view': window,
                'bubbles': true,
                'cancable': true,
                'clientX': 1,
                'clientY': 1,
                'pageX': 1,
                'pageY': 1
            });

        var sent = window.__mt.event(ev);

        it("function call with event argument returns object", function() {
            assert.strictEqual(typeof sent, "object");
        });

        it('sent data contains valid "x" value', function() {
            assert.ok(/^\d+$/.test(sent.data.coordinates.x));
        });

        it('sent data contains valid "y" value', function() {
            assert.ok(/^\d+$/.test(sent.data.coordinates.y));
        });

        it("sent data contains valid browser resolution width", function() {
            assert.ok(/^\d+$/.test(sent.data.resolution.w));
        });

        it("sent data contains valid browser resolution height", function() {
            assert.ok(/^\d+$/.test(sent.data.resolution.h));
        });

        it("sent data contains session id", function() {
            assert.notEqual(sent.data.session_id.length, 0);
        });

        it("sent data contains unique random string (cache busting)", function() {
            var event1 = __mt.event(event);
            var event2 = __mt.event(event);
            assert.notEqual(event1._, event2._);
        });*/
    });

    describe("#destroy()", function() {
        it("is a function", function() {
            assert.isFunction(__mt.destroy);
        });
    });
});
