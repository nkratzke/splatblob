// Diagramme
describe("Chart", function() {
    describe("#init()", function() {
        it("is a function", function() {
            assert.isFunction(Chart.init);
        });
    });

    describe("#update()", function() {
        it("is a function", function() {
            assert.isFunction(Chart.update);
        });

        it("returns a jQuery promise", function() {
            var promise = Chart.update();
            assert.isFunction(promise.then);
        });
    });
});
