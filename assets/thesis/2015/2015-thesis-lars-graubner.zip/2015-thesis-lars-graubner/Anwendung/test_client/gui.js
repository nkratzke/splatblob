// GUI
describe("GUI", function() {
    describe("#init()", function() {
        it("is a function", function() {
            assert.isFunction(GUI.init);
        });
    });

    describe("#update()", function() {
        it("is a function", function() {
            assert.isFunction(GUI.update);
        });

        var promise = GUI.update();

        it("returns a jQuery promise", function() {
            assert.isFunction(promise.then);
        });

        it("retrieves data", function(done) {
            assert.isFunction(promise.then);
            done();
        });
    });

    describe("#loader()", function() {
        var $loader = $("<div />").attr("id", "loader").css({
            display: "none"
        });

        before(function() {
            $('body').append($loader);
        });

        it("is a function", function() {
            assert.isFunction(GUI.loader);
        });

        it("shows the loader", function(done) {
            GUI.loader("show");
            setTimeout(function() {
                assert.equal($loader.css("display"), "block");
                done();
            }, 400);

        });

        it("hides the loader", function(done) {
            GUI.loader("hide");
            setTimeout(function() {
                assert.equal($loader.css("display"), "none");
                done();
            }, 400);
        });

        after(function() {
            $loader.remove();
        });
    });
});
