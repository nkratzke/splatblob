// Heatmaps
describe("Heatmap", function() {
    describe("#init()", function() {
        it("is a function", function() {
            assert.isFunction(Heatmap.init);
        });
    });

    describe("#update()", function() {
        it("is a function", function() {
            assert.isFunction(Heatmap.update);
        });

        it("returns a jQuery promise", function() {

            var promise = Heatmap.update();
            assert.isFunction(promise.then);
        });
    });

    describe("#create()", function() {
        it("is a function", function() {
            assert.isFunction(Heatmap.create);
        });
    });

    describe("#remove()", function() {
        it("is a function", function() {
            assert.isFunction(Heatmap.remove);
        });
    });
});
