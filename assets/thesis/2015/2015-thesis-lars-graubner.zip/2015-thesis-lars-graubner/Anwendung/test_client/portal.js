// Portal
describe("Portal", function() {
    describe("#getBaseURL()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.getBaseURL);
        });

        it("returns a string", function() {
            assert.strictEqual(typeof Portal.getBaseURL(), "string");
        });

        it("returns a valid URL", function() {
            assert.ok(/^http:\/\/|^https:\/\//.test(Portal.getBaseURL()), "string");
        });
    });

    describe("#getConfig()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.getConfig);
        });

        it("returns an object", function() {
            assert.strictEqual(typeof Portal.getConfig(), "object");
        });
    });

    describe("#setConfig()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.setConfig);
        });

        it("adds elements to config object", function() {
            Portal.setConfig({ param: "val" });

            var changed = Portal.setConfig({ param: "test"});

            assert.propertyNotVal(changed, 'param', "val");
        });
    });

    describe("#getParams()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.getParams);
        });

        it("returns an object", function() {
            assert.strictEqual(typeof Portal.getParams(), "object");
        });
    });

    describe("#setParams()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.setParams);
        });

        it("adds elements to params object", function() {
            Portal.setParams({ param: "val"});
            var changed = Portal.setParams({ param: "test"});

            assert.propertyNotVal(changed, "param", "val");
        });
    });

    describe("#generateURL()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.generateURL);
        });

        it("returns a string", function() {
            assert.strictEqual(typeof Portal.generateURL(), "string");
        });

        it("returns a valid URL", function() {
            assert.ok(/^http:\/\/|^https:\/\//.test(Portal.generateURL()));
        });
    });

    describe("#init()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.init);
        });
    });

    describe("#refresh()", function() {
        it("is a function", function() {
            assert.isFunction(Portal.refresh);
        });
    });

    describe("#isloading", function() {
        it("is a Boolean", function() {
            assert.isBoolean(Portal.isloading);
        });
    });
});
