#!/bin/bash
cont=$(docker ps -a -q);
if [ -n "$cont" ]
    then
        echo "Removing docker containers...";
        docker rm $(docker ps -a -q);
        echo "Done!";
fi
