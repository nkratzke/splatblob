#!/bin/bash
cont=$(docker ps -a -q);
if [ -n "$cont" ]
    then
        echo "Stopping docker containers...";
        docker stop $(docker ps -a -q);
        echo "Done!";
fi
