#!/bin/bash
cont=$(docker images -q);
if [ -n "$cont" ]
    then
        echo "Removing docker images...";
        docker rmi $(docker images -q);
        echo "Done!";
fi
