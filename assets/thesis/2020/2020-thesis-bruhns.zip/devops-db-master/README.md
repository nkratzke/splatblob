# Automatisierung von Datenbanken in DevOps-Szenarien

## Aufgabenstellung

Innerhalb von Continuous Integration und Delivery (CI/CD) Prozessen gibt es Integrationstests, die Datenbanken (DB) benötigen. Damit solche Tests automatisiert durchgeführt werden können, sind Schnittstellen zu DB-Management-Systemen (DBMS) erforderlich, um DBen

- dynamisch erzeugen,
- mit Testdaten befüllen
- und löschen zu können.

Damit diese Schnittstelle universell eingesetzt werden kann, ist zu untersuchen, ob diese mittels einem DBMS Controller (Server mit REST-basierter API) und Build-System-spezifischen Plugins (Client) konzipiert werden kann. Bei der Konzeption der REST-basierten API des DBMS Controllers und erforderlicher Plugins sind folgende Aspekte zu berücksichtigen:

- Unterschiedliche Datenbank-Systeme sind geeignet zu berücksichtigen (der Nachweis kann in der Arbeit anhand von zwei geeigneten Typvertretern erfolgen).
- Unterschiedliche Build-Systeme sind geeignet zu berücksichtigen (der Nachweis kann in der Arbeit anhand von zwei geeigneten Typvertretern erfolgen).
- DBen müssen angelegt und gelöscht werden können.
- DB-Zustände (Schema + Daten) müssen geeignet verglichen werden können.
- DB-Zustände (Schema + Daten) müssen verwaltet werden können (erzeugen, klonen, zurücksetzen, auflisten, löschen, etc.).

Das Problem soll anhand des Fallbeispiels von Jenkins-getriggerten Integrationstests in Continuous Delivery-Builds des Praxispartners AEB untersucht, analysiert und (prototypisch) gelöst werden.

## Hinweise

Neben den [Informationen des Fachbereichs](https://lernraum.th-luebeck.de/course/view.php?id=222#section-5)

- [Anleitung zum Erstellen einer Abschlussarbeit](https://lernraum.th-luebeck.de/pluginfile.php/54955/mod_resource/content/1/StudentischeArbeit_Vorlage.pdf)
- [Formulare und Merkblätter](https://lernraum.th-luebeck.de/mod/folder/view.php?id=41003)
- [Vorlagen für Abschlussarbeiten](https://lernraum.th-luebeck.de/mod/folder/view.php?id=41004)

finden Sie im Internet viele [weitere Informationen](https://www.scribbr.de/wissensdatenbank/) rund um eine Abschlussarbeit.

- [Wie schreibe ich eine Abschlussarbeit?](https://www.in.th-nuernberg.de/professors/Weber/Abschlussarbeit%20Methodik.pdf) (externer Link auf Hochschule Nürnberg)
- Hinweise zum [akademischen Schreiben](https://www.scribbr.de/category/akademisches-schreiben/)
- [Aufbau und Gliederung](https://www.scribbr.de/category/aufbau-und-gliederung/) sowie
- diverse [Beispiele](https://www.scribbr.de/category/beispiele/). 

Selber im Internet zu recherchieren lohnt aber sicher auch. Wie immer, ist Google vermutlich ein wertvolles Tool hierfür.

## Zeitplanung

- __Ihre Arbeit fängt nicht erst mit der offiziellen Anmeldung an.__ Davor gibt es viel zu tun. 
  Diese Zeit entscheidet meist bereits über Erfolg oder Misserfolg der Abschlussarbeit. 
  12 Wochen (bei einer Bachelorarbeit) sind nicht viel Zeit. Sie können nach hinten raus, kaum noch Anfangsversäumnisse einholen.

- __Passen Sie diesen Rahmenplan an Ihre Aufgabenstellung an.__
  Diese Planung ist natürlich sehr individuell. 
  Beachten Sie, dass Sie meist mehrere Aufgaben zeitgleich im Blick haben müssen.

- __Konkretisieren Sie diese Tabelle möglichst mit  konkreten Teilaufgaben.__
  Arbeiten Sie mit den konkreten Kalenderwochen (und nicht relativen wie in diesem Rahmenplan).
  Vergessen Sie nicht, Woche für Woche die Erledigungsspalte mit den aktuellen Erfüllungsgraden zu aktualisieren.
  So zwingen Sie sich einen "quantifizierbaren" Sachstand über Ihre Arbeit zu erheben und bestimmen wo Sie stehen.


| Aktivität                      | Erledigung | KW 11 | KW 12 | KW 13 | KW 14 | KW 15 | KW 16 | KW 17 | KW 18 | KW 19 | KW 20 | KW 21 | KW 22 | KW 23 | KW 24 | KW 25 | KW 26 | KW 27 | KW 28 | KW 29 | KW 30 | KW 31 | KW 32 | KW 33 | KW 34 | KW 35 |
|--------------------------------|-----------:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|:-----:|
| __AEB__                        |            |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |
| Beginn der Thesis              |      100%  |       |       |       |       |       |       |       |   x   |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |
| Ende der Thesis                |      100%  |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |       |       |
| __Formales__                   |            |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |
| Anmeldung                      |      100%  |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |       |       |       |       |       |       |       |       |       |
| Einholen eines Feedbacks       |      100%  |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |       |       |   x   |   x   |       |       |       |       |       |       |       |
| Korrektur lesen lassen         |      100%  |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |       |
| Abgabe (inkl. Druck der Thesis)|        0%  |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |
| Kolloquium                     |        0%  |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |   x   |
| __Problemlösung__              |            |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |
| (Literatur-) Recherche         |      100%  |   x   |   x   |   x   |   x   |   x   |       |       |       |       |   x   |   x   |       |   x   |       |       |       |       |       |       |       |       |       |       |       |       |
| Anforderungen ermitteln        |      100%  |       |       |       |       |       |       |   x   |   x   |   x   |       |       |       |       |       |       |       |       |   x   |       |       |       |       |       |       |       |
| Lösungskonzept (Architektur)   |      100%  |       |       |       |       |       |       |   x   |   x   |       |       |   x   |       |   x   |       |       |       |       |   x   |       |       |       |       |       |       |       |
| Nachweisstrategie              |      100%  |       |       |       |       |       |       |       |   x   |   x   |       |       |       |   x   |       |       |       |       |   x   |       |       |       |       |       |       |       |
| Implementierung                |      100%  |       |       |       |       |       |       |       |       |   x   |   x   |   x   |   x   |       |   x   |   x   |   x   |   x   |       |   x   |   x   |       |       |       |       |       |
| Nachweisführung                |      100%  |       |       |       |       |       |       |       |       |   x   |   x   |   x   |   x   |       |   x   |   x   |   x   |   x   |       |   x   |   x   |   x   |       |       |       |       |
| __Dokumentation__              |            |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |
| Dok.1: Einleitung              |      100%  |       |       |       |   x   |       |       |       |       |       |       |       |       |   x   |       |       |       |       |       |       |       |   x   |       |       |       |       |
| Dok.2: Grundlagen              |      100%  |       |       |   x   |   x   |   x   |   x   |   x   |   x   |       |   x   |       |       |   x   |       |       |       |       |   x   |       |       |       |       |       |       |       |
| Dok.3: Anforderungsanalyse     |      100%  |       |       |       |       |       |       |       |   x   |   x   |       |       |       |   x   |       |       |       |       |       |       |       |       |       |       |       |       |
| Dok.4: Architektur/Konzept     |      100%  |       |       |       |       |       |       |       |       |   x   |       |   x   |       |   x   |       |       |       |       |   x   |       |   x   |       |       |       |       |       |
| Dok.5: Implementierung         |      100%  |       |       |       |       |       |       |       |       |       |       |   x   |   x   |       |   x   |       |   x   |   x   |       |   x   |   x   |       |       |       |       |       |
| Dok.6: Nachweisführung         |      100%  |       |       |       |       |       |       |       |       |       |       |   x   |   x   |       |   x   |       |   x   |   x   |       |   x   |   x   |   x   |       |       |       |       |
| Dok.7: Fazit                   |      100%  |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |       |   x   |       |       |       |       |

## Dokumentation

Es gibt diverse Kombinationen von Textverarbeitungsprogrammen und [Literaturverwaltungen](https://de.wikipedia.org/wiki/Literaturverwaltungsprogramm).
Die Wahl einer Toolsuite ist jedoch meist eine hochindividuelle Angelegenheit. Bis auf Word sind dabei alle Tools der nachfolgenden Aufstellung für Studierende kostenfrei nutzbar.

Jede Kombination davon hat Ihre Stärken und Schwächen. Setzen Sie sich damit von Anfang an auseinander. Die folgende Aufstellung (weder bindend noch vollständig) ist nach Komfort absteigend sortiert (aufsteigend nach Kontrolle über den Output). Ich persönlich präferiere meist einen Mittelweg zwischen Komfort und Kontrolle und lande daher bei vielen Projekten oft bei den Kombinationen (3) oder (4).

1. Word + [Mendeley](https://www.mendeley.com/download-desktop/)          _(<- für den Komforttyp)_
2. [LibreOffice](https://de.libreoffice.org/) + [Mendeley](https://www.mendeley.com/download-desktop/)
3. [LyX](https://www.lyx.org/) + [Bibtex](https://de.wikipedia.org/wiki/BibTeX)
4. [Pandoc](https://pandoc.org/) + [Markdown](https://de.wikipedia.org/wiki/Markdown) + Bibtex _(wenn Sie diverse Output Formate generieren wollen)_
5. [Latex](https://www.latex-project.org/get/) + Bibtex           _(<- für alle, die vollkommene Kontrolle wollen, kann auch mit Pandoc kombiniert werden)_

Sie sollten bedenken, dass insbesondere eine Bachelorarbeit kurz ist und Sie nicht zu viel Zeit in das erlernen einer neuen Textverarbeitungstoolsuite investieren sollten. Haben Sie also wenig Vorerfahrung mit Latex oder ähnlichen Ansätzen ist vermutlich (1) oder (2) eine pragmatische Wahl.

Sichten Sie diese Möglichkeiten und entscheiden Sie sich frühzeitig für eine davon. Berücksichtigen Sie auch weitere Aspekte. Beherrschen Sie Ihre Toolsuite so gut, dass Sie schnelle und pragmatische Antworten für folgende Probleme finden?

- Mit welchem Betriebssystem müssen/wollen Sie meist für die Abschlussarbeit arbeiten (Windows, Linux, Mac)?
- Addons zur Darstellung von Quelltexten (Syntax Highlighting, ggf. direkter Import aus dem Repository)
- Automatisierte Verzeichnisse (Literatur, Abbildungen, Tabellen)
- Darstellung mathematischer Formeln
- Welche (skalierbaren) Abbildungsformate wollen Sie nutzen?
- Generierung von gut lesbaren PDF Dokumenten (ggf. mit Links und Verweisen wie in HTML-Dokumenten?)
- usw.

