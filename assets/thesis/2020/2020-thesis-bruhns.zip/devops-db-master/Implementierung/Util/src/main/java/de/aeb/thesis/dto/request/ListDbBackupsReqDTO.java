package de.aeb.thesis.dto.request;

import java.util.Map;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to list all backups from a database.
 */
public class ListDbBackupsReqDTO extends RequestDTO {

	private String databaseName;
	
	public ListDbBackupsReqDTO() {}

	public ListDbBackupsReqDTO(String type, String databaseName) {
		super(type);
		this.databaseName = databaseName;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getDatabaseName() == null ;
	}
	
	@Override
	public Map<String, String> getParamsAsMap() {
		Map<String, String> params = super.getParamsAsMap();
		params.put("databaseName", getDatabaseName());
		return params;
	}
	
}