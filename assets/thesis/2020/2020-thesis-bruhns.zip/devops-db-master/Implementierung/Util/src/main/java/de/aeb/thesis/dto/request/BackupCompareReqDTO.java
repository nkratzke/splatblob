package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to compare two backups.
 */
public class BackupCompareReqDTO extends RequestDTO {
	
	private String nameFirstBackup;
	private String nameSecondBackup;
	
	public BackupCompareReqDTO() {}
	
	public BackupCompareReqDTO(String type, String nameFirstBackup, String nameSecondBackup) {
		super(type);
		this.nameFirstBackup = nameFirstBackup;
		this.nameSecondBackup = nameSecondBackup;
	}

	public String getNameFirstBackup() {
		return nameFirstBackup;
	}
	
	public String getNameSecondBackup() {
		return nameSecondBackup;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getNameFirstBackup() == null ||
				getNameSecondBackup() == null;
	}
	
}