package de.aeb.thesis.dto.util;

public class AuthenticationDTO {
	
	private String databaseUrl;
	private String user;
	private String password;
	
	public AuthenticationDTO(String databaseUrl, String user, String password) {
		this.databaseUrl = databaseUrl;
		this.user = user;
		this.password = password;
	}

	public String getDatabaseUrl() {
		return databaseUrl;
	}

	public String getUser() {
		return user;
	}

	public String getPassword() {
		return password;
	}	
	
}