package de.aeb.thesis.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to compare two backups.
 */
@JsonInclude(Include.NON_NULL)
public class BackupCompareRespDTO extends ResponseDTO {

	private String message;
	
	public BackupCompareRespDTO(String errorMessage, String exception, String message) {
		super(errorMessage, exception);
		this.message = message;
	}
	
	public BackupCompareRespDTO() {}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
}