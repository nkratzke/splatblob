package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to create a empty database.
 */
public class CreateDbReqDTO extends RequestDTO {
	
	private String databaseName;
	private String schema;
	
	public CreateDbReqDTO() {}
	
	public CreateDbReqDTO(String type, String databaseName, String schema) {
		super(type);
		this.databaseName = databaseName;
		this.schema = schema;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	public String getSchema() {
		return schema;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getDatabaseName() == null ||
				getSchema() == null;
	}
	
}