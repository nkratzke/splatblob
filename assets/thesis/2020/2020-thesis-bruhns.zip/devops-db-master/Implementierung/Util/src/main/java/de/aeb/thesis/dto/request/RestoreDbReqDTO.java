package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to reset a database using a backup.
 */
public class RestoreDbReqDTO extends RequestDTO {

	private String databaseName;
	private String backupName;
	
	public RestoreDbReqDTO() {}

	public RestoreDbReqDTO(String type, String databaseName, String backupName) {
		super(type);
		this.databaseName = databaseName;
		this.backupName = backupName;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	public String getBackupName() {
		return backupName;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getDatabaseName() == null ||
				getBackupName() == null;
	}
	
}