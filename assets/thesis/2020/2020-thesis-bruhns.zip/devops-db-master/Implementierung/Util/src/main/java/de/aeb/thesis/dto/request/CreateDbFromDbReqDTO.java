package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to duplicate a database.
 */
public class CreateDbFromDbReqDTO extends RequestDTO {

	private String nameFirstDatabase;
	private String nameSecondDatabase;
	
	public CreateDbFromDbReqDTO() {}

	public CreateDbFromDbReqDTO(String type, String nameFirstDatabase, String nameSecondDatabase) {
		super(type);
		this.nameFirstDatabase = nameFirstDatabase;
		this.nameSecondDatabase = nameSecondDatabase;
	}

	public String getNameFirstDatabase() {
		return nameFirstDatabase;
	}
	
	public String getNameSecondDatabase() {
		return nameSecondDatabase;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getNameFirstDatabase() == null ||
				getNameSecondDatabase() == null;
	}
	
}