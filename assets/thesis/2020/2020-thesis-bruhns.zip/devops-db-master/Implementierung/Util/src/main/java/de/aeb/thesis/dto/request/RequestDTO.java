package de.aeb.thesis.dto.request;

import java.util.HashMap;
import java.util.Map;

/**
 * An abstract template to map the requests to an object of a Java class.
 */
public class RequestDTO {
	
	private String type;
	
	public RequestDTO() {}
	
	public RequestDTO(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
	
	public Map<String, String> getParamsAsMap() {
		Map<String, String> params = new HashMap<>();
		params.put("type", getType());
		return params;
	}
	
	/**
	 * Checks whether the request is complete. All parameters must be set.  
	 * @return true if all parameters are set.
	 */
	public boolean isComplete() {
		return getType() == null;
	}
	
}