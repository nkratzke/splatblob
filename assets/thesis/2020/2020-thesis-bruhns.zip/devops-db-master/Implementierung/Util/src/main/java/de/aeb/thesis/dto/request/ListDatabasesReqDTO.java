package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to list all databases.
 */
public class ListDatabasesReqDTO extends RequestDTO {

	public ListDatabasesReqDTO() {}
	
	public ListDatabasesReqDTO(String type) {
		super(type);
	}
	
}