package de.aeb.thesis.dto.request;

import java.util.Map;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to delete a database.
 */
public class DeleteDbReqDTO extends RequestDTO {
	
	private String name;
	private boolean deleteAllBackups;
	
	public DeleteDbReqDTO() {}
	
	public DeleteDbReqDTO(String type, String name, boolean deleteAllBackups) {
		super(type);
		this.name = name;
		this.deleteAllBackups = deleteAllBackups;
	}

	public String getName() {
		return name;
	}
	
	public boolean getDeleteAllBackups() {
		return this.deleteAllBackups;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getName() == null;
	}
	
	@Override
	public Map<String, String> getParamsAsMap(){
		Map<String, String> params = super.getParamsAsMap();
		params.put("name", getName());
		params.put("deleteAllBackups", String.valueOf(getDeleteAllBackups()));
		return params;
	}
}