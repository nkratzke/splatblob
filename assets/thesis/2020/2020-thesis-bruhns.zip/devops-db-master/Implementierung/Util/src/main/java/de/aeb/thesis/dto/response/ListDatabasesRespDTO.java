package de.aeb.thesis.dto.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to list all databases.
 */
@JsonInclude(Include.NON_NULL)
public class ListDatabasesRespDTO extends ResponseDTO {
	
	private List<String> databases;
	
	public ListDatabasesRespDTO(String errorMessage, String exception, List<String> databases) {
		super(errorMessage, exception);
		this.databases = databases;
	}

	public ListDatabasesRespDTO() {}
	
	public List<String> getDatabases(){
		return databases;
	}
	
	public void setDatabases(List<String> databases) {
		this.databases = databases;
	}
	
}