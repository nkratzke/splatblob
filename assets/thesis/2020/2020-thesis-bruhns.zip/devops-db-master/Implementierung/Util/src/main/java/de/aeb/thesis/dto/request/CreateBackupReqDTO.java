package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to create a backup.
 */
public class CreateBackupReqDTO extends RequestDTO {
	
	private String databaseName;
	private String backupName;
	private String comment;
	
	public CreateBackupReqDTO() {}

	public CreateBackupReqDTO(String type, String databaseName, String backupName, String comment) {
		super(type);
		this.databaseName = databaseName;
		this.backupName = backupName;
		this.comment = comment;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	public String getBackupName() {
		return backupName;
	}
	
	public String getComment() {
		return comment;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getDatabaseName() == null ||
				getBackupName() == null ||
				getComment() == null;
	}
	
}