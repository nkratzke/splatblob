package de.aeb.thesis.dto.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to list all backups from a database.
 */
@JsonInclude(Include.NON_NULL)
public class ListDbBackupsRespDTO extends ResponseDTO {
	
	private Map<String, Map<String, Map<String, String>>> backups;
	
	public ListDbBackupsRespDTO(String errorMessage, String exception, Map<String, Map<String, Map<String, String>>> backups) {
		super(errorMessage, exception);
		this.backups = backups;
	}
	
	public ListDbBackupsRespDTO() {}
	
	public Map<String, Map<String, Map<String, String>>> getBackups(){
		return backups;
	}
	
	public void setBackups(Map<String, Map<String, Map<String, String>>> backups) {
		this.backups = backups;
	}
	
}