package de.aeb.thesis.dto.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to delete a database.
 */
@JsonInclude(Include.NON_NULL)
public class DeleteDbRespDTO extends ResponseDTO {

	private String message;
	private Map<String, Map<String, Map<String, String>>> backups;
	
	public DeleteDbRespDTO(String errorMessage, String exception, String message, Map<String, Map<String, Map<String, String>>> backups) {
		super(errorMessage, exception);
		this.message = message;
		this.backups = backups;
	}
	
	public DeleteDbRespDTO() {}
	
	public String getMessage() {
		return message;
	}
	
	public Map<String, Map<String, Map<String, String>>> getBackups(){
		return backups;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setBackups(Map<String, Map<String, Map<String, String>>> backups) {
		this.backups = backups;
	}
	
}