package de.aeb.thesis.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to create a backup.
 */
@JsonInclude(Include.NON_NULL)
public class CreateBackupRespDTO extends ResponseDTO {

	public CreateBackupRespDTO(String errorMessage, String exception) {
		super(errorMessage, exception);
	}
	
	public CreateBackupRespDTO() {}

}