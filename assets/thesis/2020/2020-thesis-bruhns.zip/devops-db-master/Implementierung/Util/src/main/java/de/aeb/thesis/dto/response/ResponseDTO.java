package de.aeb.thesis.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template for generating responses.
 */
@JsonInclude(Include.NON_NULL)
public class ResponseDTO {
	
	private String errorMessage;
	private String exception;
	
	public ResponseDTO(String errorMessage, String exception) {
		this.errorMessage = errorMessage;
		this.exception = exception;
	}
	
	public ResponseDTO(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public ResponseDTO() {}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public String getException() {
		return exception;
	}
	
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public void setException(String exception) {
		this.exception = exception;
	}
	
}