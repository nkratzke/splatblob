package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to create a database.
 */
public class CreateDbFromDataReqDTO extends RequestDTO {
	
	private String databaseName;
	private String pathToData;
	
	public CreateDbFromDataReqDTO() {}
	
	public CreateDbFromDataReqDTO(String type, String databaseName, String pathToData) {
		super(type);
		this.databaseName = databaseName;
		this.pathToData = pathToData;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	public String getPathToData() {
		return pathToData;
	}
	
	@Override
	public boolean isComplete() {
		return getType() == null ||
				getDatabaseName() == null ||
				getPathToData() == null;
	}
	
}