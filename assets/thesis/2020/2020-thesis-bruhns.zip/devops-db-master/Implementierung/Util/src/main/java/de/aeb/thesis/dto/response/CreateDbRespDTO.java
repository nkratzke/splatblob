package de.aeb.thesis.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import de.aeb.thesis.dto.util.AuthenticationDTO;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to create a empty database.
 */
@JsonInclude(Include.NON_NULL)
public class CreateDbRespDTO extends ResponseDTO {

	private String databaseUrl;
	private String user;
	private String password;
	
	public CreateDbRespDTO(String errorMessage, String exception, String databaseUrl, String user, String password) {
		super(errorMessage, exception);
		this.databaseUrl = databaseUrl;
		this.user = user;
		this.password = password;
	}
	
	public CreateDbRespDTO() {}
	
	public void setAccessData(AuthenticationDTO authDTO) {
		databaseUrl = authDTO.getDatabaseUrl();
		user = authDTO.getUser();
		password = authDTO.getPassword();
	}
	
	public String getDatabaseUrl() {
		return databaseUrl;
	}

	public String getUser() {
		return user;
	}

	public String getPassword() {
		return password;
	}
	
	public void setDatabaseUrl(String databaseUrl) {
		this.databaseUrl = databaseUrl;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}