package de.aeb.thesis.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template to map a specific response to an object of a Java class.
 * The specific response is used to delete a backup.
 */
@JsonInclude(Include.NON_NULL)
public class DeleteBackupRespDTO extends ResponseDTO {

	public DeleteBackupRespDTO(String errorMessage, String exception) {
		super(errorMessage, exception);
	}
	
	public DeleteBackupRespDTO() {}
	
}