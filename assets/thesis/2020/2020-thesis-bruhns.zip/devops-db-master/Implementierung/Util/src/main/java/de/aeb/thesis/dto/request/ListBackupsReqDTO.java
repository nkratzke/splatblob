package de.aeb.thesis.dto.request;

/**
 * A template to map a specific request to an object of a Java class.
 * The specific request is used to list all backups.
 */
public class ListBackupsReqDTO extends RequestDTO {

	public ListBackupsReqDTO() {}
	
	public ListBackupsReqDTO(String type) {
		super(type);
	}
	
}