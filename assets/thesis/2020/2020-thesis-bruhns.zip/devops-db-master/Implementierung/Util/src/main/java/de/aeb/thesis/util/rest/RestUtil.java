package de.aeb.thesis.util.rest;

/**
 * A helper class contains all server paths.
 */
public class RestUtil {
	
	public static final String REST_URL = "http://localhost:8080";
	
	public static final String REST_PATH_CREATE_EMPTY_DATABASE = "database";
	public static final String REST_PATH_CREATE_DATABASE = "database/fromdata";
	public static final String REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP = "database/frombackup";
	public static final String REST_PATH_CLONE_DATABASE = "database/fromdatabase";
	public static final String REST_PATH_RESET_DATABASE_FROM_BACKUP = "database/restore";
	public static final String REST_PATH_CREATE_DATABASE_BACKUP = "database/backup";
	public static final String REST_PATH_COMPARE_BACKUPS = "backup/compare";
	
	public static final String REST_PATH_DELETE_DATABASE = "database";
	public static final String REST_PATH_DELETE_BACKUP = "backup";
	
	public static final String REST_PATH_LIST_ALL_DATABASES = "databases";
	public static final String REST_PATH_LIST_ALL_BACKUPS_FROM_DATABASE = "database/backups";
	public static final String REST_PATH_LIST_ALL_BACKUPS = "backups";
	
	private RestUtil() {
		//only static methods
	}
	
}