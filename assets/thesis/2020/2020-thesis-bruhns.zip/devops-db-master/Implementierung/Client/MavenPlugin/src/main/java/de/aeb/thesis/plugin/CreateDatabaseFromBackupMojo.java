package de.aeb.thesis.plugin;

import java.io.File;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.MavenPluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to create a database using a backup.
 */
@Mojo(name = "createDatabaseFromBackup")
public class CreateDatabaseFromBackupMojo extends AbstractMavenPluginMojo {

	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	
	@Parameter(required = true)
	String databaseName;
	
	@Parameter(required = true)
	String backupName;
	
	@Parameter(required = true)
	File accessDataToDatabasesDir;
	
	private CreateDbFromBackupRespDTO respDTO;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.createDatabaseFromBackup(url, type, databaseName, backupName);
			getLog().info(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
			MavenPluginUtil.saveAccessData(accessDataToDatabasesDir.toPath(), databaseName, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}
	
	public CreateDbFromBackupRespDTO getRespDTO() {
		return respDTO;
	}
	
}