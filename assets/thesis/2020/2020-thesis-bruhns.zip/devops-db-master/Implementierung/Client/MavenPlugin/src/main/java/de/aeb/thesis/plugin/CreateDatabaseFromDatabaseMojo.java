package de.aeb.thesis.plugin;

import java.io.File;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.MavenPluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to clone an existing database.
 */
@Mojo(name = "createDatabaseFromDatabase")
public class CreateDatabaseFromDatabaseMojo extends AbstractMavenPluginMojo {

	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	
	@Parameter(required = true)
	String nameFirstDatabase;
	
	@Parameter(required = true)
	String nameSecondDatabase;
	
	@Parameter(required = true)
	File accessDataToDatabasesDir;
	
	private CreateDbFromDbRespDTO respDTO;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.createDatabaseFromDatabase(url, type, nameFirstDatabase, nameSecondDatabase);
			getLog().info(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
			MavenPluginUtil.saveAccessData(accessDataToDatabasesDir.toPath(), nameSecondDatabase, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}	
	
	public CreateDbFromDbRespDTO getRespDTO() {
		return respDTO;
	}
	
}

