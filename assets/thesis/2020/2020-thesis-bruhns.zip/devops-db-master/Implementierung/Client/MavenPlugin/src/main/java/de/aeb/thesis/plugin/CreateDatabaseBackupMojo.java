package de.aeb.thesis.plugin;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to create a backup of an existing database.
 */
@Mojo(name = "createDatabaseBackup")
public class CreateDatabaseBackupMojo extends AbstractMavenPluginMojo {
	
	private static final String MESSAGE_CREATION_BACKUP_SUCCESSFUL = "The backup was successfully created.";
	
	@Parameter(required = true)
	String databaseName;
	
	@Parameter(required = true)
	String backupName;
	
	@Parameter(required = true)
	String comment;
	
	private CreateBackupRespDTO respDTO;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.createDatabaseBackup(url, type, databaseName, backupName, comment);
			getLog().info(MESSAGE_CREATION_BACKUP_SUCCESSFUL);
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}

	public CreateBackupRespDTO getRespDTO() {
		return respDTO;
	}

}

