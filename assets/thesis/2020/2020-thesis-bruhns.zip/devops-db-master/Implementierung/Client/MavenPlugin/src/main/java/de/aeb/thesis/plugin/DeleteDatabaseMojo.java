package de.aeb.thesis.plugin;

import java.io.File;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.MavenPluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to delete an existing database. Optionally, all backups belonging to the database are deleted.
 */
@Mojo(name = "deleteDatabase")
public class DeleteDatabaseMojo extends AbstractMavenPluginMojo {
	
	private static final String MESSAGE_NO_BACKUPS_AVAILABLE = "No backups available.";
	private static final String MESSAGE_DELETION_SUCCESSFUL = "The deletion was successful.";
	
	@Parameter(required = true)
	String databaseName;
	
	@Parameter(required = true)
	boolean deleteAllBackups;
	
	@Parameter(required = true)
	File accessDataToDatabasesDir;
	
	private DeleteDbRespDTO respDTO;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.deleteDatabase(url, type, databaseName, deleteAllBackups);
			if(respDTO.getBackups() != null) {
				getLog().info(respDTO.getMessage());
				MavenPluginUtil.logBackups(respDTO.getBackups(), getLog());
			} else {
				getLog().info(MESSAGE_NO_BACKUPS_AVAILABLE);
			}
			getLog().info(MESSAGE_DELETION_SUCCESSFUL);
			MavenPluginUtil.deleteAccessData(accessDataToDatabasesDir.toPath(), databaseName);
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}
	
	public DeleteDbRespDTO getRespDTO() {
		return respDTO;
	}
	
}