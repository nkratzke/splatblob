package de.aeb.thesis.plugin;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to delete an existing backup.
 */
@Mojo(name = "deleteBackup")
public class DeleteBackupMojo extends AbstractMavenPluginMojo {
	
	private static final String MESSAGE_DELETION_BACKUP_SUCESSFUL = "The backup was successfully deleted.";
	
	@Parameter(required = true)
	String name;
	
	private DeleteBackupRespDTO respDTO;
	
	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.deleteBackup(url, type, name);
			getLog().info(MESSAGE_DELETION_BACKUP_SUCESSFUL);
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}

	public DeleteBackupRespDTO getRespDTO() {
		return respDTO;
	}
	
}