package de.aeb.thesis.plugin;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;

import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.MavenPluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to list all backups.
 */
@Mojo(name = "listBackups")
public class ListBackupsMojo extends AbstractMavenPluginMojo {
	
	private static final String MESSAGE_NO_BACKUPS_AVAILABLE = "No backups available.";
	
	private ListBackupsRespDTO respDTO;
	
	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.listBackups(url, type);
			if(!respDTO.getBackups().isEmpty()) {
				MavenPluginUtil.logBackups(respDTO.getBackups(), getLog());
			} else {
				getLog().info(MESSAGE_NO_BACKUPS_AVAILABLE);
			}
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}

	public ListBackupsRespDTO getRespDTO() {
		return respDTO;
	}
	
}