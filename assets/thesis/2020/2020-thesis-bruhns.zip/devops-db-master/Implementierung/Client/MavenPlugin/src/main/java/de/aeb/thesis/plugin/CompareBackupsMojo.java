package de.aeb.thesis.plugin;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Goal to compare two existing backups.
 */
@Mojo(name = "compareBackups")
public class CompareBackupsMojo extends AbstractMavenPluginMojo {
	
	public static final String MESSAGE_BACKUPS_EQUALS = "The backups are identical.";
	public static final String MESSAGE_BACKUPS_NOT_EQUALS = "The backups are not identical.";
	
	@Parameter(required = true)
	String nameFirstBackup;
	
	@Parameter(required = true)
	String nameSecondBackup;
	
	@Parameter
	boolean failIfDifferent;
	
	private BackupCompareRespDTO respDTO;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			respDTO = PluginHelper.compareBackups(url, type, nameFirstBackup, nameSecondBackup);
			if(MESSAGE_BACKUPS_EQUALS.equals(respDTO.getMessage())) {
				getLog().info(respDTO.getMessage());
			} else {
				getLog().warn(respDTO.getMessage());
				if(failIfDifferent) {
					throw new MojoFailureException(respDTO.getMessage());
				}
			}
		} catch (ServerException e) {
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
			getLog().error(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
			throw new MojoFailureException(e.getMessage(), e);
		} catch (ProcessingException e) {
			getLog().error(PROCESSING_EXCEPTION_MESSAGE);
			throw new MojoFailureException(e.getMessage(), e);
		} catch (Exception e) {
			getLog().error(EXCEPTION_MESSAGE, e);
			throw new MojoExecutionException(e.getMessage(), e);
		}
	}
	
	public BackupCompareRespDTO getRespDTO() {
		return respDTO;
	}
	
}