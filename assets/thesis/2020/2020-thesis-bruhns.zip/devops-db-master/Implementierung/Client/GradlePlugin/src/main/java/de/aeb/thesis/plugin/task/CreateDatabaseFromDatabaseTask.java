/*
 ******************************************************************************
 *                                                                            *
 *          (C) COPYRIGHT by AEB SE 2020                                      *
 *                                                                            *
 ******************************************************************************
 */
package de.aeb.thesis.plugin.task;

import java.nio.file.Path;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDatabaseExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to clone an existing database.
 */
public class CreateDatabaseFromDatabaseTask extends AbstractTask {

	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	
	private CreateDbFromDbRespDTO respDTO;

	@TaskAction
	public void createDatabaseFromDatabase() {
		CreateDatabaseFromDatabaseExtension extension = getProject()
				.getExtensions()
				.findByType(CreateDatabaseFromDatabaseExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.createDatabaseFromDatabase(extension.getUrl(), extension.getType(), extension.getNameFirstDatabase(), extension.getNameSecondDatabase());
				getProject().getLogger().lifecycle(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
				GradlePluginUtil.saveAccessData(Path.of(extension.getAccessDataToDatabasesDir()), extension.getNameSecondDatabase(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public CreateDbFromDbRespDTO getRespDTO() {
		return respDTO;
	}
	
}