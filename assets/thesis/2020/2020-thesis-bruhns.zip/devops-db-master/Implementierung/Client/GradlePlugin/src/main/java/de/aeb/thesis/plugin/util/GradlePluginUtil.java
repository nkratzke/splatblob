/*
 ******************************************************************************
 *                                                                            *
 *          (C) COPYRIGHT by AEB SE 2020                                      *
 *                                                                            *
 ******************************************************************************
 */
package de.aeb.thesis.plugin.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Map.Entry;

import org.gradle.api.logging.Logger;

/**
 * A helper class containing uniform functionalities.
 */
public class GradlePluginUtil {
	
	private static final String SAVE_ACCESS_DATA = "%s %s %s";
	private static final String TXT_FILE = "%s.txt";
	
	private GradlePluginUtil() {
		//only static methods
	}
	
	/**
	 * The backups with all information (name of the database, comment, time stamp) are logged.
	 * @param result A map containing all information about the backups (name of the database, comment and time stamp).
	 * @param logger An object of {@link Logger}
	 */
	public static void logBackups(Map<String, Map<String, Map<String, String>>> result, Logger logger) {
		logger.lifecycle("Pattern: Name of the database - Name of the backup - Comment - Timestamp");
		for(Entry<String, Map<String, Map<String, String>>> database : result.entrySet()) {
			for(Entry<String, Map<String, String>> backups : database.getValue().entrySet()) {
				logger.lifecycle(String.format("%s - %s - %s - %s", database.getKey(), backups.getKey(), backups.getValue().get("Comment"), backups.getValue().get("Date")));
			}
		}
	}
	
	public static void saveAccessData(Path pathToAccessData, String databaseName, String databaseUrl, String user, String password) throws IOException {
		if(!Files.exists(pathToAccessData)) Files.createDirectory(pathToAccessData);
		Files.createFile(pathToAccessData.resolve(String.format(TXT_FILE, databaseName)));
		Files.writeString(pathToAccessData.resolve(String.format(TXT_FILE, databaseName)), String.format(SAVE_ACCESS_DATA, databaseUrl, user, password));
	}
	
	public static void deleteAccessData(Path pathToAccessData, String databaseName) throws IOException {
		Files.deleteIfExists(pathToAccessData.resolve(String.format(TXT_FILE, databaseName)));
	}
	
}