package de.aeb.thesis.plugin.extension;

/**
 * Extension to create a database using an existing backup.
 */
public class CreateDatabaseFromBackupExtension extends AbstractExtension {
	
	private String databaseName;
	private String backupName;
	private String accessDataToDatabasesDir;
	
	public String getAccessDataToDatabasesDir() {
		return accessDataToDatabasesDir;
	}

	public void setAccessDataToDatabasesDir(String accessDataToDatabasesDir) {
		this.accessDataToDatabasesDir = accessDataToDatabasesDir;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getBackupName() {
		return backupName;
	}
	
	public void setBackupName(String backupName) {
		this.backupName = backupName;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null ||
				backupName == null;
	}
	
}