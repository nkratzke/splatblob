CREATE DATABASE TestDatabase_Gradle_Plugin_One;

USE TestDatabase_Gradle_Plugin_One; 

CREATE SCHEMA pizza;

CREATE TABLE pizza.Person(ID INT NOT NULL, NAME VARCHAR(20) NOT NULL, AGE INT NOT NULL);

INSERT INTO pizza.PERSON (ID, NAME, AGE) VALUES (1, 'Kevin', 13);

INSERT INTO pizza.PERSON (ID, NAME, AGE) VALUES (2, 'Chantal', 19);