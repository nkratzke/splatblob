package de.aeb.thesis.plugin.extension;

/**
 * Extension to list all backups.
 */
public class ListBackupsExtension extends AbstractExtension {

	
}