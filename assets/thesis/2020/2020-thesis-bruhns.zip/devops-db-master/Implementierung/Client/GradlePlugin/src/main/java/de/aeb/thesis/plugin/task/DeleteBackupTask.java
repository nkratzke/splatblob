package de.aeb.thesis.plugin.task;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.plugin.extension.DeleteBackupExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to delete an existing backup.
 */
public class DeleteBackupTask extends AbstractTask {
	
	private static final String MESSAGE_DELETION_BACKUP_SUCESSFUL = "The backup was successfully deleted.";
	
	private DeleteBackupRespDTO respDTO;

	@TaskAction
	public void deleteBackup() {
		DeleteBackupExtension extension = getProject()
				.getExtensions()
				.findByType(DeleteBackupExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.deleteBackup(extension.getUrl(), extension.getType(), extension.getName());
				getProject().getLogger().lifecycle(MESSAGE_DELETION_BACKUP_SUCESSFUL);
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public DeleteBackupRespDTO getRespDTO() {
		return respDTO;
	}
	
}