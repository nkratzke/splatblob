package de.aeb.thesis.plugin.extension;

/**
 * Extension to clone an existing database.
 */
public class CreateDatabaseFromDatabaseExtension extends AbstractExtension {
	
	private String nameFirstDatabase;
	private String nameSecondDatabase;
	private String accessDataToDatabasesDir;
	
	public String getAccessDataToDatabasesDir() {
		return accessDataToDatabasesDir;
	}

	public void setAccessDataToDatabasesDir(String accessDataToDatabasesDir) {
		this.accessDataToDatabasesDir = accessDataToDatabasesDir;
	}

	public String getNameFirstDatabase() {
		return nameFirstDatabase;
	}
	
	public void setNameFirstDatabase(String nameFirstDatabase) {
		this.nameFirstDatabase = nameFirstDatabase;
	}
	
	public String getNameSecondDatabase() {
		return nameSecondDatabase;
	}
	
	public void setNameSecondDatabase(String nameSecondDatabase) {
		this.nameSecondDatabase = nameSecondDatabase;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				nameFirstDatabase == null ||
				nameSecondDatabase == null;
	}
	
}