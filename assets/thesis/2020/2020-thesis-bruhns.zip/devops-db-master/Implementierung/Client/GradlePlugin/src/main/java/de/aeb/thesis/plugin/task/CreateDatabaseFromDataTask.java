package de.aeb.thesis.plugin.task;

import java.nio.file.Path;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDataExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to create a database with initial data.
 */
public class CreateDatabaseFromDataTask extends AbstractTask {
	
	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";

	private CreateDbFromDataRespDTO respDTO;

	@TaskAction
	public void createDatabaseFromData() {
		CreateDatabaseFromDataExtension extension = getProject()
				.getExtensions()
				.findByType(CreateDatabaseFromDataExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.createDatabaseFromData(extension.getUrl(), extension.getType(), extension.getDatabaseName(), extension.getPathToData());
				getProject().getLogger().lifecycle(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
				GradlePluginUtil.saveAccessData(Path.of(extension.getAccessDataToDatabasesDir()), extension.getDatabaseName(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public CreateDbFromDataRespDTO getRespDTO() {
		return respDTO;
	}

	
}