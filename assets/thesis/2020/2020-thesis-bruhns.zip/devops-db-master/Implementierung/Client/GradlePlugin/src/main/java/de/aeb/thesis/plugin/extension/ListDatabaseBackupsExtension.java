package de.aeb.thesis.plugin.extension;

/**
 * Extension to list all backups from an existing database.
 */
public class ListDatabaseBackupsExtension extends AbstractExtension {
	
	private String databaseName;

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null;
	}
	
}