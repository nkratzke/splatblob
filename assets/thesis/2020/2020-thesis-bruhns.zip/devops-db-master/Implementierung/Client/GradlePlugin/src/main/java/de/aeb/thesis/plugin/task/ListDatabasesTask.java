package de.aeb.thesis.plugin.task;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.plugin.extension.ListDatabasesExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to list all databases.
 */
public class ListDatabasesTask extends AbstractTask {

	private static final String MESSAGE_NO_DATABASES_AVAILABLE = "No databases available.";
	private static final String MESSAGE_DATABASES = "Existing databases: %s";
	
	private ListDatabasesRespDTO respDTO;

	@TaskAction
	public void listDatabases() {
		ListDatabasesExtension extension = getProject()
				.getExtensions()
				.findByType(ListDatabasesExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.listDatabases(extension.getUrl(), extension.getType());
				if(!respDTO.getDatabases().isEmpty()) {
					getProject().getLogger().lifecycle(String.format(MESSAGE_DATABASES, respDTO.getDatabases()));
				} else {
					getProject().getLogger().lifecycle(MESSAGE_NO_DATABASES_AVAILABLE);
				}
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}

	@Input
	public ListDatabasesRespDTO getRespDTO() {
		return respDTO;
	}
	
}