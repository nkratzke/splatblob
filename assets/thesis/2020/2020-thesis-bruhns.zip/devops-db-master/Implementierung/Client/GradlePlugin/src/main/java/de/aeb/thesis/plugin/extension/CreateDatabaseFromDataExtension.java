package de.aeb.thesis.plugin.extension;

/**
 * Extension to create a  database with initial data.
 */
public class CreateDatabaseFromDataExtension extends AbstractExtension {
	
	private String databaseName;
	private String pathToData;
	private String accessDataToDatabasesDir;
	
	public String getAccessDataToDatabasesDir() {
		return accessDataToDatabasesDir;
	}

	public void setAccessDataToDatabasesDir(String accessDataToDatabasesDir) {
		this.accessDataToDatabasesDir = accessDataToDatabasesDir;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getPathToData() {
		return pathToData;
	}
	
	public void setPathToData(String pathToData) {
		this.pathToData = pathToData;
	}
		
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null ||
				pathToData == null;
	}
	
}