package de.aeb.thesis.plugin.extension;

/**
 * Extension to delete an existing database.
 */
public class DeleteDatabaseExtension extends AbstractExtension {
	
	private String databaseName;
	private boolean deleteAllBackups;
	private String accessDataToDatabasesDir;
	
	public String getAccessDataToDatabasesDir() {
		return accessDataToDatabasesDir;
	}

	public void setAccessDataToDatabasesDir(String accessDataToDatabasesDir) {
		this.accessDataToDatabasesDir = accessDataToDatabasesDir;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public boolean isDeleteAllBackups() {
		return deleteAllBackups;
	}
	
	public void setDeleteAllBackups(boolean deleteAllBackups) {
		this.deleteAllBackups = deleteAllBackups;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null;
	}
	
}