package de.aeb.thesis.plugin.extension;

/**
 * Extension to reset an existing database using an existing backup.
 */
public class RestoreDatabaseExtension extends AbstractExtension {

	private String databaseName;
	private String backupName;
	
	public String getDatabaseName() {
		return databaseName;
	}
	
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getBackupName() {
		return backupName;
	}
	
	public void setBackupName(String backupName) {
		this.backupName = backupName;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null ||
				backupName == null;
	}
	
}