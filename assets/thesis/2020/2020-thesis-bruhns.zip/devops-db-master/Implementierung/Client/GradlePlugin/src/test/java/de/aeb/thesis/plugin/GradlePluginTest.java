package de.aeb.thesis.plugin;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.gradle.api.GradleException;
import org.gradle.api.Project;
import org.gradle.internal.impldep.org.junit.Rule;
import org.gradle.internal.impldep.org.junit.rules.ExpectedException;
import org.gradle.testfixtures.ProjectBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.mongodb.MongoClient;

import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.plugin.extension.CompareBackupsExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseBackupExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromBackupExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDataExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDatabaseExtension;
import de.aeb.thesis.plugin.extension.DeleteBackupExtension;
import de.aeb.thesis.plugin.extension.DeleteDatabaseExtension;
import de.aeb.thesis.plugin.extension.ListBackupsExtension;
import de.aeb.thesis.plugin.extension.ListDatabaseBackupsExtension;
import de.aeb.thesis.plugin.extension.ListDatabasesExtension;
import de.aeb.thesis.plugin.extension.RestoreDatabaseExtension;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.task.CompareBackupsTask;
import de.aeb.thesis.plugin.task.CreateDatabaseBackupTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromBackupTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromDataTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromDatabaseTask;
import de.aeb.thesis.plugin.task.CreateDatabaseTask;
import de.aeb.thesis.plugin.task.DeleteBackupTask;
import de.aeb.thesis.plugin.task.DeleteDatabaseTask;
import de.aeb.thesis.plugin.task.ListBackupsTask;
import de.aeb.thesis.plugin.task.ListDatabaseBackupsTask;
import de.aeb.thesis.plugin.task.ListDatabasesTask;
import de.aeb.thesis.plugin.task.RestoreDatabaseTask;

/**
 * All test cases (User Acceptance Tests) for the component {@link GradlePlugin}.
 * It is necessary that a (test) server is provided. The server must be started.
 */
class GradlePluginTest {
	
	private static final String PLUGIN_NAME = "GradlePlugin";
	
	private static final String DATABASE_MSSQL = "MSSQL";
	private static final String DATABASE_MONGODB = "MONGODB";
	
	private static final String SERVER_URL = "http://localhost:8080";
	
	private static final int STATUS_CODE_BAD_REQUEST = 400;
	
	private static final String CREATE_DATABASE = "createDatabase";
	private static final String CREATE_DATABASE_FROM_DATA = "createDatabaseFromData";
	private static final String CREATE_DATABASE_FROM_BACKUP = "createDatabaseFromBackup";
	private static final String CREATE_DATABASE_FROM_DATABASE = "createDatabaseFromDatabase";
	private static final String RESTORE_DATABASE = "restoreDatabase";
	private static final String CREATE_DATABASE_BACKUP = "createDatabaseBackup";
	private static final String COMPARE_BACKUP = "compareBackups";
	private static final String DELETE_DATABASE = "deleteDatabase";
	private static final String DELETE_BACKUP = "deleteBackup";
	private static final String LIST_DATABASES = "listDatabases";
	private static final String LIST_BACKUPS = "listBackups";
	private static final String LIST_DATABASE_BACKUPS= "listDatabaseBackups";	
	
	private static final String DATABASE_NAME_ONE = "TestDatabase_Gradle_Plugin_One";
	private static final String DATABASE_NAME_TWO = "TestDatabase_Gradle_Plugin_Two";
	private static final String DATABASE_SCHEMA_ONE = "HelloWorld";
	private static final String DATABASE_SCHEMA_TWO = "HelloGermany";

	private static final String BACKUP_NAME_ONE = "TestBackup_HelloWorld";
	private static final String BACKUP_NAME_TWO = "TestBackup_HelloGermany";

	private static final String COMMENT = "Only created for the tests";
	
	private static final String MESSAGE_BACKUPS_EQUALS = "The backups are identical.";
	private static final String MESSAGE_BACKUPS_NOT_EQUALS = "The backups are not identical.";
	
	private static final String PATH_TO_DATA_MSSQL = "C:\\Users\\bru\\git\\automatisierung-von-datenbanken-in-devops-szenarien\\Client\\GradlePlugin\\src\\test\\resources\\MSSQL\\script.sql";
	private static final String PATH_TO_DATA_MONGODB = "C:\\Users\\bru\\git\\automatisierung-von-datenbanken-in-devops-szenarien\\Client\\GradlePlugin\\src\\test\\resources\\MongoDB\\Initial_Data_Sets";
	private static final String PATH_TO_ACCESS_DATA = "C:\\Users\\bru\\git\\automatisierung-von-datenbanken-in-devops-szenarien\\Client\\GradlePlugin\\src\\test\\resources\\access-data-databases";
	
	private static final String MSSQL_COMMAND_READ_ACCESS = "SELECT * FROM TestDatabase_Gradle_Plugin_One.pizza.Person;";
	
	private static Project project = ProjectBuilder.builder().build();
	
	private static Stream<String> databaseTypes(){
		return Stream.of(DATABASE_MSSQL, DATABASE_MONGODB);
	}
	
	private static Stream<String> databaseTypesWithInitialData(){
		return Stream.of(DATABASE_MSSQL +" " + PATH_TO_DATA_MSSQL, DATABASE_MONGODB + " " + PATH_TO_DATA_MONGODB);
	}
	
	  //////////////////////
	 // Required methods //
	//////////////////////

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	
	@BeforeEach
	public void applyGradlePlugin() {
		project.getPluginManager().apply(PLUGIN_NAME);
	}
	
	private void configureCreateDatabaseFromDatabaseExtension(String type, String nameFirstDatabase, String nameSecondDatabase) {
		CreateDatabaseFromDatabaseExtension extension = (CreateDatabaseFromDatabaseExtension) project.getExtensions().getByName(CREATE_DATABASE_FROM_DATABASE);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setNameFirstDatabase(nameFirstDatabase);
		extension.setNameSecondDatabase(nameSecondDatabase);
		extension.setAccessDataToDatabasesDir(PATH_TO_ACCESS_DATA);
	}
	
	private void configureCompareBackupsExtension(String type, String nameFirstBackup, String nameSecondBackup) {
		CompareBackupsExtension extension = (CompareBackupsExtension) project.getExtensions().getByName(COMPARE_BACKUP);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setNameFirstBackup(nameFirstBackup);
		extension.setNameSecondBackup(nameSecondBackup);
	}
	
	private void configureCreateDatabaseBackupExtension(String type, String databaseName, String backupName, String comment) {
		CreateDatabaseBackupExtension extension = (CreateDatabaseBackupExtension) project.getExtensions().getByName(CREATE_DATABASE_BACKUP);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setBackupName(backupName);
		extension.setComment(comment);
	}
	
	private void configureCreateDatabaseFromDataExtension(String type, String databaseName, String pathToData) {
		CreateDatabaseFromDataExtension extension = (CreateDatabaseFromDataExtension) project.getExtensions().getByName(CREATE_DATABASE_FROM_DATA);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setPathToData(pathToData);
		extension.setAccessDataToDatabasesDir(PATH_TO_ACCESS_DATA);
	}
	
	private void configureCreateDatabaseFromBackupExtension(String type, String databaseName, String backupName) {
		CreateDatabaseFromBackupExtension extension = (CreateDatabaseFromBackupExtension) project.getExtensions().getByName(CREATE_DATABASE_FROM_BACKUP);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setBackupName(backupName);
		extension.setAccessDataToDatabasesDir(PATH_TO_ACCESS_DATA);
	}
	
	private void configureCreateDatabaseExtension(String type, String databaseName, String schema) {
		CreateDatabaseExtension extension = (CreateDatabaseExtension) project.getExtensions().getByName(CREATE_DATABASE);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setSchema(schema);
		extension.setAccessDataToDatabasesDir(PATH_TO_ACCESS_DATA);
	}
	
	private void configureDeleteBackupExtension(String type, String backupName) {
		DeleteBackupExtension extension = (DeleteBackupExtension) project.getExtensions().getByName(DELETE_BACKUP);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setName(backupName);
	}
		
	private void configureDeleteDatabaseExtension(String type, String databaseName) {
		DeleteDatabaseExtension extension = (DeleteDatabaseExtension) project.getExtensions().getByName(DELETE_DATABASE);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setDeleteAllBackups(true);
	}
	
	private void configureListBackupsExtension(String type) {
		ListBackupsExtension extension = (ListBackupsExtension) project.getExtensions().getByName(LIST_BACKUPS);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
	}
	
	private void configureListDatabaseBackupsExtension(String type, String databaseName) {
		ListDatabaseBackupsExtension extension = (ListDatabaseBackupsExtension) project.getExtensions().getByName(LIST_DATABASE_BACKUPS);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
	}	
	
	private void configureListDatabasesExtension(String type) {
		ListDatabasesExtension extension = (ListDatabasesExtension) project.getExtensions().getByName(LIST_DATABASES);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
	}
	
	private void configureRestoreDatabaseExtension(String type, String databaseName, String backupName) {
		RestoreDatabaseExtension extension = (RestoreDatabaseExtension) project.getExtensions().getByName(RESTORE_DATABASE);
		extension.setUrl(SERVER_URL);
		extension.setType(type);
		extension.setDatabaseName(databaseName);
		extension.setBackupName(backupName);
	}
	
	private Connection createConnectionToMSSQL(String url, String user, String password) throws SQLException {
		DriverManager.registerDriver(new SQLServerDriver());
    	return DriverManager.getConnection(url, user, password);
	}
	
	private MongoClient createConnectionToMongoDB(String url) throws URISyntaxException {
		URI uri = new URI(url);
		return new MongoClient(uri.getHost(), uri.getPort());
	}
	
	private void simulateReadAccess(String type, CreateDbFromDataRespDTO respDTO) throws SQLException, URISyntaxException {
		switch(type) {
			case DATABASE_MSSQL :
				try(Connection connection = createConnectionToMSSQL(respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
						Statement stmt = connection.createStatement()) {
						stmt.execute(MSSQL_COMMAND_READ_ACCESS);
				}
				break;
			case DATABASE_MONGODB :
				try (MongoClient client = createConnectionToMongoDB(respDTO.getDatabaseUrl())) {
					client.getDatabase(DATABASE_NAME_ONE).listCollectionNames();
				}
		}
	}
	
	@AfterEach
	public void deleteTestDatabases() {
		try {
			configureDeleteDatabaseExtension(DATABASE_MSSQL, DATABASE_NAME_ONE);
	    	DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
	    	task.deleteDatabase();
		} catch (Exception ignore) {}
		
		try {
			configureDeleteDatabaseExtension(DATABASE_MSSQL, DATABASE_NAME_TWO);
	    	DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
	    	task.deleteDatabase();
		} catch (Exception ignore) {}
		
		try {
			configureDeleteDatabaseExtension(DATABASE_MONGODB, DATABASE_NAME_ONE);
	    	DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
	    	task.deleteDatabase();
		} catch (Exception ignore) {}
		
		try {
			configureDeleteDatabaseExtension(DATABASE_MONGODB, DATABASE_NAME_TWO);
	    	DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
	    	task.deleteDatabase();
		} catch (Exception ignore) {}
	}

	@AfterEach
	public void deleteTestBackups() {
		try {		
			configureDeleteBackupExtension(DATABASE_MSSQL, BACKUP_NAME_ONE);
	    	DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
	    	task.deleteBackup();
		} catch (Exception ignore) {}
		
		try {		
			configureDeleteBackupExtension(DATABASE_MSSQL, BACKUP_NAME_TWO);
	    	DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
	    	task.deleteBackup();
		} catch (Exception ignore) {}
		
		try {		
			configureDeleteBackupExtension(DATABASE_MONGODB, BACKUP_NAME_ONE);
	    	DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
	    	task.deleteBackup();
		} catch (Exception ignore) {}
		
		try {		
			configureDeleteBackupExtension(DATABASE_MONGODB, BACKUP_NAME_TWO);
	    	DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
	    	task.deleteBackup();
		} catch (Exception ignore) {}
	}
	
	@AfterEach
	public void deleteAccesDataDatabases() throws IOException {
		if(Files.exists(Path.of(PATH_TO_ACCESS_DATA))) FileUtils.forceDelete(Path.of(PATH_TO_ACCESS_DATA).toFile());
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods createDatabase(...) //
	/////////////////////////////////////////////////	
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptyDatabase(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		CreateDatabaseTask task = (CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE);
		task.createDatabase();
		CreateDbRespDTO respDTO = task.getRespDTO();
		assertNotNull(respDTO.getDatabaseUrl());
		assertNotNull(respDTO.getUser());
		assertNotNull(respDTO.getPassword());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptySameDatabaseTwice(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
    		CreateDatabaseTask task = (CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE);
    		task.createDatabase();
    		task.createDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods deleteDatabase(...) //
	////////////////////////////////////////////////	

	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingDatabase(String type) {
		try {
			configureDeleteDatabaseExtension(type, DATABASE_NAME_ONE);
			DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
    		task.deleteDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabase(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureDeleteDatabaseExtension(type, DATABASE_NAME_ONE);
		DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
		task.deleteDatabase();
		DeleteDbRespDTO respDTO = task.getRespDTO();
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseWitchBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureDeleteDatabaseExtension(type, DATABASE_NAME_ONE);
		DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
		task.deleteDatabase();
		DeleteDbRespDTO respDTO = task.getRespDTO();
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseTwice(String type) {
		try {
			configureDeleteDatabaseExtension(type, DATABASE_NAME_ONE);
			DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
    		task.deleteDatabase();
    		task.deleteDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  ///////////////////////////////////////////////
	 // Test cases for methods listDatabases(...) //
	///////////////////////////////////////////////	
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listAllDatabases(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureListDatabasesExtension(type);
		ListDatabasesTask task = (ListDatabasesTask) project.getTasks().getByName(LIST_DATABASES);
		task.listDatabases();
		ListDatabasesRespDTO respDTO = task.getRespDTO();
		assertTrue(respDTO.getDatabases().contains(DATABASE_NAME_ONE));
	}
	
	@Test
	public void listAllDatabasesIncorrectType() {
		try {
    		configureListDatabasesExtension("");
    		ListDatabasesTask task = (ListDatabasesTask) project.getTasks().getByName(LIST_DATABASES);
    		task.listDatabases();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}

	  //////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseBackup(...) //
	//////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromNonExistingDatabase(String type) {
		try {
			configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
			CreateDatabaseBackupTask task = (CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP);
    		task.createDatabaseBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabase(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		CreateDatabaseBackupTask task = (CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP);
		task.createDatabaseBackup();
		CreateBackupRespDTO respDTO = task.getRespDTO();
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabaseTwice(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
			CreateDatabaseBackupTask task = (CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP);
    		task.createDatabaseBackup();
    		task.createDatabaseBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
			
		}
	}	
	
	  //////////////////////////////////////////////
	 // Test cases for methods deleteBackup(...) //
	//////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingBackup(String type) {
		try {
			configureDeleteBackupExtension(type, BACKUP_NAME_ONE);
			DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
    		task.deleteBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureDeleteBackupExtension(type, BACKUP_NAME_ONE);
		DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
		task.deleteBackup();
		DeleteBackupRespDTO respDTO = task.getRespDTO();
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackupTwice(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
			((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
			
			DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
			task.deleteBackup();
			task.deleteBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  /////////////////////////////////////////////
	 // Test cases for methods listBackups(...) //
	/////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupsContainsExistingBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureListBackupsExtension(type);
		ListBackupsTask task = (ListBackupsTask) project.getTasks().getByName(LIST_BACKUPS);
		task.listBackups();
		ListBackupsRespDTO respDTO = task.getRespDTO();
		assertTrue(respDTO.getBackups().containsKey(DATABASE_NAME_ONE));
		assertTrue(respDTO.getBackups().get(DATABASE_NAME_ONE).keySet().contains(BACKUP_NAME_ONE));
	}
	
	@Test
	public void listBackupsIncorrectType() {
		try {
			configureListBackupsExtension("");
			ListBackupsTask task = (ListBackupsTask) project.getTasks().getByName(LIST_BACKUPS);
			task.listBackups();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  /////////////////////////////////////////////////////
	 // Test cases for methods listDatabaseBackups(...) //
	/////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupsFromDatabaseContainsExistingBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureListDatabaseBackupsExtension(type, DATABASE_NAME_ONE);
		ListDatabaseBackupsTask task = (ListDatabaseBackupsTask) project.getTasks().getByName(LIST_DATABASE_BACKUPS);
		task.listDatabaseBackups();
		ListDbBackupsRespDTO respDTO = task.getRespDTO();
		assertTrue(respDTO.getBackups().containsKey(DATABASE_NAME_ONE));
		assertTrue(respDTO.getBackups().get(DATABASE_NAME_ONE).keySet().contains(BACKUP_NAME_ONE));
	}
	
	@Test
	public void listBackupFromDatabaseIncorrectType() {
		try {
			configureListDatabaseBackupsExtension("", DATABASE_NAME_ONE);
			ListDatabaseBackupsTask task = (ListDatabaseBackupsTask) project.getTasks().getByName(LIST_DATABASE_BACKUPS);
			task.listDatabaseBackups();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  /////////////////////////////////////////////////
	 // Test cases for methods restoreDatabase(...) //
	/////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromExistingBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureRestoreDatabaseExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
		RestoreDatabaseTask task = (RestoreDatabaseTask) project.getTasks().getByName(RESTORE_DATABASE);
		task.restoreDatabase();
		RestoreDbRespDTO respDTO = task.getRespDTO();
		assertNotNull(respDTO.getDatabaseUrl());
		assertNotNull(respDTO.getUser());
		assertNotNull(respDTO.getPassword());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromNonExistingBackup(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureRestoreDatabaseExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
			RestoreDatabaseTask task = (RestoreDatabaseTask) project.getTasks().getByName(RESTORE_DATABASE);
			task.restoreDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}	

    //////////////////////////////////////////////////////////
   // Test cases for methods createDatabaseFromBackup(...) //
	//////////////////////////////////////////////////////////

	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromExistingBackup(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCreateDatabaseFromBackupExtension(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE);
		CreateDatabaseFromBackupTask task = (CreateDatabaseFromBackupTask) project.getTasks().getByName(CREATE_DATABASE_FROM_BACKUP);
		task.createDatabaseFromBackup();
		CreateDbFromBackupRespDTO respDTO = task.getRespDTO();
		assertNotNull(respDTO.getDatabaseUrl());
		assertNotNull(respDTO.getUser());
		assertNotNull(respDTO.getPassword());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromNonExistingBackup(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseFromBackupExtension(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE);
			CreateDatabaseFromBackupTask task = (CreateDatabaseFromBackupTask) project.getTasks().getByName(CREATE_DATABASE_FROM_BACKUP);
			task.createDatabaseFromBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createExistingDatabaseFromExistingBackup(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
			((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
			
			configureCreateDatabaseFromBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
			CreateDatabaseFromBackupTask task = (CreateDatabaseFromBackupTask) project.getTasks().getByName(CREATE_DATABASE_FROM_BACKUP);
			task.createDatabaseFromBackup();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  ////////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromDatabase(...) //
	////////////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneExistingDatabaseToNonExistingDatabase(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseFromDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
		CreateDatabaseFromDatabaseTask task = (CreateDatabaseFromDatabaseTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATABASE);
		task.createDatabaseFromDatabase();
		CreateDbFromDbRespDTO respDTO = task.getRespDTO();
		assertNotNull(respDTO.getDatabaseUrl());
		assertNotNull(respDTO.getUser());
		assertNotNull(respDTO.getPassword());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneNonExistingDatabaseToNonExistingDatabase(String type) {
		try {
			configureCreateDatabaseFromDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
			CreateDatabaseFromDatabaseTask task = (CreateDatabaseFromDatabaseTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATABASE);
			task.createDatabaseFromDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneDatabaseToExistingDatabase(String type) {
		try {
			configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseExtension(type, DATABASE_NAME_TWO, DATABASE_SCHEMA_ONE);		
			((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
			
			configureCreateDatabaseFromDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
			CreateDatabaseFromDatabaseTask task = (CreateDatabaseFromDatabaseTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATABASE);
			task.createDatabaseFromDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods compareBackups(...) //
	////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareTwoBackups(String type) {
		configureCreateDatabaseExtension(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCreateDatabaseBackupExtension(type, DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCompareBackupsExtension(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
		CompareBackupsTask task = (CompareBackupsTask) project.getTasks().getByName(COMPARE_BACKUP);
		task.compareBackups();
		BackupCompareRespDTO respDTO = task.getRespDTO();
		assertEquals(MESSAGE_BACKUPS_EQUALS, respDTO.getMessage());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareNonExistingBackups(String type) {
		try {
			configureCompareBackupsExtension(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
			CompareBackupsTask task = (CompareBackupsTask) project.getTasks().getByName(COMPARE_BACKUP);
			task.compareBackups();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void backupsFromDifferentDatabasesAreAlwaysDifferent(String input) {
		String[] inputs = input.split(" ");
		
		configureCreateDatabaseFromDataExtension(inputs[0], DATABASE_NAME_ONE, inputs[1]);		
		((CreateDatabaseFromDataTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATA)).createDatabaseFromData();
		
		configureCreateDatabaseExtension(inputs[0], DATABASE_NAME_TWO, DATABASE_SCHEMA_TWO);		
		((CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE)).createDatabase();
		
		configureCreateDatabaseBackupExtension(inputs[0], DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCreateDatabaseBackupExtension(inputs[0], DATABASE_NAME_TWO, BACKUP_NAME_TWO, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCompareBackupsExtension(inputs[0], BACKUP_NAME_ONE, BACKUP_NAME_TWO);
		CompareBackupsTask task = (CompareBackupsTask) project.getTasks().getByName(COMPARE_BACKUP);
		task.compareBackups();
		BackupCompareRespDTO respDTO = task.getRespDTO();
		assertEquals(MESSAGE_BACKUPS_NOT_EQUALS, respDTO.getMessage());
		assertNull(respDTO.getException());
	}	
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void compareTwoBackupsReadAccessBeetweenComparison(String input) throws SQLException, URISyntaxException {
		String[] inputs = input.split(" ");
		
		configureCreateDatabaseFromDataExtension(inputs[0], DATABASE_NAME_ONE, inputs[1]);		
		CreateDatabaseFromDataTask taskCreate = (CreateDatabaseFromDataTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATA);
		taskCreate.createDatabaseFromData();
		
		configureCreateDatabaseBackupExtension(inputs[0], DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		simulateReadAccess(inputs[0], taskCreate.getRespDTO());

		configureCreateDatabaseBackupExtension(inputs[0], DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT);
		((CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP)).createDatabaseBackup();
		
		configureCompareBackupsExtension(inputs[0], BACKUP_NAME_ONE, BACKUP_NAME_TWO);
		CompareBackupsTask taskCompare = (CompareBackupsTask) project.getTasks().getByName(COMPARE_BACKUP);
		taskCompare.compareBackups();
		BackupCompareRespDTO respDTO = taskCompare.getRespDTO();
		assertEquals(MESSAGE_BACKUPS_EQUALS, respDTO.getMessage());
		assertNull(respDTO.getException());
	}
	
	  ////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromData(...) //
	////////////////////////////////////////////////////////	
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createDatabase(String input) {
		String[] inputs = input.split(" ");
		configureCreateDatabaseFromDataExtension(inputs[0], DATABASE_NAME_ONE, inputs[1]);		
		CreateDatabaseFromDataTask task = (CreateDatabaseFromDataTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATA);
		task.createDatabaseFromData();
		CreateDbFromDataRespDTO respDTO = task.getRespDTO();
		assertNotNull(respDTO.getDatabaseUrl());
		assertNotNull(respDTO.getUser());
		assertNotNull(respDTO.getPassword());
		assertNull(respDTO.getException());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createSameDatabaseTwice(String input) {
		try {
			String[] inputs = input.split(" ");
			configureCreateDatabaseFromDataExtension(inputs[0], DATABASE_NAME_ONE, inputs[1]);		
			CreateDatabaseFromDataTask task = (CreateDatabaseFromDataTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATA);
			task.createDatabaseFromData();
			task.createDatabaseFromData();
		} catch (Exception e) {
			assertTrue(e instanceof ServerException);
			int statuscode = ((ServerException) e).getStatuscode();
			assertTrue(statuscode == STATUS_CODE_BAD_REQUEST);
		}
	}
	
	  ////////////////////////////////////////////////////
	 // Test cases for requests with an incorrect type //
	////////////////////////////////////////////////////	
	
	@Test
	public void incorrectExtensionCompareBackups() {
		try {
			configureCompareBackupsExtension(null, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
			CompareBackupsTask task = (CompareBackupsTask) project.getTasks().getByName(COMPARE_BACKUP);
			task.compareBackups();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionCreateDatabaseBackup() {
		try {
			configureCreateDatabaseBackupExtension(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
			CreateDatabaseBackupTask task = (CreateDatabaseBackupTask) project.getTasks().getByName(CREATE_DATABASE_BACKUP);
			task.createDatabaseBackup();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionCreateDatabaseFromBackup() {
		try {
			configureCreateDatabaseFromBackupExtension(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
			CreateDatabaseFromBackupTask task = (CreateDatabaseFromBackupTask) project.getTasks().getByName(CREATE_DATABASE_FROM_BACKUP);
			task.createDatabaseFromBackup();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionCreateDatabaseFromDatabase() {
		try {
			configureCreateDatabaseFromDatabaseExtension(null, DATABASE_NAME_ONE, BACKUP_NAME_TWO);
			CreateDatabaseFromDatabaseTask task = (CreateDatabaseFromDatabaseTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATABASE);
			task.createDatabaseFromDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionCreateDatabaseFromData() {
		try {
			configureCreateDatabaseFromDataExtension(null, DATABASE_NAME_ONE, PATH_TO_DATA_MSSQL);
			CreateDatabaseFromDataTask task = (CreateDatabaseFromDataTask) project.getTasks().getByName(CREATE_DATABASE_FROM_DATA);
			task.createDatabaseFromData();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionCreateDatabase() {
		try {
			configureCreateDatabaseExtension(null, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE);
			CreateDatabaseTask task = (CreateDatabaseTask) project.getTasks().getByName(CREATE_DATABASE);
			task.createDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionDeleteBackup() {
		try {
			configureDeleteBackupExtension(null, BACKUP_NAME_ONE);
			DeleteBackupTask task = (DeleteBackupTask) project.getTasks().getByName(DELETE_BACKUP);
			task.deleteBackup();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionDeleteDatabase() {
		try {
			configureDeleteDatabaseExtension(null, DATABASE_NAME_ONE);
			DeleteDatabaseTask task = (DeleteDatabaseTask) project.getTasks().getByName(DELETE_DATABASE);
			task.deleteDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionListBackups() {
		try {
			configureListBackupsExtension(null);
			ListBackupsTask task = (ListBackupsTask) project.getTasks().getByName(LIST_BACKUPS);
			task.listBackups();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionListDatabaseBackups() {
		try {
			configureListDatabaseBackupsExtension(null, DATABASE_NAME_ONE);
			ListDatabaseBackupsTask task = (ListDatabaseBackupsTask) project.getTasks().getByName(LIST_DATABASE_BACKUPS);
			task.listDatabaseBackups();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionListDatabases() {
		try {
			configureListDatabasesExtension(null);
			ListDatabasesTask task = (ListDatabasesTask) project.getTasks().getByName(LIST_DATABASES);
			task.listDatabases();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
	@Test
	public void incorrectExtensionRestoreDatabase() {
		try {
			configureRestoreDatabaseExtension(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
			RestoreDatabaseTask task = (RestoreDatabaseTask) project.getTasks().getByName(RESTORE_DATABASE);
			task.restoreDatabase();
		} catch (Exception e) {
			assertTrue(e instanceof GradleException);
		}
	}
	
}