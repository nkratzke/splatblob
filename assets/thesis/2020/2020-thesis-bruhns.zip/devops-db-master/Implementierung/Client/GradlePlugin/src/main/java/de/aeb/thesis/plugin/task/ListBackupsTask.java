package de.aeb.thesis.plugin.task;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.plugin.extension.ListBackupsExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to list all backups.
 */
public class ListBackupsTask extends AbstractTask {
	
	private static final String MESSAGE_NO_BACKUPS_AVAILABLE = "No backups available.";
	
	private ListBackupsRespDTO respDTO;

	@TaskAction
	public void listBackups() {
		ListBackupsExtension extension = getProject()
				.getExtensions()
				.findByType(ListBackupsExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.listBackups(extension.getUrl(), extension.getType());
				if(!respDTO.getBackups().isEmpty()) {
					GradlePluginUtil.logBackups(respDTO.getBackups(), getProject().getLogger());
				} else {
					getProject().getLogger().lifecycle(MESSAGE_NO_BACKUPS_AVAILABLE);
				}
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public ListBackupsRespDTO getRespDTO() {
		return respDTO;
	}
	
}