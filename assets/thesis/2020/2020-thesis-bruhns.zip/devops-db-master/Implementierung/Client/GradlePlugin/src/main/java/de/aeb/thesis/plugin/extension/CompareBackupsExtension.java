/*
 ******************************************************************************
 *                                                                            *
 *          (C) COPYRIGHT by AEB SE 2020                                      *
 *                                                                            *
 ******************************************************************************
 */
package de.aeb.thesis.plugin.extension;

/**
 * Extension to compare two existing backups.
 */
public class CompareBackupsExtension extends AbstractExtension {
	
	private String nameFirstBackup;
	private String nameSecondBackup;
	
	public String getNameFirstBackup() {
		return nameFirstBackup;
	}
	
	public void setNameFirstBackup(String nameFirstBackup) {
		this.nameFirstBackup = nameFirstBackup;
	}
	
	public String getNameSecondBackup() {
		return nameSecondBackup;
	}
	
	public void setNameSecondBackup(String nameSecondBackup) {
		this.nameSecondBackup = nameSecondBackup;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				nameFirstBackup == null ||
				nameSecondBackup == null;
	}
	
}