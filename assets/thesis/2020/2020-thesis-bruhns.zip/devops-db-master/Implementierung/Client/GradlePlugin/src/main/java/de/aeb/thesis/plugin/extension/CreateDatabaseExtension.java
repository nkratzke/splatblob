package de.aeb.thesis.plugin.extension;

/**
 * Extension to create an empty database.
 */
public class CreateDatabaseExtension extends AbstractExtension {

	private String databaseName;
	private String schema;
	private String accessDataToDatabasesDir;
	
	public String getAccessDataToDatabasesDir() {
		return accessDataToDatabasesDir;
	}

	public void setAccessDataToDatabasesDir(String accessDataToDatabasesDir) {
		this.accessDataToDatabasesDir = accessDataToDatabasesDir;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getSchema() {
		return schema;
	}
	
	public void setSchema(String schema) {
		this.schema = schema;
	}
		
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				databaseName == null ||
				schema == null;
	}
	
}