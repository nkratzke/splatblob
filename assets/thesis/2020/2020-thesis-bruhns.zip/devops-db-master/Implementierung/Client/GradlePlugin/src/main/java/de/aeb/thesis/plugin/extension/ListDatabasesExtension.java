package de.aeb.thesis.plugin.extension;

/**
 * Extension to list all databases.
 */
public class ListDatabasesExtension extends AbstractExtension {
	
}