package de.aeb.thesis.plugin.task;

import java.nio.file.Path;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromBackupExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to create a database from an existing backup.
 */
public class CreateDatabaseFromBackupTask extends AbstractTask {
	
	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	
	private CreateDbFromBackupRespDTO respDTO;

	@TaskAction
	public void createDatabaseFromBackup() {
		CreateDatabaseFromBackupExtension extension = getProject()
				.getExtensions()
				.findByType(CreateDatabaseFromBackupExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.createDatabaseFromBackup(extension.getUrl(), extension.getType(), extension.getDatabaseName(), extension.getBackupName());
				getProject().getLogger().lifecycle(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
				GradlePluginUtil.saveAccessData(Path.of(extension.getAccessDataToDatabasesDir()), extension.getDatabaseName(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public CreateDbFromBackupRespDTO getRespDTO() {
		return respDTO;
	}
}