/*
 ******************************************************************************
 *                                                                            *
 *          (C) COPYRIGHT by AEB SE 2020                                      *
 *                                                                            *
 ******************************************************************************
 */
package de.aeb.thesis.plugin;

import org.gradle.api.Plugin;
import org.gradle.api.Project;

import de.aeb.thesis.plugin.extension.CompareBackupsExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseBackupExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromBackupExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDataExtension;
import de.aeb.thesis.plugin.extension.CreateDatabaseFromDatabaseExtension;
import de.aeb.thesis.plugin.extension.DeleteBackupExtension;
import de.aeb.thesis.plugin.extension.DeleteDatabaseExtension;
import de.aeb.thesis.plugin.extension.ListBackupsExtension;
import de.aeb.thesis.plugin.extension.ListDatabaseBackupsExtension;
import de.aeb.thesis.plugin.extension.ListDatabasesExtension;
import de.aeb.thesis.plugin.extension.RestoreDatabaseExtension;
import de.aeb.thesis.plugin.task.CompareBackupsTask;
import de.aeb.thesis.plugin.task.CreateDatabaseBackupTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromBackupTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromDataTask;
import de.aeb.thesis.plugin.task.CreateDatabaseFromDatabaseTask;
import de.aeb.thesis.plugin.task.CreateDatabaseTask;
import de.aeb.thesis.plugin.task.DeleteBackupTask;
import de.aeb.thesis.plugin.task.DeleteDatabaseTask;
import de.aeb.thesis.plugin.task.ListBackupsTask;
import de.aeb.thesis.plugin.task.ListDatabaseBackupsTask;
import de.aeb.thesis.plugin.task.ListDatabasesTask;
import de.aeb.thesis.plugin.task.RestoreDatabaseTask;

/**
 * Plugin for creating and managing databases and backups.
 */
public class GradlePlugin implements Plugin<Project> {

	@Override
	public void apply(Project project) {	
		project.getExtensions()
			.create("createDatabaseFromDatabase", CreateDatabaseFromDatabaseExtension.class);
		
		project.getExtensions()
			.create("compareBackups", CompareBackupsExtension.class);
		
		project.getExtensions()
			.create("createDatabaseBackup", CreateDatabaseBackupExtension.class);
		
		project.getExtensions()
			.create("createDatabaseFromData", CreateDatabaseFromDataExtension.class);
		
		project.getExtensions()
			.create("createDatabaseFromBackup", CreateDatabaseFromBackupExtension.class);
		
		project.getExtensions()
			.create("createDatabase", CreateDatabaseExtension.class);
		
		project.getExtensions()
			.create("deleteBackup", DeleteBackupExtension.class);
		
		project.getExtensions()
			.create("deleteDatabase", DeleteDatabaseExtension.class);
		
		project.getExtensions()
			.create("listDatabaseBackups", ListDatabaseBackupsExtension.class);
		
		project.getExtensions()
			.create("listBackups", ListBackupsExtension.class);
		
		project.getExtensions()
			.create("listDatabases", ListDatabasesExtension.class);
		
		project.getExtensions()
				.create("restoreDatabase", RestoreDatabaseExtension.class);
		
		project.getTasks()
			.create("createDatabaseFromDatabase", CreateDatabaseFromDatabaseTask.class);
		
		project.getTasks()
			.create("compareBackups", CompareBackupsTask.class);
		
		project.getTasks()
			.create("createDatabaseBackup", CreateDatabaseBackupTask.class);
		
		project.getTasks()
			.create("createDatabaseFromData", CreateDatabaseFromDataTask.class);
		
		project.getTasks()
			.create("createDatabaseFromBackup", CreateDatabaseFromBackupTask.class);
		
		project.getTasks()
			.create("createDatabase", CreateDatabaseTask.class);
		
		project.getTasks()
			.create("deleteBackup", DeleteBackupTask.class);
		
		project.getTasks()
			.create("deleteDatabase", DeleteDatabaseTask.class);
		
		project.getTasks()
			.create("listDatabaseBackups", ListDatabaseBackupsTask.class);
		
		project.getTasks()
			.create("listBackups", ListBackupsTask.class);
		
		project.getTasks()
			.create("listDatabases", ListDatabasesTask.class);
		
		project.getTasks()
			.create("restoreDatabase", RestoreDatabaseTask.class);
	}
	
}