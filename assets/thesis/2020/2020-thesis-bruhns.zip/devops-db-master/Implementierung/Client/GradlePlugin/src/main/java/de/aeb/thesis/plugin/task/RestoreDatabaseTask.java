package de.aeb.thesis.plugin.task;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.plugin.extension.RestoreDatabaseExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to reset an existing database using an existing backup.
 */
public class RestoreDatabaseTask extends AbstractTask {
	
	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	
	private RestoreDbRespDTO respDTO;

	@TaskAction
	public void restoreDatabase() {
		RestoreDatabaseExtension extension = getProject()
				.getExtensions()
				.findByType(RestoreDatabaseExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.restoreDatabase(extension.getUrl(), extension.getType(), extension.getDatabaseName(), extension.getBackupName());
				getProject().getLogger().lifecycle(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}

	@Input
	public RestoreDbRespDTO getRespDTO() {
		return respDTO;
	}
	
}