package de.aeb.thesis.plugin.extension;

/**
 * Extension to delete an existing backup.
 */
public class DeleteBackupExtension extends AbstractExtension {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public boolean isNotComplete() {
		return super.isNotComplete() ||
				name == null;
	}
	
}