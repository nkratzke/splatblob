package de.aeb.thesis.plugin.task;

import java.nio.file.Path;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.plugin.extension.CreateDatabaseExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to create an empty database.
 */
public class CreateDatabaseTask extends AbstractTask {
	
	private static final String ACCESS_DATA = "ACCESS: %s %s %s (URL, USER, PASSWORD)";
	private CreateDbRespDTO respDTO;

	@TaskAction
	public void createDatabase() {
		CreateDatabaseExtension extension = getProject()
				.getExtensions()
				.findByType(CreateDatabaseExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.createDatabase(extension.getUrl(), extension.getType(), extension.getDatabaseName(), extension.getSchema());
				getProject().getLogger().lifecycle(String.format(ACCESS_DATA, respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword()));
				GradlePluginUtil.saveAccessData(Path.of(extension.getAccessDataToDatabasesDir()), extension.getDatabaseName(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}
	
	@Input
	public CreateDbRespDTO getRespDTO() {
		return respDTO;
	}
}