package de.aeb.thesis.plugin.task;

import org.gradle.api.DefaultTask;

/**
 * Abstract task.
 */
public class AbstractTask extends DefaultTask {

	protected static final String SERVER_EXCEPTION_MESSAGE_STATUSCODE = "The request was not executed successfully. Statuscode: %s. Message: %s";
	protected static final String SERVER_EXCEPTION_MESSAGE_FROM_SERVER = "Exception message from the server: %s";
	protected static final String PROCESSING_EXCEPTION_MESSAGE = "The server is currently not available.";
	protected static final String EXCEPTION_MESSAGE = "An error has occurred";
	protected static final String MESSAGE_MISSING_PARAMETER = "Parameters are missing.";
	
}