package de.aeb.thesis.plugin.task;

import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;

import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.plugin.extension.DeleteDatabaseExtension;
import de.aeb.thesis.plugin.helper.PluginHelper;
import de.aeb.thesis.plugin.helper.PluginHelper.ServerException;
import de.aeb.thesis.plugin.util.GradlePluginUtil;
import jakarta.ws.rs.ProcessingException;

/**
 * Task to delete an existing database.
 */
public class DeleteDatabaseTask extends AbstractTask {
	
	private static final String MESSAGE_NO_BACKUPS_AVAILABLE = "No backups available.";
	private static final String MESSAGE_DELETION_SUCCESSFUL = "The deletion was successful.";
	
	private DeleteDbRespDTO respDTO;
	
	@TaskAction
	public void deleteDatabase() {
		DeleteDatabaseExtension extension = getProject()
				.getExtensions()
				.findByType(DeleteDatabaseExtension.class);
		
		if(extension.isNotComplete()) {
			throw new GradleException(MESSAGE_MISSING_PARAMETER);
		} else {
			try {
				respDTO = PluginHelper.deleteDatabase(extension.getUrl(), extension.getType(), extension.getDatabaseName(), extension.isDeleteAllBackups());
				if(!respDTO.getBackups().isEmpty()) {
					getProject().getLogger().lifecycle(respDTO.getMessage());
					GradlePluginUtil.logBackups(respDTO.getBackups(), getProject().getLogger());
				} else {
					getProject().getLogger().lifecycle(MESSAGE_NO_BACKUPS_AVAILABLE);
				}
				getProject().getLogger().lifecycle(MESSAGE_DELETION_SUCCESSFUL);
				//GradlePluginUtil.deleteAccessData(Path.of(extension.getAccessDataToDatabasesDir()), extension.getDatabaseName());
			} catch (ServerException e) {
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_STATUSCODE, e.getStatuscode(), e.getMessage()));
				getProject().getLogger().lifecycle(String.format(SERVER_EXCEPTION_MESSAGE_FROM_SERVER, e.getExceptionMessageFromServer()));
				throw e;
			} catch (ProcessingException e) {
				getProject().getLogger().lifecycle(PROCESSING_EXCEPTION_MESSAGE);
				throw new GradleException(e.getMessage(), e);
			} catch (Exception e) {
				getProject().getLogger().lifecycle(EXCEPTION_MESSAGE, e);
				throw new GradleException(e.getMessage(), e);
			}
		}
	}

	@Input
	public DeleteDbRespDTO getRespDTO() {
		return respDTO;
	}
	
}