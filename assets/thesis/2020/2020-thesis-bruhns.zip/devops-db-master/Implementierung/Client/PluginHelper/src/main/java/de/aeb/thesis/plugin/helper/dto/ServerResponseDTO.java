package de.aeb.thesis.plugin.helper.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * A template for generating responses.
 */
@JsonInclude(Include.NON_NULL)
public class ServerResponseDTO {
	
	private String errorMessage;
	private String exception;
	
	private String message;
	private String databaseUrl;
	private String user;
	private String password;
	private List<String> databases;
	private Map<String, Map<String, Map<String, String>>> backups;
	
	public ServerResponseDTO() {
		//It is used for response.
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public String getException() {
		return exception;
	}
	
	public String getMessage() {
		return message;
	}

	public String getDatabaseUrl() {
		return databaseUrl;
	}

	public String getUser() {
		return user;
	}

	public String getPassword() {
		return password;
	}
	
	public List<String> getDatabases(){
		return databases;
	}
	
	public Map<String, Map<String, Map<String, String>>> getBackups(){
		return backups;
	}
	
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public void setException(String exception) {
		this.exception = exception;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public void setDatabaseUrl(String databaseUrl) {
		this.databaseUrl = databaseUrl;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setDatabases(List<String> databases) {
		this.databases = databases;
	}
	
	public void setBackups(Map<String, Map<String, Map<String, String>>> backups) {
		this.backups = backups;
	}
	
}