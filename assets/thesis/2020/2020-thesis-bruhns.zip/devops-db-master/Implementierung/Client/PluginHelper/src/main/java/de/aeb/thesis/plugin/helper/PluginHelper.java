package de.aeb.thesis.plugin.helper;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import com.google.gson.Gson;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListBackupsReqDTO;
import de.aeb.thesis.dto.request.ListDatabasesReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RequestDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.plugin.helper.dto.ServerResponseDTO;
import de.aeb.thesis.util.rest.RestUtil;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class PluginHelper {
	
	@FunctionalInterface
	public interface TriFunction<F, S, T, R> {
		public R apply(F first, S second, T third);
	}
	
	public static class ServerException extends RuntimeException {
		
		private final int statuscode;
		private final String exceptionMessageFromServer;
		
		public ServerException(int statuscode, String message, String exceptionMessageFromServer) {
			super(message);
			this.statuscode = statuscode;
			this.exceptionMessageFromServer = exceptionMessageFromServer;
		}
		
		public int getStatuscode() {
			return statuscode;
		}
		
		public String getExceptionMessageFromServer() {
			return exceptionMessageFromServer;
		}
	}
	
	private static final int STATUS_CODE_BAD_REQUEST = 400;
	private static final int STATUS_CODE_NOT_FOUND = 404;
	private static final int STATUS_CODE_INTERNAL_SERVER_ERROR = 500;
	
	private static final String EXCEPTION_MESSAGE_NOT_FOUND = "The server has not found anything matching the Request-URI.";
	
	private static Client client = ClientBuilder.newClient();
	
	private static TriFunction<String, String, RequestDTO, Response> postRequest = (url, path, dto) -> client
			.target(url)
			.path(path)
			.request(MediaType.APPLICATION_JSON)
			.post(Entity.entity(dto, MediaType.APPLICATION_JSON));
	
	private static Function<WebTarget, Response> getRequest = webTarget -> webTarget
			.request()
			.get();
	
	private static Function<WebTarget, Response> deleteRequest = webTarget -> webTarget
			.request()
			.delete();

	private static Function<Response, ServerResponseDTO> processResponse = resp -> {
		if(resp.getStatus() == STATUS_CODE_NOT_FOUND) {
			throw new ServerException(STATUS_CODE_NOT_FOUND, EXCEPTION_MESSAGE_NOT_FOUND, null);
		} else if(resp.getStatus() == STATUS_CODE_BAD_REQUEST || resp.getStatus() == STATUS_CODE_INTERNAL_SERVER_ERROR) {
			String result = resp.readEntity(String.class);
			ResponseDTO respDTO = new Gson().fromJson(result, ResponseDTO.class);
			throw new ServerException(resp.getStatus(), respDTO.getErrorMessage(), respDTO.getException());
		} else {
			return resp.readEntity(ServerResponseDTO.class);
		}
	};
	
	/**
	 * Prepares a request by setting parameters to the desired URL.
	 * @param params The parameters to be added to the URL
	 * @param url The URL to the server
	 * @param path The desired URL
	 * @return An instance of {@link WebTarget} which can executed.
	 */
	private static WebTarget prepareGetAndDeleteRequest(Map<String, String> params, String url, String path) {
		WebTarget webTarget = client.target(url).path(path);
		for(Entry<String, String> param : params.entrySet()) {
			webTarget = webTarget.queryParam(param.getKey(), param.getValue());
		}
		return webTarget;
	}
	
	/**
	 * Make a request to create an empty database.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the database to be created
	 * @param schema The schema of the database. This parameter must also be specified for NoSQL databases, even if it is not considered.
	 * @return An instance of {@link CreateDbRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static CreateDbRespDTO createDatabase(String url, String type, String databaseName, String schema) {
		CreateDbReqDTO dto = new CreateDbReqDTO(type, databaseName, schema);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_CREATE_EMPTY_DATABASE, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new CreateDbRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
	}
	
	/**
	 * Make a request to create a database with initial data.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the database to be created
	 * @param pathToData The path to the directory where the initial data is stored
	 * @return An instance of {@link CreateDbFromDataRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static CreateDbFromDataRespDTO createDatabaseFromData(String url, String type, String databaseName, String pathToData) {
		CreateDbFromDataReqDTO dto = new CreateDbFromDataReqDTO(type, databaseName, pathToData);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_CREATE_DATABASE, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new CreateDbFromDataRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
	}
	
	/**
	 * Make a request to create a database using a backup.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the database to be created
	 * @param backupName The name of the existing backup
	 * @return An instance of {@link CreateDbFromBackupRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static CreateDbFromBackupRespDTO createDatabaseFromBackup(String url, String type, String databaseName, String backupName) {
		CreateDbFromBackupReqDTO dto = new CreateDbFromBackupReqDTO(type, databaseName, backupName);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new CreateDbFromBackupRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
	}
	
	/**
	 * Make a request to clone an existing database.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param nameFirstDatabase The name of the existing database.
	 * @param nameSecondDatabase The name of the database to be created
	 * @return An instance of {@link CreateDbFromDbRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static CreateDbFromDbRespDTO createDatabaseFromDatabase(String url, String type, String nameFirstDatabase, String nameSecondDatabase) {
		CreateDbFromDbReqDTO dto = new CreateDbFromDbReqDTO(type, nameFirstDatabase, nameSecondDatabase);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_CLONE_DATABASE, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);		
		return new CreateDbFromDbRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
	}
	
	/**
	 * Make a request to reset an existing database using a backup.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the existing database
	 * @param backupName The name of the backup
	 * @return An instance of {@link RestoreDbRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static RestoreDbRespDTO restoreDatabase(String url, String type, String databaseName, String backupName) {
		RestoreDbReqDTO dto = new RestoreDbReqDTO(type, databaseName, backupName);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_RESET_DATABASE_FROM_BACKUP, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);	
		return new RestoreDbRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabaseUrl(), respDTO.getUser(), respDTO.getPassword());
	}
	
	/**
	 * Make a request to create a backup of an existing database.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the database
	 * @param backupName The name of the backup to created
	 * @param comment A comment on the creation of the backup
	 * @return An instance of {@link CreateBackupRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static CreateBackupRespDTO createDatabaseBackup(String url, String type, String databaseName, String backupName, String comment) {
		CreateBackupReqDTO dto = new CreateBackupReqDTO(type, databaseName, backupName, comment);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_CREATE_DATABASE_BACKUP, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new CreateBackupRespDTO(respDTO.getErrorMessage(), respDTO.getException());
	}
	
	/**
	 * Make a request to compare two existing backups.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param nameFirstBackup The name of the first backup
	 * @param nameSecondBackup The name of the second backup
	 * @return An instance of {@link BackupCompareRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static BackupCompareRespDTO compareBackups(String url, String type, String nameFirstBackup, String nameSecondBackup) {
		BackupCompareReqDTO dto = new BackupCompareReqDTO(type, nameFirstBackup, nameSecondBackup);
		Response resp = postRequest.apply(url, RestUtil.REST_PATH_COMPARE_BACKUPS, dto);
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new BackupCompareRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getMessage());
	}
	
	/**
	 * Make a request to delete a database.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the database to be deleted
	 * @param deleteAllBackups An option to delete all backups belonging to the database
	 * @return An instance of {@link DeleteDbRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static DeleteDbRespDTO deleteDatabase(String url, String type, String databaseName, boolean deleteAllBackups) {
		DeleteDbReqDTO dto = new DeleteDbReqDTO(type, databaseName, deleteAllBackups);
		Response resp = deleteRequest.apply(prepareGetAndDeleteRequest(dto.getParamsAsMap(), url, RestUtil.REST_PATH_DELETE_DATABASE));
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new DeleteDbRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getMessage(), respDTO.getBackups());
	}
	
	/**
	 * Make a request to delete an existing backup.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param name The name of the existing backup
	 * @return An instance of {@link DeleteBackupRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static DeleteBackupRespDTO deleteBackup(String url, String type, String name) {
		DeleteBackupReqDTO dto = new DeleteBackupReqDTO(type, name);
		Response resp = deleteRequest.apply(prepareGetAndDeleteRequest(dto.getParamsAsMap(), url, RestUtil.REST_PATH_DELETE_BACKUP));
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new DeleteBackupRespDTO(respDTO.getErrorMessage(), respDTO.getException());
	}
	
	/**
	 * Make a request to list all existing databases.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @return An instance of {@link ListDatabasesRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static ListDatabasesRespDTO listDatabases(String url, String type) {	
		ListDatabasesReqDTO dto = new ListDatabasesReqDTO(type);
		Response resp = getRequest.apply(prepareGetAndDeleteRequest(dto.getParamsAsMap(), url, RestUtil.REST_PATH_LIST_ALL_DATABASES));
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new ListDatabasesRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getDatabases());
	}
	
	/**
	 * Make a request to list all existing backups from an existing database.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @param databaseName The name of the existing database
	 * @return An instance of {@link ListDbBackupsRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static ListDbBackupsRespDTO listDatabaseBackups(String url, String type, String databaseName) {
		ListDbBackupsReqDTO dto = new ListDbBackupsReqDTO(type, databaseName);
		Response resp = getRequest.apply(prepareGetAndDeleteRequest(dto.getParamsAsMap(), url, RestUtil.REST_PATH_LIST_ALL_BACKUPS_FROM_DATABASE));
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new ListDbBackupsRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getBackups());
	}
	
	/**
	 * Make a request to list all existing backups.
	 * @param url The URL to the server
	 * @param type The specific Database Management System
	 * @return An instance of {@link ListBackupsRespDTO}.
	 * @throws ProcessingException - If the server is currently not available.
	 */
	public static ListBackupsRespDTO listBackups(String url, String type) {
		ListBackupsReqDTO dto = new ListBackupsReqDTO(type);
		Response resp = getRequest.apply(prepareGetAndDeleteRequest(dto.getParamsAsMap(), url, RestUtil.REST_PATH_LIST_ALL_BACKUPS));
		ServerResponseDTO respDTO = processResponse.apply(resp);
		return new ListBackupsRespDTO(respDTO.getErrorMessage(), respDTO.getException(), respDTO.getBackups());
	}
	
}