package de.aeb.thesis.server.database;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;

public interface DatabaseInterface {
	
	/**
	 * Creates an empty database using.
	 * @param resp An object of {@link CreateDbRespDTO} to create a answer
	 * @param req An object of {@link CreateDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO createDatabase(CreateDbRespDTO resp, CreateDbReqDTO req);
	
	/**
	 * Creates a database.
	 * @param resp An object of {@link CreateDbFromDataRespDTO} to create a answer
	 * @param req An object of {@link CreateDbFromDataReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO createDatabaseFromData(CreateDbFromDataRespDTO resp, CreateDbFromDataReqDTO req);
	
	/**
	 * Creates a database using a backup
	 * @param resp An object of {@link CreateDbFromBackupRespDTO} to create a answer
	 * @param req An object of {@link CreateDbFromBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO createDatabaseFromBackup(CreateDbFromBackupRespDTO resp, CreateDbFromBackupReqDTO req);
	
	/**
	 * Duplicates a database.
	 * @param resp An object of {@link CreateDbFromDbRespDTO} to create a answer
	 * @param req An object of {@link CreateDbFromDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO createDatabaseFromDatabase(CreateDbFromDbRespDTO resp, CreateDbFromDbReqDTO req);
	
	/**
	 * Restore an existing database from a backup. 
	 * @param resp An object of {@link RestoreDbRespDTO} to create a answer
	 * @param req An object of {@link RestoreDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO restoreDatabase(RestoreDbRespDTO resp, RestoreDbReqDTO req);
	
	/**
	 * Creates backup from a database. 
	 * @param resp An object of {@link CreateBackupRespDTO} to create a answer
	 * @param req An object of {@link CreateBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO createDatabaseBackup(CreateBackupRespDTO resp, CreateBackupReqDTO req);
	
	/**
	 * Compares two backups with each other.
	 * @param resp An object of {@link BackupCompareRespDTO} to create a answer
	 * @param req An object of {@link BackupCompareReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO compareBackups(BackupCompareRespDTO resp, BackupCompareReqDTO req);
	
	/**
	 * Deletes a database.
	 * @param resp An object of {@link DeleteDbRespDTO} to create a answer
	 * @param req An object of {@link DeleteDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO deleteDatabase(DeleteDbRespDTO resp, DeleteDbReqDTO req);
	
	/**
	 * Deletes a backup.
	 * @param resp An object of {@link DeleteBackupRespDTO} to create a answer
	 * @param req An object of {@link DeleteBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	ResponseDTO deleteBackup(DeleteBackupRespDTO resp, DeleteBackupReqDTO req);
	
	/**
	 * List all databases.
	 * @param resp An object of {@link ListDatabasesRespDTO} to create a answer
	 * @return A response for the client
	 */
	ResponseDTO listDatabases(ListDatabasesRespDTO resp);
	
	/**
	 * Lists all backups from a database.
	 * @param resp An object of {@link ListDbBackupsRespDTO} to create a answer
	 * @param req An object of {@link ListDbBackupsReqDTO} for the specific request from the client.
	 * @return
	 */
	ResponseDTO listDatabaseBackups(ListDbBackupsRespDTO resp, ListDbBackupsReqDTO req);
	
	/**
	 * Lists all backups.
	 * @param resp An object of {@link ListBackupsRespDTO} to create a answer
	 * @return A response for the client
	 */
	ResponseDTO listBackups(ListBackupsRespDTO resp);

}