package de.aeb.thesis.server.service.registry;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import de.aeb.thesis.server.database.mssql.MSSQL;

@SpringBootTest
class DatabaseRegistryTest {

	private static final String MSSQL_NAME = "MSSQL";
	private static final String TESTDB = "TESTDB";
	
	@Autowired
	DatabaseRegistry registry;
	
	@Autowired
	MSSQL mssql;
	
	@Test
	public void registeredInstanceIsIncluded() {
		registry.registerInstance(MSSQL_NAME, mssql);
		assertNotNull(registry.getInstance(MSSQL_NAME));
	}
	
	@Test
	public void nonRregisteredInstanceIsIncluded() {
		assertNull(registry.getInstance(TESTDB));
	}

}