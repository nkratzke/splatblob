package de.aeb.thesis.server.database.mongodb;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.server.database.DatabaseTest;

/**
 * All test cases for the component {@link MongoDB}.
 */
@SpringBootTest(
		properties = {
				"spring.data.mongodb.host=localhost", 
				"spring.data.mongodb.port=27017", 
				"spring.data.mongodb.backup.path=C\\:\\\\Users\\\\bru\\\\MongoDB\\\\Backups"
		}
)
public class MongoDBTest extends DatabaseTest {
	
	private static final String TYPE = "MONGODB";
	private static final String SCHEMA = "No Schema";
	
	public static final String PATH_TO_DATA = ".\\src\\test\\resources\\MongoDB\\Initial_Data_Sets";
	
	@Autowired
	MongoDB db;
	
	@Autowired
	private MongoClient client;
	
	  //////////////////////
	 // Required methods //
	//////////////////////
	
	@BeforeEach
	@AfterEach
	public void deleteTestDatabase() {
		DeleteDbReqDTO request = getDeleteDatabaseDTO(TYPE, DATABASE_NAME_ONE, false);
		db.deleteDatabase(new DeleteDbRespDTO(), request);
		request = getDeleteDatabaseDTO(TYPE, DATABASE_NAME_TWO, false);
		db.deleteDatabase(new DeleteDbRespDTO(), request);
	}
	
	@BeforeEach
	@AfterEach
	public void deleteTestBackup() {
		DeleteBackupReqDTO request = getDeleteBackupDTO(TYPE, BACKUP_NAME_ONE);
		db.deleteBackup(new DeleteBackupRespDTO(), request);
		request = getDeleteBackupDTO(TYPE, BACKUP_NAME_TWO);
		db.deleteBackup(new DeleteBackupRespDTO(), request);
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods createDatabase(...) //
	////////////////////////////////////////////////
	
	@Test
	public void createEmptyDatabase() {
		CreateDbRespDTO resp = new CreateDbRespDTO();
		createEmptyDatabase(db, resp, TYPE, SCHEMA);
		assertNull(resp.getErrorMessage());
		assertNotNull(resp.getDatabaseUrl());
		assertNotNull(resp.getUser());
		assertNotNull(resp.getPassword());
	}
	
	@Test
	public void createEmptySameDatabaseTwice() {
		CreateDbRespDTO resp = new CreateDbRespDTO();
		createEmptySameDatabaseTwice(db, resp, TYPE, SCHEMA);
		assertNotNull(resp.getErrorMessage());
	}
	
      ////////////////////////////////////////////////
     // Test cases for methods deleteDatabase(...) //
    ////////////////////////////////////////////////
    
    @Test
    public void deleteNonExistingDatabase() {
    	DeleteDbRespDTO resp = new DeleteDbRespDTO();
        deleteNonExistingDatabase(db, resp, TYPE);
        assertNotNull(resp.getErrorMessage());
    }
    
    @Test
    public void deleteExistingDatabaseWithoutBackups() {
    	DeleteDbRespDTO resp = new DeleteDbRespDTO();
        deleteExistingDatabaseWithoutBackups(db, resp, TYPE, SCHEMA);
        assertNull(resp.getErrorMessage());
    }
    
    @Test
    public void deleteExistingDatabaseWithAllBackups() {
    	DeleteDbRespDTO resp = new DeleteDbRespDTO();
        deleteExistingDatabaseWithAllBackups(db, resp, TYPE, SCHEMA);
        assertNull(resp.getErrorMessage());
        assertNull(resp.getBackups());
    }
    
    @Test
    public void deleteExistingDatabaseTwice() {
    	DeleteDbRespDTO resp = new DeleteDbRespDTO();
        deleteExistingDatabaseTwice(db, resp, TYPE, SCHEMA);
        assertNotNull(resp.getErrorMessage());
    }
    
      ///////////////////////////////////////////////
     // Test cases for methods listDatabases(...) //
    ///////////////////////////////////////////////
    
    @Test
    public void listAllDatabases() {
    	ListDatabasesRespDTO resp = new ListDatabasesRespDTO();
        listAllDatabases(db, resp, TYPE, SCHEMA);
        assertTrue(resp.getDatabases().contains(DATABASE_NAME_ONE));
    }
    
      //////////////////////////////////////////////////////
     // Test cases for methods createDatabaseBackup(...) //
    //////////////////////////////////////////////////////
    
    @Test
    public void createBackupFromNonExistingDatabase() {
    	CreateBackupRespDTO resp = new CreateBackupRespDTO();
        createBackupFromNonExistingDatabase(db, resp, TYPE);
        assertNotNull(resp.getErrorMessage());
    }
	
    @Test
    public void createBackupFromExistingDatabase() {
    	CreateBackupRespDTO resp = new CreateBackupRespDTO();
        createBackupFromExistingDatabase(db, resp, TYPE, SCHEMA);
        assertNull(resp.getErrorMessage());
    }
    
    @Test
    public void createBackupFromExistingDatabaseTwice() {
    	CreateBackupRespDTO resp = new CreateBackupRespDTO();
        createBackupFromExistingDatabaseTwice(db, resp, TYPE, SCHEMA);
        assertNotNull(resp.getErrorMessage());
    }
    
      //////////////////////////////////////////////
     // Test cases for methods deleteBackup(...) //
    //////////////////////////////////////////////
    
    @Test
    public void deleteNonExistingBackup() {
    	DeleteBackupRespDTO resp = new DeleteBackupRespDTO();
        deleteNonExistingBackup(db, resp, TYPE);
        assertNotNull(resp.getErrorMessage());
    }
    
    @Test
    public void deleteExistingBackup() {
    	DeleteBackupRespDTO resp = new DeleteBackupRespDTO();
        deleteExistingBackup(db, resp, TYPE, SCHEMA);
        assertNull(resp.getErrorMessage());
    }
    
    @Test
    public void deleteExistingBackupTwice() {
    	DeleteBackupRespDTO resp = new DeleteBackupRespDTO();
        deleteExistingBackupTwice(db, resp, TYPE, SCHEMA);
        assertNotNull(resp.getErrorMessage());
    }
    
     /////////////////////////////////////////////
    // Test cases for methods listBackups(...) //
   /////////////////////////////////////////////
   
   @Test
   public void listBackupContainsExistingBackup() throws JsonProcessingException {
	   ListBackupsRespDTO resp = new ListBackupsRespDTO();
       listBackupContainsExistingBackup(db, resp, TYPE, SCHEMA);
       assertTrue(new ObjectMapper().writeValueAsString(resp.getBackups()).contains(BACKUP_NAME_ONE));
   }
   
	  /////////////////////////////////////////////////////
	 // Test cases for methods listDatabaseBackups(...) //
	/////////////////////////////////////////////////////
	
	@Test
	public void listBackupFromDatabaseContainsExistingBackup() throws JsonProcessingException {
		ListDbBackupsRespDTO resp = new ListDbBackupsRespDTO();	
		listBackupFromDatabaseContainsExistingBackup(db, resp, TYPE, SCHEMA, SCHEMA);
		assertTrue(new ObjectMapper().writeValueAsString(resp.getBackups()).contains(BACKUP_NAME_ONE));
		assertFalse(new ObjectMapper().writeValueAsString(resp.getBackups()).contains(BACKUP_NAME_TWO));
	}
	
	  //////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromBackup(...) //
	//////////////////////////////////////////////////////////
	
	@Test
	public void createDatabaseFromExistingBackup() {
		CreateDbFromBackupRespDTO resp = new CreateDbFromBackupRespDTO();
	    createDatabaseFromExistingBackup(db, resp, TYPE, SCHEMA);
	    assertNull(resp.getErrorMessage());
	}
	
	@Test
	public void createDatabaseFromNonExistingBackup() {
		CreateDbFromBackupRespDTO resp = new CreateDbFromBackupRespDTO();
	    createDatabaseFromNonExistingBackup(db, resp, SCHEMA);
	    assertNotNull(resp.getErrorMessage());
	}
	
	@Test
	public void createExistingDatabaseFromExistingBackup() {
		CreateDbFromBackupRespDTO resp = new CreateDbFromBackupRespDTO();
	    createExistingDatabaseFromExistingBackup(db, resp, TYPE, SCHEMA);
	    assertNotNull(resp.getErrorMessage());
	}
	
	  /////////////////////////////////////////////////
	 // Test cases for methods restoreDatabase(...) //
	/////////////////////////////////////////////////
	
	@Test
	public void restoreDatabaseFromExistingBackup() {
		RestoreDbRespDTO resp = new RestoreDbRespDTO();
	    restoreDatabaseFromExistingBackup(db, resp, TYPE, SCHEMA);
	    assertNull(resp.getErrorMessage());
	}
	
	@Test
	public void restoreDatabaseFromNonExistingBackup() {
		RestoreDbRespDTO resp = new RestoreDbRespDTO();
	    restoreDatabaseFromNonExistingBackup(db, resp, TYPE);
	    assertNotNull(resp.getErrorMessage());
	}
	
	  ////////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromDatabase(...) //
	////////////////////////////////////////////////////////////
	
	@Test
	public void cloneExistingDatabaseToNonExistingDatabase() {
		CreateDbFromDbRespDTO resp = new CreateDbFromDbRespDTO();
	    cloneExistingDatabaseToNonExistingDatabase(db, resp, TYPE, SCHEMA);
	    assertNull(resp.getException());
	}
	
	@Test
	public void cloneNonExistingDatabaseToNonExistingDatabase() {
		CreateDbFromDbRespDTO resp = new CreateDbFromDbRespDTO();
	    cloneNonExistingDatabaseToNonExistingDatabase(db, resp, TYPE);
	    assertNotNull(resp.getErrorMessage());
	}
	
	@Test
	public void cloneDatabaseToExistingDatabase() {
		CreateDbFromDbRespDTO resp = new CreateDbFromDbRespDTO();
	    cloneDatabaseToExistingDatabase(db, resp, TYPE, SCHEMA, SCHEMA);
	    assertNotNull(resp.getErrorMessage());
	}
	
	  ////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromData(...) //
	////////////////////////////////////////////////////////
	
	@Test
	public void createDatabase() {
		CreateDbFromDataRespDTO resp = new CreateDbFromDataRespDTO();
		createDatabase(db, resp, TYPE, PATH_TO_DATA);
		assertNull(resp.getErrorMessage());
		assertNotNull(resp.getDatabaseUrl());
		assertNotNull(resp.getUser());
		assertNotNull(resp.getPassword());
	}
	
	@Test
	public void createSameDatabaseTwice() {
		CreateDbFromDataRespDTO resp = new CreateDbFromDataRespDTO();
		createDatabase(db, new CreateDbFromDataRespDTO(), TYPE, PATH_TO_DATA);
		createDatabase(db, resp, TYPE, PATH_TO_DATA);
		assertNotNull(resp.getErrorMessage());
		assertNull(resp.getDatabaseUrl());
		assertNull(resp.getUser());
		assertNull(resp.getPassword());
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods compareBackups(...) //
	////////////////////////////////////////////////
	
	@Test
	public void compareTwoBackups() {
		BackupCompareRespDTO resp = new BackupCompareRespDTO();
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_ONE, SCHEMA);
		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		BackupCompareReqDTO request = getBackupCompareDTO(TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
	    db.compareBackups(resp, request);
	    assertTrue(resp.getMessage().equals(MESSAGE_BACKUPS_EQUALS));
	}
	
	@Test
	public void compareTwoBackupsReadAccessBeetweenComparison() {
		BackupCompareRespDTO resp = new BackupCompareRespDTO();
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_ONE, SCHEMA);
		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		MongoDatabase database = client.getDatabase(DATABASE_NAME_ONE);
		database.listCollections();
		requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		BackupCompareReqDTO request = getBackupCompareDTO(TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
	    db.compareBackups(resp, request);
	    assertTrue(resp.getMessage().equals(MESSAGE_BACKUPS_EQUALS));
	}
	
	@Test
	public void compareBackupsTwiceWriteAccessBeetweenComparison() {
		BackupCompareRespDTO resp = new BackupCompareRespDTO();
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_ONE, SCHEMA);
		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		MongoDatabase database = client.getDatabase(DATABASE_NAME_ONE);
		database.createCollection(TYPE);
		requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		BackupCompareReqDTO request = getBackupCompareDTO(TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
	    db.compareBackups(resp, request);
	    assertTrue(resp.getMessage().equals(MESSAGE_BACKUPS_NOT_EQUALS));
	}
	
	@Test
	public void compareNonExistingBackups() {
		BackupCompareRespDTO resp = new BackupCompareRespDTO();
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_ONE, SCHEMA);		
	    db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    BackupCompareReqDTO request = getBackupCompareDTO(TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
	    db.compareBackups(resp, request);
	    assertNull(resp.getException());
	}
	
	@Test
	public void backupsFromDifferentDatabasesAreAlwaysDifferent() {
		BackupCompareRespDTO resp = new BackupCompareRespDTO();
		
		//Create first database and backup
	    CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_ONE, SCHEMA); 
	    CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		//Create second database and backup
	    requestForCreationDatabase = getCreateDbDTO(TYPE, DATABASE_NAME_TWO, SCHEMA); 
	    requestForCreationBackup = getCreateBackupDTO(TYPE, DATABASE_NAME_TWO, BACKUP_NAME_TWO, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
	    BackupCompareReqDTO request = getBackupCompareDTO(TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO);
	    db.compareBackups(resp, request);
	    assertTrue(resp.getMessage().equals(MESSAGE_BACKUPS_NOT_EQUALS));
	}
	
}