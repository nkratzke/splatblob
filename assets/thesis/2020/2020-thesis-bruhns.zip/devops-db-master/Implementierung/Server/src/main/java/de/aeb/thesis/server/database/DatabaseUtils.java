package de.aeb.thesis.server.database;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.codec.digest.DigestUtils;

import de.aeb.thesis.dto.response.BackupCompareRespDTO;

/**
 * A utility class for the components which interact with a database.
 */
public class DatabaseUtils {
	
	public static final String ERROR_BACKUP_ALREADY_EXISTS = "A backup with this name already exists.";
	public static final String ERROR_BACKUP_DOESNT_EXISTS = "The backup with the specified name does not exist.";
	public static final String ERROR_BACKUPS_COULD_NOT_LIST = "Backups cannot be queried.";
	public static final String ERROR_COMPARISON_FAILED = "The comparison of the two backups failed.";
	public static final String ERROR_CREATION_BACKUP_FAILED = "Creation the backup failed.";
	public static final String ERROR_CREATION_DATABASE_FAILED = "Creation the database failed.";
	public static final String ERROR_CREATION_DATABASE_USING_DATA_FAILED = "Not all commands of the script could be executed. It is not allowed that a line begins with a space. A SQL command may not be defined over several lines. It is possible that the database was partially created. The database may have to be deleted before the request can be executed again.";
	public static final String ERROR_CLONE_DATABASE_FAILED = "Duplicating the backup failed.";
	public static final String ERROR_DATABASE_ALREADY_EXISTS = "The database exists with the specified name."; 
	public static final String ERROR_DATABASE_DOESNT_EXISTS = "The database with the specified name does not exist.";
	public static final String ERROR_DELETE_BACKUP_FAILED = "Deletion the backup failed.";
	public static final String ERROR_DELETE_DATABASE_FAILED = "Deletion the database failed.";
	public static final String ERROR_LIST_DATABASES_FAILED = "List all databases failed.";
	public static final String ERROR_LOAD_INFO_FAILED = "Backup information could not be loaded.";
	public static final String ERROR_RESTORE_DATABASE_FAILED = "The database could not be set to the state of the backup.";
	
	public static final String MESSAGE_BACKUPS_EQUALS = "The backups are identical.";
	public static final String MESSAGE_BACKUPS_NOT_EQUALS = "The backups are not identical.";
	public static final String MESSAGE_LIST_ALL_DELETED_BACKUPS = "All deleted backups are listed by name.";
	
	public static final String COMMENT = "Comment";
	public static final String DATE = "Date";
	
	private DatabaseUtils() {
		//only static methods
	}
	
	/**
	 * Compares the files of two backups.
	 * @param resp An object of {@link BackupCompareRespDTO} to create the answer
	 * @param firstBackupPath The path to the files of the first backup 
	 * @param secondBackupPath The path to the files of the second backup
	 * @param firstBackupFiles A list of all files from the first backup
	 * @param secondBackupFiles A list of all files from the second backup
	 * @throws IOException - If an error occurs when determining the checksum
	 */
	public static void compareBackupFiles(BackupCompareRespDTO resp, Path firstBackupPath, Path secondBackupPath, List<String> firstBackupFiles, List<String> secondBackupFiles) throws IOException {
		if(firstBackupFiles.size() == secondBackupFiles.size()) {
			
			Iterator<String> firstBackupIt = firstBackupFiles.iterator();
			Iterator<String> secondBackupIt = secondBackupFiles.iterator();
			
			while(firstBackupIt.hasNext() && secondBackupIt.hasNext()) {
				String firstBackupFileChecksum = DatabaseUtils.getFileChecksum(firstBackupPath.resolve(firstBackupIt.next()).toFile());
				String secondBackupFileChecksum = DatabaseUtils.getFileChecksum(secondBackupPath.resolve(secondBackupIt.next()).toFile());
				
				if(!firstBackupFileChecksum.equals(secondBackupFileChecksum)) {
					resp.setMessage(MESSAGE_BACKUPS_NOT_EQUALS);
					return;
				}
			}
			
			resp.setMessage(MESSAGE_BACKUPS_EQUALS);
		} else {
			resp.setMessage(MESSAGE_BACKUPS_NOT_EQUALS);
		}
	}
	
	/**
	 * Sorts a list of files alphabetically.
	 * @param path The path to the file
	 * @return An alphabetically sorted list of files
	 */
	public static List<String> sortListOfFiles(Path path) {
		return Arrays.asList(path.toFile().list())
				.stream()
				.sorted()
				.collect(Collectors.toList());
	}
	
	/**
	 * Determines the checksum of a file.
	 * @param file The desired file
	 * @return The checksum of the file.
	 * @throws IOException - If an error occurs when determining the checksum
	 */
	public static String getFileChecksum(File file) throws IOException {
		return DigestUtils.md5Hex(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
	}
	
}