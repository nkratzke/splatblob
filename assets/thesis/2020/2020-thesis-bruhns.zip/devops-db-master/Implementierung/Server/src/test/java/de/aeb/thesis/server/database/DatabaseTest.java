package de.aeb.thesis.server.database;

import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.server.ServerTest;

/**
 * This class provides methods which can use the test classes of components interacting with a database. 
 * Every database system should implement the functionalities provided by the server. 
 * Therefore, the test cases for these functionalities can be abstracted.
 * The names of the methods provided in this class correspond to the names of the test cases from the test classes and are self-explanatory.
 */
public abstract class DatabaseTest extends ServerTest {
	
      //////////////////////////////////////////////////////////////////////////
     // General functions for the test cases for methods createDatabase(...) //
    ///////////////////////////////////////////////////////////////////////////
    
    public void createEmptyDatabase(DatabaseInterface db, CreateDbRespDTO resp, String type, String schema) {
    	CreateDbReqDTO request = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
    	db.createDatabase(resp, request);
    }

    public void createEmptySameDatabaseTwice(DatabaseInterface db, CreateDbRespDTO resp, String type, String schema) {
    	CreateDbReqDTO request = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
    	db.createDatabase(resp, request);
    	db.createDatabase(resp, request);
    }
    
      //////////////////////////////////////////////////////////////////////////
     // General functions for the test cases for methods deleteDatabase(...) //
    //////////////////////////////////////////////////////////////////////////
  
    public void deleteNonExistingDatabase(DatabaseInterface db, DeleteDbRespDTO resp, String type) {
    	DeleteDbReqDTO request = getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false);
    	db.deleteDatabase(resp, request);
    }
  
    public void deleteExistingDatabaseWithoutBackups(DatabaseInterface db, DeleteDbRespDTO resp, String type, String schema) {
    	CreateDbReqDTO requestForCreation = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
    	DeleteDbReqDTO requestForDeletion = getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false);
    	db.createDatabase(new CreateDbRespDTO(), requestForCreation);
    	db.deleteDatabase(resp, requestForDeletion);
    }
    
    public void deleteExistingDatabaseWithAllBackups(DatabaseInterface db, DeleteDbRespDTO resp, String type, String schema) {
    	CreateDbReqDTO requestForDbCreation = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
    	CreateBackupReqDTO requestForBackupCreation = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
    	DeleteDbReqDTO requestForDeletion = getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, true);
    	ListDbBackupsReqDTO requestListBackupsFromDb = getListDbBackupsDTO(type, DATABASE_NAME_ONE);
    	db.createDatabase(new CreateDbRespDTO(), requestForDbCreation);
    	db.createDatabaseBackup(new CreateBackupRespDTO(), requestForBackupCreation);
    	db.deleteDatabase(resp, requestForDeletion);
    	resp.setBackups(null);
    	db.listDatabaseBackups(new ListDbBackupsRespDTO(), requestListBackupsFromDb);
    }
 
    public void deleteExistingDatabaseTwice(DatabaseInterface db, DeleteDbRespDTO resp, String type, String schema) {
    	CreateDbReqDTO requestForCreation = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
    	DeleteDbReqDTO requestForDeletion = getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false);
    	db.createDatabase(new CreateDbRespDTO(), requestForCreation);
    	db.deleteDatabase(resp, requestForDeletion);
    	db.deleteDatabase(resp, requestForDeletion);
    }
      
      /////////////////////////////////////////////////////////////////////////
     // General functions for the test cases for methods listDatabases(...) //
    /////////////////////////////////////////////////////////////////////////
  
  	public void listAllDatabases(DatabaseInterface db, ListDatabasesRespDTO resp, String type, String schema) {
  		CreateDbReqDTO request = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
  		db.createDatabase(new CreateDbRespDTO(), request);
      	db.listDatabases(resp);
  	}
  
      ////////////////////////////////////////////////////////////////////////////////
  	 // General functions for the test cases for methods createDatabaseBackup(...) //
  	////////////////////////////////////////////////////////////////////////////////
  
  	public void createBackupFromNonExistingDatabase(DatabaseInterface db, CreateBackupRespDTO resp, String type) {
  		CreateBackupReqDTO request = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
  		db.createDatabaseBackup(resp, request);
  	}
	
  	public void createBackupFromExistingDatabase(DatabaseInterface db, CreateBackupRespDTO resp, String type, String schema) {	
  		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
  		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT) ;
      	db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
      	db.createDatabaseBackup(resp, requestForCreationBackup);
   	}
  
  	public void createBackupFromExistingDatabaseTwice(DatabaseInterface db, CreateBackupRespDTO resp, String type, String schema) {
	  	CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
  		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
  		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
  		db.createDatabaseBackup(resp, requestForCreationBackup);
  		db.createDatabaseBackup(resp, requestForCreationBackup);
  	}
  
      ////////////////////////////////////////////////////////////////////////
     // General functions for the test cases for methods deleteBackup(...) //
  	////////////////////////////////////////////////////////////////////////
  
  	public void deleteNonExistingBackup(DatabaseInterface db, DeleteBackupRespDTO resp, String type) {
  		DeleteBackupReqDTO request = getDeleteBackupDTO(type, BACKUP_NAME_ONE);
  		db.deleteBackup(resp, request);
  	}	
  
  	public void deleteExistingBackup(DatabaseInterface db, DeleteBackupRespDTO resp, String type, String schema) {
  		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
  		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
  		DeleteBackupReqDTO requestForDeletion = getDeleteBackupDTO(type, BACKUP_NAME_ONE);
  		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
  		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
  		db.deleteBackup(resp, requestForDeletion);
  	}
  
  	public void deleteExistingBackupTwice(DatabaseInterface db, DeleteBackupRespDTO resp, String type, String schema) {
  		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
  		CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
  		DeleteBackupReqDTO requestForDeletion = getDeleteBackupDTO(type, BACKUP_NAME_ONE);
  		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
  		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
      	db.deleteBackup(resp, requestForDeletion);
      	db.deleteBackup(resp, requestForDeletion);
  	}
      
      ///////////////////////////////////////////////////////////////////////
     // General functions for the test cases for methods listBackups(...) //
    ///////////////////////////////////////////////////////////////////////
     
  	public void listBackupContainsExistingBackup(DatabaseInterface db, ListBackupsRespDTO resp, String type, String schema) {
  		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
        CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
        db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
        db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
        db.listBackups(resp);
     }	
	
	  ///////////////////////////////////////////////////////////////////////////////
	 // General functions for the test cases for methods listDatabaseBackups(...) //
	///////////////////////////////////////////////////////////////////////////////
	
	public void listBackupFromDatabaseContainsExistingBackup(DatabaseInterface db, ListDbBackupsRespDTO resp, String type, String dbSchemaOne, String dbSchemaTwo) {
		//Create first database and backup
	    CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, dbSchemaOne); 
	    CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		//Create second database and backup
	    requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_TWO, dbSchemaTwo); 
	    requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_TWO, COMMENT);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
		
		ListDbBackupsReqDTO request = getListDbBackupsDTO(type, DATABASE_NAME_ONE);
		db.listDatabaseBackups(resp, request);
	}

	  ////////////////////////////////////////////////////////////////////////////////////
	 // General functions for the test cases for methods createDatabaseFromBackup(...) //
	////////////////////////////////////////////////////////////////////////////////////
	
	public void createDatabaseFromExistingBackup(DatabaseInterface db, CreateDbFromBackupRespDTO resp, String type, String schema) {
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
	    CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
	    db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
	    CreateDbFromBackupReqDTO request = getCreateDbFromBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE);
	    db.createDatabaseFromBackup(resp, request);
	}
	
	public void createDatabaseFromNonExistingBackup(DatabaseInterface db, CreateDbFromBackupRespDTO resp, String type) {
	    CreateDbFromBackupReqDTO request = getCreateDbFromBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE);
	    db.createDatabaseFromBackup(resp, request);
	}
	
	public void createExistingDatabaseFromExistingBackup(DatabaseInterface db, CreateDbFromBackupRespDTO resp, String type, String schema) {
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
	    CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
	    db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
	    CreateDbFromBackupReqDTO request = getCreateDbFromBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
	    db.createDatabaseFromBackup(resp, request);
	}

	  ///////////////////////////////////////////////////////////////////////////
	 // General functions for the test cases for methods restoreDatabase(...) //
	///////////////////////////////////////////////////////////////////////////
	
	public void restoreDatabaseFromExistingBackup(DatabaseInterface db, RestoreDbRespDTO resp, String type, String schema) {
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema); 
	    CreateBackupReqDTO requestForCreationBackup = getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT);
	    db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    db.createDatabaseBackup(new CreateBackupRespDTO(), requestForCreationBackup);
	    RestoreDbReqDTO request = getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
	    db.restoreDatabase(resp, request);
	}
	
	public void restoreDatabaseFromNonExistingBackup(DatabaseInterface db, RestoreDbRespDTO resp, String type) {
		RestoreDbReqDTO request = getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE);
	    db.restoreDatabase(resp, request);
	}
	
	  //////////////////////////////////////////////////////////////////////////////////////
	 // General functions for the test cases for methods createDatabaseFromDatabase(...) //
	//////////////////////////////////////////////////////////////////////////////////////
	
	public void cloneExistingDatabaseToNonExistingDatabase(DatabaseInterface db, CreateDbFromDbRespDTO resp, String type, String schema) {
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, schema);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
		CreateDbFromDbReqDTO request = getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
	    db.createDatabaseFromDatabase(resp, request);
	}
	
	public void cloneNonExistingDatabaseToNonExistingDatabase(DatabaseInterface db, CreateDbFromDbRespDTO resp, String type) {
		CreateDbFromDbReqDTO request = getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
	    db.createDatabaseFromDatabase(resp, request);
	}
	
	public void cloneDatabaseToExistingDatabase(DatabaseInterface db, CreateDbFromDbRespDTO resp, String type, String dbSchemaOne, String dbSchemaTwo) {
		CreateDbReqDTO requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_ONE, dbSchemaOne);
		db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    requestForCreationDatabase = getCreateDbDTO(type, DATABASE_NAME_TWO, dbSchemaTwo);
	    db.createDatabase(new CreateDbRespDTO(), requestForCreationDatabase);
	    CreateDbFromDbReqDTO request = getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO);
	    db.createDatabaseFromDatabase(resp, request);
	}
	
	  //////////////////////////////////////////////////////////////////////////////////
	 // General functions for the test cases for methods createDatabaseFromData(...) //
	//////////////////////////////////////////////////////////////////////////////////
	
	public void createDatabase(DatabaseInterface db, CreateDbFromDataRespDTO resp, String type, String pathToData) {
		CreateDbFromDataReqDTO req = getCreateDbFromDataDTO(type, DATABASE_NAME_ONE, pathToData);
		db.createDatabaseFromData(resp, req);
	}
	
	public void createSameDatabaseTwice(DatabaseInterface db, CreateDbFromDataRespDTO resp, String type, String pathToData) {
		CreateDbFromDataReqDTO req = getCreateDbFromDataDTO(type, DATABASE_NAME_ONE, pathToData);
		db.createDatabaseFromData(new CreateDbFromDataRespDTO(), req);
		db.createDatabaseFromData(resp, req);
	}	
}