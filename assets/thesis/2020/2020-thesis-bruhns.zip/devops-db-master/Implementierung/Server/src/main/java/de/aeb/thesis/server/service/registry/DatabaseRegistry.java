package de.aeb.thesis.server.service.registry;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import de.aeb.thesis.server.database.DatabaseInterface;

/**
 * A helper class for the registry pattern.
 * All components that have direct access to databases are managed.
 */
@Component("registry")
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class DatabaseRegistry {
	
	@Autowired
	private Map<String, DatabaseInterface> databaseInstances;
	
	/**
	 * Registers a component, that have direct access to a database.
	 * @param type The unique name of the component
	 * @param db An object of this component
	 */
	public void registerInstance(String type, DatabaseInterface db) {
		databaseInstances.put(type, db);
	}
	
	/**
	 * Return the desired component.
	 * @param type The unique name of the component
	 * @return The object of the component or null if the component is not registered.
	 */
	public DatabaseInterface getInstance(String type) {
		return databaseInstances.get(type);
	}
}