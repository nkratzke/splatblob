package de.aeb.thesis.server;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.service.registry.DatabaseRegistry;

/**
 * The starting point of the server.
 */
@SpringBootApplication
public class Server {
	
	public static void main(String[] args) throws IOException {
		ApplicationContext context = SpringApplication.run(Server.class, args);
		registerIncludedDatabases(context);
	}

	/**
	 * Registers all components that have direct access to a database.
	 * @param context The {@link ApplicationContext} of Spring
	 * @throws IOException - If the components cannot be determined or registered.
	 * @throws BeansException - If a desired component does not exist.
	 */
	private static void registerIncludedDatabases(ApplicationContext context) throws IOException, BeansException {
		try {
			Path path = Paths.get("src").resolve("main").resolve("resources").resolve("included_databases.txt");
			List<String> dbs = Files.readAllLines(path);
			DatabaseRegistry registry = (DatabaseRegistry) context.getBean("registry");
			dbs.forEach(db -> registry.registerInstance(db, (DatabaseInterface) context.getBean(db)));
		} catch (BeansException e) {
			throw new IOException("No interaction with the specified database.", e);
		} catch (IOException e) {
			throw new IOException("The file with the database names that the server can operate cannot be loaded.", e);
		}		

	}
	
}