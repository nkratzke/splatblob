package de.aeb.thesis.server.database;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Configuration class for components that operate directly with a database.
 */
@Configuration
public class DatabaseConfiguration {
	
	/**
	 * Returns all stored commands for MSSQL.
	 * @return The commands represented in a map as key command entries.
	 * @throws IOException - If the file in which the commands are stored could not be opened.
	 */
	@Bean(name = "mssqlCommands")
	@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
	public Map<String, String> getMSSQLCommands() throws IOException{
		File commands = Paths.get("src").resolve("main").resolve("resources").resolve("mssql_commands.json").toFile();
		return getCommands(commands);
	}
	
	/**
	 * Returns all stored commands for MongoDB.
	 * @return The commands represented in a map as key command entries.
	 * @throws IOException - If the file in which the commands are stored could not be opened.
	 */
	@Bean(name = "mongodbCommands")
	@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
	public Map<String, String> getMongoDBCommands() throws IOException{
		File commands = Paths.get("src").resolve("main").resolve("resources").resolve("mongodb_commands.json").toFile();
		return getCommands(commands);
	}
	
	/**
	 * Returns all stored commands for the given database.
	 * @param commands An object of {@link File} containing all commands
	 * @return The commands represented in a map as key command entries.
	 * @throws IOException - If the file in which the commands are stored could not be opened.
	 */
	private Map<String, String> getCommands(File commands) throws IOException {
		try {
			return new ObjectMapper().readValue(commands , HashMap.class);
		} catch (IOException e) {
			throw new IOException("File containing the db commands could not be loaded.", e);
		}
	}
	
}