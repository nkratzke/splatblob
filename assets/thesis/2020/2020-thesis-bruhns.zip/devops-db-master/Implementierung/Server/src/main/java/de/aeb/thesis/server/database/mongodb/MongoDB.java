package de.aeb.thesis.server.database.mongodb;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.dto.util.AuthenticationDTO;
import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.database.DatabaseUtils;

@Component("MONGODB")
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
@PropertySource("classpath:application.properties")
public class MongoDB implements DatabaseInterface {
	
	private static final String INFO_FILE_NAME = "information.txt";
	private static final String DATE_FILE_NAME = "date.txt";
	private static final String COLLECTION_DEFAULT = "default";
	private static final String AUTHORIZATION_NOT_REQUIRED = "Authorization is not required";
	
	@Autowired
	private MongoClient client;
	
	@Autowired
	@Value("${spring.data.mongodb.host}")
	private String host;
	@Autowired
	@Value("${spring.data.mongodb.port}")
	private String port;
	@Autowired
	@Value("${spring.data.mongodb.backup.path}")
	String pathToBackups;
	
	@Autowired
	Map<String,String> mongodbCommands;
	
	@Override
	public ResponseDTO createDatabase(CreateDbRespDTO resp, CreateDbReqDTO req) {
		if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
		} else {
			MongoDatabase db = client.getDatabase(req.getDatabaseName());
			db.createCollection(COLLECTION_DEFAULT);
			resp.setAccessData(setAccessDataToResponse());
		}
		return resp;
	}
	
	@Override
	public ResponseDTO createDatabaseFromBackup(CreateDbFromBackupRespDTO resp, CreateDbFromBackupReqDTO req) {
		try {
    		if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
    			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
    		} else {
    			restoreDatabase(resp, req.getDatabaseName(), req.getBackupName());
    			resp.setAccessData(setAccessDataToResponse());
    		}
		} catch (IOException | InterruptedException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_RESTORE_DATABASE_FAILED);
			resp.setException(e.getMessage());
			Thread.currentThread().interrupt();
		}
		return resp;
	}

	@Override
	public ResponseDTO createDatabaseFromData(CreateDbFromDataRespDTO resp, CreateDbFromDataReqDTO req) {
		if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
		} else {
			try {
				JSONParser parser = new JSONParser();
				MongoDatabase db = client.getDatabase(req.getDatabaseName());
				Path pathToInitialData = Path.of(req.getPathToData());
				List<File> listOfCollections = List.of(pathToInitialData.toFile().listFiles());
				for(File collection : listOfCollections) {
					if(Files.isDirectory(collection.toPath())) {
						db.createCollection(collection.getName());
						List<File> listOfDocuments = List.of(collection.listFiles());
						for(File document : listOfDocuments) {
							if(!Files.isDirectory(document.toPath())) {
								JSONObject object = (JSONObject) parser.parse(new FileReader(document.getAbsolutePath()));
								Document doc = Document.parse(object.toJSONString());
								db.getCollection(collection.getName()).insertOne(doc);
							}
						}
					}
				}
    			resp.setAccessData(setAccessDataToResponse());
			} catch (IOException | ParseException e) {
				resp.setErrorMessage(DatabaseUtils.ERROR_CREATION_DATABASE_FAILED);
				resp.setException(e.getMessage());
			}
		}
		return resp;
	}

	@Override
	public ResponseDTO deleteDatabase(DeleteDbRespDTO resp, DeleteDbReqDTO req) {
		if(checkIfDatabaseAlreadyExist(req.getName())) {
			client.getDatabase(req.getName()).drop();
			if(req.getDeleteAllBackups()) {
				resp.setBackups(listAllBackups(req.getName()));
				if(resp.getBackups() != null && resp.getBackups().containsKey(req.getName())) {
					Set<String> allBackups = resp.getBackups().get(req.getName()).keySet();
					for(String backupName : allBackups) {
						try {
							deleteBackup(getBackupPath(backupName));
						} catch (IOException e) {
							resp.setErrorMessage(DatabaseUtils.ERROR_DELETE_BACKUP_FAILED);
							resp.setException(e.getMessage());;
						}
					}
					resp.setMessage(DatabaseUtils.MESSAGE_LIST_ALL_DELETED_BACKUPS);
				}
			}
		} else {
			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
		}
		return resp;
	}
	
	@Override
	public ResponseDTO createDatabaseFromDatabase(CreateDbFromDbRespDTO resp, CreateDbFromDbReqDTO req) {		
		try {
    		if(checkIfDatabaseAlreadyExist(req.getNameFirstDatabase())) {
    			if(checkIfDatabaseAlreadyExist(req.getNameSecondDatabase())) {
    				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
    			} else {
    				String backupName = req.getNameFirstDatabase().concat((new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date())));
    				createDatabaseBackup(req.getNameFirstDatabase(), backupName, "");
    				restoreDatabase(resp, req.getNameSecondDatabase(), backupName);
    				deleteBackup(getBackupPath(backupName));
    				resp.setAccessData(setAccessDataToResponse());
    			}
    		} else {
    			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
    		}
		} catch (IOException | InterruptedException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CLONE_DATABASE_FAILED);
			resp.setException(e.getMessage());
			Thread.currentThread().interrupt();
		}
		
		return resp;
	}
	
	@Override
	public ResponseDTO listDatabases(ListDatabasesRespDTO resp) {
		MongoCursor<String> dbs = client.listDatabaseNames().iterator();
		List<String> results = new ArrayList<>();
		
		while(dbs.hasNext()) {
			results.add(dbs.next());
		}
		
		if(!results.isEmpty()) {
			resp.setDatabases(results);
		}
		
		return resp;
	}

	@Override
	public ResponseDTO createDatabaseBackup(CreateBackupRespDTO resp, CreateBackupReqDTO req) {
		try {
			if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
				if(getBackupPath(req.getBackupName()) == null) {
					createDatabaseBackup(req.getDatabaseName(), req.getBackupName(), req.getComment());
				} else {
					resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_ALREADY_EXISTS);
				}
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
			}
		} catch (IOException | InterruptedException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CREATION_BACKUP_FAILED);
			resp.setException(e.getMessage());
			Thread.currentThread().interrupt();
		}
		
		return resp;
	}

	@Override
	public ResponseDTO compareBackups(BackupCompareRespDTO resp, BackupCompareReqDTO req) {
		try {		
			Path firstBackupPath = getBackupPath(req.getNameFirstBackup());
			Path secondBackupPath = getBackupPath(req.getNameSecondBackup());
			if(firstBackupPath == null || secondBackupPath == null) {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			} else {
				firstBackupPath = firstBackupPath.resolve(firstBackupPath.getParent().getFileName());
				secondBackupPath = secondBackupPath.resolve(secondBackupPath.getParent().getFileName());
				
				List<String> firstBackupFiles = DatabaseUtils.sortListOfFiles(firstBackupPath);
				List<String> secondBackupFiles = DatabaseUtils.sortListOfFiles(secondBackupPath);
				
				DatabaseUtils.compareBackupFiles(resp, firstBackupPath, secondBackupPath, firstBackupFiles, secondBackupFiles);
			}
		} catch (IOException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_COMPARISON_FAILED);
			resp.setException(e.getMessage());
		}
		
		return resp;
	}

	@Override
	public ResponseDTO deleteBackup(DeleteBackupRespDTO resp, DeleteBackupReqDTO req) {
		try {
			Path backupSourcePath = getBackupPath(req.getName());
			if(backupSourcePath == null) {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			} else {
				deleteBackup(backupSourcePath);
			}
		} catch (IOException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_DELETE_BACKUP_FAILED);
			resp.setException(e.getMessage());
		}
		return resp;
	}

	@Override
	public ResponseDTO listBackups(ListBackupsRespDTO resp) {
		resp.setBackups(listAllBackups(null));
		return resp;
	}

	@Override
	public ResponseDTO listDatabaseBackups(ListDbBackupsRespDTO resp, ListDbBackupsReqDTO req) {
		resp.setBackups(listAllBackups(req.getDatabaseName()));
		return resp;
	}

	@Override
	public ResponseDTO restoreDatabase(RestoreDbRespDTO resp, RestoreDbReqDTO req) {
		try {
    		if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
    			MongoDatabase db = client.getDatabase(req.getDatabaseName());
    			try(MongoCursor<String> collections = db.listCollectionNames().iterator()) {
        			restoreDatabase(resp, req.getDatabaseName(), req.getBackupName());
        			if(resp.getErrorMessage() == null) {
        				while(collections.hasNext()) {
        					db.getCollection(collections.next()).drop();
        				}
        			}
        			resp.setAccessData(setAccessDataToResponse());
    			}
    		} else {
    			resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
    		}
		}  catch (IOException | InterruptedException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_RESTORE_DATABASE_FAILED);
			resp.setException(e.getMessage());
			Thread.currentThread().interrupt();
		}
		return resp;
	}
	
	/**
	 * The access data is added to the object of {@link AuthenticationDTO}.
	 * @return An object of {@link AuthenticationDTO}.
	 */
	private AuthenticationDTO setAccessDataToResponse() {
		return new AuthenticationDTO(String.join(":", host, port), AUTHORIZATION_NOT_REQUIRED, AUTHORIZATION_NOT_REQUIRED);
	}
	
	/**
	 * Checks whether a database with the specified name already exists.
	 * @param name The name of the database
	 * @return true, if the database with the specified name already exists.
	 */
	private boolean checkIfDatabaseAlreadyExist(String name) {
		try(MongoCursor<String> dbs = client.listDatabaseNames().iterator()) {
			while(dbs.hasNext()) {
				if(name.equals(dbs.next())) {
					return true;
				}
			}
			return false;
		}
	}
	
	/**
	 * Creates a backup of a database.
	 * @param databaseName The name of the database
	 * @param backupName The name of the backup
	 * @param comment A comment for the backup
	 * @throws IOException - If an error occurs during the creation of the backup.
	 * @throws InterruptedException - If the specific command of MongoDB fails.
	 */
	private void createDatabaseBackup(String databaseName, String backupName, String comment) throws IOException, InterruptedException {
		Path backupDestinationPath = Path.of(pathToBackups).resolve(databaseName).resolve(backupName);
		Runtime.getRuntime()
			.exec(String.format(mongodbCommands.get("MONGO_DUMP"), host, port, databaseName, backupDestinationPath.toString()))
			.waitFor();
		Files.writeString(backupDestinationPath.resolve(INFO_FILE_NAME), comment);
		Files.writeString(backupDestinationPath.resolve(DATE_FILE_NAME), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
	}
	
	/**
	 * Deletes a backup.
	 * @param backupSourcePath The absolute path to the backup
	 * @throws IOException - If an error occurs during the deletion of the backup.
	 */
	private void deleteBackup(Path backupSourcePath) throws IOException {
		Path parent = backupSourcePath.getParent();
		FileUtils.forceDelete(backupSourcePath.toFile());
		if(parent.toFile().list().length == 0) Files.deleteIfExists(parent);
	}
	
	/**
	 * A database is restored to the state of a specified backup. If the database does not exist, the database will be created.
	 * @param resp An object of {@link ResponseDTO} to create the answer
	 * @param databaseName The name of the database
	 * @param backupName The name of the backup
	 * @return The object of {@link ResponseDTO} 
	 * @throws IOException - If an error occurs during the restore of the backup.
	 * @throws InterruptedException - If the specific command of MongoDB fails.
	 */
	private ResponseDTO restoreDatabase(ResponseDTO resp, String databaseName, String backupName) throws IOException, InterruptedException {
			Path backupSourcePath = getBackupPath(backupName);
			if(backupSourcePath != null) {
				backupSourcePath = backupSourcePath.resolve(backupSourcePath.getParent().getFileName());
				Runtime.getRuntime()
					.exec(String.format(mongodbCommands.get("MONGO_RESTORE"), host, port, databaseName, backupSourcePath.toString()))
					.waitFor();
			} else {					
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			}
		return resp;
	}
	
	/**
	 * Determines the path of a backup.
	 * @param backupName The name of the backup
	 * @return The path of the backup or null if the backups does not exists.
	 * @throws IOException - If an error occurs during the determination of the path.
	 */
	private Path getBackupPath(String backupName) throws IOException {
		List<Path> result = new ArrayList<>();
		try(Stream<Path> walk = Files.walk(Paths.get(pathToBackups))) {	
			result = walk
					.filter(Files::isDirectory)
					.filter(file -> backupName.equals(file.getFileName().toString()))
					.collect(Collectors.toList());
		}
		return result.isEmpty() ? null : result.get(0);
	}
	
	/**
	 * All backups are listed according to the parameter databaseName.
	 * @param resp An object of {@link ResponseDTO} to create the answer
	 * @param databaseName The name of the database
	 * @return An overview over all backups.
	 */
	private Map<String, Map<String, Map<String, String>>> listAllBackups(String databaseName) {	
		Map<String, Map<String, Map<String, String>>> allBackups = new HashMap<>();
		for(String db : Paths.get(pathToBackups).toFile().list()) {
			if(databaseName == null || databaseName.equals(db)) {
				Map<String, Map<String, String>> backupsFromSameDB = new HashMap<>();
				for(String backup : Paths.get(pathToBackups).resolve(db).toFile().list()) {
					Map<String, String> backupInformations = new HashMap<>();
					try {
						Path pathToInfoFile = Paths.get(pathToBackups).resolve(db).resolve(backup).resolve(INFO_FILE_NAME);
						backupInformations.put(DatabaseUtils.COMMENT, Files.readAllLines(pathToInfoFile).stream().collect(Collectors.joining("\n")));
					} catch (IOException e) {
						backupInformations.put(DatabaseUtils.COMMENT, DatabaseUtils.ERROR_LOAD_INFO_FAILED);
					}
					
					try {
						Path pathToInfoFile = Paths.get(pathToBackups).resolve(db).resolve(backup).resolve(DATE_FILE_NAME);
						backupInformations.put(DatabaseUtils.DATE, Files.readAllLines(pathToInfoFile).stream().collect(Collectors.joining("\n")));
					} catch (IOException e) {
						backupInformations.put(DatabaseUtils.DATE, DatabaseUtils.ERROR_LOAD_INFO_FAILED);
					}
					backupsFromSameDB.put(backup, backupInformations);
				}
				allBackups.put(db, backupsFromSameDB);
			}
		}
		
		return allBackups;
	}
	
} 