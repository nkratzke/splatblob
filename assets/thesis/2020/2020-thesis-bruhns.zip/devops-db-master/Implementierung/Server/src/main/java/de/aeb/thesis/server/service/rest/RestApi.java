package de.aeb.thesis.server.service.rest;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListBackupsReqDTO;
import de.aeb.thesis.dto.request.ListDatabasesReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.server.service.ApiInterface;
import de.aeb.thesis.server.service.service.DatabaseService;
import de.aeb.thesis.util.rest.RestUtil;

/**
 * The interface of the server to which a client can send a request.
 */
@RestController
public class RestApi implements ApiInterface {
	
	private static final String MESSAGE_MISSING_PARAMETERS = "Parameters are missing.";
	private DatabaseService service;
	
	@Autowired
	public RestApi(DatabaseService service) {
		this.service = service;
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_CREATE_DATABASE, consumes = "application/json")
	public ResponseEntity<ResponseDTO> createDatabaseFromData(@RequestBody CreateDbFromDataReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.createDatabaseFromData(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP, consumes = "application/json")
	public ResponseEntity<ResponseDTO> createDatabaseFromBackup(@RequestBody CreateDbFromBackupReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.createDatabaseFromBackup(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_CREATE_EMPTY_DATABASE)
	public ResponseEntity<ResponseDTO> createDatabase(@RequestBody CreateDbReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.createDatabase(json);
	}
	
	@DeleteMapping(value = RestUtil.REST_PATH_DELETE_DATABASE)
	public ResponseEntity<ResponseDTO> deleteDatabase(@RequestParam Map<String, String> parameters) {
		return deleteDatabase(new ObjectMapper().convertValue(parameters, DeleteDbReqDTO.class));
	}
	
	@Override
	public ResponseEntity<ResponseDTO> deleteDatabase(@RequestBody DeleteDbReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.deleteDatabase(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_CLONE_DATABASE)
	public ResponseEntity<ResponseDTO> createDatabaseFromDatabase(@RequestBody CreateDbFromDbReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.createDatabaseFromDatabase(json);
	}
	
	@GetMapping(value = RestUtil.REST_PATH_LIST_ALL_DATABASES)
	public ResponseEntity<ResponseDTO> listDatabases(@RequestParam Map<String, String> parameters) {
		return listDatabases(new ObjectMapper().convertValue(parameters, ListDatabasesReqDTO.class));
	}
	
	@Override
	public ResponseEntity<ResponseDTO> listDatabases(@RequestBody ListDatabasesReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.listDatabases(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_COMPARE_BACKUPS, consumes = "application/json")
	public ResponseEntity<ResponseDTO> compareBackups(@RequestBody BackupCompareReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.compareBackups(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_CREATE_DATABASE_BACKUP, consumes = "application/json")
	public ResponseEntity<ResponseDTO> createDatabaseBackup(@RequestBody CreateBackupReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.createDatabaseBackup(json);
	}
	
	@DeleteMapping(value = RestUtil.REST_PATH_DELETE_BACKUP)
	public ResponseEntity<ResponseDTO> deleteBackup(@RequestParam Map<String, String> parameters) {
		return deleteBackup(new ObjectMapper().convertValue(parameters, DeleteBackupReqDTO.class));
	}
	
	@Override
	public ResponseEntity<ResponseDTO> deleteBackup(@RequestBody DeleteBackupReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.deleteBackup(json);
	}
	
	@GetMapping(value = RestUtil.REST_PATH_LIST_ALL_BACKUPS)
	public ResponseEntity<ResponseDTO> listBackups(@RequestParam Map<String, String> parameters) {
		return listBackups(new ObjectMapper().convertValue(parameters, ListBackupsReqDTO.class));
	}
	
	@Override
	public ResponseEntity<ResponseDTO> listBackups(ListBackupsReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.listBackups(json);
	}

	@GetMapping(value = RestUtil.REST_PATH_LIST_ALL_BACKUPS_FROM_DATABASE)
	public ResponseEntity<ResponseDTO> listDatabaseBackups(@RequestParam Map<String, String> parameters) {
		return listDatabaseBackups(new ObjectMapper().convertValue(parameters, ListDbBackupsReqDTO.class));
	}
	
	@Override
	public ResponseEntity<ResponseDTO> listDatabaseBackups(ListDbBackupsReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.listDatabaseBackups(json);
	}
	
	@Override
	@PostMapping(value = RestUtil.REST_PATH_RESET_DATABASE_FROM_BACKUP, consumes = "application/json")
	public ResponseEntity<ResponseDTO> restoreDatabase(@RequestBody RestoreDbReqDTO json) {
		return json.isComplete() ? generateErrorMessage() : service.restoreDatabase(json);
	}
	
	/**
	 * Generates a error response which is returned to the client.
	 * @return The error response for the client.
	 */
	private ResponseEntity<ResponseDTO> generateErrorMessage() {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(new ResponseDTO(MESSAGE_MISSING_PARAMETERS));	
	}
	
}