package de.aeb.thesis.server.service;

import org.springframework.http.ResponseEntity;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListBackupsReqDTO;
import de.aeb.thesis.dto.request.ListDatabasesReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.server.service.rest.RestApi;
import de.aeb.thesis.server.service.service.DatabaseService;

/**
 * An interface that provides the unified methods of {@link RestApi} and {@link DatabaseService} of the server.
 */
public interface ApiInterface {
	
	/**
	 * Creates an empty database using.
	 * @param request An object of {@link CreateDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> createDatabase(CreateDbReqDTO request);
	
	/**
	 * Creates a database.
	 * @param request An object of {@link CreateDbFromDataReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> createDatabaseFromData(CreateDbFromDataReqDTO request);
	
	/**
	 * Creates a database using a backup.
	 * @param request An object of {@link CreateDbFromBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> createDatabaseFromBackup(CreateDbFromBackupReqDTO request);
	
	/**
	 * Duplicates a database.
	 * @param request An object of {@link CreateDbFromDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> createDatabaseFromDatabase(CreateDbFromDbReqDTO request);
	
	/**
	 * Restore an existing database from a backup. 
	 * @param request An object of {@link RestoreDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> restoreDatabase(RestoreDbReqDTO request);
	
	/**
	 * Creates backup from a database.
	 * @param request An object of {@link CreateBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> createDatabaseBackup(CreateBackupReqDTO request);
	
	/**
	 * Compares two backups with each other.
	 * @param request An object of {@link BackupCompareReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> compareBackups(BackupCompareReqDTO request);
	
	/**
	 * Deletes a database.
	 * @param request An object of {@link DeleteDbReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> deleteDatabase(DeleteDbReqDTO request);
	
	/**
	 * Deletes a backup.
	 * @param request An object of {@link DeleteBackupReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> deleteBackup(DeleteBackupReqDTO request);
	
	/**
	 * List all databases.
	 * @param request An object of {@link ListDatabasesReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> listDatabases(ListDatabasesReqDTO request);
	
	/**
	 * Lists all backups from a database.
	 * @param request An object of {@link ListDbBackupsReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> listDatabaseBackups(ListDbBackupsReqDTO request);
	
	/**
	 * Lists all backups.
	 * @param request An object of {@link ListBackupsReqDTO} for the specific request from the client.
	 * @return A response for the client
	 */
	public ResponseEntity<ResponseDTO> listBackups(ListBackupsReqDTO request);

	
}