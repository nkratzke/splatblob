package de.aeb.thesis.server;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListBackupsReqDTO;
import de.aeb.thesis.dto.request.ListDatabasesReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;

/**
 * This class provides methods to get a specific request. 
 */
public abstract class ServerTest {
	
	public static final String DATABASE_NAME_ONE = "TestDatabase_HelloWorld";
	public static final String DATABASE_NAME_TWO = "TestDatabase_HelloGermany";
	public static final String DATABASE_SCHEMA_ONE = "HelloWorld";
	public static final String DATABASE_SCHEMA_TWO = "HelloGermany";
	
	public static final String BACKUP_NAME_ONE = "TestBackup_HelloWorld";
	public static final String BACKUP_NAME_TWO = "TestBackup_HelloGermany";
	
	public static final String COMMENT = "Only created for the tests";
	
	public static final String MESSAGE_BACKUPS_EQUALS = "The backups are identical.";
	public static final String MESSAGE_BACKUPS_NOT_EQUALS = "The backups are not identical.";
	
	  //////////////////////
	 // Required methods //
	//////////////////////
	
	public BackupCompareReqDTO getBackupCompareDTO(String type, String nameFirstBackup, String nameScondBackup) {
		return new BackupCompareReqDTO(type, nameFirstBackup, nameScondBackup);
	}
	
	public CreateDbFromDbReqDTO getCreateDbFromDbDTO(String type, String nameFirstDatabase, String nameSecondDatabase) {
		return new CreateDbFromDbReqDTO(type, nameFirstDatabase, nameSecondDatabase);
	}
	
	public CreateBackupReqDTO getCreateBackupDTO(String type, String databaseName, String backupName, String comment) {
		return new CreateBackupReqDTO(type, databaseName, backupName, comment);
	}
	
	public CreateDbFromDataReqDTO getCreateDbFromDataDTO(String type, String databaseName, String pathToData) {
		return new CreateDbFromDataReqDTO(type, databaseName, pathToData);
	}
	
	public CreateDbFromBackupReqDTO getCreateDbFromBackupDTO(String type, String databaseName, String backupName) {
		return new CreateDbFromBackupReqDTO(type, databaseName, backupName);
	}
	
	public CreateDbReqDTO getCreateDbDTO(String type, String databaseName, String schema) {
		return new CreateDbReqDTO(type, databaseName, schema);
	}
	
	public DeleteBackupReqDTO getDeleteBackupDTO(String type, String name) {
		return new DeleteBackupReqDTO(type, name);
	}
	
	public DeleteDbReqDTO getDeleteDatabaseDTO(String type, String name, boolean deleteAllBackups) {
		return new DeleteDbReqDTO(type, name, deleteAllBackups);
	}
	
	public ListDatabasesReqDTO getListDatabasesDTO(String type) {
		return new ListDatabasesReqDTO(type);
	}
	
	public ListBackupsReqDTO getListBackupsDTO(String type) {
		return new ListBackupsReqDTO(type);
	}
	
	public ListDbBackupsReqDTO getListDbBackupsDTO(String type, String databaseName) {
		return new ListDbBackupsReqDTO(type, databaseName);
	}
	
	public RestoreDbReqDTO getRestoreDbDTO(String type, String databaseName, String backupName) {
		return new RestoreDbReqDTO(type, databaseName, backupName);
	}
	
}