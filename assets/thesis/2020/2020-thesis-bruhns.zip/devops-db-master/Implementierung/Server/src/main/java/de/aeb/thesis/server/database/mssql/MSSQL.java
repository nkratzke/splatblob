package de.aeb.thesis.server.database.mssql;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.dto.util.AuthenticationDTO;
import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.database.DatabaseUtils;

@Component("MSSQL")
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
@PropertySource("classpath:application.properties")
public class MSSQL implements DatabaseInterface {
	
	private static final String DATE_FORMAT = "yyyy_MM_dd_HH_mm_ss";
	private static final String CSV_FILE = "%s.csv";
	
	@Autowired
	@Value("${mssql.db.url}")
	private String url;
	@Autowired
	@Value("${mssql.db.name}")
	private String servername;
	@Autowired
	@Value("${mssql.db.user}")
	private String user;
	@Autowired
	@Value("${mssql.db.password}")
	private String password;
	@Autowired
	@Value("${mssql.db.path.databases}")
	private String pathToDatabases;
	@Autowired
	@Value("${mssql.db.path.backups}")
	private String pathToBackups;
	@Autowired
	@Value("${mssql.db.path.export.files}")
	private String pathToExportFiles;
	
	@Autowired
	Map<String,String> mssqlCommands;
	
	/**
	 * Creates a connection to the database server.
	 * @return The connection to the database server.
	 * @throws SQLException - If an error occurs during the establishing the connection.
	 */
	private Connection createConnection() throws SQLException {
		DriverManager.registerDriver(new SQLServerDriver());
    	return DriverManager.getConnection(url, user, password);
	}

	@Override
	public ResponseDTO createDatabase(CreateDbRespDTO resp, CreateDbReqDTO req) {
		try(Connection connection = createConnection()) { 
			if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
			} else {
    			connection.setAutoCommit(false);
    			try(Statement stmt = connection.createStatement()) {
    				stmt.execute(String.format(mssqlCommands.get("CREATE_DATABASE"), req.getDatabaseName()));
    				stmt.execute(String.format(mssqlCommands.get("USE_DATABASE"), req.getDatabaseName()));
    				stmt.execute(String.format(mssqlCommands.get("CREATE_SCHEMA"), req.getSchema()));
    			}
    			
    			connection.commit();
    			resp.setAccessData(setAccessDataToResponse());
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CREATION_DATABASE_FAILED);
			resp.setException(e.getMessage());
		}
		
		return resp;
	}
	
	@Override
	public ResponseDTO createDatabaseFromBackup(CreateDbFromBackupRespDTO resp, CreateDbFromBackupReqDTO req) {
		try {
			if(checkIfBackupAlreadyExist(req.getBackupName())) {
				if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) { 
					resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
				} else {
					restoreDatabase(req.getDatabaseName(), req.getBackupName());
					resp.setAccessData(setAccessDataToResponse());
				}
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_RESTORE_DATABASE_FAILED);
			resp.setException(e.getMessage());
		}
		
		return resp;
	}

	@Override
	public ResponseDTO createDatabaseFromData(CreateDbFromDataRespDTO resp, CreateDbFromDataReqDTO req) {
		try(Connection connection = createConnection()) {
			if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
			} else {
				List<String> commands = Files.readAllLines(Path.of(req.getPathToData()));
				commands.removeIf(s -> s.startsWith(" ") || s.length() == 0);
				try(Statement stmt = connection.createStatement()) {
	    			connection.setAutoCommit(false);
    				for(String command : commands) {
    					stmt.execute(command);
    				}
        			connection.commit();
					resp.setAccessData(setAccessDataToResponse());
				}
			}
		} catch (SQLException | IOException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CREATION_DATABASE_USING_DATA_FAILED);
			resp.setException(e.getMessage());
		}
		return resp;
	}

	@Override
	public ResponseDTO deleteDatabase(DeleteDbRespDTO resp, DeleteDbReqDTO req) {
		try {
			if(checkIfDatabaseAlreadyExist(req.getName())) {
				deleteDatabase(req.getName());
				if(req.getDeleteAllBackups()) {
					resp.setBackups(listBackups(String.format(mssqlCommands.get("LIST_ALL_BACKUPS_FROM_DATABASE"), req.getName())));
					if(resp.getBackups() != null && resp.getBackups().containsKey(req.getName())) {
						Set<String> allBackups = resp.getBackups().get(req.getName()).keySet();
    					for(String backupName : allBackups) {
    						deleteBackup(backupName);
    					}
    					resp.setMessage(DatabaseUtils.MESSAGE_LIST_ALL_DELETED_BACKUPS);
					}
				}
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
			}
    	} catch (SQLException | IOException e) {
    		resp.setErrorMessage(DatabaseUtils.ERROR_DELETE_DATABASE_FAILED.concat(e.getMessage()));
    		resp.setException(e.getMessage());
    	}
		
		return resp;
	}
	
	@Override
	public ResponseDTO createDatabaseFromDatabase(CreateDbFromDbRespDTO resp, CreateDbFromDbReqDTO req) {
		try {
			if(checkIfDatabaseAlreadyExist(req.getNameFirstDatabase())) {
				if(checkIfDatabaseAlreadyExist(req.getNameSecondDatabase())) {
					resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_ALREADY_EXISTS);
				} else {
					try (Connection connection = createConnection();
							Statement stmt = connection.createStatement()) {
						stmt.execute(String.format(mssqlCommands.get("USE_DATABASE"), req.getNameFirstDatabase()));
						stmt.execute(String.format(mssqlCommands.get("CLONE_DATABASE"), req.getNameFirstDatabase(), req.getNameSecondDatabase()));
					}
					resp.setAccessData(setAccessDataToResponse());
				}
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CLONE_DATABASE_FAILED);
			resp.setException(e.getMessage());
		}
		return resp;
	}
	
	@Override
	public ResponseDTO listDatabases(ListDatabasesRespDTO resp) {
		try (Connection connection = createConnection();
				Statement stmt = connection.createStatement();
				ResultSet res = stmt.executeQuery(mssqlCommands.get("LIST_DATABASES"))) {
			List<String> result = new ArrayList<>();
			while (res.next()) {
				result.add(res.getString(1));
			}
			
			if (!result.isEmpty()) {
				resp.setDatabases(result);
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_LIST_DATABASES_FAILED);
			resp.setException(e.getMessage());
		}
		return resp;
	}
	
	@Override
	public ResponseDTO createDatabaseBackup(CreateBackupRespDTO resp, CreateBackupReqDTO req) {
		try {
			if(checkIfBackupAlreadyExist(req.getBackupName())) {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_ALREADY_EXISTS);
			} else {
				if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
					try (Connection connection = createConnection();
							Statement stmt = connection.createStatement()) {
						String request = String.format(mssqlCommands.get("CREATE_BACKUP"), 
								req.getDatabaseName(), 
								req.getBackupName(), 
								req.getComment(),
								req.getBackupName());
						stmt.execute(request);
					}
				} else {
					resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
				}
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_CREATION_BACKUP_FAILED);
			resp.setException(e.getMessage());
		}
		
		return resp;
	}
	
	@Override
	public ResponseDTO compareBackups(BackupCompareRespDTO resp, BackupCompareReqDTO req) {
		try {
			if(checkIfBackupAlreadyExist(req.getNameFirstBackup()) || checkIfBackupAlreadyExist(req.getNameSecondBackup())) {
				String firstDatabaseName = req.getNameFirstBackup().concat((new SimpleDateFormat(DATE_FORMAT).format(new Date())));
				String secondDatabaseName = req.getNameSecondBackup().concat((new SimpleDateFormat(DATE_FORMAT).format(new Date())));
				try {
					restoreDatabase(firstDatabaseName, req.getNameFirstBackup());
					restoreDatabase(secondDatabaseName, req.getNameSecondBackup());
				
    				if(checkIfSchemasAreEquals(firstDatabaseName, secondDatabaseName)) {
    					resp.setMessage(DatabaseUtils.MESSAGE_BACKUPS_NOT_EQUALS);
    				} else {
    					Path exportFilesFirstDbPath = createExportFiles(firstDatabaseName);
    					Path exportFilesSecondDbPath = createExportFiles(secondDatabaseName);
    					
    					List<String> firstDbFiles = DatabaseUtils.sortListOfFiles(exportFilesFirstDbPath);
    					List<String> secondDbFiles = DatabaseUtils.sortListOfFiles(exportFilesSecondDbPath);
    					
    					DatabaseUtils.compareBackupFiles(resp, exportFilesFirstDbPath, exportFilesSecondDbPath, firstDbFiles, secondDbFiles);

						FileUtils.forceDelete(exportFilesFirstDbPath.toFile());
						FileUtils.forceDelete(exportFilesSecondDbPath.toFile());
    				}
				} finally {
					deleteDatabase(firstDatabaseName);
					deleteDatabase(secondDatabaseName);
				}

			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			}
		} catch (SQLException | IOException | InterruptedException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_COMPARISON_FAILED);
			resp.setException(e.getMessage());
			Thread.currentThread().interrupt();
		}
		return resp;
	}
	
	@Override
	public ResponseDTO deleteBackup(DeleteBackupRespDTO resp, DeleteBackupReqDTO req) {
		try {
			if(checkIfBackupAlreadyExist(req.getName())) {
    			deleteBackup(req.getName());
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			}
		} catch (SQLException | IOException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_DELETE_BACKUP_FAILED);
			resp.setException(e.getMessage());
		}		
		
		return resp;
	}

	@Override
	public ResponseDTO restoreDatabase(RestoreDbRespDTO resp, RestoreDbReqDTO req) {		
		try {
			if(checkIfBackupAlreadyExist(req.getBackupName())) {
				if(checkIfDatabaseAlreadyExist(req.getDatabaseName())) {
					deleteDatabase(req.getDatabaseName());
					restoreDatabase(req.getDatabaseName(), req.getBackupName());
					resp.setAccessData(setAccessDataToResponse());
				} else {
					resp.setErrorMessage(DatabaseUtils.ERROR_DATABASE_DOESNT_EXISTS);
				}
			} else {
				resp.setErrorMessage(DatabaseUtils.ERROR_BACKUP_DOESNT_EXISTS);
			}
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_RESTORE_DATABASE_FAILED);
			resp.setException(e.getMessage());
		}	
		
		return resp;
	}

	@Override
	public ResponseDTO listBackups(ListBackupsRespDTO resp) {
		try {
			resp.setBackups(listBackups(mssqlCommands.get("LIST_ALL_BACKUPS")));
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_BACKUPS_COULD_NOT_LIST);
			resp.setException(e.getMessage());
		}
		return resp;
	}

	@Override
	public ResponseDTO listDatabaseBackups(ListDbBackupsRespDTO resp, ListDbBackupsReqDTO req) {
		try {
			resp.setBackups(listBackups(String.format(mssqlCommands.get("LIST_ALL_BACKUPS_FROM_DATABASE"), req.getDatabaseName())));
		} catch (SQLException e) {
			resp.setErrorMessage(DatabaseUtils.ERROR_BACKUPS_COULD_NOT_LIST);
			resp.setException(e.getMessage());
		}
		return resp;
	}
	
	/**
	 * The access data is added to the object of {@link AuthenticationDTO}.
	 * @return An object of {@link AuthenticationDTO}.
	 */
	private AuthenticationDTO setAccessDataToResponse() {
		return new AuthenticationDTO(url, user, password);
	}
	
	/**
	 * Checks whether a database with the specified name already exists.
	 * @param name The name of the database
	 * @return true, if the database with the specified name already exists.
	 */
	private boolean checkIfDatabaseAlreadyExist(String name) throws SQLException {
		try(Connection connection = createConnection();
				Statement stmt = connection.createStatement();
				ResultSet res = stmt.executeQuery(String.format(mssqlCommands.get("SELECT_DATABASE_BY_NAME"), name))) {
			return res.next();
		}
	}
	
	/**
	 * Checks whether a backup with the specified name already exists.
	 * @param name The name of the database
	 * @return true, if the backup with the specified name already exists.
	 * @throws SQLException - If an error occurs during the check.
	 */
	private boolean checkIfBackupAlreadyExist(String name) throws SQLException {
		try(Connection connection = createConnection();
				Statement stmt = connection.createStatement();
    			ResultSet res = stmt.executeQuery(String.format(mssqlCommands.get("SELECT_BACKUP_BY_NAME"), name))) {
    				return res.next();
		}
	}
	
	/**
	 * Deletes a database. 
	 * @param name The name of the database
	 * @throws SQLException - If an error occurs during the deletion.
	 */
	private void deleteDatabase(String name) throws SQLException {
		try(Connection connection = createConnection();
				Statement stmt = connection.createStatement()) {
			stmt.execute(String.format(mssqlCommands.get("DELETE_DATABASE"), name));
		}
	}
	
	/**
	 * Deletes a backup.
	 * @param name The name of the backup
	 * @throws SQLException If an error occurs during the deletion of entries.
	 * @throws IOException If an error occurs during the deletion of the backup file.
	 */
	private void deleteBackup(String name) throws SQLException, IOException {
		try(Connection connection = createConnection()) {
			connection.setAutoCommit(false);
			try(Statement stmt = connection.createStatement()) {
				stmt.execute(String.format(mssqlCommands.get("DELETE_BACKUP_FILEGROUP"), name));
				stmt.execute(String.format(mssqlCommands.get("DELETE_BACKUP_FILE"), name));
				stmt.execute(String.format(mssqlCommands.get("DELETE_RESTORE_FILEGROUP"), name));
				stmt.execute(String.format(mssqlCommands.get("DELETE_RESTORE_FILE"), name));
				stmt.execute(String.format(mssqlCommands.get("DELETE_RESTORE_FILEHISTOREY"), name));
				stmt.execute(String.format(mssqlCommands.get("DELETE_BACKUP"), name));
			}
			connection.commit();
			
			Files.delete(Path.of(pathToBackups).resolve(name.concat(".bak")));
		}
	}
	
	/**
	 * A database is restored to the state of a specified backup.
	 * @param databaseName The name of the database
	 * @param backupName The name of the backup
	 * @throws SQLException - If an error occurs during the restore of backup.
	 */
	private void restoreDatabase(String databaseName, String backupName) throws SQLException {
		List<String> result = new ArrayList<>();
		try (Connection connection = createConnection()) {
			try(Statement stmt = connection.createStatement();
					ResultSet res = stmt.executeQuery(String.format(mssqlCommands.get("RESTORE_FILELISTONLY"), backupName))) {
				while (res.next()) {
					result.add(res.getString("LogicalName"));
				}
			}
			
			try(Statement stmt = connection.createStatement()) {
				Path path = Path.of(pathToDatabases);				
				String request = String.format(mssqlCommands.get("RESTORE_DATABASE"), 
						databaseName,
						backupName, 
						result.get(0), 
						path.resolve(databaseName), 
						result.get(1), 
						path.resolve(databaseName));
				stmt.execute(request);
			}
		}
	}
	
	/**
	 * Lists all backups according to the request.
	 * @param resp An object of {@link ResponseDTO} to create the answer
	 * @param request The specific request that is executed.
	 * @return An overview over all backups.
	 * @throws SQLException 
	 */
	private Map<String, Map<String, Map<String, String>>> listBackups(String request) throws SQLException {
		try (Connection connection = createConnection();
				Statement stmt = connection.createStatement();
				ResultSet res = stmt.executeQuery(request)) {
			Map<String, Map<String, Map<String, String>>> allBackups = new HashMap<>();
			
			while (res.next()) {
				String databaseName = res.getString(1);
				String backupName = res.getString(2);
				String comment = res.getString(3);
				String date = res.getString(4);
						
				Map<String, String> backupInformations = new HashMap<>();
				backupInformations.put(DatabaseUtils.COMMENT, comment);
				backupInformations.put(DatabaseUtils.DATE, date);
				
				if (allBackups.containsKey(databaseName)) {
					allBackups.get(databaseName).put(backupName, backupInformations);
				} else {
					Map<String, Map<String, String>> backupsFromSameDB = new HashMap<>();
					backupsFromSameDB.put(backupName, backupInformations);
					allBackups.put(databaseName, backupsFromSameDB);
				}
			}
			
			return allBackups;
		}
	}
	
	/**
	 * Checks whether the schemas of two databases are equal.
	 * @param firstDatabaseName The name of the first database
	 * @param secondDatabaseName The name of the second database
	 * @return true if the schemas are equals.
	 * @throws SQLException - If an error occurs during the check.
	 */
	private boolean checkIfSchemasAreEquals(String firstDatabaseName, String secondDatabaseName) throws SQLException {
		try (Connection connection = createConnection();
				Statement stmt = connection.createStatement();
				ResultSet res = stmt.executeQuery(String.format(mssqlCommands.get("COMPARE_EXPECT_INFORMATION_SCHEMA"), firstDatabaseName, secondDatabaseName))) {
			if (res.next()) {
				return true;
			} else {
				try (ResultSet res2 = stmt.executeQuery(
						String.format(mssqlCommands.get("COMPARE_EXPECT_INFORMATION_SCHEMA"), secondDatabaseName, firstDatabaseName))) {
					return res2.next();
				}
			}
		}
	}
	
	/**
	 * Exports the tables of a database to CSV files.
	 * @param databaseName The name of the database
	 * @return true The path where the files are stored
	 * @throws SQLException - If the table names and the schema cannot be retrieved.
	 * @throws IOException - If an error occurs during the creation of the directory of the files.
	 * @throws InterruptedException - If an error occurs during the creation of the files.
	 */
	private Path createExportFiles(String databaseName) throws SQLException, IOException, InterruptedException {
		Map<String, String> tables = new HashMap<>();
		
		try (Connection connection = createConnection();
				Statement stmt = connection.createStatement();
				ResultSet res = stmt.executeQuery(String.format(mssqlCommands.get("SELECT_ALL_TABLES"), databaseName))) {
			while (res.next()) {
				tables.put(res.getString(1), res.getString(2));
			}
		}
		
		Path exportFilesPath = Path.of(pathToExportFiles);
		Path exportFilesDbPath = exportFilesPath.resolve(databaseName);
		
		Files.createDirectories(exportFilesDbPath);
		
		for(Entry<String, String> entry : tables.entrySet()) {			
			Runtime.getRuntime()
			.exec(String.format(mssqlCommands.get("BCP"), 
					databaseName,
					entry.getValue(),
					entry.getKey(),
					exportFilesDbPath.resolve(String.format(CSV_FILE, entry.getKey())),
					servername,
					user,
					password
				))
			.waitFor();
		}
		
		return exportFilesDbPath;
	}
	
}