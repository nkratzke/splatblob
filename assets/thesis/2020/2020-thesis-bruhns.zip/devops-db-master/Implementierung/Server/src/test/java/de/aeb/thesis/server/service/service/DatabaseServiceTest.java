package de.aeb.thesis.server.service.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;

import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.server.ServerTest;
import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.database.mongodb.MongoDBTest;
import de.aeb.thesis.server.database.mssql.MSSQLTest;
import de.aeb.thesis.server.service.registry.DatabaseRegistry;

/**
 * All test cases for the component {@link DatabaseService}.
 */
@SpringBootTest(
		properties = {
				"mssql.db.url=jdbc\\:sqlserver\\://PC-XDDEV0222\\\\XE4AEBDEV", 
				"mssql.db.user=bru", "mssql.db.password=bru", 
				"mssql.db.path.databases=C\\:\\\\Program Files\\\\Microsoft SQL Server\\\\MSSQL13.XE4AEBDEV\\\\MSSQL\\\\DATA\\\\", 
				"mssql.db.path.backups=C\\:\\\\Program Files\\\\Microsoft SQL Server\\\\MSSQL13.XE4AEBDEV\\\\MSSQL\\\\Backup\\\\",
				"spring.data.mongodb.host=localhost", 
				"spring.data.mongodb.port=27017", 
				"spring.data.mongodb.backup.path=C\\:\\\\Users\\\\bru\\\\MongoDB\\\\Backups"
		}
)
public class DatabaseServiceTest extends ServerTest {
	
	public static final String INCORRECT_TYPE = "null";
	
	@Autowired
	DatabaseService service;
	@Autowired
	DatabaseRegistry registry;
	@Autowired
	ApplicationContext context;
	
	private static Stream<String> databaseTypes(){
		return Stream.of("MSSQL","MONGODB");
	}
	
	private static Stream<String> databaseTypesWithInitialData(){
		return Stream.of("MSSQL " + MSSQLTest.PATH_TO_DATA, "MONGODB " + MongoDBTest.PATH_TO_DATA);
	}
	
	  //////////////////////
	 // Required methods //
	//////////////////////
	
	@BeforeEach
	public void registerInstance() {
		databaseTypes().forEach(type -> {
			registry.registerInstance(type, (DatabaseInterface) context.getBean(type));
		});
	}

	@BeforeEach
	@AfterEach
	public void deleteTestDatabase() {
		databaseTypes().forEach(type -> {
			DeleteDbReqDTO request = getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false);
			service.deleteDatabase(request);
			request = getDeleteDatabaseDTO(type, DATABASE_NAME_TWO, false);
			service.deleteDatabase(request);
		});
	}
	
	@BeforeEach
	@AfterEach
	public void deleteTestBackup() {
		databaseTypes().forEach(type -> {
			DeleteBackupReqDTO request = getDeleteBackupDTO(type, BACKUP_NAME_ONE);
			service.deleteBackup(request);
			request = getDeleteBackupDTO(type, BACKUP_NAME_TWO);
			service.deleteBackup(request);
		});	
	}	
	
	  ////////////////////////////////////////////////
	 // Test cases for methods createDatabase(...) //
	////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptyDatabase(String type) {
		assertEquals(HttpStatus.CREATED, service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptySameDatabaseTwice(String type) {
		assertEquals(HttpStatus.CREATED, service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE)).getStatusCode());
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods deleteDatabase(...) //
	////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingDatabase(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteDatabase(getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseWithoutBackups(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.OK, service.deleteDatabase(getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseWithAllBackups(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.OK, service.deleteDatabase(getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, true)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseTwice(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.OK, service.deleteDatabase(getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteDatabase(getDeleteDatabaseDTO(type, DATABASE_NAME_ONE, false)).getStatusCode());
	}
	
	  ///////////////////////////////////////////////
	 // Test cases for methods listDatabases(...) //
	///////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listAllDatabases(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.OK, service.listDatabases(getListDatabasesDTO(type)).getStatusCode());
	}
	
	  //////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseBackup(...) //
	//////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromNonExistingDatabase(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabase(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.CREATED, service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabaseTwice(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.CREATED, service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT)).getStatusCode());
	}
 
	  //////////////////////////////////////////////
	 // Test cases for methods deleteBackup(...) //
	//////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingBackup(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteBackup(getDeleteBackupDTO(type, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.OK, service.deleteBackup(getDeleteBackupDTO(type, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackupTwice(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.OK, service.deleteBackup(getDeleteBackupDTO(type, BACKUP_NAME_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteBackup(getDeleteBackupDTO(type, BACKUP_NAME_ONE)).getStatusCode());
	}

	  /////////////////////////////////////////////
	 // Test cases for methods listBackups(...) //
	/////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupContainsExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.OK, service.listBackups(getListBackupsDTO(type)).getStatusCode());
	}
	
	  /////////////////////////////////////////////////////
	 // Test cases for methods listDatabaseBackups(...) //
	/////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupFromDatabaseContainsExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.OK, service.listDatabaseBackups(getListDbBackupsDTO(type, DATABASE_NAME_ONE)).getStatusCode());
	}
	
      //////////////////////////////////////////////////////////
     // Test cases for methods createDatabaseFromBackup(...) //
	//////////////////////////////////////////////////////////
  
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.CREATED, service.createDatabaseFromBackup(getCreateDbFromBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromNonExistingBackup(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromBackup(getCreateDbFromBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createExistingDatabaseFromExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromBackup(getCreateDbFromBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
	}

	  /////////////////////////////////////////////////
	 // Test cases for methods restoreDatabase(...) //
	/////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromExistingBackup(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		assertEquals(HttpStatus.OK, service.restoreDatabase(getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromNonExistingBackup(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.restoreDatabase(getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
	}
	
	  ////////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromDatabase(...) //
	////////////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneExistingDatabaseToNonExistingDatabase(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.CREATED, service.createDatabaseFromDatabase(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneNonExistingDatabaseToNonExistingDatabase(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromDatabase(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneDatabaseToExistingDatabase(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_TWO, DATABASE_SCHEMA_ONE));
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromDatabase(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO)).getStatusCode());
	}
	
	  ////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromData(...) //
	////////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createDatabase(String input) {
		String[] inputs = input.split(" ");
		assertEquals(HttpStatus.CREATED, service.createDatabaseFromData(getCreateDbFromDataDTO(inputs[0], DATABASE_NAME_ONE, inputs[1])).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createSameDatabaseTwice(String input) {
		String[] inputs = input.split(" ");
		service.createDatabaseFromData(getCreateDbFromDataDTO(inputs[0], DATABASE_NAME_ONE, inputs[1]));
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromData(getCreateDbFromDataDTO(inputs[0], DATABASE_NAME_ONE, inputs[1])).getStatusCode());
	}		
	
	  ////////////////////////////////////////////////
	 // Test cases for methods compareBackups(...) //
	////////////////////////////////////////////////

	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareNonExistingBackups(String type) {
		assertEquals(HttpStatus.BAD_REQUEST, service.compareBackups(getBackupCompareDTO(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO)).getStatusCode());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareExistingBackups(String type) {
		service.createDatabase(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT));
		service.createDatabaseBackup(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_TWO, COMMENT));
		assertEquals(HttpStatus.OK, service.compareBackups(getBackupCompareDTO(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO)).getStatusCode());
	}
	
	  ////////////////////////////////////////////////////
	 // Test cases for requests with an incorrect type //
	////////////////////////////////////////////////////
	
	@Test
	public void incorrectTypeInRequest() {
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromData(getCreateDbFromDataDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, "")).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromBackup(getCreateDbFromBackupDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabase(getCreateDbDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteDatabase(getDeleteDatabaseDTO(INCORRECT_TYPE, BACKUP_NAME_ONE, false)).getStatusCode());		
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseFromDatabase(getCreateDbFromDbDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, BACKUP_NAME_TWO)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.listDatabases(getListDatabasesDTO(INCORRECT_TYPE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.compareBackups(getBackupCompareDTO(INCORRECT_TYPE, BACKUP_NAME_ONE, BACKUP_NAME_TWO)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.createDatabaseBackup(getCreateBackupDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.deleteBackup(getDeleteBackupDTO(INCORRECT_TYPE, BACKUP_NAME_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.restoreDatabase(getRestoreDbDTO(INCORRECT_TYPE, DATABASE_NAME_ONE, BACKUP_NAME_ONE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.listBackups(getListBackupsDTO(INCORRECT_TYPE)).getStatusCode());
		assertEquals(HttpStatus.BAD_REQUEST, service.listDatabaseBackups(getListDbBackupsDTO(INCORRECT_TYPE, DATABASE_NAME_ONE)).getStatusCode());
	}
	
}