package de.aeb.thesis.server.service.rest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import de.aeb.thesis.dto.request.RequestDTO;
import de.aeb.thesis.server.ServerTest;
import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.database.mongodb.MongoDBTest;
import de.aeb.thesis.server.database.mssql.MSSQLTest;
import de.aeb.thesis.server.service.registry.DatabaseRegistry;
import de.aeb.thesis.util.rest.RestUtil;

/**
 * All test cases for the component {@link RestApi}.
 */
@SpringBootTest(
		properties = {
				"mssql.db.url=jdbc\\:sqlserver\\://PC-XDDEV0222\\\\XE4AEBDEV", 
				"mssql.db.user=bru", "mssql.db.password=bru", 
				"mssql.db.path.databases=C\\:\\\\Program Files\\\\Microsoft SQL Server\\\\MSSQL13.XE4AEBDEV\\\\MSSQL\\\\DATA\\\\", 
				"mssql.db.path.backups=C\\:\\\\Program Files\\\\Microsoft SQL Server\\\\MSSQL13.XE4AEBDEV\\\\MSSQL\\\\Backup\\\\",
				"spring.data.mongodb.host=localhost", 
				"spring.data.mongodb.port=27017", 
				"spring.data.mongodb.backup.path=C\\:\\\\Users\\\\bru\\\\MongoDB\\\\Backups"
		}
)
@AutoConfigureMockMvc
public class RestApiTest extends ServerTest{
	
	private static final Logger logger = LoggerFactory.getLogger(RestApiTest.class);
	
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	DatabaseRegistry registry;
	@Autowired
	ApplicationContext context;
	
	private static Stream<String> databaseTypes(){
		return Stream.of("MSSQL", "MONGODB");
	}
	
	private static Stream<String> databaseTypesWithInitialData(){
		return Stream.of("MSSQL " + MSSQLTest.PATH_TO_DATA, "MONGODB " + MongoDBTest.PATH_TO_DATA);
	}
	
	  //////////////////////
	 // Required methods //
	//////////////////////
	
	@BeforeEach
	public void registerInstance() {
		databaseTypes().forEach(type -> {
			registry.registerInstance(type, (DatabaseInterface) context.getBean(type));
		});
	}
	
	@BeforeEach
	@AfterEach
	public void deleteTestDatabase() {
		databaseTypes().forEach(type -> {
			try {
				mockMvc.perform(delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE));
				mockMvc.perform(delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_TWO));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		});
	}
	
	@BeforeEach
	@AfterEach
	public void deleteTestBackup() {
		databaseTypes().forEach(type -> {
			try {
				mockMvc.perform(delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_ONE));
				mockMvc.perform(delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_TWO));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		});	
	}
	
	public String toJSON(RequestDTO request) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			return mapper.writeValueAsString(request);
		} catch (JsonProcessingException e) {
			logger.error("The error message could not be converted to json.", e);
		}
		return null;
	}
	
	public String addDelimiterToRestPath(String restPath) {
		return "/" + restPath;
	}
	
	  ////////////////////////////////////////////////
	 // Test cases for methods createDatabase(...) //
	////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptyDatabase(String type) throws Exception {
		mockMvc.perform(post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
					.contentType(MediaType.APPLICATION_JSON)
					.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
		.andExpect(status().isCreated());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createEmptySameDatabaseTwice(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isBadRequest());
	}	

	  ////////////////////////////////////////////////
	 // Test cases for methods deleteDatabase(...) //
	////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE)
						.param("deleteAllBackups", Boolean.FALSE.toString()))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseWithoutBackups(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE)
						.param("deleteAllBackups", Boolean.FALSE.toString()))
				.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseWithAllBackups(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE)
						.param("deleteAllBackups", Boolean.TRUE.toString()))
				.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingDatabaseTwice(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE)
						.param("deleteAllBackups", Boolean.TRUE.toString()))
				.andExpect(status().isOk());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("type", type)
						.param("name", DATABASE_NAME_ONE)
						.param("deleteAllBackups", Boolean.TRUE.toString()))
				.andExpect(status().isBadRequest());
	}	

	  ///////////////////////////////////////////////
	 // Test cases for methods listDatabases(...) //
	///////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listAllDatabases(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_DATABASES))
						.param("type", type))
				.andExpect(status().isOk());
	}
	
	  //////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseBackup(...) //
	//////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromNonExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createBackupFromExistingDatabaseTwice(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isBadRequest());
	}	
	
	  //////////////////////////////////////////////
	 // Test cases for methods deleteBackup(...) //
	//////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteNonExistingBackup(String type) throws Exception {
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_ONE))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_ONE))
				.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void deleteExistingBackupTwice(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_ONE))
				.andExpect(status().isOk());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.param("type", type)
						.param("name", BACKUP_NAME_ONE))
				.andExpect(status().isBadRequest());
	}	

	  /////////////////////////////////////////////
	 // Test cases for methods listBackups(...) //
	/////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupContainsExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_BACKUPS))
						.param("type", type))
				.andExpect(status().isOk());
	}
	
	  /////////////////////////////////////////////////////
	 // Test cases for methods listDatabaseBackups(...) //
	/////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void listBackupFromDatabaseContainsExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_BACKUPS_FROM_DATABASE))
						.param("type", type)
						.param("databaseName", DATABASE_NAME_ONE))
				.andExpect(status().isOk());
	}	

     //////////////////////////////////////////////////////////
     // Test cases for methods createDatabaseFromBackup(...) //
	//////////////////////////////////////////////////////////

	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createDatabaseFromNonExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_ONE))))
				.andExpect(status().isCreated());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void createExistingDatabaseFromExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
	}	

	  /////////////////////////////////////////////////
	 // Test cases for methods restoreDatabase(...) //
	/////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_RESET_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isOk());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void restoreDatabaseFromNonExistingBackup(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_RESET_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getRestoreDbDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
	}	
	
	  ////////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromDatabase(...) //
	////////////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneExistingDatabaseToNonExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CLONE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO))))
				.andExpect(status().isCreated());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneNonExistingDatabaseToNonExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CLONE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO))))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void cloneDatabaseToExistingDatabase(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_TWO, DATABASE_SCHEMA_TWO))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CLONE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDbDTO(type, DATABASE_NAME_ONE, DATABASE_NAME_TWO))))
				.andExpect(status().isBadRequest());
	}
	
	  ////////////////////////////////////////////////////////
	 // Test cases for methods createDatabaseFromData(...) //
	////////////////////////////////////////////////////////
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createDatabase(String type) throws Exception {
		String[] input = type.split(" ");
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDataDTO(input[0], DATABASE_NAME_ONE, input[1]))))
				.andExpect(status().isCreated());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypesWithInitialData")
	public void createSameDatabaseTwice(String type) throws Exception {
		String[] input = type.split(" ");
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDataDTO(input[0], DATABASE_NAME_ONE, input[1]))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDataDTO(input[0], DATABASE_NAME_ONE, input[1]))))
				.andExpect(status().isBadRequest());
	}	
	
	  ////////////////////////////////////////////////
	 // Test cases for methods compareBackups(...) //
	////////////////////////////////////////////////

	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareNonExistingBackups(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_COMPARE_BACKUPS))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getBackupCompareDTO(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO))))
				.andExpect(status().isBadRequest());
	}
	
	@ParameterizedTest
	@MethodSource("databaseTypes")
	public void compareExistingBackups(String type) throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(type, DATABASE_NAME_TWO, DATABASE_SCHEMA_TWO))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(type, DATABASE_NAME_TWO, BACKUP_NAME_TWO, COMMENT))))
				.andExpect(status().isCreated());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_COMPARE_BACKUPS))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getBackupCompareDTO(type, BACKUP_NAME_ONE, BACKUP_NAME_TWO))))
				.andExpect(status().isOk());
	}
	
	  ////////////////////////////////////////////////////
	 // Test cases for requests with an incorrect type //
	////////////////////////////////////////////////////
	
	@Test
	public void incorrectTypeInRequest() throws Exception {
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDataDTO(null, DATABASE_NAME_ONE, ""))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_NEW_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromBackupDTO(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_EMPTY_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbDTO(null, DATABASE_NAME_ONE, DATABASE_SCHEMA_ONE))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_DATABASE))
						.param("name", DATABASE_NAME_ONE))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CLONE_DATABASE))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateDbFromDbDTO(null, DATABASE_NAME_ONE, DATABASE_NAME_TWO))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_DATABASES)))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_COMPARE_BACKUPS))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getBackupCompareDTO(null, BACKUP_NAME_ONE, BACKUP_NAME_TWO))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_CREATE_DATABASE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getCreateBackupDTO(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE, COMMENT))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				delete(addDelimiterToRestPath(RestUtil.REST_PATH_DELETE_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getDeleteBackupDTO(null, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_BACKUPS)))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				get(addDelimiterToRestPath(RestUtil.REST_PATH_LIST_ALL_BACKUPS_FROM_DATABASE))
					.param("databaseName", DATABASE_NAME_ONE))
				.andExpect(status().isBadRequest());
		
		mockMvc.perform(
				post(addDelimiterToRestPath(RestUtil.REST_PATH_RESET_DATABASE_FROM_BACKUP))
						.contentType(MediaType.APPLICATION_JSON)
						.content(toJSON(getRestoreDbDTO(null, DATABASE_NAME_ONE, BACKUP_NAME_ONE))))
				.andExpect(status().isBadRequest());
	}
	
}