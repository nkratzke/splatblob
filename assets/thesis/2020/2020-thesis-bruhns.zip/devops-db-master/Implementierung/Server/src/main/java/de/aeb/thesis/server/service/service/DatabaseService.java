package de.aeb.thesis.server.service.service;

import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import de.aeb.thesis.dto.request.BackupCompareReqDTO;
import de.aeb.thesis.dto.request.CreateBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromBackupReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDataReqDTO;
import de.aeb.thesis.dto.request.CreateDbFromDbReqDTO;
import de.aeb.thesis.dto.request.CreateDbReqDTO;
import de.aeb.thesis.dto.request.DeleteBackupReqDTO;
import de.aeb.thesis.dto.request.DeleteDbReqDTO;
import de.aeb.thesis.dto.request.ListBackupsReqDTO;
import de.aeb.thesis.dto.request.ListDatabasesReqDTO;
import de.aeb.thesis.dto.request.ListDbBackupsReqDTO;
import de.aeb.thesis.dto.request.RequestDTO;
import de.aeb.thesis.dto.request.RestoreDbReqDTO;
import de.aeb.thesis.dto.response.BackupCompareRespDTO;
import de.aeb.thesis.dto.response.CreateBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromBackupRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDataRespDTO;
import de.aeb.thesis.dto.response.CreateDbFromDbRespDTO;
import de.aeb.thesis.dto.response.CreateDbRespDTO;
import de.aeb.thesis.dto.response.DeleteBackupRespDTO;
import de.aeb.thesis.dto.response.DeleteDbRespDTO;
import de.aeb.thesis.dto.response.ListBackupsRespDTO;
import de.aeb.thesis.dto.response.ListDatabasesRespDTO;
import de.aeb.thesis.dto.response.ListDbBackupsRespDTO;
import de.aeb.thesis.dto.response.ResponseDTO;
import de.aeb.thesis.dto.response.RestoreDbRespDTO;
import de.aeb.thesis.server.database.DatabaseInterface;
import de.aeb.thesis.server.service.ApiInterface;
import de.aeb.thesis.server.service.registry.DatabaseRegistry;
import de.aeb.thesis.server.service.rest.RestApi;

/**
 * The service of the server that forwards the requests of a client to the corresponding components.
 */
@Component("service")
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class DatabaseService implements ApiInterface {
	
	@FunctionalInterface
	public interface TriFunction<F, S, T, R> {
		public R apply(F first, S second, T third);
	}
	
	private static final String MESSAGE_INCORRECT_DATABASE_TYPE = "An incorrect database type was selected.";
	
	private DatabaseRegistry databaseRegistry;
	
	/**
	 * A function that processes the request from the client.
	 */
	private TriFunction<HttpStatus, RequestDTO, Supplier<ResponseDTO>, ResponseEntity<ResponseDTO>> function = (status, req, sup) -> {
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		if (db == null) {
			ResponseDTO resp = new ResponseDTO();
			resp.setErrorMessage(MESSAGE_INCORRECT_DATABASE_TYPE);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
		} else {
			return generateResponse(sup.get(), status);
		}
	};

	@Autowired
	public DatabaseService(DatabaseRegistry databaseRegistry) {
		this.databaseRegistry = databaseRegistry;
	}
	
	@Override
	public ResponseEntity<ResponseDTO> createDatabaseFromData(CreateDbFromDataReqDTO req) {
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.createDatabaseFromData(new CreateDbFromDataRespDTO(), req);
		return function.apply(HttpStatus.CREATED, req, supplier);
	}

	@Override
	public ResponseEntity<ResponseDTO> createDatabaseFromBackup(CreateDbFromBackupReqDTO req) {
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.createDatabaseFromBackup(new CreateDbFromBackupRespDTO(), req);
		return function.apply(HttpStatus.CREATED, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> createDatabase(CreateDbReqDTO req) {	
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.createDatabase(new CreateDbRespDTO(), req);
		return function.apply(HttpStatus.CREATED, req, supplier);
	}

	@Override
	public ResponseEntity<ResponseDTO> deleteDatabase(DeleteDbReqDTO req) {		
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.deleteDatabase(new DeleteDbRespDTO(), req);
		return function.apply(HttpStatus.OK, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> createDatabaseFromDatabase(CreateDbFromDbReqDTO req) {		
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.createDatabaseFromDatabase(new CreateDbFromDbRespDTO(), req);
		return function.apply(HttpStatus.CREATED, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> listDatabases(ListDatabasesReqDTO req) {		
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.listDatabases(new ListDatabasesRespDTO());
		return function.apply(HttpStatus.OK, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> compareBackups(BackupCompareReqDTO req) {				
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.compareBackups(new BackupCompareRespDTO(), req);
		return function.apply(HttpStatus.OK, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> createDatabaseBackup(CreateBackupReqDTO req) {
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.createDatabaseBackup(new CreateBackupRespDTO(), req);
		return function.apply(HttpStatus.CREATED, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> deleteBackup(DeleteBackupReqDTO req) {
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.deleteBackup(new DeleteBackupRespDTO(), req);
		return function.apply(HttpStatus.OK, req, supplier);
	}

	@Override
	public ResponseEntity<ResponseDTO> restoreDatabase(RestoreDbReqDTO req) {			
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.restoreDatabase(new RestoreDbRespDTO(), req);
		return function.apply(HttpStatus.OK, req, supplier);
	}

	@Override
	public ResponseEntity<ResponseDTO> listBackups(ListBackupsReqDTO req) {		
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.listBackups(new ListBackupsRespDTO());
		return function.apply(HttpStatus.OK, req, supplier);
	}
	
	@Override
	public ResponseEntity<ResponseDTO> listDatabaseBackups(ListDbBackupsReqDTO req) {		
		DatabaseInterface db = databaseRegistry.getInstance(req.getType());
		Supplier<ResponseDTO> supplier = () -> db.listDatabaseBackups(new ListDbBackupsRespDTO(), req);
		return function.apply(HttpStatus.OK, req, supplier);
	}
	
	/**
	 * Generates a response which is returned to the client via {@link RestApi}.
	 * @param resp An object of {@link ResponseDTO} which includes the result of the request
	 * @param status The desired {@link HttpStatus} (Only used if the request is successful.)
	 * @return The response for the client.
	 */
	private ResponseEntity<ResponseDTO> generateResponse(ResponseDTO resp, HttpStatus status) {
		return resp.getErrorMessage() != null ? ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp): ResponseEntity.status(status).body(resp);
	}

}