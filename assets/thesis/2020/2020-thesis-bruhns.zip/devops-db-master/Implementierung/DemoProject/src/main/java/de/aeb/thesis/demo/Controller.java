/*
 ******************************************************************************
 *                                                                            *
 *          (C) COPYRIGHT by AEB SE 2020                                      *
 *                                                                            *
 ******************************************************************************
 */
package de.aeb.thesis.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@GetMapping("/")
	public String hello() {
		return "Hello javaTpoint";
	}
	
}