package de.aeb.thesis.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;

public class ApplicationTestUseCaseThree {

	private static final String ACCESS_DATA_TO_DATABASE_DIR = "C:\\Users\\bru\\git\\automatisierung-von-datenbanken-in-devops-szenarien\\DemoProject\\src\\test\\resources\\access-data-databases";
	
	private static String ACCESS_FILE_TO_FIRST_DATABASE = "TargetDemoDb.txt";
	
	private List<String> readAccessData(Path path) throws IOException{
		return List.of(Files.readString(path).split(" "));
	}
	
	private Connection createConnection(String url, String user, String password) throws SQLException {
		DriverManager.registerDriver(new SQLServerDriver());
    	return DriverManager.getConnection(url, user, password);
	}
	
	@Test //TODO: Sonar
	public void manipulateDatabase() throws IOException, SQLException {
		List<String> accessData = readAccessData(Path.of(ACCESS_DATA_TO_DATABASE_DIR).resolve(ACCESS_FILE_TO_FIRST_DATABASE));
		try(Connection connection = createConnection(accessData.get(0), accessData.get(1), accessData.get(2))){
			try (Statement stmt = connection.createStatement()) {
				stmt.execute("INSERT INTO TargetDemoDb.demo.PERSON (ID, NAME, AGE) VALUES (3, 'Lena', 21);");
			}
		}
	}
	
}