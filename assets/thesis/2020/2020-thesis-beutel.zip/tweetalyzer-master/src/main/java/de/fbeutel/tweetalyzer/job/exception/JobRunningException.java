package de.fbeutel.tweetalyzer.job.exception;

public class JobRunningException extends JobException {
}
