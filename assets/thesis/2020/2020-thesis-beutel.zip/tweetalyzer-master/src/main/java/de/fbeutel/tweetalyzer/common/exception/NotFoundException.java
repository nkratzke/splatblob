package de.fbeutel.tweetalyzer.common.exception;

public class NotFoundException extends RuntimeException {
}
