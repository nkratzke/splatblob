package de.fbeutel.tweetalyzer.graph.domain;

public enum RelationshipType {
  TWEETS, RETWEETS, MENTIONS, REPLIES_TO, QUOTES
}
