package de.fbeutel.tweetalyzer.job.exception;

public class JobInRunningMutexGroupException extends JobException {
}
