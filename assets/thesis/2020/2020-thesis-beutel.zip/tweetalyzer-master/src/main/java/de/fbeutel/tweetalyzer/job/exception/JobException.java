package de.fbeutel.tweetalyzer.job.exception;

public abstract class JobException extends RuntimeException {
}
