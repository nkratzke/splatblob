package de.fbeutel.tweetalyzer.graph.domain;

public enum NodeType {
  USER, TWEET
}
