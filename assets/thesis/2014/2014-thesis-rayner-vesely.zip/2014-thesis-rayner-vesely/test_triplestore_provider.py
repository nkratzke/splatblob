# -*- coding: iso-8859-1 -*-
import os
import filecmp
import unittest
from plato.common.unittest_tools import get_user_setting
from plato.common.unittest_pws import PwsBrowserSession, TestServer
from plato.common.tools import COMMONPATH_Project, getCommonPath

server = TestServer(start_script=getCommonPath(COMMONPATH_Project, "actions", "plato_e1ns_actions.py"))
 
# setupModule() requires python 2.7+ or unittest2 
def setUpModule():
    server.start()
 
def tearDownModule():
    server.stop()
    
#===============================================================================
# TriplestoreProviderTest
#===============================================================================
class TriplestoreProviderTest(unittest.TestCase):
    # Read option from environment or <HOME>\plato_user_settings.ini
    PWS_ROOT = get_user_setting("test.ActionsServer", "http://127.0.0.1:8002/")
    APP_ID = get_user_setting("test.appId", r"PLATO\e1ns.actions\UnitTest")
    CREDENTIALS = get_user_setting("test.account", "plato:plato2@setup60")
    FILE_PATH = get_user_setting("test.rdfImportFiles")
    
    
    def setUp(self):
        self.browser = PwsBrowserSession(PWS_ROOT, CREDENTIALS, APP_ID)
        self.format_list = ["nt", "n3", "turtle", "trig", "rdfxml", "rdfa"]

    def tearDown(self):
        del self.browser
    
    def test_import_rdf(self):
        url = "/triplestore/import_rdf"
        
        for format in self.format_list:
            # For simplicity all files end with *.rdf
            path = os.path.join(FILE_PATH, "actions_rdf_import", "%s.rdf" % format)
            
            # Open file
            file = open(path, "r")
            
            data = {"rdfImport": file,
                    "format": format}
            
            # Send request
            result = self.browser.POST(url, data)
            
            # Check result
            self.assertTrue(self.browser.check_result(result, "import_rdf"))
            
            # Close opened file 
            file.close()
    
    def test_export_rdf(self):
        url = "/triplestore/export_rdf?element_key={0FB946ED-5EB8-43EE-98CE-53F34F71F3F8}&element_type=scio.project&format=%s"
        
        for format in self.format_list:
            # Send request
            result = self.browser.GET(url % format)
            
            # For simplicity all files end with *.rdf
            path = os.path.join(FILE_PATH, "actions_rdf_import", "%s.rdf" % format)
            
            # Open file
            import_file = open(path, "r")
            
            # Compare files
            self.assertTrue(filecmp.cmp(result, import_file))
            
            # Close file and delete file object
            import_file.close()
            del result
    
    def test_send_graph(self):
        url = "/triplestore/send_graph?element_key{0FB946ED-5EB8-43EE-98CE-53F34F71F3F8}&element_type=scio.project"
        
        # Get graph for scio.project with the key {0FB946ED-5EB8-43EE-98CE-53F34F71F3F8}
        result = self.browser.GET(url)
        
        # Check result
        self.assertTrue(self.browser.check_result(result, "send_graph"))
    
    def test_query(self):
        url = "/triplestore/query?project_graph_key={0FB946ED-5EB8-43EE-98CE-53F34F71F3F8}%2Factions_project&query=%s"
        
        query = """select ?action_title
                        where {
                                ?action_node actions:owner "Rayner Vesely"^^xsd:Name .
                                ?action_node actions:title ?action_title .
                            }"""
        
        # Add query to URL
        url = url % query
        
        # Send request with query
        result_list = self.browser.GET(url)
        
        self.assertTrue(len(result_list) == 1)
        self.assertTrue(result_list[0]["action_title"] == u"Action 01")
        
#===============================================================================
# Main
#===============================================================================
if __name__ == "__main__":
    unittest.main()
