# -*- coding: iso-8859-1 -*-
"""
PLATO e1ns.actions
(c) PLATO AG 2014
"""
import rdflib

from rdflib.namespace import Namespace, XSD, RDF
from rdflib.term import BNode, Literal
from datetime import datetime
from netbios import ACTION_HEADER
from plato.eplm.pyseki import FusekiConnection
from cherrypy.lib.static import serve_download
import tempfile
import os
from plato.common.tools import makePwsJsonOkResponse,\
    makePwsJsonExceptionResponse, logDebug

ACTIONS_URI = "http://plato.de/actions/definition/1.0#"
ACTIONS_NS_STRING = "actions:"
ACTIONS = Namespace(ACTIONS_URI)

#===============================================================================
# Class TriplestoreProvider
#===============================================================================

class TriplestoreProvider(object):


    def __init__(self, actions_provider):
        self.actions_provider = actions_provider
        self.converter = ElementGraphConverter(actions_provider, self)
    
    def get_graph(self, element_key, element_type):
        supported_element_list = ["scio.project", ]
        
        if element_type not in supported_element_list:
            raise ValueError("Element type '%s' is not supported. Following element types can be used: %s" % (element_type, ", ".join(supported_element_list)))
        
        # Creating graph
        element_graph_key = FusekiConnection.make_rdf_graph_identifier(element_key, element_type)
        graph = rdflib.Graph(identifier=element_graph_key)
        
        # Get root element from e1ns.actions
        root_element = self.actions_provider.get_element(element_key, element_type)
        
        # Add root element to graph
        root_element_node = self.converter.add(root_element, graph)
        
        # Get all direct children that have the type actions.action
        child_gen = self.actions_provider.get_children_by_type(element_key, element_type, "actions.action")
        
        for action_element in child_gen:
            action_node = self.converter.add(action_element, graph)
            graph.add((root_element_node, ACTIONS["project_actions"], action_node))
        
        return graph
    
    def export_rdf(self, element_key, element_type, format="TriG"):
        """Export structure of given element by key as RDF.
        
        Supported element types:
            scio.project
        
        @param element_key: element key
        @param element_type: element type
        @return: element structure as RDF file
        """
        graph = self.get_graph(element_key, element_type)
        
        text = graph.serialize(format)
        temp_dir = tempfile.mkdtemp(suffix="actions_rdf_export")
        path = os.path.join(temp_dir, "%s.rdf" % element_key)
        file = open(path, "w")
        file.write(text)
        file.close()
        
        return serve_download(path)
    
    def import_rdf(self, *args, **kw):
        try:
            #Create graph object
            import_graph = rdflib.Graph()
            
            import_graph.parse(kw["rdfImport"].file, format=kw.get("format", "TriG"))
             
            logDebug("Graph has %s statements.\n" % len(import_graph))
            
            elements_dict = {}
            
            for project_s, project_p, project_o in import_graph.triples((None, RDF.type, ACTIONS["scio.project"])):
                if (project_s, project_p, project_o) not in import_graph:
                    raise Exception("It better be!")
                 
                logDebug("Getting project...")
                logDebug("{project_s: %s, project_p: %s, project_o: %s}"  % (project_s, project_p.split('#')[-1], project_o.split('#')[-1])) 
                 
                elements_dict[project_s] = {}
             
            logDebug("Getting project data...")
            
            for s, p, o in import_graph.triples((project_s, None, None)):
                assert s == project_s
                 
                if (s, p, o) not in import_graph:
                    raise Exception("It better be!")
                 
                p = p.split('#')[-1]
                o = o.split('#')[-1]
                 
                logDebug("{s: %s, p: %s, o: %s}" % (s, p, o))
                 
                if p in elements_dict[s]:
                    value = elements_dict[s][p]
                     
                    if type(value) == list:
                        elements_dict[s][p].append(o)
                    else:
                        elements_dict[s][p] = [value, o]
                else:
                    elements_dict[s][p] = o
             
            for action_s in  elements_dict[project_s]["project_actions"]:
                action_s = BNode(action_s)
                elements_dict[action_s] = {}
                 
                for s, p, o in import_graph.triples((action_s, None, None)):
                    assert s == action_s
                 
                    if (s, p, o) not in import_graph:
                        raise Exception("It better be!")
                     
                    p = p.split('#')[-1]
                    o = o.split('#')[-1]
                     
                    logDebug("{s: %s, p: %s, o: %s}" % (s, p, o))
                     
                    elements_dict[s][p] = o
             
            self.converter.set(elements_dict)
        except:
            return makePwsJsonExceptionResponse()
        
        return makePwsJsonOkResponse("import_rdf")
    
    def send_graph(self, element_key, element_type):
        graph = self.get_graph(element_key, element_type)
        
        fuseki_conn = FusekiConnection()
        fuseki_conn.send_graph(graph)
        
        return fuseki_conn
     
    def query(self, project_graph_key, query):
        fuseki_conn = FusekiConnection()
        
        res = fuseki_conn.query(query, from_list=[project_graph_key])
         
        print res.get_json_obj()
        
#===============================================================================
# Class ElementGraphConverter
#===============================================================================

class ElementGraphConverter(object):
    
    
    def __init__(self, actions_provider, triplestore_provider):
        self.actions_provider = actions_provider
        self.triplestore_provider = triplestore_provider
    
    def add(self, element, graph):
        return getattr(self, "add_%s" % element.type.replace(".", "_"))(element, graph)
    
    def add_scio_project(self, element, graph):
        scio_project_node = BNode()
        
        graph.add((scio_project_node, RDF.type, ACTIONS[element.type]))
        graph.add((scio_project_node, ACTIONS["title"], Literal(element.title)))
        graph.add((scio_project_node, ACTIONS["key"], Literal(element.key, datatype=XSD.string)))
        graph.add((scio_project_node, ACTIONS["start_date"], Literal(datetime.now(), datatype=XSD.dateTime)))
        graph.add((scio_project_node, ACTIONS["end_date"], Literal(datetime.now(), datatype=XSD.dateTime)))
        graph.add((scio_project_node, ACTIONS["owner"], Literal(element.owner, datatype=XSD.Name)))
        
        return scio_project_node
    
    def add_actions_action(self, element, graph):
        actions_action_node = BNode()
        
        graph.add((actions_action_node, RDF.type, ACTIONS[element.type]))
        
        graph.add((actions_action_node, ACTIONS["title"], Literal(element.title, datatype=XSD.string)))
        graph.add((actions_action_node, ACTIONS["key"], Literal(element.key, datatype=XSD.string)))
        graph.add((actions_action_node, ACTIONS["definition_description"], Literal(element.definition, datatype=XSD.string)))
        graph.add((actions_action_node, ACTIONS["implementation_descrition"], Literal(element.implementation, datatype=XSD.string)))
        graph.add((actions_action_node, ACTIONS["start_date"], Literal(element.startDate, datatype=XSD.date)))
        graph.add((actions_action_node, ACTIONS["end_date"], Literal(element.endDate, datatype=XSD.date)))
        graph.add((actions_action_node, ACTIONS["state"], Literal(element.state, datatype=XSD.string)))
        graph.add((actions_action_node, ACTIONS["implementation_rate"], Literal(element.state_info, datatype=XSD.long)))
        graph.add((actions_action_node, ACTIONS["priority"], Literal(element.priority, datatype=XSD.long)))
        graph.add((actions_action_node, ACTIONS["owner"], Literal(element.owner.name, datatype=XSD.Name)))
        graph.add((actions_action_node, ACTIONS["manager"], Literal(element.manager.name, datatype=XSD.Name)))
        graph.add((actions_action_node, ACTIONS["creator"], Literal(element.creator.name, datatype=XSD.Name)))
        graph.add((actions_action_node, ACTIONS["creation_date"], Literal(element.creationDate, datatype=XSD.date)))
        graph.add((actions_action_node, ACTIONS["category"], Literal("", datatype=XSD.string)))
        
        return actions_action_node
    
    def set(self, elements_dict):
        for key in elements_dict:
            element_dict = elements_dict[key]
            getattr(self, "set_%s" % element_dict["type"].replace(".", "_"))(element_dict)
            
    def set_scio_project(self, project_dict):
        # Create or update scio project
        self.actions_provider.update_element(project_dict)
    
    def set_actions_action(self, action_dict):
        # Create or update actions action
        self.actions_provider.update_element(action_dict)