# -*- coding: iso-8859-1 -*-

import atexit
import sys

from plato.eplm.pyseki import FusekiServer

FUSEKI = None

def end_fuseki():
    if FUSEKI is not None:
        FUSEKI.stop()

atexit.register(end_fuseki)

def main():
    global FUSEKI
    FUSEKI = FusekiServer(blocking=True, execute=True, start_batch=False)
    try:
        FUSEKI.run()
    except KeyboardInterrupt:
        FUSEKI.stop()
        sys.exit()    

if __name__ == "__main__":
    main()
    
    