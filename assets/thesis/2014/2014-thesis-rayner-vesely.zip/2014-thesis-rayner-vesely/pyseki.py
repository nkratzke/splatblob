# -*- coding: iso-8859-1 -*-
import sys
import os
import subprocess
import time
import datetime
import threading
import copy
import cStringIO
import logging
import requests
import rdflib

from plato.common.config import appConfig
from plato.common.patterns import Singleton
from plato.common import tools
from plato.common.exceptions import PlatoError
from plato.common.tools import logDebug, logInfo, logError, logWarning,\
    logException, g_Debug

from string import Template

ACTIONS_URI = "http://plato.de/actions/definition/1.0#"

ERROR_HINTS = "Possible reason: the Java Bin folder is not in the system PATH or not configured in the fusekiJavaBin option."

one_back_slash = "\\"
two_back_slashes = 2 * one_back_slash

def make_jave_cmd_line_string(s):
    return s.replace(one_back_slash, two_back_slashes)

def _init_fuseki_default_logging():
    """Initialize getLogger('plato') with standard settings.
    
    This is automatically executed when the tools module is loaded, to make sure
    that logDebug, ... goes to the console.
    """
    # Set a format which is simpler for console use
    formatterShort = logging.Formatter("%(asctime)s.%(msecs)-3d - %(name)s:%(levelname)s: %(message)s",
                                       "%H:%M:%S")
    
    # Define handlers
    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setFormatter(formatterShort)
    
    if g_Debug:
        consoleHandler.setLevel(logging.DEBUG)
    else:
        consoleHandler.setLevel(logging.INFO)
    
    logger = logging.getLogger("fuseki")
    logger.setLevel(logging.DEBUG)
    
    # Remove previous handlers
    for hdlr in logger.handlers: 
        logger.removeHandler(hdlr)
    
    logger.addHandler(consoleHandler)
    # Don't call root handlers after our custom handlers
    logger.propagate = False

class FusekiResult(object):
    
    def __init__(self, result_dict):
        self.result_dict = result_dict
        query_result = result_dict.get("results")
        
        if query_result is None:
            self.result_list = []
        else:
            query_result = query_result.get("bindings")
            
            if query_result is None:
                self.result_list = []
        
        self.result_list = query_result
        self.head = head = result_dict.get("head", {})
        self.vars = head.get("vars", [])
    
    def __iter__(self):
        for row in self.result_list:
            yield FusekiResultRow(row)
    
    def get_json_obj(self):
        return self.result_list
    
    def has_result(self):
        return len(self.result_list) > 0

class FusekiResultRow():
    
    CONVERTERS = {"integer": int,
                  }
    
    def __init__(self, row):
        self.res_row = row
        
    def get_val(self, field, convertion=None):
        row_val = self.res_row[field]["value"]
        
        if convertion is not None:
            row_val = convertion(row_val)
            
        return row_val
    
    def __getitem__(self, field):
        data = self.res_row[field] 
        rdf_type = data.get("datatype", "")
        type_compsonents = rdf_type.split("#")
        convertion = None
        
        if len(type_compsonents) == 2:
            convertion = self.CONVERTERS.get(type_compsonents[1], None)
            
        return self.get_val(field, convertion=convertion)

class ConnectionError(Exception):
    
    def __init__(self, request_exception, msg):
        self.request_exception = request_exception
        self.msg = msg
        super(ConnectionError, self).__init__()
        
class FusekiConnection(object):
    
    data_collection = "/actions"
    graph_identifier_base = "http://actions-rdf"
    
    
    @classmethod
    def make_fuseki_graph_identifier(cls, graph_id):
        graph_id = graph_id.replace("{", "guid_").replace("}", "")
        res_id = "%s/%s" % (cls.graph_identifier_base, graph_id)
        
        return res_id
    
    @staticmethod
    def make_rdf_graph_identifier(guid, ws_def_id):
        rdf_graph_identifier = "%s/%s" % (guid, ws_def_id)
        return rdf_graph_identifier
    
    def __init__(self, end_point_base=None):
        server = FusekiServer()
        end_point_base = end_point_base or server.fuseki_endpoint
        
        if end_point_base.endswith("/"):
            end_point_base = end_point_base[:-1]
        
        self.end_point_base = end_point_base
        self.end_point_coll = "%s%s" % (end_point_base, self.data_collection)
        self.session = requests.Session()
        
        
    def send_graph(self, graph):
        headers = {'content-type': 'application/rdf+xml; charset=utf8'}
        graph_identifier = graph.identifier
        
        url = "%s/data?graph=%s" % (self.end_point_coll, self.make_fuseki_graph_identifier(graph_identifier))
        rdf = graph.serialize(format="xml", encoding='utf-8')
        logDebug(rdf)
        
        try:
            r = self.session.put(url, data=rdf, headers=headers)
            
            if not r.status_code in [204, 201]:
                raise Exception("send_graph - Fuseki error'%s'" % r.text)
        except requests.exceptions.ConnectionError, e:
            msg = "Fuseki could not be reached at <%s>" % self.end_point_base
            logException(msg)
            raise ConnectionError(e, msg)
            
        return r.text
        
        
    def query(self, sparql_select, from_list, sparql_where=None, binding_dict=None, output="json"):
        if binding_dict is not None:
            sparql_select = self._bind_variables(sparql_select, binding_dict)
            
        if isinstance(sparql_select, Template):
            sparql_select = sparql_select.template
            
        if from_list is None:
            from_list = []
            
        if not isinstance(from_list, list):
            from_list = [from_list]
            
        sparql_from_list = []
        
        for graph_id in from_list:
            sparql_from_list.append("from <%s>" % self.make_fuseki_graph_identifier(graph_id))
        
        if sparql_where is None:
            sparql_comp = sparql_select.split("where")
            sparql_select = sparql_comp[0]
            sparql_where = "where %s" % sparql_comp[1]
            
        sparql = """
                    PREFIX rdf: <%s>
                    PREFIX xsd: <%s>
                    PREFIX actions: <%s>
                    
                    BASE <%s>
                    %s
                    %s
                    %s
                """ % (rdflib.RDF, rdflib.XSD, ACTIONS_URI, self.graph_identifier_base, sparql_select, "\n".join(sparql_from_list), sparql_where)
        url = "%s/query" % self.end_point_coll
        logDebug("Fuseki query = %s" % sparql)
        try:
            r = self.session.post(url, data=dict(query=sparql, output=output))
            
            if r.status_code != 200:
                raise Exception("query - Fuseki error'%s'" % r.text)
        except requests.exceptions.ConnectionError, e:
            msg = "Fuseki could not be reached at <%s>" % self.end_point_base
            logException(msg)
            if output == "json":
                return [{"": tools.makePwsFaultDict(msg)}]
            else:                
                raise ConnectionError(e, msg)
        
        if output == "json":
            return FusekiResult(r.json())
        else:
            return r.text
        
    def _bind_variables(self, sparql_expr, binding_dict):
        
        def string_converter(val):
            return'"%s"' % val
        
        str_converter = string_converter
        unicode_converter = string_converter
        
        assert type(binding_dict) == dict, "Need a dict for binding, not '%s'" % type(binding_dict)
        
        for var, val in binding_dict.items():
            conv_name = "%s_converter" % type(val).__name__
            conv_func = locals().get(conv_name)
            
            if conv_func is not None:
                val = conv_func(val)
                
                if var.startswith("$"):
                    var = var[1:]
                binding_dict[var] = val
        
        if not isinstance(sparql_expr, Template):
            t = Template(sparql_expr)
        else:
            t = sparql_expr
            
        res = t.substitute(binding_dict)
        return res
        
    def make_rdf_identifier_list(self, guid_list, ws_def):
        ws_def_id = ws_def.get_id()
        make_rdf_graph_identifier = self.make_rdf_graph_identifier
        res_list = [make_rdf_graph_identifier(guid, ws_def_id) for guid in guid_list]
        return res_list

class FusekiServer(Singleton):
    
    FUSEKI_BIN = "jena-fuseki"
    FUSEKI_BAT = "fuseki-server.bat"
    FUSEKI_DATA_DIR = "rdf-data"
    BATCH_PATTERN = """
                    REM create at %s
                    cd "%s"
                    fuseki-server --loc="%s" --desc="%s" --port %s --update --localhost %s
                    """
    JAVA_PATTERN = ["java", "-jar", "fuseki-server.jar", "--update", "--localhost"]
    BATCH_NAME = "plato-fuseki-server.bat"
    
    ASSEMBLER_PATTERN = """
@prefix rdf:     <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs:    <http://www.w3.org/2000/01/rdf-schema#> .
@prefix ja:      <http://jena.hpl.hp.com/2005/11/Assembler#> .
@prefix tdb:     <http://jena.hpl.hp.com/2008/tdb#> .

[] ja:loadClass "com.hp.hpl.jena.tdb.TDB" .
tdb:DatasetTDB  rdfs:subClassOf  ja:RDFDataset .
tdb:GraphTDB    rdfs:subClassOf  ja:Model .

<#dataset>     rdf:type tdb:DatasetTDB ;
            tdb:location "%s" ;
            tdb:unionDefaultGraph     true ;
            .
"""
         
    def __init__(self, blocking=False, start_batch=False, execute=False):
        
        _init_fuseki_default_logging()
        
        self.server_start_time = None
        self.fuseki_port = fuseki_port = appConfig.getString("actions.fusekiPort", "3030") 
        self.fuseki_endpoint = "http://localhost:%s" % fuseki_port
        self.server_end_time = None
        self.fuseki_process = None
        self.fuseki_path = None

        default_plato_data_path = tools.getCommonPath(tools.COMMONPATH_PlatoData, self.FUSEKI_DATA_DIR)
        plato_data_path = appConfig.getString("actions.fusekiDataPath", default_plato_data_path)
        fuseki_data_path = os.path.join(plato_data_path, "default")
        
        logInfo("Using Fuseki path %s" % fuseki_data_path)
        
        opt_key = "actions.fusekiJavaBin"
        
        self.java_bin_path = appConfig.getString(opt_key, None)
        
        if self.java_bin_path and not os.path.isdir(self.java_bin_path):
            appConfig.raiseOptError(opt_key, "Folder must exist (if options is specified)")

        opt_key = "actions.fusekiJavaHome"
        
        self.java_home_path = appConfig.getString(opt_key, None)
        
        if self.java_home_path and not os.path.isdir(self.java_home_path):
            appConfig.raiseOptError(opt_key, "Folder must exist (if options is specified)")
        
        # Get path to fuseki folder
        fuseki_path = tools.getCommonPath(tools.COMMONPATH_BinFolder, self.FUSEKI_BIN)
        
        self.fuseki_path = fuseki_path
        self.blocking = blocking
        
        args = []
        
        if execute:
            fuseki_conf_path = os.path.join(fuseki_data_path, "conf")
            
            logInfo("Using Fuseki conf-path %s" % fuseki_conf_path)
            
            if not os.path.exists(fuseki_data_path):
                os.makedirs(fuseki_data_path)
                
            if not os.path.exists(fuseki_conf_path):
                os.makedirs(fuseki_conf_path)
                    
            # Check if folder exists
            if not os.path.exists(fuseki_path):
                raise PlatoError("Folder for %s does not exist: %s" % (self.FUSEKI_BIN, fuseki_path))
                
            actions_assembler_file = os.path.join(fuseki_conf_path, "actions.ttl")
            assembler_text = self.ASSEMBLER_PATTERN % make_jave_cmd_line_string(fuseki_data_path)
            
            with open(actions_assembler_file, "w") as fp:
                    fp.write(assembler_text)
            
            if not os.path.exists(actions_assembler_file):
                raise SystemError("Config file '%s' does not exist.\n(Copy and rename from templates/conf/rdf-data/example_actions.ttl)" % actions_assembler_file)
            
            if start_batch:
                # Get path to fuseki executable
                fuseki_bat = os.path.join(fuseki_path, self.FUSEKI_BAT)
                
                # Check if executable exists
                if not os.path.exists(fuseki_bat):
                    raise PlatoError("Executable for %s does not exist: %s" % (self.FUSEKI_BIN, fuseki_bat))
                        
                batch_content = self.BATCH_PATTERN % (datetime.datetime.now(), 
                                                      fuseki_path, 
                                                      fuseki_data_path, 
                                                      actions_assembler_file,
                                                      fuseki_port, 
                                                      FusekiConnection.data_collection)
                
                start_batch_path = os.path.join(plato_data_path, self.BATCH_NAME)
                
                with open(start_batch_path, "w") as fp:
                    fp.write(batch_content)
                
                args = [start_batch_path]
                # Debugausgabe        
                logDebug("************ FUSEKI Batch Start **********", logger_name="fuseki")
                logDebug("Starting in %s / thru %s" % (fuseki_path, start_batch_path), logger_name="fuseki")
                logDebug("******************", logger_name="fuseki")
                logDebug(batch_content, logger_name="fuseki")
            else:
                args = copy.copy(self.JAVA_PATTERN)
                
                # Set the path to java.exe if passed via actions.fusekiJavaBin
                # Override "java" with explicit path to java.exe
                if self.java_bin_path is not None:
                    java_exe = os.path.join(self.java_bin_path, "java.exe")
                    if os.path.exists(java_exe):
                        logInfo("used java.exe: %s" % java_exe)
                        args[0] = java_exe
        
                # NOTE: Popen verwendet subprocess.list2cmdline(), welches
                # die listenelemente zusammenbaut, aber Elemente mit Leerzeichen 
                # in '"' setzt. Daher muss "--loc=" und Path getrennt �bergeben 
                # werden.
                # Dann wird zwichen '=' und '"' allerdings ein Space erzeugt.
                # See http://stackoverflow.com/a/805052/19166
                args.append("--loc=")
                args.append(fuseki_data_path)
                
                ######################################
                # TODO - Untersuchen, warum es mit Assembler-File nicht startet
                # obwohl es mit Batchstart geht 
                args.append("--desc=")
                args.append(actions_assembler_file)
                ######################################
                
                args.append('--port=%s' % fuseki_port)
                args.append(FusekiConnection.data_collection)

                logDebug("************ FUSEKI Java Start **********", logger_name="fuseki")
                logDebug("Starting in %s / thru %s" % (fuseki_path, args), logger_name="fuseki")
                logDebug("******************", logger_name="fuseki")
        
        self.args = args
                
        
    def stop(self):
        p = self.fuseki_process
        if p:
            logInfo( "Stopping Fuseki with PID = %s ..." % p.pid, logger_name="fuseki")
            timeout_sec = 5
            p_sec = 0
            for _second in range(timeout_sec):
                if p.poll() == None:
                    time.sleep(1)
                    p_sec += 1
            if p_sec >= timeout_sec:
                p.kill()

            logInfo("Terminated Fuseki process. PID = %s" % p.pid, logger_name="fuseki")
            self.fuseki_process = None # Stop only once
        
        
    def run(self):
        
        def _run_fuseki():

            logInfo("Fuseki path: %s" % self.fuseki_path)
            
            # NOTE: Popen verwendet subprocess.list2cmdline(), welches
            # die listenelemente zusammenbaut, aber Elemente mit Leerzeichen 
            # in '"' setzt. Daher muss "--loc=" und Path getrennt �bergeben 
            # werden.
            # Dann wird zwichen '=' und '"' allerdings ein Space erzeugt.
            # See http://stackoverflow.com/a/805052/19166
            argline = subprocess.list2cmdline(self.args)
            argline = argline.replace('= "', '="')
            argline = argline.replace('--loc= ', '--loc=')
            argline = argline.replace('--desc= ', '--desc=')
            logInfo("Fuseki args: %s" % argline)

            # Make a copy of the environment    
            env = dict(os.environ)
            
            if self.java_home_path:
                assert os.path.isdir(self.java_home_path), "Did not find java path: '%s'" % self.java_home_path
                env["JAVA_HOME"] = self.java_home_path
                
            try:
                self.fuseki_process = p = subprocess.Popen(argline,
                                                         # Working directory
                                                         cwd=self.fuseki_path,
                                                         env=env,
                                                         #stderr=subprocess.PIPE,
                                                         # Indicates that a pipe to the standard stream should
                                                         # be opened.
                                                         stdout=subprocess.PIPE,
                                                         )
            except KeyboardInterrupt:
                raise
            except Exception:
                logException("Popen failed: %s" % argline)
                logError(ERROR_HINTS)
                raise
            
            started = False
            out = []  
            log_actions = {"INFO": logInfo,
                           "WARN": logWarning,
                           "ERROR": logError,
                           } 
            while True:
                outline = p.stdout.readline().strip()
                line_values = outline.split(" ")
                log_function = logDebug
                if len(line_values) > 2:
                    out_type = line_values[1]
                    if out_type in log_actions:
                        outline = " ".join(line_values[2:])
                    log_function = log_actions.get(out_type, logDebug)
                outline = "FUSEKI: %s" % outline
                log_function(outline, logger_name="fuseki")
                if not started:
                    out.append(outline)
                    started = "Started" in outline 
                    if started:
                        out = []
                        self.server_start_time = datetime.datetime.now()
                        logInfo("fuseki server started at %s - pid = %s" % (self.server_start_time, p.pid), logger_name="fuseki")

                if p.poll() is not None:
                    break
                
            if started:
                self.server_end_time = datetime.datetime.now()
                logDebug("fuseki server ended at %s - pid = %s - status = %s" % (self.server_end_time, p.pid, p.returncode), logger_name="fuseki")
            else:
                time.sleep(.1) # give the 'port in use' exception time
                if p.poll() is not None:
                    out.append(p.stdout.read())
                    outtext = "".join(out)
                    if "ERROR" in outtext:
                        logError(outtext, logger_name="fuseki")
                        time.sleep(5)
                        raise PlatoError(outtext)
                                    
                logError("fuseki did not start <status=%s>:\n%s." % (p.returncode, "\n".join(out)), logger_name="fuseki")
            
        if self.blocking:
            _run_fuseki()
        else:
            t = threading.Thread(target=_run_fuseki, name="Run fuseki-server %s" % self.args, args=())
            t.start()
