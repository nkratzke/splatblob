﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sca.Tools.CodeAnalysis.Framework
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Control ctrl = new Control();
        }
    }
}
