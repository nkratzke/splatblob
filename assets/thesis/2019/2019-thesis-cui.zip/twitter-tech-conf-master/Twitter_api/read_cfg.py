import configparser
import os

# for safety reason and all the key or token are saved in twitter_config.txt
cf = configparser.ConfigParser()
work_dir = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(work_dir,'twitter_config.txt')

cf.read(path)
#for twitter api part
consumer_keys = cf.get('api_access','consumer_keys')
consumer_secret_keys = cf.get('api_access','consumer_secret_keys')
access_token = cf.get('api_access','access_token')
access_token_secret = cf.get('api_access','access_token_secret')
# print(consumer_keys,consumer_secret_keys,access_token,access_token_secret)
#for neo4j part

url = cf.get('neo4j_access','url')
username = cf.get('neo4j_access','username')
password = cf.get('neo4j_access','password')