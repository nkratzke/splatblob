import json
import os
import simplejson
import re
import matplotlib.pyplot as plt
from datetime import datetime
from datetime import timezone
from make_chart import make_time_chart
from collections import Counter
from wordcloud import WordCloud,STOPWORDS

time_list = []
time = 0
time_dict = {}
date_list = []
#test error from json files
def validate_and_import(file_path):
    with open(file_path) as json_file:
        try:
            simplejson.load(json_file)
            batch_import(file_path)
        except:
            print ("error happens in "+str(file_path))
            


def prettyPrint(wcDict):
    
    valKeyList = []
    for key,val in wcDict.items():
        valKeyList.append((key,val))
    #sort by date
    valKeyList.sort(reverse=False)
    number = []
    date = []
    for val,key in valKeyList:
        number.append(key)
        date.append(val)
    plt = make_time_chart(date,number)
    plt.show()
    print(number)
    print(date)



def batch_import(file_path):
    global time
    with open(file_path, "r", encoding="UTF-8") as f:
        tweets = json.load(f)
        for t in tweets:
            time = time + 1
            date = datetime.strptime(t["created_at"], '%a %b %d %H:%M:%S %z %Y').replace(
                tzinfo=timezone.utc).astimezone(tz=None).strftime('%b %d')
            date_list.append(date)

path = os.path.abspath(os.path.join(os.getcwd(), ".."))
#choose the dictionary
json_file_dir = path+"\\usecase2"
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]
for index, js_file in enumerate(json_files):

    file_path = json_file_dir+'\\'+js_file
    validate_and_import(file_path)

print(time)
#count the frequency
date_list = dict(Counter(date_list))
print(date_list)
prettyPrint(date_list)