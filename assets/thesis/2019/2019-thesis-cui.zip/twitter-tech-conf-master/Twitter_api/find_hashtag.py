import os, json
import pandas as pd
from collections import Counter



def prettyPrint(word_count_dict):
    value_key_list = []
    for key,value in word_count_dict.items():
        value_key_list.append((value,key))
    #order by value
    value_key_list.sort(reverse=True)
    #print with key and value
    for value,key in value_key_list:
            print(key,value)
            
words_list = []
word_count_dict = {}
i = 0
path = os.path.abspath(os.path.join(os.getcwd(), ".."))
json_file_dir = path+"\\testcase2"
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]

for index, js_file in enumerate(json_files):
    file_path = json_file_dir + '\\' + js_file
    with open(file_path) as json_file:
        json_text = json.load(json_file)
        #get the hashtag from the tweet
        for t in json_text:
            i = i + 1
            e = t["entities"]
            for h in e.get("hashtags",[]):
                words_list.append(h["text"].lower())
word_count_dict = dict(Counter(words_list))
print(i)
print(prettyPrint(word_count_dict))







