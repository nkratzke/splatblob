import json
import os
import simplejson
from datetime import datetime
from datetime import timezone
from make_chart import make_language_list
import re
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
from collections import Counter


# this script can be used for 
time_list = []
time = 0
time_dict = {}

#I wrote this country dictionary because twitter includes lolcat as a language type
#While it will be imcomplete if other usecase was recorded
country_list = {'en':"English", 'da':"Danish", 'it':"Italian1",
                'pl':"Polish", 'tr':"Turkish", 'pt':"Portuguese",
                'zh-cn':"Chinese(s)", 'en-gb':"English(UK)",
                'nl':"Dutch", 'hu':"Hungarian",'ja':"Japanese",
                'de':"German", 'es':"Spanish", 'fr':"French",
                'ru':"Russian", 'sv':"Swedish", 'th':"Thai",
                'vi':"Vietnamese", 'gl':"Galician", 'ca':"Catalan",
                'he':"Hebrew", 'da':"Danish", 'id':"Indonesian",
                'uk':"Ukrainian", 'ko':"Korean", 'hr':"Croatian",
                'ar':"Arabic", 'el':"Greek", 'fi':"Finnish",
                'no':"Norwegian",'zh-tw':"Chinese (T)",'ta':"Tamil",
                'cs':"Czech",'ro':"Romanian",'sr':"Serbian",
                'bg':"Bulgarian",'xx-lc':"Lolcat"
                }

def validate_and_import(file_path):
    with open(file_path) as json_file:
        try:
            simplejson.load(json_file)
            batch_import(file_path)
        except:
            print("error happens in " + str(file_path))


def prettyPrint(wcDict):
    valKeyList = []

    for key, val in wcDict.items():
        valKeyList.append((val, key))
    valKeyList.sort(reverse=False)
    number = []
    loc = []
    new_loc = []
    for val, key in valKeyList:
        number.append(val)
        loc.append(key)
    for l in loc:
        new_loc.append(country_list[l])

    plt = make_language_list(new_loc, number)
    plt.show()



def batch_import(file_path):
    global time
    with open(file_path, "r", encoding="UTF-8") as f:
        tweets = json.load(f)
        for t in tweets:
            time = time + 1
            location  = t["user"]["lang"]
            location = location.lower()
            time_list.append(location)

path = os.path.abspath(os.path.join(os.getcwd(), ".."))
json_file_dir = path+"\\usecase2"
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]
for index, js_file in enumerate(json_files):
    file_path = json_file_dir + '\\' + js_file
    validate_and_import(file_path)
time_list = dict(Counter(time_list))
print(time_list)

prettyPrint(time_list)