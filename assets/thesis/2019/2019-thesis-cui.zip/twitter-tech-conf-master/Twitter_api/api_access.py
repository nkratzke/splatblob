from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
from read_cfg import consumer_keys,consumer_secret_keys,access_token,access_token_secret
import time
import json
import os
import sys
import io

tweets = []
index = 0
file_index = 0
class listener(StreamListener):

    def on_data(self, data):
        global index
        global tweets
        global file_index
        tweet = json.loads(data)
        tweets.append(tweet)
        #save 500 tweets per file
        tweets_per_file = 500
        print(index)
        index = index + 1

        if(index==tweets_per_file):
            work_dir = os.path.dirname(os.path.abspath(__file__))
            json_path = os.path.join(work_dir, 'twitter_stream')
            with open(json_path+str(file_index)+".json", 'a') as my_file:
                my_file.write(json.dumps(tweets))
                index = 0
                file_index = file_index + 1
                tweets = []
        return True

    def on_error(self, status_code):
        print(status_code)

def start_stream():
    #avoid error interrupts the recording process
    while True:
        try:
            print("start")
            auth = OAuthHandler(consumer_keys, consumer_secret_keys)
            auth.set_access_token(access_token,access_token_secret)
            twitterStream = Stream(auth, listener())
            #set the filter by hashtags and language limitation
            twitterStream.filter(track=["#DockerCon"],languages=["en"])

        except:
            continue
        
start_stream()
