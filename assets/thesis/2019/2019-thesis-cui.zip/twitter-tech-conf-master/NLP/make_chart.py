import matplotlib.pyplot as plt
import numpy as np
from process_with_blob import text_blob
import random




def make_id_list(id_list,reply_num):
    id_list =np.array(id_list)
    reply_num = np.array(reply_num)
    y = np.arange(len(id_list))+1
    x = reply_num
    plt.barh(y,reply_num,fc="g",tick_label=id_list,label ="reply_num")
    for a,b in zip(x,y):
        plt.text(a,b-0.35,"%.0d" % a,ha='left',va='bottom',fontsize=7)

    plt.grid(axis='x')
    plt.legend()
    return plt

def make_language_list(id_list,reply_num):
    id_list =np.array(id_list)
    reply_num = np.array(reply_num)
    y = np.arange(len(id_list))+1
    x = reply_num
    plt.barh(y,reply_num,fc="g",tick_label=id_list)
    for a,b in zip(x,y):
        plt.text(a,b-0.35,"%.0d" % a,ha='left',va='bottom',fontsize=7)
    plt.xlabel("number of tweets")
    plt.grid(axis='x')
    plt.tick_params(labelsize=6)

    plt.savefig("location.jpg", dpi=200)
    return plt

def make_time_chart(time_list,number):

    time_list = np.array(time_list)
    number = np.array(number).astype(np.int32)
    plt.bar(range(len(number)),number,fc="b",tick_label=time_list,label ="tweets per day")
    plt.axhline(np.average(number), color='green')
    plt.xlabel("Date")
    plt.ylabel("Number of tweets")
    plt.text(0,np.average(number),"Average: "+str(int(np.average(number))))
    plt.tick_params(labelsize=6)
    plt.legend()
    return plt

def user_post_chart(id_list,post_list):
    pos_list,neg_list,neu_list,number_list = text_blob(post_list)
    new_list = list(zip(id_list,number_list,pos_list,neg_list,neu_list))
    # new_list = random.sample(new_list,10)
    # new_list = sorted(new_list,key=lambda new_list:new_list[1],reverse=False)

    id_list= []
    pos_list = []
    neg_list = []
    neu_list = []
    for each in new_list:
        id_list.append(each[0])
        pos_list.append(each[2])
        neg_list.append(each[3])
        neu_list.append(each[4])

    y = np.arange(len(id_list))
    x = pos_list
    x1 = neg_list
    x2 = neu_list
    # plt.figure(figsize=(8, 1.5))
    plt.barh(range(len(id_list)), pos_list,height= 0.4,fc="b",tick_label=id_list,label="positive")
    plt.barh(range(len(id_list)), neg_list,height= 0.4,left=pos_list,fc="y",label="negative")
    plt.barh(range(len(id_list)), neu_list,height= 0.4, left=np.array(neg_list)+np.array(pos_list), fc="g", label="neutral")

    for a,b,c,d in zip(x,y,x1,x2):
        if(a!=0):
            plt.text(a, b, "%.0f" % a, ha='left', va='bottom', fontsize=6)
        if(c!=0):
            plt.text(c + a + 0.75, b , "%.0f" % c, ha='left', va='bottom', fontsize=6)
        if(d!= 0):
            plt.text(c + a+ d + 0.5, b, "%.0f" % d, ha='left', va='bottom', fontsize=6)


    plt.xlabel("Number of tweets")
    plt.grid(axis='x')
    plt.tick_params(labelsize=6)
    plt.legend(loc='center left', bbox_to_anchor=(0.75, 0.15))
    plt.savefig('user_post_kubecon.jpg')


    plt.show()
    return plt

def user_overall_chart(id_list,post_list):
    pos_list, neg_list, neu_list, num_list = text_blob(post_list)

    x = np.array(pos_list).astype(np.int)
    x = np.sum(x)
    x1 = np.array(neg_list).astype(np.int)
    x1 = np.sum(x1)
    x2 = np.array(neu_list).astype(np.int)
    x2 = np.sum(x2)
    print(x,x1,x2)

    result = [x,x1,x2]
    colors = ['blue','yellow','green']
    labels = ['positive','negative','neutral']

    plt.pie(result, labels=labels, colors = colors,shadow= False,autopct='%.0f%%',pctdistance= 0.6)
    plt.show()


def make_user_list(id_list,reply_num):

    id_list =np.array(id_list)
    reply_num = np.array(reply_num)
    y = np.arange(len(id_list))+1
    x = reply_num
    plt.barh(y,reply_num,fc="g",tick_label=id_list,label ="follower_num")
    for a,b in zip(x,y):
        plt.text(a,b-0.35,"%.0d" % a,ha='left',va='bottom')


    plt.grid(axis='x')

    plt.legend()
    return plt

def make_retweeted_chart(spread_list,retweeted_list):

    new_retweeted_list = np.log10([i+1 for i in retweeted_list])
    new_spread_list = np.log10([i+1 for i in spread_list])
    avg_retweet = np.log10(np.average(retweeted_list))
    max_spread = np.log10(np.max(spread_list))
    avg_spread = np.log10(np.average(spread_list))
    max_retweet = np.log10(np.max(retweeted_list))
    #to avoid log(0)
    min_spread = np.log10(np.min(spread_list)+1)
    min_retweet = np.log10(np.min(retweeted_list)+1)
    plt.axvline(avg_retweet,color='green')
    plt.axhline(avg_spread, color='green')
    plt.text(avg_retweet,max_spread-0.2,"average of\nthe retweeted time",fontsize=10)
    plt.text(max_retweet-0.5,avg_spread,
             "average of\nthe spread score", fontsize=10)
    plt.text((max_retweet+avg_retweet-0.5)/2,(max_spread+avg_spread)/2,"Multiplier",fontsize = 18)
    plt.text((avg_retweet-0.5)/2,(max_spread+avg_spread)/2,"Spreader",fontsize = 18)
    plt.text((avg_retweet-0.5)/2,(min_spread+avg_spread-0.5)/2,"Watcher",fontsize = 18)
    plt.text((max_retweet+avg_retweet-0.5)/2,(min_spread+avg_spread-0.5)/2,"Visionaries",fontsize = 18)
    plt.ticklabel_format(style='plain')
    plt.scatter(new_retweeted_list, new_spread_list, color='g')
    plt.xlabel('retweeted time(in logarithm form)\n recognition by others')
    plt.ylabel('spread score(in logarithm form)\n reach')
    plt.autoscale(True,axis='y')
    plt.show()

def make_3d_plot(spread_list,retweeted_list,mention_list):
    z = np.log10([i+1 for i in spread_list])
    y = np.log10([i+1 for i in retweeted_list])
    x = np.log10([i+1 for i in mention_list])

    ax = plt.subplot(projection='3d')
    ax.scatter(x, y, z, c='g',s=z*z)


    ax.set_zlabel('spread score\n(in logarithm form)')
    ax.set_ylabel('retweeted time\n(in logarithm form)')
    ax.set_xlabel('mention time\n(in logarithm form)')
    plt.draw()
    plt.savefig("result_usecase1.jpg")
    plt.show()



def make_mention_chart(spread_list, mention_list):


    new_mention_list = np.log10([i+1 for i in mention_list])
    new_spread_list = np.log10([i+1 for i in spread_list])
    avg_mention = np.log10(np.average(mention_list))
    max_spread = np.log10(np.max(spread_list))
    avg_spread = np.log10(np.average(spread_list))
    max_mention = np.log10(np.max(mention_list))
    min_spread = np.log10(np.min(spread_list)+1)
    min_mention = np.log10(np.min(mention_list)+1)
    plt.axvline(avg_mention,color='green')
    plt.axhline(avg_spread, color='green')
    plt.text(avg_mention,max_spread-0.2,"average of\nthe mention time",fontsize=10)
    plt.text(max_mention-0.5,avg_spread,
             "average of\nthe spread score", fontsize=10)
    plt.text((max_mention+avg_mention-0.5)/2,(max_spread+avg_spread)/2,"Multiplier",fontsize = 18)
    plt.text((avg_mention-0.5)/2,(max_spread+avg_spread)/2,"Spreader",fontsize = 18)
    plt.text((avg_mention-0.5)/2,(min_spread+avg_spread-0.5)/2,"Watcher",fontsize = 18)
    plt.text((max_mention+avg_mention-0.5)/2,(min_spread+avg_spread-0.5)/2,"Visionaries",fontsize = 18)
    plt.ticklabel_format(style='plain')
    plt.scatter(new_mention_list, new_spread_list, color='g')
    plt.xlabel('mention time(in logarithm form)\n acceptance by others')
    plt.ylabel('spread score(in logarithm form)\n reach')
    plt.autoscale(True,axis='y')
    plt.show()

def find_range(data_list):
    x_ticks = np.arange(-1, 1.05, 0.05)
    plt.xticks(x_ticks,rotation=45,fontsize=6)
    plt.hist(data_list, 
             range=(-1,1),
             bins=40,
             color='steelblue',
             edgecolor='k'
             )
    plt.xlabel("Polarity")
    plt.savefig("sentiment.jpg",dpi=300)
    plt.show()