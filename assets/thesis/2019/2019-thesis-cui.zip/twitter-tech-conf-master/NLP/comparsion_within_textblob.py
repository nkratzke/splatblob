from textblob import TextBlob,Blobber
from textblob.sentiments import NaiveBayesAnalyzer
from textblob.classifiers import NaiveBayesClassifier
from nltk.corpus import stopwords
import re
import csv
import pandas as pd

import pickle
import numpy as np
import json

def clean_words(data):
    data = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', data)
    data = re.sub('@[\w]*', '', data)
    data = re.sub('#[\w]*', '', data)
    data = re.sub("[\s+\.\!\/_,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+", " ", data)
    return data

#####Case1#####
#####Sentiment Analysis Dataset.csv(160MB--exceed the upload limitation)#####

##### make dataset

# r = csv.reader(open('Sentiment Analysis Dataset.csv',encoding="utf-8"))
# lines = [line for line in r]
# i = 0
# f=open('train_set.csv', 'w',encoding="utf-8")
# f1=open('test_set.csv', 'w',encoding="utf-8")
# for line in lines:
#     if(i==0):
#         i = i+1
#         pass
#     else:
#
#
#         if (line[1] == "1"):
#             line[1] = 'positive'
#         elif (line[1] == "0"):
#             line[1] = "negative"
#
#         if(i<2001):
#
#             f.write(clean_words(line[3]))
#             f.write(",")
#             f.write(line[1])
#             f.write('\n')
#
#         if(i>2000):
#             f1.write(clean_words(line[3]))
#             f1.write(",")
#             f1.write(line[1])
#             f1.write('\n')
#         i = i + 1
#         if(i>22000):
#             break
# print("down")
# f.close()
# f1.close()


#####Case2#####
#####training.1600000.processed.noemoticon.csv(227MB)#####
#####need to shuffle the list#####

# r = csv.reader(open('training.1600000.processed.noemoticon.csv',encoding="ISO-8859-1"))
# lines = [line for line in r]
# i = 0
# f=open('train_set1.csv', 'w',encoding="utf-8")
# f1=open('test_set1.csv', 'w',encoding="utf-8")
# random.shuffle(lines)
# for line in lines:
#     if(i==0):
#         i = i+1
#         pass
#     else:
#
#
#         if (line[0] == "4"):
#             line[0] = 'positive'
#         elif (line[0] == "0"):
#             line[0] = "negative"
#
#         if(i<2001):
#
#             f.write(clean_words(line[5]))
#             f.write(",")
#             f.write(line[0])
#             f.write('\n')
#
#         if(i>2000):
#             f1.write(clean_words(line[5]))
#             f1.write(",")
#             f1.write(line[0])
#             f1.write('\n')
#         i = i + 1
#         if(i>22000):
#             break
# print("down")
# f.close()
# f1.close()







#####NaiveBayesClassifier
#Use case1/case2 trainset as classifier
# with open('train_set.csv','r',encoding="utf-8") as fp:
# with open('train_set1.csv','r',encoding="utf-8") as fp:
#
#     cl = NaiveBayesClassifier(fp, format="csv")
#     print("ok")
#
#     trained_file = open('sentiment_classifier.obj', 'wb')
#     pickle.dump(cl, trained_file)
#     trained_file.close()

#Evaluation

# with open('test_set.csv', 'r',encoding="utf-8") as fp:
# with open('test_set1.csv', 'r',encoding="utf-8") as fp:

#     cl = pickle.load(open('sentiment_classifier.obj', 'rb'))
#     print(cl.accuracy(fp,format="csv"))

#case1:test_set: around 0.58,test_set1:aournd 0.57
#case2:test_set:0.67,test_set1:0.68



#####Use analyzer

# blobber = Blobber(analyzer=NaiveBayesAnalyzer())

# r = csv.reader(open('test_set.csv',encoding="utf-8"))
# r = csv.reader(open('test_set1.csv',encoding="utf-8"))

# lines = [line for line in r]
# i = 0
# posright = 0
# negright = 0
# neu = 0
# for line in lines:
#     i = i + 1
#     b = blobber(line[0]).sentiment.p_pos
#
#     if(b>0.5):
#         if(line[1]=="positive"):
#             posright = posright + 1

#     elif(b<0.5):
#         if (line[1] == "negative"):
#             negright = negright + 1
#     else:
#         
#         neu = neu+1
# 
# right = posright+negright
# print(right/(i-neu))
#    
# need to exclude the situation of neutral
#case1:around 0.53
#case2:around 0.54



#####Use textblob

# r = csv.reader(open('test_set.csv',encoding="utf-8"))
# lines = [line for line in r]
# i = 0
# posright = 0
# negright = 0
# neu = 0
# for line in lines:
#     i = i + 1
#     b = TextBlob(line[0]).sentiment[0]
#
#     if(b>0):
#         if(line[1]=="positive"):
#             posright = posright + 1
#
#     elif(b<0):
#         if (line[1] == "negative"):
#             negright = negright + 1
#     else:
#         neu = neu+1
# 
# right = posright+negright
# print(right/(i-neu))

#also need to exclude the situation of neutral

#case1: around 0.67
#case2: around 0.68






