import re
from textblob import TextBlob


#analyze result tweet
def text_blob(data_list):
    pos_list=[]
    neg_list=[]
    neu_list=[]
    number_list=[]
    for index in data_list:
        neu = 0
        pos = 0
        neg = 0
        all = 0
        for i in index:
            i = str(i)
            all = all+1
            result = TextBlob(i).sentiment[0]
            #usecase 1: 0.25 to 0
            if(result>=0.25):
                pos = pos+1
            elif(result<0):
                neg = neg+1
            elif(0<=result<=0.25):
                neu = neu+1

        pos_list.append(pos)
        neg_list.append(neg)
        neu_list.append(neu)
        number_list.append(all)
    return pos_list,neg_list,neu_list,number_list



def clean_words(data):
    data = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', data)
    data = re.sub('@[\w]*', '', data)
    data = re.sub('#[\w]*', '', data)
    data = re.sub("[\s+\.\!\/_,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+", " ", data)
    return data


