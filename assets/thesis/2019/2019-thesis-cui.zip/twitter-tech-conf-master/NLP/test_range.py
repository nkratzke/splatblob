from textblob import TextBlob
import os
import simplejson
import json
from make_chart import find_range
import re
from collections import Counter
def validate_and_import(file_path):
    with open(file_path) as json_file:
        try:
            simplejson.load(json_file)
            batch_import(file_path)
        except:
            print ("error happens in "+str(file_path))

def batch_import(file_path):

    with open(file_path, "r", encoding="UTF-8") as f:
        tweets = json.load(f)
        for t in tweets:
            i = clean_words(t["text"])
            result = TextBlob(i).sentiment[0]
            result_list.append(result)

def clean_words(data):
    data = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', data)
    data = re.sub('@[\w]*', '', data)
    data = re.sub('#[\w]*', '', data)
    data = re.sub("[\s+\.\!\/_,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+", " ", data)
    return data


result_list = []
path = os.path.abspath(os.path.join(os.getcwd(), ".."))
json_file_dir = path+"\\usecase2"
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]
for index, js_file in enumerate(json_files):
    file_path = json_file_dir+'\\'+js_file
    batch_import(file_path)

find_range(result_list)
# print(Counter(result_list))