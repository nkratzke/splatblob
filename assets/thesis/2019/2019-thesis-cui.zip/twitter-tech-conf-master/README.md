# Social Network Analysis of Twitter Interactions around Technology Conferences (Xiao Cui)

Industrial technology conferences are used to demonstrate and report on the latest trends 
in software, systems, gadgets, frameworks, services, solutions, and more. 
To estimate the future impact of these trends corresponding triggered social network interactions 
might be a viable data source for evaluation. Trends that trigger more interactions 
might be more interesting to the audience than trends with less impact on social media channels.

This thesis should exploratively gather and analyze data from the social network 
Twitter around cloud computing related technology conferences. 
It should analyze whether it is possible to identify such trends and correlated 
multipliers. The overall aim is to identify automatically the

- “hot topics”
- and relevant multipliers

in a stream of social network interactions around technology conferences.
Therefore, the thesis compromises the following tasks:

- Literature review on sentiment analysis and natural language processing.
- Literature review on social network analysis (graphs).
- Comparison of existing NLP and sentiment analysis libraries (usability for the study).
- Comparison of existing graph databases (usability and necessity for the study).
- Implementation of a Twitter stream recording solution using [Tweepy](https://www.tweepy.org).
- Implementation of a sentiment and multiplier analysis solution on recorded tweets based on libraries from the comparisons above.

Additionally, the analysis solution should demonstrate its operational
functioning on two concrete case studies (technology conferences about cloud
computing and container-based cloud-native platforms). The following technology
conferences should be used to demonstrate the operational functioning. 
It should be considered that the relevant reporting around conferences already
starts in the upfront and endures more extended than the events.

- DockerCon (San Francisco, 29 Apr - 02 May, 2019)
- KubeCon + Cloud Native Con Europe (Barcelona, May 20 - 23, 2019)

Both use cases are not offensive from an ethical point of view. 
However, the thesis should also discuss critically how the same tools and
techniques could be misused. E.g., national authorities or further actors
could observe systematically social media channels to suppress or manipulate
public opinions or freedom of media reporting.

Note: Should individual aspects are shown to be too difficult to achieve during
the processing of this work, the task can be adapted - after credible proof of
difficulty.