import os
from read_cfg import url,username,password
from py2neo import Graph


def find_user(num):

    cypher = """\
    Match (n:User)
    Return n.username, n.follower
    Order by n.follower Desc
    Limit"""+" "+str(num)

    query = graph.run(cypher)
    query1 = query.to_ndarray()
    print(query.to_table())
    return query1

def find_tweet(id):
    query1 = graph.run("""\
    Match (n:Tweet{id:"""
    +str(id)
    +"""})Return n.text
    """).to_ndarray()
    return query1[0][0]

def find_reply(id):
    result = []
    query1 = graph.run("""\
    Match (t:Tweet)-[:REPLY_TO]->(d:Tweet{id:"""
    +str(id)
    +"""})
    Return t.text,d
    """).to_ndarray()
    for i in range(len(query1)):
        result.append(query1[i][0])
    return result

def find_most_reply(num):
    cypher = """\
    Match (n:Tweet)-[:REPLY_TO]->(n1:Tweet)
    Return count (n) as Reply_num ,n1.id as Id
    
    Order by Reply_num Desc
    Limit"""+" "+str(num)

    print(graph.run(cypher).to_table())
    query = graph.run(cypher).to_ndarray()
    return query

def find_most_retweet():
    cypher = """\
    MATCH (u:User)-[:POSTS]->(t:Tweet)-[:RETWEETS]->(t2:Tweet)
    RETURN u.username,u.follower,count(t) as retweet_count
    Order by retweet_count desc
    """
    # print(graph.run(cypher).to_table())
    query = graph.run(cypher).to_ndarray()
    return query

def find_most_mention():
    cypher = """\
    MATCH (u:User)<-[:MENTIONS]-(t:Tweet)
    Return u.username,u.follower,count (t) as mention_count
    Order by mention_count desc
    """
    # print(graph.run(cypher).to_table())
    query = graph.run(cypher).to_ndarray()
    return query

def find_mention(username):
    query = graph.run("""\
    MATCH (u:User{username:"""
    +"'"+str(username)+"'"+
    """})<-[:MENTIONS]-(t:Tweet)
    Return u.username,u.follower,count (t) as mention_count

    """).to_ndarray()
    return query

def find_retweeted(username):
    query = graph.run("""\
    MATCH (u:User{username:"""
    + "'" + str(username) + "'" +
    """})-[: POSTS]->(t:Tweet)<-[: RETWEETS]-(t2:Tweet)
    RETURN u.username, u.follower, count(t2) as retweeted_count
      """).to_ndarray()
    return query

def find_post(username):
    query = graph.run("""\
        MATCH (u:User{username:"""
                      + "'" + str(username) + "'" +
                      """})-[: POSTS]->(t:Tweet)
                      RETURN t.text
                        """).to_ndarray()
    return query

work_dir = os.path.dirname(os.path.abspath(__file__))
graph = Graph(url,username=username,password=password)










