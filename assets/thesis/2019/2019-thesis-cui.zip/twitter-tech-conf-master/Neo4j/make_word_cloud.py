from collections import Counter
import json
import os
import simplejson
import re
from wordcloud import WordCloud,STOPWORDS
import matplotlib.pyplot as plt
import numpy as np

work_dir = os.path.dirname(os.path.abspath(__file__))
tweet_list = []
wcdict = {}


def prettyPrint(wordCountDict):
    value_key_list = []
    for key,value in wordCountDict.items():
        value_key_list.append((value,key))
    value_key_list.sort(reverse=True)
    hot_words = []
    count = []
    for value,key in value_key_list:
        count.append(value)
    count = np.array(count).astype(np.int)
    average = np.average(count)
    print(average)
    for val,key in value_key_list:
        if(int(val)>average):
            hot_words.append(key)
    return hot_words

def validate_and_import(file_path):
    with open(file_path) as json_file:
        try:
            simplejson.load(json_file)
            batch_import(file_path)
        except:
            print ("error happens in "+str(file_path))

def batch_import(file_path):
    i = 0
    with open(file_path, "r", encoding="UTF-8") as f:
        tweets = json.load(f)
        for t in tweets:
            i = i + 1
            tweet_list.append(t["text"])

#
# This part was the codes created by Stephen Hsu
#
""" Title: Introduction to Data Science: Custom Twitter Word Clouds
Author: Stephen Hsu
Date: 25.04.2019
Availability: https://medium.com/@shsu14/introduction-to-data-science-custom-twitter-word-clouds-704ec5538f46 """

def make_word_cloud(raw_string):

    raw_string = ' '.join(tweet_list)
    raw_string = re.sub(r'http\S+', '', raw_string)
    raw_string = re.sub(r"\\[a-z][a-z]?[0-9]+", '', raw_string)
    raw_string = re.sub('[^A-Za-z ]+', '', raw_string)
    words = raw_string.split(" ")
    words = [word.lower() for word in words]
    words = [word for word in words if len(word) > 2]
    words = [word for word in words if word not in STOPWORDS]
    word_count_dict = dict(Counter(words))
    hot_words = prettyPrint(word_count_dict)
    wordcloud = WordCloud(
        background_color='black', max_words=200,
        max_font_size=50, scale=3,
        repeat= False,
    ).generate(str(hot_words))
    plt.axis('off')
    plt.imshow(wordcloud,interpolation="bilinear")
    plt.savefig('dockercon.jpg', dpi=300)
    plt.show()

json_file_dir = work_dir+'\\usecase1'
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]
for index, js_file in enumerate(json_files):
    file_path = json_file_dir+'\\'+js_file
    validate_and_import(file_path)
print("import finish")
make_word_cloud(tweet_list)

