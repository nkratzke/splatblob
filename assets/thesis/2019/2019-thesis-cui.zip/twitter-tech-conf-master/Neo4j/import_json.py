#
# This file was based on the codes created by Nicole White, And some improvements were made.
#
""" Title: neo4j-jupyter/scripts/twitter.py
Author: Nicole White
Date: 05.03.2019
License: https://github.com/nicolewhite/neo4j-jupyter/blob/master/lib/vis/LICENSE-MIT
Availability: https://github.com/nicolewhite/neo4j-jupyter/blob/master/scripts/twitter.py """

import json
from search_tweet import find_tweet,find_user
import os
from read_cfg  import url,username,password
import simplejson


from py2neo import Graph,Node,Relationship,NodeMatcher
graph = Graph(url,username=username,password=password)
work_dir = os.path.dirname(os.path.abspath(__file__))
graph.run("CREATE CONSTRAINT ON (u:User) ASSERT u.username IS UNIQUE")
graph.run("CREATE CONSTRAINT ON (t:Tweet) ASSERT t.id IS UNIQUE")
graph.run("CREATE CONSTRAINT ON (h:Hashtag) ASSERT h.name IS UNIQUE")
matcher = NodeMatcher(graph)


def batch_import(file_path):
    i = 0
    with open(file_path,"r" ,encoding="UTF-8") as f:
        tweets = json.load(f)
        for t in tweets:
            i=i+1
            print(i)

            u = t["user"]
            e = t["entities"]

            tweet = Node("Tweet", id=t["id"])
            graph.merge(tweet,"Tweet","id")
            tweet["text"] = t["text"]
            graph.push(tweet)

            user = Node("User", username=u["screen_name"])
            graph.merge(user,"User","username")
            user["follower"] = u["followers_count"]
            graph.push(user)
            graph.merge(Relationship(user,"POSTS",tweet))


            for h in e.get("hashtags",[]):
                hashtag = Node("Hashtag", name = h["text"].lower())
                graph.merge(hashtag,"Hashtag","name")
                graph.merge(Relationship(hashtag,"TAGS",tweet))

            #will generate some user node with null follower value
            for m in e.get('user_mentions', []):

                exists = matcher.match("User",username=m['screen_name'])
                if exists:
                    mention = exists.first()
                else:
                    mention = Node("User", username=m["screen_name"])
                    graph.merge(mention, "User", "username")
                    mention["follower"] = find_user(m['screen_name'])
                    graph.push(mention)
                graph.merge(Relationship(tweet,"MENTIONS",mention))

            reply = t.get("in_reply_to_status_id")
            if reply:
                exists = matcher.match("Tweet", id=reply)
                if exists:
                    reply_tweet = exists.first()
                else:
                    reply_tweet = Node("Tweet", id=reply)
                    graph.merge(reply_tweet,"Tweet","id")
                    #find not recorded text with api
                    reply_tweet["text"] = find_tweet(reply)
                    graph.push(reply_tweet)
                graph.merge(Relationship(tweet,"REPLY_TO",reply_tweet))


            quote = t.get("quoted_status_id")
            if quote:
                exists = matcher.match("Tweet", id=quote)
                if exists:
                    quote_tweet = exists.first()
                else:
                    quote_tweet = Node("Tweet", id=quote)
                    graph.merge(quote_tweet,"Tweet","id")
                    #find not recorded text with api
                    quote_tweet["text"] = find_tweet(quote)
                    graph.push(quote_tweet)
                graph.merge(Relationship(tweet,"QUOTE_FROM",quote_tweet))

            ret = t.get("retweeted_status",{}).get("id")
            if ret:
                exists = matcher.match("Tweet", id=ret)
                if exists:
                    retweet= exists.first()
                else:
                    retweet = Node("Tweet", id=ret)
                    graph.merge(retweet,"Tweet","id")
                    retweet["text"] = find_tweet(ret)
                    graph.push(retweet)
                graph.merge(Relationship(tweet,"RETWEETS",retweet))

def validate_and_import(file_path):
    with open(file_path) as json_file:
        try:
            simplejson.load(json_file)
            batch_import(file_path)
        except:
            print ("error happens in "+str(file_path))
            invalid_json_files.append(file_path)




invalid_json_files = []
read_json_files = []
path = os.path.abspath(os.path.join(os.getcwd(), ".."))
json_file_dir = path+"\\usecase2"
json_files = [is_json for is_json in os.listdir(json_file_dir) if is_json.endswith('.json')]
for index, js_file in enumerate(json_files):
    file_path = json_file_dir+'\\'+js_file
    validate_and_import(file_path)
print("all finish")
print ("wrong file:"+str(invalid_json_files))
print("validated files:"+str(len(read_json_files)))



    