from search_ import graph,find_most_retweet,find_mention,find_retweeted,find_post
from py2neo import Graph
from scipy.stats import spearmanr
import numpy as np
from make_chart import make_retweeted_chart,make_mention_chart,user_post_chart,user_overall_chart,make_3d_plot
import pickle
import pandas as pd

# # # # step 1 : find who retweet and order by retweet time
# query = find_most_retweet()
# query_length = len(query)
# retweet_count = 0
# follower_count = 0
# valid_length = 0
# user_list = []
# retweet_list = []
# follower_list = []
# for i in range(query_length):
#     #considering user does not exists or name changed
#     if (query[i][1] is not None):
#         follower = str(query[i][1])
#         if (follower.isdigit()):
#             user_list.append(query[i][0])
#             follower_list.append(query[i][1])
#             retweet_list.append(query[i][2])
#             follower_count = follower_count + int(query[i][1])
#             retweet_count = retweet_count + int(query[i][2])
#             valid_length = valid_length + 1
#
# new_list = list(zip(user_list,follower_list,retweet_list,follower_list))
# #calculate the average user's followers and retweet times
# retweet_avg = retweet_count/valid_length
# follower_avg = follower_count/valid_length
# print("retweet_avg: "+ str(retweet_avg))
# print("follower_avg: "+ str(follower_avg))
#
# #step2 calculate users' spread influence by multiplying followers and retweet times
# spread_list = []
# # #step3 find these user's influence by calculate the time of mention and retweet
# # new_user_list = []
# # new_follower_list = []
# mention_list = []
# retweeted_list = []
# user_list=[]
# follower_list = []
# # #find the time of mention and tweeted tweet of these user
# #  remove user who have 0 retweeted tweet and metioned time
# for eachuser in new_list:
#     user_mention = find_mention(eachuser[0])
#     user_retweeted = find_retweeted(eachuser[0])
#
#     if(user_mention.size == 0):
#         if(user_retweeted.size == 0):
#             pass
#         else:
#             mention_list.append(0)
#             user_list.append(eachuser[0])
#             retweeted_list.append(user_retweeted[0][2])
#             spread_list.append(int(eachuser[1])*int(eachuser[2]))
#             follower_list.append(eachuser[3])
#     else:
#         user_list.append(eachuser[0])
#         mention_list.append(user_mention[0][2])
#         follower_list.append(eachuser[3])
#         if(user_retweeted.size == 0):
#             retweeted_list.append(0)
#             spread_list.append(int(eachuser[1])*int(eachuser[2]))
#
#         else:
#             retweeted_list.append(user_retweeted[0][2])
#             spread_list.append(int(eachuser[1])*int(eachuser[2]))
#
#
# #pickle the result
#
# list0 = open('userlist_usecase.obj', 'wb')
# pickle.dump(user_list, list0)
# list0.close()
# list1 = open('spreadlist_usecase.obj', 'wb')
# pickle.dump(spread_list, list1)
# list1.close()
# list2 = open('retweetedlist_usecase.obj', 'wb')
# pickle.dump(retweeted_list, list2)
# list2.close()
# list3 = open('mentionlist_usecase.obj', 'wb')
# pickle.dump(mention_list, list3)
# list3.close()
# list4 = open('followerlist_usecase.obj',"wb")
# pickle.dump(follower_list, list4)
# list4.close()
#
# print("dump is ok")

# # 
list0 = pickle.load(open('userlist_usecase.obj', 'rb'))
list1 = pickle.load(open('spreadlist_usecase.obj', 'rb'))
list2 = pickle.load(open('retweetedlist_usecase.obj', 'rb'))
list3 = pickle.load(open('mentionlist_usecase.obj', 'rb'))
list4 = pickle.load(open('followerlist_usecase.obj', 'rb'))

print("load is ok")
#
user_list = list(list0)
spread_list = list(list1)
retweeted_list =list(list2)
mention_list = list(list3)
follower_list = list(list4)

spread_list = np.array(spread_list).astype(np.int)
retweeted_list = np.array(retweeted_list).astype(np.int)
mention_list = np.array(mention_list).astype(np.int)

####make a overview of 3d polt:
# make_3d_plot(spread_list,retweeted_list,mention_list)
#
# ####step4-----make two chart about influence
#
# make_retweeted_chart(spread_list,retweeted_list)
# make_mention_chart(spread_list,mention_list)


#######step5-----find the multiplier

avg_spread = np.average(spread_list)
avg_retweeted = np.average(retweeted_list)
avg_mention = np.average(mention_list)
print(avg_retweeted)
print(avg_mention)


new_list = list(zip(user_list,spread_list,mention_list,retweeted_list,follower_list))
influence_mention_user = []
for eachuser in new_list:
    if (eachuser[1] > avg_spread):
        if (eachuser[2] > avg_mention):
            influence_mention_user.append(eachuser)
#
# spread_retweeted_list = list(zip(user_list,spread_list,retweeted_list))
influence_retweeted_user = []
for eachuser in new_list:
    if(eachuser[1]>avg_spread):
        if(eachuser[3]>avg_retweeted):
            influence_retweeted_user.append(eachuser)
new_list1 = list(set(influence_mention_user).union(set(influence_retweeted_user)))

#export the list of influencial users
overall_list = []
for eachuser in new_list:
    if (eachuser[1] > avg_spread):
        if (eachuser[2] > avg_mention or eachuser[3] > avg_retweeted):
            overall_list.append(eachuser)
name = ['username','spread_score','mention_time','retweeted_time','follower_number']
test = pd.DataFrame(columns=name,data=overall_list)

test.to_csv('test1.csv',encoding='utf-8')


# #
# user_list1 = []
# post_list = []
# special_list = []
# special_list1 = []
#
# # for eachuser in new_list1:
# #     # if statements are used to exclude or record some user who posts too much tweets
# #     if (eachuser[0] == "DockerCon"):
# #         special_list.append(eachuser[0])
# #         special_list1.append(find_post(eachuser[0]))
# #     if (eachuser[0] == "SantchiWeb"):
# #         special_list.append(eachuser[0])
# #         special_list1.append(find_post(eachuser[0]))
# #     user_list1.append(eachuser[0])
# #     post_list.append(list(find_post(eachuser[0])))
#
#
# for eachuser in new_list1:
#
#     if (eachuser[0] != "DockerCon" or eachuser[0] != "SantchiWeb"):
#         special_list.append(eachuser[0])
#         special_list1.append(find_post(eachuser[0]))
#
# # user_post_chart(user_list1,post_list)
# user_post_chart(special_list,special_list1)
#
# for eachuser in influence_retweeted_user:
#     user_list1.append(eachuser[0])
#     post_list.append(list(find_post(eachuser[0])))
#
#

#
# special_list2 = []
# special_list3 = []
# for eachuser in influence_mention_user:
# #     # if statements are used to record or exclude some user who posts too much tweets
#     if (eachuser[0] == "DockerCon"):
#         special_list.append(eachuser[0])
#         special_list1.append(find_post(eachuser[0]))
#     if (eachuser[0] == "SantchiWeb"):
#         special_list.append(eachuser[0])
#         special_list1.append(find_post(eachuser[0]))
#     if(eachuser[0] not in user_list1):
#         if(eachuser[0]!="DockerCon"and eachuser[0]!="SantchiWeb"):
#             special_list2.append(eachuser[0])
#             special_list3.append(find_post(eachuser[0]))
#
#         user_list1.append(eachuser[0])
#         post_list.append(list(find_post(eachuser[0])))


# user_post_chart(special_list2,special_list3)
# user_post_chart(special_list,special_list1)
# user_overall_chart(user_list1,post_list)


# spread_list = np.array(spread_list).astype(np.int)
# mention_list = np.array(mention_list).astype(np.int)
# retweeted_list = np.array(retweeted_list).astype(np.int)
# follower_mention = spearmanr(retweeted_list,mention_list)
# print(follower_mention)

###export file as csv 
# new_list = list(zip(list(list0),list(list1),list(list2),list(list3)))
# name = ['username','spread_score','retweeted_time','mentioned_time']
# test = pd.DataFrame(columns=name,data=new_list)
# test.to_csv('test.csv',encoding='utf-8')

# print("go")
#check
# # for eachuser in new_list1:
# #     print(eachuser)
# print(len(user_list))
# print(len(retweeted_list))
# print(len(spread_list))
# print(len(mention_list))
#

