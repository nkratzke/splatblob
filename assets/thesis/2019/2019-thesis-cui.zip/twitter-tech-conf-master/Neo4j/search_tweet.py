from tweepy import Stream
from tweepy import OAuthHandler
from tweepy import API
from tweepy import error
from tweepy.streaming import StreamListener
from read_cfg import consumer_keys,consumer_secret_keys,access_token,access_token_secret

auth = OAuthHandler(consumer_keys, consumer_secret_keys)
auth.set_access_token(access_token, access_token_secret)
api = API(auth)

def find_tweet(id):

    try:
        tweet = api.get_status(id).text
        return tweet
    except error.TweepError:
        return "text may be deleted"
        pass

def find_user(screen_name):
    try:
        tweet = api.get_user(screen_name)
        return tweet.followers_count
    except error.TweepError:
        return "User not exist"
        pass




