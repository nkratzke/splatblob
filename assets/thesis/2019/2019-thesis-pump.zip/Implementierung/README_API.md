# Web Socket Service

## Usage

### List Channels

**Definition**

`GET /channels`

**Response**

- `200 OK` on success

```json
{
    "message": "Success!",
    "data": [
        {
            "id": "channel-0",
            "port": "80",
            "pattern": "pub-sub",
            "timeout": "1000",
            "clientLimit": "-1",
            "clients": 1
        },
        {
            "id": "channel-1",
            "port": "80",
            "pattern": "pub-sub",
            "timeout": "-1",
            "clientLimit": "2",
            "clients": 2
        }
    ]
}
```

### Create new Channel

**Definition**

`POST /channels`

**Arguments**

```json
{
  "pattern": "pub-sub",
  "timeout": "200",
  "clientLimit": "-1"
}
```

**Response**

- `201 Created` on success

```json
{
    "message": "Success, save your token!",
    "url": join,
    "token": "bd3efea1",
    "data": {
        "id": "channel-3",
        "port": "80",
        "pattern": "pub-sub",
        "timeout": "200",
        "clientLimit": "-1",
        "clients": 0
    }
}
```

### Get Channel by ID

**Definition**

`GET /channels/<id>`

**Response**

- `404 Not Found` if the WS does not exist
- `200 OK` on success


```json
{
    "message": "Success!",
    "data": [
        {
            "id": "channel-0",
            "port": "80",
            "pattern": "pub-sub",
            "timeout": "200",
            "clientLimit": "-1",
            "clients": 2
        }
    ]
}
```


### Delete Channel

**Definition**

`DELETE /channels/<id>`

**Response**

- `404 Not Found` if the WS does not exist
- `200 OK` on success

```json
{
    "message": "Success! Channel was found and deleted."
}
```

### Connect to channel

**Definition**

`Get /channels/<id>/connect`

must be send from Websocket Client initiating a Websocket handshake
(ws:// instead of http://)

**Quarry**

`token=<token>`

**Response**

- `400 Not Found` if http request without Upgrade Header
- handshake initiated

```json
{
  "message":join,
}
```

## Auth

if token authentication is activated use token argument in body to authenticate

`{"auth": "<token>"}`

add a Authorization Header to your request

`'authorization': 'Bearer <token>'`

or add it as parameter for simple use with Browsers

`GET localhost:5000/channel/<id>?auth=<token>`


## Browser only support

to support the usage for testing with browser only POST and DELETE request can be simulated
by GET Requests. However it is recommended to using POST or DELETE instead to keep the 
Application restfull.

### create Channel

**Definition**

`GET /channel/create`

**Quarry**

`?pattern=<pattern>&timeout=200&clientlimit=-1`

**Response**

- `201 Created` on success

```json
{
    "message": "Success, save your token!",
    "token": "bd3efea1",
    "data": {
        "id": "channel-3",
        "port": "80",
        "pattern": "pub-sub",
        "timeout": "200",
        "clientLimit": "-1",
        "clients": 0
    }
}
```

### Delete Channel

**Definition**

`GET /channels/<id>/delete`

**Response**

- `404 Not Found` if the WS does not exist
- `200 OK` on success

```json
{
    "message": "Success! Channel was found and deleted."
}
```

## Websocket Connection

to connect to the websocket relay using a websocket client use the same 
ip-address (domain) and port as for the API.

The authentication token is added to the URL as quarry component:

`ws://127.0.0.1:80/channels/<id>/connect?token=<token>`

Messages are forwarded in the network according to the chosen messaging pattern.
To see detailed information on these patterns see the official documentation.

##Messaging Patterns

### Echo

pattern key: `"echo"`

In this pattern the Relay Server echos every Message back to its origin.

### Publish-Subscribe

pattern key: `"pub-sub"`

Every Client can publish and Messages. Every Client connected to the Websocket automatically
receives all Messages except its own. This pattern impenitents basic Message broadcasting.

### Push-Pull

pattern key: `"push-pull"`

This Pattern is used for loadbalancing. Each message is forwarded to the next client in a Round Robin schedule.
A client never receives its on Message assuming if it could solve the problem it had not send it in the first place.

### Request-Reply

pattern key: `"req-repl"`

This pattern is used to exchange Requests and Replies between clients. A simple JSON based Sub Protocol is used
to differentiate between Request an Reply.
The Messages are forwarded in to all connected Clients leaving the Clients to reply or ignore.

**Usage**

To send a Request embed your message in the following JSON Structure:

`{"type": <type>, ("origin": <origin>), ("payload": ...)}`

type:       `"request"` or `"reply"`  
origin:     client id (added by server)
payload:    recommended to append your own messages

Any other JSON key value pair included is forwarded unregarded.

Messages that are no valid JSON Structure are responded by an error type message:

**Exaple**

client-1 sends:  
`{"type": "request", "payload": "What is the ultimate answer to life, The universe, and everything?"}`

client-2 receives:  
`{"type": "request", "origin": "client-1", "payload": "What is the ultimate answer to life, The universe, and everything?"}`

client-2 responds:  
`{"type": "reply", "origin": "client-1", "payload": {"Answer": "42"}}`

client-1 receives:  
`{"type": "reply", "origin": "client-1", "payload": {"Answer": "42"}}`


###Fan-in/out

pattern key: `"fan-in-out"`

To support Fan-out and Fan-in use cases the Fan-in/out pattern combines the Push-Pull queueing mechanism with the Request-Reply
sub-protocol. This enables to Fan-out tasks in a Round Robin schedule and Fan-in the Responses to its origin.

___

Version: 1.0.0  
Last-updated: 26.08.2019