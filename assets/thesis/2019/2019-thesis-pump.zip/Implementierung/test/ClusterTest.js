/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Script:          ClusterTest
 * Description:
 * tests automatic cluster connection and cluster replication
 *--------------------------------------------------------------------------------------------------------------------*/


const chai = require("chai");
const chaiHttp = require('chai-http');
const Service = require("../src/Service").WebsocketRelayService;
const Websocket = require('ws');
const assert = chai.assert;
const exec = require('child_process').exec;
const should = chai.should();
const ip = require("ip");
const http = require("http");

chai.use(chaiHttp);

process.env.WRS_MAX_STARTUP_DELAY = 0;
process.env.WRS_NODE_SNAPSHOT_LENGTH = 1000000;
process.env.WRS_PUBLIC_API_PORT = 80;
process.env.WRS_PUBLIC_SSL = false;
process.env.WRS_API_PORT = 80;
process.env.WRS_NODE_PORT = 5000;
process.env.WRS_DOMAIN = "localhost";
process.env.WRS_README_PATH = "./README.md";
process.env.WRS_SSL = false;
process.env.WRS_AUTH = false;
process.env.WRS_BROWSER_ONLY = false;
process.env.WRS_TOKEN_LENGTH = 4;

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

describe("Cluster", function () {
    this.timeout(30000);
    it("[TF: 5.2.1][TF: 5.2.2] should replicate Channels and Messages",function (done) {
        let port = 80;
        let node = getRandomInt(4000,65000);

        // create 1st Node in Child Process (on Port 80)
        const child = exec(`node ./src/app.js -p ${port} -n ${node}`,
            (error, stdout, stderr) => {
                console.log(`child: ${stdout}`);
                console.log(`child: !!! ${stderr}`);
                if (error !== null) {
                    console.log(`exec error: ${error}`);
                }
            });

        setTimeout(() => { // max 5 sec startup time
            process.env.WRS_NODE_PORT = 5000;
            process.env.WRS_DOMAIN = ip.address();
            process.env.WRS_API_PORT = 8080;
            process.env.WRS_PUBLIC_API_PORT = 80;
            process.env.WRS_DEBUG = true;

            // create 2nd Node
            new Service().run().then(service => {
                setTimeout(() => { // max 5 sec startup time + Connection time
                    // assert is connected
                    assert.equal(service.node.nodes.length, 1);

                    //create Channel
                    let pattern = "pub-sub";
                    let channel = "";
                    let token = "";
                    chai.request(service.api.app).post("/channels").send({
                        pattern: pattern,
                    }).end(function (err, res) {
                        chai.expect(res).to.have.status(201);
                        channel = res.body.data.id;
                        token = res.body.token;

                        setTimeout(() => { // 1 sec for channel replication
                            //check Channel on Node 1
                            http.get({
                                hostname: 'localhost',
                                port: 80,
                                path: `/channels/${channel}`,
                                rejectUnauthorized: false
                            }, (res) => {

                                let data = '';
                                res.on('data', (chunk) => {
                                    data += chunk;
                                    console.log(data)
                                });
                                res.on('end', () => {
                                    let json = JSON.parse(data);
                                    console.log(json)
                                    assert.equal(json.data.id, channel);
                                });
                            });

                            let msg = "Whatever";

                            // connect Client to Node 1
                            var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                            ws1.on('open', () => ws1.send(msg));
                            ws1.on('message', (data) => {
                                // assert that message is received
                                assert.equal(data, msg);
                                ws1.terminate();
                            });

                            // connect Client to Node 2
                            var ws2 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                            ws2.on('open', () => {
                            });
                            ws2.on('message', (data) => {
                                // assert that message is received
                                assert.equal(data, msg);
                                ws2.terminate();


                                // end 2nd Service
                                service.end().then(() => {

                                    // kill Child Process to end 1st Service
                                    child.stdin.pause();
                                    child.kill();
                                    done();
                                });
                            });


                        },1000);


                    });



                }, 1000);
            });
        }, 5000);


    });


});