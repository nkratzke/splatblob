/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Script:          ServiceLoadtest
 * Description:
 * this executes Loadtests for an running WebSocket relay Service using NPM serviceLoadtest
 *--------------------------------------------------------------------------------------------------------------------*/

const serviceLoadtest = require('loadtest');
const http = require('http');
const fs = require("fs");
const stdio = require('stdio');

// Command Line Parameters
let ops = stdio.getopt({
    'address':  {key: 'a', args: 1, description: 'target address'},
    'port':     {key: 'p', args: 1, description: 'target port'},
    'load':     {key: 'l', args: 1, description: 'load generated'},
    'time':     {key: 't', args: 1, description: 'time to run the test'},
    'clients':   {key: 'c', args: 1, description: 'client count'},
    'api':       {key: 'r', args: 1, description: 'test the rest-api'},
    'ws':        {key: 'w', args: 1, description: 'test the websocket server'}
});

let address = ops.address != null || "localhost";
let port = ops.port || 80;
let load = ops.load || 500;
let time = ops.time || 30;
let clients =  ops.clients || 1;
let api = ops.api || false;
let ws = ops.ws || false;

console.log(`Running ${clients} client(s) on ${address}:${port}
  - load: ${load}
  - time: ${time}
  - api : ${api}
  - ws  : ${ws}`);

var createChannel = () => {
    return new Promise((resolve)=>{
        const req = http.request({
            hostname: address,
            port: port,
            path: '/channels',
            method: 'POST',
            headers: {'Content-Type': 'application/json'}}, (res) => {
            res.on('data', (d) => {
                let json = JSON.parse(d);
                resolve({channel: json.data.id, token: json.token});
            });
            req.on('error', (error) => {
                console.error(error);
            })
        });
        req.write(`{"pattern": "echo", "timeout": ${time*2*1000}}`);
        req.end(()=>{})
    })
};

var test = (options) => {
    return new Promise((resolve) => {
        serviceLoadtest.loadTest(options, (error, results) => {
            if (error) {
                return console.error('Got an error: %s', error);
            }
            console.table(results);
            fs.writeFileSync("../../../Validierung/Basis/Loadtest/result.txt",JSON.stringify(results,null,2));

            console.log(`package lost: ${Math.round(results.totalErrors / results.totalRequests * 10000) / 100}%`);
            //resetChannel();
            resolve();
        });
    });
};

var resetChannel = () => {
    return new Promise((resolve)=>{
        const req = http.request({
            hostname: address,
            port: port,
            path: '/reset',
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'}}, (res) => {
            res.on('data', (d) => {
                resolve();
            });
            req.on('error', (error) => {
                console.error(error);
            })
        });
        req.write('');
        req.end(()=>{})
    })
};

process.env.WRS_README_PATH = "./README.md";
process.env.WRS_SSL = false;
process.env.WRS_AUTH = false;
process.env.WRS_BROWSER_ONLY = false;
process.env.WRS_TOKEN_LENGTH = 4;
process.env.WRS_MAX_STARTUP_DELAY = 0;
process.env.WRS_NODE_PORT = 5000;
process.env.WRS_DOMAIN = address;
process.env.WRS_API_PORT = port;
process.env.WRS_PUBLIC_API_PORT = port;
process.env.WRS_DEBUG = false;

createChannel().then((res)=>{
    console.log(res);
    var channel = res.channel;
    var token = res.token;

    const wsOpt = {
        url: `ws://${address}:${port}/channels/${channel}/connect?token=${token}`,
        method: 'GET',
        maxRequests: load*time,
        //requestsPerSecond: load,
        concurrency: clients,
        timelimit: time,
        requestGenerator: (params, options, client, callback) => {
            const message = '{"message": "Test"}';
            const request = client(options, callback);
            request.write(message);
            return request;
        }

    };

    const httpOpt = {
        url: `http://${address}:${port}`,
        method: 'POST',
        maxRequests: load*time,
        requestsPerSecond: load,
        concurrency: clients,
        //timelimit
        requestGenerator: (params, options, client, callback) => {
            const message = '{"pattern": "echo", "timeout": 10}';
            options.headers['Content-Type'] = 'application/json';
            options.body = '';
            options.path = '/channels';
            const request = client(options, callback);
            request.write(message);
            return request;
        }

    };

    const tst = {
        url: `https://rachel.jan-ole.de/phpmyadmin/`,
        method: 'GET',
        maxRequests: load*time,
        requestsPerSecond: load,
        concurrency: clients,
        keepAlive: true

    };

    if(api)
        test(httpOpt).then(() => {
            resetChannel();
        });
    if(ws)
        test(wsOpt).then(() => {
            resetChannel();
        });
});






