/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Script:          ServiceTest
 * Description:
 * this Script tests a number of system requirements for the WebSocket Service
 *--------------------------------------------------------------------------------------------------------------------*/

const chai = require("chai");
const chaiHttp = require('chai-http');
const Service = require("../src/Service").WebsocketRelayService;
const Websocket = require('ws');
const assert = chai.assert;
const exec = require('child_process').exec;
const should = chai.should();
const ip = require("ip");

chai.use(chaiHttp);

process.env.WRS_MAX_STARTUP_DELAY = 0;
process.env.WRS_NODE_SNAPSHOT_LENGTH = 1000000;
process.env.WRS_PUBLIC_API_PORT = 80;
process.env.WRS_PUBLIC_SSL = false;

describe("Service", function () {
    describe("[TF: 1] Basic", function () {

        var service;

        before(function (done) {
            process.env.WRS_API_PORT = 80;
            process.env.WRS_NODE_PORT = 4000;
            process.env.WRS_DOMAIN = "localhost";
            process.env.WRS_README_PATH = "./README.md";
            process.env.WRS_SSL = false;
            process.env.WRS_AUTH = false;
            process.env.WRS_BROWSER_ONLY = false;
            process.env.WRS_TOKEN_LENGTH = 4;
            process.env.WRS_MAX_STARTUP_DELAY = 0;

            new Service().run().then(ser => {
                service = ser;
                done()
            });
        });

        describe("[TF: 1.1] constructor", function () {
            it('[TF: 1.1.1] should have api, relayServer and node', function () {
                assert.isNotNull(service.api);
                assert.isNotNull(service.node);
                assert.isNotNull(service.relayServer);
            });

            it('[TF: 1.1.2] api should have server', function () {
                assert.isNotNull(service.api.server);
            })
        });


        describe("[TF: 1.2] REST-API", function () {
            it('[TF: 1.2.1] GET / should return HTML', function (done) {
                chai.request(service.api.app).get("/").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.be.html;
                        done();
                    });
            });

            it('[TF: 1.2.2] GET /readme should return HTML', function (done) {
                chai.request(service.api.app).get("/").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        //chai.expect(res.body).to.be.html;
                        done();
                    });
            });

            it('[TF: 1.2.3] GET /cluster should return JSON data==1', function (done) {
                chai.request(service.api.app).get("/cluster").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.data.should.have.property('self');
                        res.body.data.should.have.property('leader');
                        res.body.data.should.have.property('nodes');
                        res.body.data.should.have.property('leader');
                        assert.equal(res.body.data.nodes.length, 1);
                        assert.equal(res.body.data.self, service.node.id)
                        done();
                    });
            });

            it('[TF: 1.2.4] GET /channels should return JSON data:[]', function (done) {
                chai.request(service.api.app).get("/channels").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        assert.equal(res.body.data.length, 0);
                        done();
                    });
            });

            //create Channel
            let pattern = "echo";
            let clientLimit = 42;
            let timeout = 123456;
            let channel = "";
            let token = "";
            it('[TF: 1.2.5] [Req1] POST /channels should return JSON (success, data, token)', function (done) {
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                })
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(201);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        res.body.should.have.property('token');
                        // save channel data
                        assert.equal(res.body.data.pattern,pattern);
                        assert.equal(res.body.data.clientLimit,clientLimit);
                        assert.equal(res.body.data.timeout,timeout);

                        channel = res.body.data.id;
                        token = res.body.token;
                        done();
                    });
            });

            it('[TF: 1.2.6] GET /channels/:id should return JSON with channel data', function (done) {
                chai.request(service.api.app).get("/channels/" + channel).send({})
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        res.body.data.should.have.property("pattern");
                        res.body.data.should.have.property("clientLimit");
                        res.body.data.should.have.property("timeout");
                        // compare channel data
                        assert.equal(res.body.data.pattern, pattern);
                        assert.equal(res.body.data.clientLimit, clientLimit);
                        assert.equal(res.body.data.timeout, timeout);
                        done();
                    });
            });
            // delete Channel
            it('[TF: 1.2.7] [Req2] DELETE /channels/:id should return with 200', function (done) {
                chai.request(service.api.app).delete("/channels/" + channel).send({})
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.not.have.property('data');
                        done();
                    });
            });
            // no channel
            it('[TF: 1.2.8] GET /channels should return JSON data:[]', function (done) {
                chai.request(service.api.app).get("/channels").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        assert.equal(res.body.data.length, 0);
                        done();
                    });
            });
        });

        describe("[TF: 1.3] WS Connection", function () {
            it('[TF: 1.3.1] [Req3] [Req4] sending messages are received (echo Channel)', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "echo";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var message = "testMessage";
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws.on('open', () => ws.send(message));
                    ws.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, message);
                        ws.terminate();
                        chai.request(service.api.app).delete("/channels/" + channel).send();
                        done();
                    });
                });

            });

            it('[TF: 1.3.2] [Req5] sending messages are received (pub-sub)', function (done) {
                this.timeout(3000);
                //create channel

                var pattern = "pub-sub";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var msg1 = "testMessage1";
                var msg2 = "testMessage2";
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws1.on('open', () => ws1.send(msg1));
                    ws1.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, msg1);
                        ws1.terminate();
                    });
                    var ws2 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws2.on('open', () => {
                    });
                    ws2.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, msg1);
                        ws2.terminate();
                        chai.request(service.api.app).delete("/channels/" + channel).send();
                        done();
                    });
                });
            });

            it('[TF: 1.3.3] [Req6] sending messages are received equally (push-pull)', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "push-pull";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var msg1 = "testMessage1";
                var msg2 = "testMessage2";
                var counter1 = 0;
                var counter2 = 0;
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws1.on('open', () => {
                        ws1.send(msg1);
                        ws1.send(msg1);
                        ws1.send(msg1);
                        ws1.send(msg1);
                        ws1.send(msg1);
                        ws1.send(msg1);
                    });
                    ws1.on('message', (data) => {
                    });
                    var ws2 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws2.on('open', () => {
                    });
                    ws2.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, msg1);
                        counter1++;
                    });
                    var ws3 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws3.on('open', () => {
                    });
                    ws3.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, msg1);
                        counter2++;

                        if (counter2 === 3)
                            chai.request(service.api.app).delete("/channels/" + channel).send().end(() => {
                                // round robin has delivered equally
                                counter1.should.equal(counter2);
                                ws1.terminate();
                                ws2.terminate();
                                ws3.terminate();
                                done();
                            });
                    });
                });
            })

            it('[TF: 1.3.4] [Req7] sending messages are received (req-repl)', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "req-repl";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var msg1 = "testMessage1";
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws1.on('open', () => ws1.send(JSON.stringify({type: "request", payload: msg1})));
                    ws1.on('message', (data) => {
                        data = JSON.parse(data);
                        // assert that message is received
                        data.should.have.property('type');
                        data.should.have.property('payload');
                        assert.equal(data.payload, msg1);
                        ws1.terminate();
                        chai.request(service.api.app).delete("/channels/" + channel).send();
                    });
                    var ws2 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                    ws2.on('open', () => {});
                    ws2.on('message', (data) => {
                        data = JSON.parse(data);
                        // assert that message is received
                        data.should.have.property('type');
                        data.should.have.property('payload');
                        data.should.have.property('origin');
                        assert.equal(data.payload, msg1);
                        ws2.send(JSON.stringify(data));
                        ws2.terminate();
                        done();
                    });
                });
            });

            it('[TF: 1.3.5] [Req15] fail on wrong token', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "echo";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var msg1 = "testMessage1";
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${"GARBAGE"}`);
                    ws1.on('error', (err) => {
                        //console.log(JSON.stringify(err));
                        err.should.not.be.null;
                        ws1.terminate();
                        done();
                    });
                });
            });
        });

        describe("[TF: 1.4] [Req16] Timeout", function () {
            it('[TF: 1.4.1] should be delete if timeout over', function (done) {
                this.timeout(3000);
                var pattern = "echo";
                var clientLimit = -1;
                var timeout = 500;
                var channel = "";

                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                })
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(201);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        channel = res.body.data.id;

                        setTimeout(() => {
                            chai.request(service.api.app).get("/channels/" + channel).send({})
                                .end(function (err, res) {
                                    chai.expect(err).to.be.null;
                                    chai.expect(res).to.have.status(200);
                                });
                        }, timeout - 25);
                        setTimeout(() => {
                            chai.request(service.api.app).get("/channels/" + channel).send({})
                                .end(function (err, res) {
                                    chai.expect(err).to.be.null;
                                    chai.expect(res).to.have.status(404);
                                    chai.request(service.api.app).delete("/channels/" + channel).send();
                                    done();
                                });
                        }, timeout + 25);
                    });
            });

            it('[TF: 1.4.2] sending Message should reset timeout', function (done) {
                this.timeout(2000);
                var pattern = "echo";
                var clientLimit = -1;
                var timeout = 1000;
                var offset = 500;
                var channel = "";
                var token = "";

                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                })
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(201);
                        channel = res.body.data.id;
                        token = res.body.token;

                        setTimeout(() => {
                            var ws = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                            ws.on('open', () => {ws.send("test"); ws.terminate()});
                        },offset);
                        setTimeout(() => {
                            chai.request(service.api.app).get("/channels/" + channel).send({})
                                .end(function (err, res) {
                                    chai.expect(err).to.be.null;
                                    chai.expect(res).to.have.status(200);
                                });
                        }, timeout + 50);
                        setTimeout(() => {
                            chai.request(service.api.app).get("/channels/" + channel).send({})
                                .end(function (err, res) {
                                    chai.expect(err).to.be.null;
                                    chai.expect(res).to.have.status(404);
                                    chai.request(service.api.app).delete("/channels/" + channel).send();
                                    done();
                                });
                        }, timeout + offset + 100);
                    });
            });

        });

        describe("[TF: 1.5] [Req17] Client Limit", function () {
            it("[TF: 1.5.1] should accept Clients <= clientLimit", function (done) {
                this.timeout(2000);
                var pattern = "echo";
                var clientLimit = 3;
                var timeout = -1;
                var channel = "";
                var token = "";

                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                })
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(201);
                        channel = res.body.data.id;
                        token = res.body.token;

                        // connecting 4 clients in a row
                        var ws1 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                        ws1.on('open', () => {
                            assert(true);
                            var ws2 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                            ws2.on('open', () => {
                                assert(true);
                                var ws3 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                                ws3.on('open', () => {
                                    assert(true);
                                    var ws4 = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}`);
                                    ws4.on('error', (err) => {
                                        err.should.not.be.null;
                                        chai.request(service.api.app).get("/channels/" + channel).send({})
                                            .end(function (err, res) {
                                                chai.expect(err).to.be.null;
                                                chai.expect(res).to.have.status(200);
                                                assert(res.body.data.clientLimit >= res.body.data.clients);
                                                ws1.terminate();
                                                ws2.terminate();
                                                ws3.terminate();
                                                ws4.terminate();
                                                chai.request(service.api.app).delete("/channels/" + channel).send();
                                                done();
                                            });
                                    });
                                });
                            });
                        });
                    });
            })
        });

        after(async function () {
            return service.end().then(()=>{});
        });
    });


    describe("[TF: 2] SSL encryption", function () {

        let service;
        before(async function () {

            process.env.WRS_NODE_PORT = 4000;
            process.env.WRS_DOMAIN = "localhost";
            process.env.WRS_README_PATH = "./README.md";
            process.env.WRS_API_PORT = 433;
            process.env.WRS_SSL = true;
            process.env.WRS_SSL_KEY_PATH = "./ssl/96908896_ba.cedricpump.de.key";
            process.env.WRS_SSL_CERT_PATH = "./ssl/96908896_ba.cedricpump.de.cert";
            process.env.WRS_MAX_STARTUP_DELAY = 0;

            process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

            process.env.WRS_AUTH = false;
            process.env.WRS_BROWSER_ONLY = false;
            process.env.WRS_TOKEN_LENGTH = 4;


            let result = new Service().run();
            return result.then(ser => {
                service = ser;
            });
        });

        describe("[TF: 2.1] [Req13] REST-API", function () {

            it('[TF: 2.1.1] GET /channels should return JSON data:[]', function (done) {
                chai.request(service.api.app).get("/channels").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        assert.equal(res.body.data.length, 0);
                        done();
                    });
            });
        });

        describe("[TF: 2.2] [Req14] WS connection", function () {

            it('[TF: 2.2.1] sending messages are received (echo)', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "echo";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var message = "testMessage";
                chai.request(service.api.app).post("/channels").send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws = new Websocket(`wss://localhost:433/channels/${channel}/connect/?token=${token}`);
                    ws.on('open', () => ws.send(message));
                    ws.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, message);
                        ws.terminate();
                        chai.request(service.api.app).delete("/channels/" + channel).send();
                        done();
                    });
                });

            });
        });
        after(async function () {
            return service.end().then(()=>{});
        });
    });


    describe("[TF: 3] Auth Token", function () {
        var service;
        let testToken = "TEST_TOKEN";

        before(async function () {

            process.env.WRS_NODE_PORT = 4000;
            process.env.WRS_DOMAIN = "localhost";
            process.env.WRS_README_PATH = "./README.md";
            process.env.WRS_API_PORT = 80;
            process.env.WRS_SSL = false;
            process.env.WRS_AUTH = true;
            process.env.WRS_AUTH_TOKEN = testToken;
            process.env.WRS_BROWSER_ONLY = false;
            process.env.WRS_TOKEN_LENGTH = 4;

            let result = new Service().run();
            return result.then(ser => {
                service = ser;
            });
        });

        describe("[TF: 3.1] REST-API",function () {
            it('[TF: 3.1.1] GET /channels should return JSON with right token in header', function (done) {
                chai.request(service.api.app).get("/channels").set('authorization', `bearer ${testToken}`).send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        done();
                    });
            });

            it('[TF: 3.1.2] GET /channels should return JSON with right token in quarry', function (done) {
                chai.request(service.api.app).get("/channels?auth="+testToken).send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        done();
                    });
            });

            it('[TF: 3.1.3] GET /channels should return JSON with right token in body', function (done) {
                chai.request(service.api.app).get("/channels").send({auth: testToken})
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(200);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        res.body.should.have.property('data');
                        done();
                    });
            });

            it('[TF: 3.1.4] GET /channels should fail with wrong token in header', function (done) {
                chai.request(service.api.app).get("/channels").set('authorization', `bearer ${"GARBAGE"}`).send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(401);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        done();
                    });
            });

            it('[TF: 3.1.5] GET /channels should fail with wrong token in quarry', function (done) {
                chai.request(service.api.app).get("/channels?auth="+"GARBAGE").send('')
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(401);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        done();
                    });
            });

            it('[TF: 3.1.6] GET /channels should fail with wrong token in body', function (done) {
                chai.request(service.api.app).get("/channels").send({auth: "GARBAGE"})
                    .end(function (err, res) {
                        chai.expect(err).to.be.null;
                        chai.expect(res).to.have.status(401);
                        chai.expect(res).to.have.header('content-type', /application\/json/);
                        res.should.be.json;
                        res.body.should.be.a('object');
                        res.body.should.have.property('message');
                        done();
                    });
            });
        });

        describe("[TF: 3.2] WS connection", function () {
            it('[TF: 3.2.1] sending messages are received (echo)', function (done) {
                this.timeout(1000);
                //create channel

                var pattern = "echo";
                var clientLimit = -1;
                var timeout = -1;
                var channel = "";
                var token = "";
                var message = "testMessage";
                chai.request(service.api.app).post("/channels?auth="+testToken).send({
                    pattern: pattern,
                    clientLimit: clientLimit,
                    timeout: timeout
                }).end((err, res) => {
                    channel = res.body.data.id;
                    token = res.body.token;
                    var ws = new Websocket(`ws://localhost:80/channels/${channel}/connect/?token=${token}&auth=${testToken}`);
                    ws.on('open', () => ws.send(message));
                    ws.on('message', (data) => {
                        // assert that message is received
                        assert.equal(data, message);
                        ws.terminate();
                        chai.request(service.api.app).delete("/channels/" + channel).send();
                        done();
                    });
                });

            });
        });

        after(async function () {
            return service.end().then(()=>{});
        });


    });

    describe("[TF: 4] Browser Only", function () {

        let service;

        before(function (done) {

            process.env.WRS_NODE_PORT = 4000;
            process.env.WRS_DOMAIN = "localhost";
            process.env.WRS_README_PATH = "./README.md";
            process.env.WRS_API_PORT = 80;
            process.env.WRS_SSL = false;
            process.env.WRS_AUTH = false;
            process.env.WRS_BROWSER_ONLY = true;
            process.env.WRS_TOKEN_LENGTH = 4;

            new Service().run().then(ser => {
                service = ser;
                done();
            });
        });


        //create Channel
        var pattern = "echo";
        var clientLimit = 42;
        var timeout = 123456;
        var channel = "";
        var token = "";
        it('[TF: 4.1.1] GET /channel/create should return JSON (success, data, token)', function (done) {
            chai.request(service.api.app).get(`/channel/create?pattern=${pattern}&timeout=${timeout}&clientlimit=${clientLimit}`).send()
                .end(function (err, res) {
                    chai.expect(err).to.be.null;
                    chai.expect(res).to.have.status(201);
                    chai.expect(res).to.have.header('content-type', /application\/json/);
                    res.should.be.json;
                    res.body.should.be.a('object');
                    res.body.should.have.property('message');
                    res.body.should.have.property('data');
                    res.body.should.have.property('token');
                    // save channel data
                    channel = res.body.data.id;
                    token = res.body.token;
                    done();
                });
        });

        // delete Channel
        it('[TF: 4.1.2] GET /channels/:id/delete should return with 200', function (done) {
            chai.request(service.api.app).get("/channels/" + channel + "/delete").send({})
                .end(function (err, res) {
                    chai.expect(err).to.be.null;
                    chai.expect(res).to.have.status(200);
                    chai.expect(res).to.have.header('content-type', /application\/json/);
                    res.should.be.json;
                    res.body.should.be.a('object');
                    res.body.should.have.property('message');
                    res.body.should.not.have.property('data');
                    done();
                });
        });

        after(async function () {
            return service.end().then(()=>{});
        });

    });



        describe("[TF: 5] cluster", function () {
            describe("[TF: 5.1] cluster Management", function () {
                this.timeout(30000);
                process.env.WRS_SSL = false;
                process.env.WRS_AUTH = false;
                process.env.WRS_BROWSER_ONLY = false;
                process.env.WRS_TOKEN_LENGTH = 4;
                process.env.WRS_README_PATH = "./README.md";
                process.env.WRS_MAX_STARTUP_DELAY = 0;

                it("[TF: 5.1.1] should not join to no existing cluster", function (done) {
                    process.env.WRS_NODE_PORT = 4000;
                    process.env.WRS_DOMAIN = "localhost";
                    process.env.WRS_API_PORT = 80;

                    new Service().run().then(service =>{
                       assert.equal(service.node.getNodeAddresses(false).length, 0);
                       service.end().then(()=>done());
                    });
                });
                it("[TF: 5.1.2] should join to an existing cluster manually", function (done) {

                    const child = exec('node ./src/testApp.js -p 80 -n 4000',
                        (error, stdout, stderr) => {
                            console.log(`child: ${stdout}`);
                            console.log(`child: !!! ${stderr}`);
                            if (error !== null) {
                                console.log(`exec error: ${error}`);
                            }
                        });

                        process.env.WRS_NODE_PORT = 5000;
                        process.env.WRS_DOMAIN = "null";
                        process.env.WRS_API_PORT = 8080;
                        //create 2nd service
                    setTimeout(()=>{
                        new Service().run().then(service => {
                            assert.equal(service.node.getNodeAddresses(false).length, 0);

                            chai.request(service.api.app).post(`/cluster/join/${service.node.address}:4000`).send('')
                                .end(function (err, res) {
                                    console.log(res.body)
                                    chai.expect(err).to.be.null;
                                    chai.expect(res).to.have.status(200);
                                    chai.expect(res).to.have.header('content-type', /application\/json/);
                                    res.should.be.json;
                                    res.body.should.be.a('object');
                                    res.body.should.have.property('message');
                                    res.body.should.have.property('data');
                                    setTimeout(()=> {
                                        assert.equal(service.node.nodes.length, 1);
                                        service.end().then(() => {
                                            child.stdin.pause();
                                            child.kill();
                                            done();
                                        });
                                    },500);

                                });


                        });
                    },5000)


                });

                setTimeout(()=>{},5000) // wait for services to end correctly

                it("[TF: 5.1.3] should join to an existing cluster automatically", function (done) {
                    const child = exec('node ./src/testApp.js -p 80 -n 4000',
                        (error, stdout, stderr) => {
                            console.log(`child: ${stdout}`);
                            console.log(`child: !!! ${stderr}`);
                            if (error !== null) {
                                console.log(`exec error: ${error}`);
                            }
                        });

                    setTimeout(()=>{
                        process.env.WRS_NODE_PORT = 5000;
                        process.env.WRS_DOMAIN = ip.address();
                        process.env.WRS_API_PORT = 8080;
                        process.env.WRS_PUBLIC_API_PORT = 80;
                        process.env.WRS_DEBUG = true;
                        new Service().run().then(service =>{
                            setTimeout(()=> {
                                assert.equal(service.node.nodes.length, 1);
                                service.end().then(() => {
                                    child.stdin.pause();
                                    child.kill();
                                    done();
                                });
                            },1000);
                        });
                    },5000);


                });

                setTimeout(()=>{},5000) // wait for services to end correctly
/**
                it("[TF: 5.1.4] should leave a cluster correctly", function (done) {
                    const child = exec('node ./src/testApp.js -p 80 -n 4000',
                        (error, stdout, stderr) => {
                            console.log(`child: ${stdout}`);
                            console.log(`child: !!! ${stderr}`);
                            if (error !== null) {
                                console.log(`exec error: ${error}`);
                            }
                        });

                    setTimeout(()=>{
                        process.env.WRS_NODE_PORT = 5000;
                        process.env.WRS_DOMAIN = ip.address();
                        process.env.WRS_API_PORT = 8080;
                        process.env.WRS_PUBLIC_API_PORT = 80;
                        process.env.WRS_DEBUG = true;
                        new Service().run().then(service =>{
                            setTimeout(()=> {
                                assert.equal(service.node.nodes.length, 1);
                                    child.stdin.pause();
                                    child.kill("SIGINT");
                                    //process.kill(child.pid, "SIGTERM");
                                    console.log("kill");
                                    setTimeout(()=> {
                                        assert.equal(service.node.nodes.length, 0);
                                        service.end().then(() => {
                                            done();
                                        });
                                    },20000);
                            },3000);
                        });
                    },5000);


                });
 **/
            });


            describe("[TF: 5.2] Channel replication", function () {
                if("[TF: 5.2.1] should replicate Channels over nodes",function () {
                  ; // see ClusterTest.js
                });
            });
            describe("[TF: 5.2] Message replication", function () {
                if("[TF: 5.2.2] should replicate Messages to nodes",function () {
                    ; // see ClusterTest.js
                });
            });
        });



    // AFTER ALL !!!
    after(function () {
        //process.exit();
    });
});