/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Script:          app
 * Description:
 * app.js is the entry point for executing the service. It reads all variables and starts the service.
 *--------------------------------------------------------------------------------------------------------------------*/

const stdio = require('stdio');
const WebSocketService = require('./Service').WebsocketRelayService;

// Command Line Parameters
let ops = stdio.getopt({
    'portAPI':  {key: 'p', args: 1, description: 'Port to be used for REST-API'},
    'portNode': {key: 'n', args: 1, description: 'Port to be used for cluster Communication'},
    'auth':     {key: 'a', args: 1, description: 'Enables token authentication (true/false)'},
    'token':    {key: 't', args: 1, description: 'Token to access resource'},
    'ssl':      {key: 's', args: 1, description: 'Enables SSL (true/false)'}
});


/**
 * environment variable             type        range               description
 *
 * WRS_API_PORT                     {Number}    >= 0 & < 65536      Port for REST-API
 * WRS_PUBLIC_API_PORT              {Number}    >= 0 & < 65536      public Port
 * WRS_TOKEN_LENGTH                 {Number}    > 0                 length of channel token
 * WRS_DOMAIN                       {String}    IP or DNS           ip or domain use for service (IP or DNS)
 * WRS_AUTH                         {Boolean}                       if auth token used for api
 * WRS_PUBLIC_AUTH                  {Boolean}                       if SSL ist used implicit by a proxy
 * WRS_AUTH_TOKEN                   {String}                        auth token for api
 * WRS_AUTH_RESOURCES               {String}                        list of resources protected by auth: method:path(regex)
 * WRS_SSL                          {Boolean}                       if ssl is used
 * WRS_SSL_CERT_PATH                {String}    path                path to ssl certificate
 * WRS_SSL_KEY_PATH                 {String}    path                path to ssl key
 * WRS_BROWSER_ONLY                 {Boolean}                       activate browser only mode (not restful)
 * WRS_README_PATH                  {String}    path                path to readme for get root
 * WRS_MAX_STARTUP_DELAY            {Number}    > 0                 Maximum for random startup delay
 * WRS_NODE_PORT                    {Number}    >= 0 & < 65536      port for raft node communication
 * WRS_NODE_HEARTBEAT               {Number}    > 0                 raft node heartbeat interval in ms
 * WRS_NODE_MIN_ELECTION_TIMEOUT    {Number}    > 0 & > HB          raft node min election timeout in ms
 * WRS_NODE_MAX_ELECTION_TIMEOUT    {Number}    > 0 & > HB & > MAX  raft node max election timeout in ms
 * WRS_NODE_SNAPSHOT_LENGTH         {Number}    > 0                 Lenght of entries in log that triggers a snapshot
 * WRS_ID_LENGTH                    {Number}    > 0                 length of random ids
 */

if(process.env.WRS_DEBUG === undefined) process.env.WRS_DEBUG = false;

if(process.env.WRS_README_PATH === undefined) process.env.WRS_README_PATH = "./README_API.md";

if(process.env.WRS_DOMAIN === undefined) process.env.WRS_DOMAIN = "127.0.0.1";

if(process.env.WRS_TOKEN_LENGTH === undefined) process.env.WRS_TOKEN_LENGTH = "16";

if(process.env.WRS_BROWSER_ONLY === undefined) process.env.WRS_BROWSER_ONLY = false;

if(process.env.WRS_NODE_HEARTBEAT === undefined) process.env.WRS_NODE_HEARTBEAT = 500;

if(process.env.WRS_NODE_SNAPSHOT_LENGTH === undefined) process.env.WRS_NODE_SNAPSHOT_LENGTH = 10000;

if(process.env.WRS_MAX_STARTUP_DELAY === undefined) process.env.WRS_MAX_STARTUP_DELAY = 6000;

if(process.env.WRS_NODE_MIN_ELECTION_TIMEOUT === undefined) process.env.WRS_NODE_MIN_ELECTION_TIMEOUT = 2000;

if(process.env.WRS_NODE_MAX_ELECTION_TIMEOUT === undefined) process.env.WRS_NODE_MAX_ELECTION_TIMEOUT = 3000;

if(process.env.WRS_ID_LENGTH === undefined) process.env.WRS_ID_LENGTH = "4";

if(ops.ssl != null)
    process.env.WRS_SSL = JSON.parse(ops.ssl);
else if(process.env.WRS_SSL === undefined) process.env.WRS_SSL = "false";
else process.env.WRS_SSL = JSON.parse(process.env.WRS_SSL);

if(process.env.WRS_PUBLIC_SSL === undefined) process.env.WRS_PUBLIC_SSL = process.env.WRS_SSL;

if(ops.portAPI != null)
    process.env.WRS_API_PORT = ops.portAPI;
else
    if(process.env.WRS_API_PORT === undefined) process.env.WRS_API_PORT = JSON.parse(process.env.WRS_SSL) ? 443 : 80;

if(process.env.WRS_PUBLIC_API_PORT === undefined) process.env.WRS_PUBLIC_API_PORT = process.env.WRS_API_PORT;

if(ops.portNode != null)
    process.env.WRS_NODE_PORT = ops.portNode;
else
    if(process.env.WRS_NODE_PORT === undefined) process.env.WRS_NODE_PORT = 4000;

if(ops.auth != null)
    process.env.WRS_AUTH = JSON.parse(ops.auth);
else if(process.env.WRS_AUTH === undefined) process.env.WRS_AUTH = "false";
    else process.env.WRS_AUTH = JSON.parse(process.env.WRS_AUTH);

if(ops.token != null)
    process.env.WRS_AUTH_TOKEN = ops.token;
else if(process.env.WRS_AUTH_TOKEN === undefined) process.env.WRS_AUTH = "false";

if(process.env.WRS_AUTH_RESOURCES === undefined) process.env.WRS_AUTH_RESOURCES = "";



let service = new WebSocketService();
service.run();

process.on('SIGINT', function() {
    service.end().then(()=> {
        process.exit();
    });
});
/**
process.on('SIGKILL', function() {
    service.end().then(()=> {
        process.exit();
    });
});

process.on('SIGTERM', function() {
    service.end().then(()=> {
        process.exit();
    });
});
 **/