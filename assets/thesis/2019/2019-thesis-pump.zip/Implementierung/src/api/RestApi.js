/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           RestApi
 * Description:
 * gives a RESTfull API to interact with the service.
 *--------------------------------------------------------------------------------------------------------------------*/

const express = require('express');
const morgan = require("morgan");
const bodyParser = require('body-parser');
const RelayServer = require("../model/RelayServer.js").RelayServer;
const md = require("markdown-it")();
const Node = require("../cluster/RaftNode.js").Node;
const fs = require("fs");
const ip = require("ip");
const https = require("https");
const url = require("url");
const swaggerui = require("swagger-ui-express");
const swaggerdoc = require('../../openapi.json');
const cors = require('cors');
const os = require("os");

/**
 * REST-API
 */
class RestApi{
    /**
     *
     * @param {RelayServer} relayServer
     * @param {Number} port
     * @param {Boolean} ssl
     * @param {Node} node
     * @return {RestApi}
     */
    constructor(relayServer, port = 80, ssl=false,node,version){
        this.version = version;
        this.relayServer = relayServer;
        this.node = node;
        this.port = port;
        this.ssl = ssl;
        this.app = null;
        this.initApp();
        this.initResources();
        this.sToken = "";
        this.server = null;

        return this;
    }

    /**
     * inits express app
     */
    initApp(){

        this.editSwaggerDoc();

        this.app = express();
        if(process.env.WRS_DEBUG) this.app.use(morgan('dev'));
        this.app.use(bodyParser.urlencoded({ extended: false }));
        this.app.use(bodyParser.json());
        this.app.use('/favicon.ico', express.static('images/icon.ico'));

        this.app.use(cors());

        let options = {
            customCss: '.swagger-ui .topbar { display: none }'
        };

        this.app.use('/docs', swaggerui.serve, swaggerui.setup(swaggerdoc, options));

        /*this.app.options("/*", function(req, res, next){
            res.header('Access-Control-Allow-Origin', '*');
            res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
            res.header('Access-Control-Allow-Credentials', 'true');
            res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With, X-CSRF-Token');
            res.sendStatus(200);
        });*/
    }

    /**
     * adds Server configuration to Swagger
     */
    editSwaggerDoc(){
        swaggerdoc.servers = [{
            url: (JSON.parse(process.env.WRS_PUBLIC_SSL) ? "https://" : "http://") + process.env.WRS_DOMAIN + ":" + process.env.WRS_PUBLIC_API_PORT + "/"
        }];

        swaggerdoc.tags[0].externalDocs.url=(JSON.parse(process.env.WRS_PUBLIC_SSL) ? "https://" : "http://") + process.env.WRS_DOMAIN + ":" + process.env.WRS_PUBLIC_API_PORT + "/readme";

        if(!JSON.parse(process.env.WRS_BROWSER_ONLY)){
            Object.keys(swaggerdoc.paths).forEach(p => {
                if (swaggerdoc.paths[p].get !== undefined && swaggerdoc.paths[p].get.tags.indexOf("Browser-Only-Support") > -1){
                    swaggerdoc.paths[p].get.deprecated = true;
                }
            });
            swaggerdoc.tags.filter(t=>t.name === "Browser-Only-Support")[0].description = "NOT ACTIVE"
        }
    }

    /**
     * inits HTTP Request Handlers
     */
    initResources(){

        /// ----------------------------------------------
        ///    README
        /// ----------------------------------------------
        /**
         * GET /
         * redirect to /docs
         */
        this.app.get('/', function(req, res) {
            res.redirect('/docs');
        });

        /**
         * GET /service
         * gives Metadata about the service
         */
        this.app.get('/service', (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                response.status(200).send(JSON.stringify({
                    message: "Success!",
                    data: {
                        version: `${this.version}`,
                        channels: this.relayServer.channels.size,
                        nodes: this.node.nodes.length+1,
                        ssl: this.ssl,
                        auth: process.env.WRS_AUTH,
                        browserOnlyMode: process.env.WRS_BROWSER_ONLY,
                    }
                }, null, 4));
            }
        });

        /**
         * GET /readme
         * return readme
         */
        this.app.get("/readme", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'text/html');
                response.setHeader('data-type', 'html');
                try {
                    response.status(200).send(md.render(fs.readFileSync(process.env.WRS_README_PATH, "utf8")));
                } catch (e) {
                    response.status(200).send("ERROR\n" + e.message);
                }
            }
        });

        /// ----------------------------------------------
        ///    TEST Client
        /// ----------------------------------------------
        /**
         * GET /client
         * return readme
         */
        this.app.get("/client", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                try {
                    response.sendFile('./client/testClient.html', {root: "."});
                } catch (e) {
                    response.status(200).send("ERROR\n" + e.message);
                }
            }
        });

        /// ----------------------------------------------
        ///    CHANNELS
        /// ----------------------------------------------
        /**
         * GET /channels
         * return all channels
         */
        this.app.get("/channels", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                let channels = this.relayServer.getAllChannels();
                let out = [];
                channels.forEach((c) => {
                    out.push(c.toJSON())
                });
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                response.status(200).send(JSON.stringify({
                    message: "Success!",
                    data: out
                }, null, 4));
            }
        });

        /**
         * GET /channels/id
         * return channel with id
         */
        this.app.get("/channels/:id", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                let chn = this.relayServer.getChannel(request.params.id);
                if (chn != null)
                    response.status(200).send(JSON.stringify({
                        message: "Success!",
                        data: chn.toJSON()
                    }, null, 4));
                else
                    this.channelNotFound(request, response, request.params.id)
            }
        });

        /**
         * DELETE /channels/id
         * deleting channel with id
         */
        this.app.delete("/channels/:id", (request, response,next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                if (this.node.state === Node.states.indexOf("CANDIDATE"))
                    response.status(500).send({message: "Node ind CANDIDATE State!"});
                let res = this.relayServer.deleteChannel(request.params.id);
                console.log("REST API: Channel deleted");
                if (res) {
                    response.status(200).send({message: "Success! Channel was found and deleted."})
                } else
                    this.channelNotFound(request, response, request.params.id)
            }
        });

        /**
         * POST /channels
         * creating new channel
         */
        this.app.post("/channels", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
            response.setHeader('content-type', 'application/json');
            response.setHeader('data-type', 'json');
            if(this.node.state === Node.states.indexOf("CANDIDATE"))
                response.status(500).send({message: "Node ind CANDIDATE State!"});
            try {
                let json = request.body;
                if((Object.keys(json).indexOf('pattern') < 0))
                    response.status(400).send({message: "Failed! Make sure pattern attribute is present"});
                else {
                    if (json.timeout === undefined)
                        json.timeout = 86400000;

                    if (json.clientLimit === undefined)
                        json.clientLimit = -1;

                    let channel = this.relayServer.createChannel(json.pattern, json.timeout, json.clientLimit);

                    console.log(`REST API: Channel created`);
                    response.status(201).send(JSON.stringify(
                        {
                            message: `Success, save your token!`,
                            //url: `ws${this.ssl ? "s" : ""}://${process.env.USE_DOMAIN}:${channel.port}/channels/${channel.id}/connect?token=${channel.token}`,
                            token: channel.getToken(),
                            data: channel.toJSON()
                        }, null, 4));
                }
            } catch (e) {
                console.log(e);
                response.status(400).send({message: "Failed!"})
            }
            }
        });

        /**
         * DELETE /reset
         * deleting all Channels
         */
        this.app.delete("/reset", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                if (this.node.state === Node.states.indexOf("CANDIDATE"))
                    response.status(500).send({message: "Node ind CANDIDATE State!"});
                this.relayServer.channels.forEach((c) => {
                    c.delete();
                });
                response.status(200).send(JSON.stringify({
                    message: "Success!",
                    data: []
                }, null, 4));
            }
        });

        /**
         * GET /channels/:id/join
         * connecting to a channel via GET Request
         */
        this.app.get("/channel/:id/join", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                if (this.node.state === Node.states.indexOf("CANDIDATE"))
                    response.status(500).send({message: "Node ind CANDIDATE State!"});
                console.log(request.headers);
                let id = request.params.id;
                response.status(400).send({message: `Use Websocket protocol to connect to this channel: ws${this.ssl ? "s" : ""}://${ip.address()}:${this.port}/channels/${id}/connect?token=<token>`})
            }
        });

        /// ----------------------------------------------
        ///    CLUSTER
        /// ----------------------------------------------

        /**
         * GET /cluster
         * return cluster Configuration
         */
        this.app.get("/cluster", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                response.status(200).send(JSON.stringify({
                    message: "Success!",
                    data: {
                        self: node.id,
                        state: Node.states[node.state],
                        nodes: node.getNodeAddresses(),
                        logSize: node.log[node.log.length-1].index + 1,
                        snapshotSize: node.snapshots.lastIncludedIndex + 1,
                        leader: node.knownLeader
                    }
                }, null, 4));
            }
        });

        /**
         * POST /cluster/join
         * creating new channel
         */
        this.app.post("/cluster/join/:address", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                let address = request.params.address;
                let ip = address.split(':')[0];
                let port = Number.parseInt(address.split(':')[1]);
                this.node.join(ip, port).then(res => {
                    if (res.success) {
                        response.status(200).send(JSON.stringify({
                            message: "Success!",
                            data: []
                        }, null, 4));
                    } else {
                        response.status(400).send(JSON.stringify({
                            message: "Could not join!",
                            data: []
                        }, null, 4));
                    }
                });
            }
        });

        /**
         * DELETE /cluster/:id
         * removing broken channel manually
         */
        this.app.delete("/cluster/:id", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                let id = request.params.id;
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                    this.node.remove(id).then(res => {
                        if (res.success) {
                            response.status(200).send(JSON.stringify({
                                message: "Success!",
                                data: {
                                    self: node.id,
                                    state: Node.states[node.state],
                                    nodes: node.getNodeAddresses(),
                                    logSize: node.log[node.log.length-1].index + 1,
                                    snapshotSize: node.snapshots.lastIncludedIndex + 1,
                                    leader: node.knownLeader
                                }
                            }, null, 4));
                        } else {
                            response.status(404).send(JSON.stringify({
                                message: "node not found!",
                                data: {
                                    self: node.id,
                                    state: Node.states[node.state],
                                    nodes: node.getNodeAddresses(),
                                    logSize: node.log[node.log.length-1].index + 1,
                                    snapshotSize: node.snapshots.lastIncludedIndex + 1,
                                    leader: node.knownLeader
                                }
                            }, null, 4));
                        }
                    });



            }
        });

        /*/**
         * GET /networks
         * return Networks (unsecure, dev only)
         * @deprecated
         *//*
        this.app.get("/networks", (request, response, next) => {
            if(this.checkTokenMiddleware(request,response,next)) {
                response.setHeader('content-type', 'application/json');
                response.setHeader('data-type', 'json');
                response.status(200).send(JSON.stringify(os.networkInterfaces(), null, 4));
            }
        })*/

        /// ----------------------------------------------
        ///    BROWSER ONLY
        /// ----------------------------------------------
        /**
         * HTML Requests für Browser Only Usage
         * not REST conform
         *
         */
        if(JSON.parse(process.env.WRS_BROWSER_ONLY)){

            /**
             * GET /channel/create
             * creating channel via GET Request
             */
            this.app.get("/channel/create", (request, response, next) => {
                if(this.checkTokenMiddleware(request,response,next)) {
                    response.setHeader('content-type', 'application/json');
                    response.setHeader('data-type', 'json');
                    if (this.node.state === Node.states.indexOf("CANDIDATE"))
                        response.status(500).send({message: "Node ind CANDIDATE State!"});
                    if (request.query.pattern != null && request.query.pattern !== "") {
                        try {
                            if (request.query.timeout === undefined)
                                request.query.timeout = 86400000;

                            if (request.query.clientlimit === undefined)
                                request.query.clientlimit = -1;

                            let channel = this.relayServer.createChannel(request.query.pattern, request.query.timeout, request.query.clientlimit);

                            console.log(`REST API: Channel created`);
                            response.status(201).send(JSON.stringify(
                                {
                                    message: `Success, save your token!`,
                                    //url: `ws${this.ssl ? "s" : ""}://${process.env.USE_DOMAIN}:${channel.port}/channels/${channel.id}/connect?token=${channel.token}`,
                                    token: channel.getToken(),
                                    data: channel.toJSON()
                                }, null, 4));
                        } catch (e) {
                            console.log(e);
                            response.status(400).send({message: "Failed! " + e.message})
                        }
                    } else {
                        response.status(400).send({message: `Missing Argument! (GET /channel/create?pattern=\<pattern\>)`})
                    }
                }
            });

            /**
             * GET /channels/:id/delete
             * deleting channel via GET Request
             */
            this.app.get("/channels/:id/delete", (request, response, next) => {
                if(this.checkTokenMiddleware(request,response,next)) {
                    response.setHeader('content-type', 'application/json');
                    response.setHeader('data-type', 'json');
                    if (this.node.state === Node.states.indexOf("CANDIDATE"))
                        response.status(500).send({message: "Node ind CANDIDATE State!"});
                    let res = this.relayServer.deleteChannel(request.params.id);
                    if (res) {
                        response.status(200).send({message: "Success! Channel was found and deleted."})
                    } else
                        this.channelNotFound(request, response, request.params.id)
                }
            });

            /**
             * GET /reset
             * deleting all channels
             */
            this.app.get("/reset", (request, response, next) => {
                if(this.checkTokenMiddleware(request,response,next)) {
                    response.setHeader('content-type', 'application/json');
                    response.setHeader('data-type', 'json');
                    if (this.node.state === Node.states.indexOf("CANDIDATE"))
                        response.status(500).send({message: "Node ind CANDIDATE State!"});
                    this.relayServer.channels.forEach((c) => {
                        c.delete();
                    });
                    response.status(200).send(JSON.stringify({
                        message: "Success!",
                        data: []
                    }, null, 4));
                }
            });

            /**
             * GET /cluster/join/:address
             * connecting to cluster Node
             */
            this.app.get("/cluster/join/:address", (request, response, next) => {
                if (this.checkTokenMiddleware(request, response, next)) {
                    response.setHeader('content-type', 'application/json');
                    response.setHeader('data-type', 'json');
                    let address = request.params.address;
                    let ip = address.split(':')[0];
                    let port = Number.parseInt(address.split(':')[1]);
                    if(ip === this.node.address && port === this.node.port){
                        response.status(400).send(JSON.stringify({
                            message: "Self!",
                            data: []
                        }, null, 4));
                    } else {
                        this.node.join(ip, port).then(res => {
                            if (res) {
                                node.command({
                                    type: "nodeShutdown",
                                    nodeId: id
                                });
                                response.status(200).send(JSON.stringify({
                                    message: "Success!",
                                    data: {
                                        self: node.id,
                                        state: Node.states[node.state],
                                        nodes: node.getNodeAddresses(),
                                        leader: node.knownLeader
                                    }
                                }, null, 4));
                            } else {
                                response.status(400).send(JSON.stringify({
                                    message: "Could not join!",
                                    data: {
                                        self: node.id,
                                        state: Node.states[node.state],
                                        nodes: node.getNodeAddresses(),
                                        leader: node.knownLeader
                                    }
                                }, null, 4));
                            }
                        });
                    }
                }
            });

            /**
             * Get /cluster/:id/remove
             * removing broken channel manually
             */
            this.app.get("/cluster/:id/remove", (request, response, next) => {
                if(this.checkTokenMiddleware(request,response,next)) {
                    let id = request.params.id;
                    response.setHeader('content-type', 'application/json');
                    response.setHeader('data-type', 'json');
                        this.node.remove(id).then(res => {
                            if (res.success) {
                                response.status(200).send(JSON.stringify({
                                    message: "Success!",
                                    data: {
                                        self: node.id,
                                        state: Node.states[node.state],
                                        nodes: node.getNodeAddresses(),
                                        logSize: node.log[node.log.length - 1].index + 1,
                                        snapshotSize: node.snapshots.lastIncludedIndex + 1,
                                        leader: node.knownLeader
                                    }
                                }, null, 4));
                            } else {
                                response.status(404).send(JSON.stringify({
                                    message: "node not found!",
                                    data: {
                                        self: node.id,
                                        state: Node.states[node.state],
                                        nodes: node.getNodeAddresses(),
                                        logSize: node.log[node.log.length - 1].index + 1,
                                        snapshotSize: node.snapshots.lastIncludedIndex + 1,
                                        leader: node.knownLeader
                                    }
                                }, null, 4));
                            }
                        });

                }
            });

        }
    }

    /**
     * GET /channels/:id/connect (ws://)
     * connecting to a channel via GET Request
     */
    addUpgradeHandler()
    {
        this.server.on('upgrade', (request, socket, head) => {
            if(this.checkToken(request)) {
                // get pathname from url
                let resources = url.parse(request.url).pathname.split('/');
                console.log(`GET ${url.parse(request.url).pathname} : "connection": ${request.headers.connection}, "upgrade": ${request.headers.upgrade}`);
                // expected: ["","channel",":id","join"]
                if (resources[1] === 'channels' && resources[3] === 'connect') {
                    let id = resources[2];
                    if (!this.relayServer.getChannel(id)) {
                        if (!this.ssl) {
                            socket.end('HTTP/1.1 404 NOT FOUND\r\n\r\n', 'ascii');
                            console.log(`no such channel ${socket}`);
                        } else {
                            try {
                                socket.end('HTTP/1.1 404 NOT FOUND', 'ascii');
                                console.log(`no such channel ${socket}`);
                            } catch (e) {
                                console.log(e.message)
                            }
                        }
                    } else{
                        this.relayServer.handleUpgrade(id, request, socket, head);
                    }
                } else {
                    if (!this.ssl) {
                        socket.end('HTTP/1.1 400 Bad Request\r\n\r\n','ascii');
                        console.log(`wrong format`);
                    } else {
                        socket.end('HTTPS/1.1 400 Bad Request','ascii');
                        console.log(`wrong format`);
                    }
                }
            } else {
                if (!this.ssl) {
                    socket.end('HTTP/1.1 401 UNAUTHORISED\r\n\r\n','ascii');
                    console.log(`wrong auth ${socket}`);
                } else {
                    socket.end('HTTP/1.1 401 UNAUTHORISED','ascii');
                    console.log(`wrong auth ${socket}`);
                }
            }
        });
    }

    /**
     * handle Channel not found
     * @param request
     * @param response
     * @param channelId
     */
    channelNotFound(request, response, channelId){
        console.log(`Channel not found: ${channelId}`);
        if(response)
            response.status(404).send({message: "Channel not found!"})
    }

    /**
     * Run HTTP(S) Server
     * @returns {RestApi}
     */
    run() {
        const api = this;
            if(JSON.parse(process.env.WRS_SSL)){
                try{
                let options = {
                    cert: fs.readFileSync(process.env.WRS_SSL_CERT_PATH),
                    key: fs.readFileSync(process.env.WRS_SSL_KEY_PATH)
                };
                this.server = https.createServer(options,this.app).listen(this.port,()=>{
                        console.log(`REST-API is running on https://${ip.address()}:${this.port}`);
                    });
                } catch (e) {
                    console.log(process.env.WRS_SSL_CERT_PATH+"Error loading SSL Certificate!\nMake sure WRS_SSL_CERT_PATH and WRS_SSL_KEY_PATH are set:\n"+e.message);
                    process.exit();
                }

            } else {

                this.server = this.app.listen(this.port, () => {
                    console.log(`REST-API is running on http://${ip.address()}:${this.port}`);
                });
            }
        this.addUpgradeHandler();
        return api;
    }

    /**
     * returns current HTTP(S) Server
     * @returns {Object} HTTP(S) Server
     */
    getServer(){
        return this.server;
    }

    /**
     * stops server
     * @return {Promise}
     */
    stop(){
        return new Promise(resolve =>{
            this.server.close(()=>{
                console.log("API ended");
                resolve()
            })
        })
    }

    checkTokenMiddleware(req, res, next) {
        if (this.checkToken(req)) {
            console.log('auth success!');
            return true;
        } else {
            res.status(401).json({
                message: 'UNAUTHORIZED'
            }).send();
            return false;
        }
    };


    /**
     * checks Token and gives back true or false
     * @param req           Request
     * @return {boolean}
     */
    checkToken(req) {
        if (JSON.parse(process.env.WRS_AUTH)) {
            if (req.path === undefined) req.path = "/";
            let locked = {};
            console.log(process.env.WRS_AUTH_RESOURCES);
            let match = true;
            if (process.env.WRS_AUTH_RESOURCES !== undefined && process.env.WRS_AUTH_RESOURCES !== '') {
                process.env.WRS_AUTH_RESOURCES.split(' ').forEach(
                    s => {
                        locked[s.split(':')[1]] = s.split(':')[0];
                    });
                match = false;
                Object.keys(locked).forEach(k => {
                    if (new RegExp(k).test(req.path) && (locked[k] === req.method || locked[k] === '*')) match = true
                })
            }

            console.log(locked.length + " " + req.path);

            // check if resource locked
            if (match) {
                try {
                    this.sToken = process.env.WRS_AUTH_TOKEN;
                    if (req.headers.authorization != null && req.headers.authorization.split(' ')[1] === this.sToken) {
                        return true;
                    } else if (req.query.auth != null && req.query.auth === this.sToken) {
                        return true;
                    } else if (req.body.auth != null && req.body.auth === this.sToken) {
                        return true;
                    } else {
                        let reg = new RegExp(`auth=${this.sToken}`)
                        if (req.url != null && reg.test(req.url))
                            return true;
                    }
                    return false
                } catch (e) {
                    let reg = new RegExp(`auth=${this.sToken}`);
                    return req.url != null && reg.test(req.url);
                }
            } else {
                return true
            }
        }
        else
            return true
    }
}

module.exports = {RestApi: RestApi};