/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           Channel
 * Description:
 * A channel provides relaying messages among all connected WebSocket Clients according to the used messaging-pattern
 *--------------------------------------------------------------------------------------------------------------------*/

const ws = require("ws");
const url = require("url");
const Client = require("./Client.js");
const randomToken = require("./token-helpers/tokenGernerator.js").randomToken;
const gen = require('../cluster/idGenerator.js').randomID;
const EventEmitter = require("events").EventEmitter;

const patternTypes = ["pub-sub","echo","push-pull","req-repl"];

//var channelId = 0;

class Channel extends EventEmitter{
    /**
     *  Constructor
     * @param {Number} port         port
     * @param {String} pattern      pattern
     * @param {Number} timeout      timeout in ms -1 if none
     * @param {Number} clientLimit  clientLimit -1 if none
     * @param {String} id           id randomly generated if ''
     * @param {String} token        token randomly generated if ''
     */
    constructor(port, pattern="echo", timeout = 86400000, clientLimit= -1, id = "", token = ""){
        super();
        if(id === "")
            this.id = gen(process.env.WRS_ID_LENGTH); //`channel-${channelId++}-${gen(process.env.WRS_ID_LENGTH)}`;
        else
            this.id = id;
        this.port = port;
        this.timeout = timeout;
        this.lastActivity = new Date().getTime();
        this.clientLimit = clientLimit;
        if(patternTypes.includes(pattern))
            this.pattern = pattern;
        else
            throw new Error(`Invalid pattern, use one of: ${patternTypes}`);
        if(token === "")
            this.token = Channel.generateToken();
        else
            this.token = token;
        this.server = this.initServer();
        this.clients = new Map();
        this.queue = [];

       this.checkTimeout();
    }

    /**
     * resets last activity to now for timout check
     */
    updateActivity(){
        this.lastActivity = new Date().getTime();
    }

    /**
     * Checks if Timout is exceeded in an Interval
     * checks every Second (minimum timeout 50ms)
     */
    checkTimeout(){

        if(this.timeout > 0)
            this.interval = setInterval(
                () => {
                    //console.log(`${(new Date().getTime() - this.lastActivity)}`);
                    if( (new Date().getTime()) - this.lastActivity > this.timeout ) {
                        console.log(`${this.id} shutting down, timout exceeded.`);
                        this.emit("timeout",{id: this.id});
                        this.delete();
                        clearInterval(this.interval);
                    }
            }, 50);
    }



    /**
     * initialize Websocket Server
     * @returns {*} server
     */
    initServer(){
        var auth = (info, cb) => {
            // Token verification
            let token = url.parse(info.req.url, true).query.token;
            if (!token) {
                console.log("no Token present");
                cb(false, 401, 'Unauthorized');
            } else {
                if (token !== this.token) {
                    console.log("wrong Token");
                    cb(false, 401, 'Unauthorized');
                }
            }
            // check clientLimit
            if(this.clientLimit >= 0 && this.clientLimit <= this.clients.size) {
                console.log("Client Limit reached");
                cb(false, 402, `Forbidden: this channel is limited to ${this.clientLimit} client connections`);
            } else
                cb(true);
        };

        // create Server
        this.server = new ws.Server(
            {
                noServer: true,
                verifyClient: auth
            });

        // basic connection handling
        this.server.on("connection", (s) => {
            // adds Client
            let client = this.addClient(s);

            console.log(`${client.displayName} connected`);
            this.emit("clientConnect",{channelId: this.id, clientId: client.id});
            s.on('message', (data) => {
                this.updateActivity();
                console.log(`> ${client.displayName}: ${data}`);
                this.handleMessage(client.id,data);
            });
            s.on("close", () => {
                this.deleteClient(client.id);
                    console.log(`${client.displayName} disconnected`);
                    this.emit("clientDisconnect",{channelId: this.id, clientId: client.id});
                });
        });

        this.server.on("close", () => {

        });
        return this.server;
    }

    /**
     *  adds Client with actual Socket
     * @param {ws.Socket} s
     * @return {Client}
     */
    addClient(s){
        let client = new Client(s,"",false);
        this.clients.set(client.id,client);
        this.queue.push(client);
        //console.log(this.queue);
        return client;
    }

    /**
     *  adds a RemoteClient with id
     * @param {String} id
     * @return {Client}
     */
    addRemoteClient(id){
        if(this.clients.get(id) === undefined){
            let client = new Client(null,id,true);
            this.clients.set(client.id,client);
            this.queue.push(client);
            //console.log(this.queue);
            return client;
        } else
            return null
    }

    /**
     *  deletes Client with id
     * @param {String} id
     */
    deleteClient(id){
        this.clients.delete(id);
        this.queue = this.queue.filter((c)=>{return c.id !== id});
    }

    /**
     * Returns next element from queue except Client with id
     * @param {String} id        id for exception
     * @return {Client}
     */
    fromQueue(id){
        if(this.queue[0].id === id && this.queue.length > 1) {
            return this.queue[1];
        }
        else{
            return  this.queue[0];
        }
    }

    /**
     * cycles que one time if id does not match
     * otherwise two times
     */
    cycleQueue(id){
        let i;
        do {
            i = this.queue[0].id;
            let c = this.queue[0];
            this.queue.shift();
            this.queue.push(c);
        } while (id !== i)
    }

    /**
     * message handling regarding the pattern used
     * @param {String} id    Client id
     * @param data  message data
     */
    handleMessage(id,data){
        switch (this.pattern) {
            case "echo": {
                // echo
                this.sendMessage(data,[this.clients.get(id)]);
                break;
            }
            case "pub-sub": {
                // broadcast
                this.sendMessage(data,this.clients);
                break;
            }
            case "push-pull": {
                this.sendMessage(data,[this.fromQueue(id)],true);
                break;
            }
            case "req-repl": {
                try {
                    let json = JSON.parse(data);
                    let type = json.type;
                    console.log(json);
                    if (type === "request") {
                        json.origin = id;
                        this.sendMessage(JSON.stringify(json),this.clients,true);
                    } else if (type === "reply") {
                        this.sendMessage(data,[this.clients.get(json.origin)]);
                    } else 
                        throw new Error("WrongType");
                } catch (e) {
                    this.clients.get(id).socket.send(
                        JSON.stringify({"type": "error", "origin": "server", "message": 'Wrong Protocol Format: use {"type": <type>, ("origin": <origin>), "payload": ...} to send requests and replies'})
                    );
                }
                break;
            }
            case "fan-in-out": {
                try {
                    let json = JSON.parse(data);
                    let type = json.type;
                    console.log(json);
                    if (type === "request") {
                        json.origin = id;
                        this.sendMessage(JSON.stringify(json),[this.fromQueue(id)],true);
                    } else if (type === "reply") {
                        this.sendMessage(data,[this.clients.get(json.origin)]);
                    } else
                        throw new Error("WrongType");
                } catch (e) {
                    this.clients.get(id).socket.send(
                        JSON.stringify({"type": "error", "origin": "server", "message": 'Wrong Protocol Format: use {"type": <type>, ("origin": <origin>), "payload": ...} to send requests and replies'})
                    );
                }
                break;
            }
        }
    }

    /**
     * send message to Clients
     * @param data      Data
     * @param cycle     if queue is cycled by this message
     * @param {Array<Client>} clients   Array of Clients
     */
    sendMessage(data,clients,cycle=false){
        let cs = [];
        clients.forEach((c)=>{
               //c.send(data);
               cs.push(c.id);
        });
        this.emit("message",{channelId: this.id,data: data, clients: cs, cycle: cycle})
    }

    /**
     *  handles Remote Message
     *  cycles Queue
     * @param data
     * @param clients
     * @param cycle
     */
    handleRemoteMessage(data,clients,cycle){
        if(cycle)
            this.cycleQueue(clients[0]);
       clients.forEach((c)=>{
            this.clients.get(c).send(data);
        });
    }

    /**
     * generates token for channel access
     * @returns {String} Token
     */
    static generateToken() {
        return randomToken();
    }

    /**
     * Handles an Upgrade Request passed by HTTP Server.
     * Request needs to include a valid WS handshake attempt.
     * @param request   HTTP Request
     * @param socket    Socket
     * @param head      head
     */
    handleUpgrade(request, socket, head){
        this.server.handleUpgrade(request, socket, head,
            (ws) => {
                this.server.emit('connection', ws, request);
            });
    }

    /**
     * shuts down the server
     * @returns {boolean}
     */
    delete() {
        this.clients.forEach((value) => {
           this.deleteClient(value);
        });
        this.server.close();
        console.log(`Channel ${this.id} ended!`);
        this.emit("end",{channelId: this.id});
        this.server.on("close",()=>{
            delete this.server;
            return true;
        });
    }

    /**
     * Gives JSON representation of Server, hides sensible information.
     * @returns {{clients: number, port: *, pattern: string, id: (string|*)}}
     */
    toJSON(){
        let countdown = -1;
        if(this.timeout>0)
            countdown = this.timeout - (new Date().getTime() - this.lastActivity);
        return {
            id: this.id,
            port: this.port,
            pattern: this.pattern,
            timeout: this.timeout,
            countdown: countdown,
            clientLimit: this.clientLimit,
            clients: this.clients.size
        }
    }

    /**
     * returns auth Token
     */
    getToken() {
        return this.token;
    }
}

module.exports = {Channel: Channel};