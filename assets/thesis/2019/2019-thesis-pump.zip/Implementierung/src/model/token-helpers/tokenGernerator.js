/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Function:        randomToken
 * Description:
 * a Tool to generate random Tokens
 *--------------------------------------------------------------------------------------------------------------------*/

const crypto = require("crypto");

function randomToken(){
    return crypto.randomBytes(JSON.parse(process.env.WRS_TOKEN_LENGTH)).toString('hex');
}

module.exports = {randomToken: randomToken};