/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Function:        check-token (Middleware)
 * Description:
 * this is the Middleware that checks the Auth Token before servicing a http request
 *--------------------------------------------------------------------------------------------------------------------*/

module.exports = (req, res, next) => {
    if(JSON.parse(process.env.WRS_AUTH)) {
        if(req.path === undefined) req.path = "/";
        let locked = {};
        console.log(process.env.WRS_AUTH_RESOURCES);
        let match = true;
        if(process.env.WRS_AUTH_RESOURCES !== undefined && process.env.WRS_AUTH_RESOURCES !== '') {
            process.env.WRS_AUTH_RESOURCES.split(' ').forEach(
                s => {
                    locked[s.split(':')[1]] = s.split(':')[0];
                });
            match = false;
            Object.keys(locked).forEach(k=>{if(new RegExp(k).test(req.path) && (locked[k] === req.method || locked[k] === '*')) match=true })
        }

        console.log(locked.length +" "+ req.path );

        // check if resource locked
        if(match) {
            try {
                this.sToken = process.env.WRS_AUTH_TOKEN;
                let success = false;
                if (req.headers.authorization != null && req.headers.authorization.split(' ')[1] === this.sToken) {
                    success = true;
                } else if (req.query.auth != null && req.query.auth === this.sToken) {
                    success = true;
                } else if (req.body.auth != null && req.body.auth === this.sToken) {
                    success = true;
                }

                if (success) {
                    console.log('auth success!');
                    next();
                } else {
                    return res.status(401).json({
                        message: 'UNAUTHORIZED'
                    })
                }
            } catch (e) {
                return res.status(401).json({
                    message: 'UNAUTHORIZED ' + e.message
                })
            }
        }else {
            next();
        }
    } else {
        next();
    }
};