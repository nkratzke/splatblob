/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           Client
 * Description:
 * represents a Client connected to a Channel. Clients can contain an actual WebSocket Client or be a remote Client,
 * representing a WebSocket Client connected to another node.
 *--------------------------------------------------------------------------------------------------------------------*/

const gen = require('../cluster/idGenerator.js').randomID;
var clientCounter = 0;

class Client{
    /**
     *  Constructor
     * @param {ws.Socket} socket
     * @param {String} id
     * @param {Boolean} remote
     */
    constructor(socket = null, id = "", remote = true){
        if(socket !== null) {
            this.id = `client-${clientCounter++}-${gen(process.env.USE_ID_LENGTH)}`;
            this.socket = socket;
            this.displayName = `${this.id} (${socket._socket.remoteAddress}:${socket._socket.remotePort})`;
            this.remote = false;
        } else if(id !== "") {
            this.id = id;
            this.socket = null;
            this.displayName = `${this.id} (remote)`;
            this.remote = remote;
        }
    }

    /**
     * String representation of Client
     * @return {string}
     */
    toString(){
        return JSON.stringify({
            id: this.id,
            displayname: this.displayName
        },2);
    }

    /**
     *  send data over socket
     * @param data
     * @return {boolean} has sent
     */
    send(data){
        console.log(this.remote);
        if(!this.remote) {
            //console.log(`> ${this.displayName}: ${data}` );
            this.socket.send(data);
            return true
        } else {
            return false
        }
    }
}

module.exports = Client;