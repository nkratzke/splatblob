/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           RelayServer
 * Description:
 * Holds an manages Channels. It uses te RaftNodes command() function and "commit"-Events to replicate Events over
 * all other connected nodes of the cluster
 *--------------------------------------------------------------------------------------------------------------------*/

const Channel = require("./Channel.js").Channel;
const gen = require('../cluster/idGenerator.js').randomID;

class RelayServer {
    constructor(port = 4000,ssl = false, node)
    {
        this.port = port;
        this.node = node;
        this.ssl = ssl;
        this.channels = new Map();

        this.node.on("commit",(command)=>{
            console.log("event: "+JSON.stringify(command));
            switch (command.type) {
                case "addChannel": {
                    this.onCreateChannel(command.pattern,command.timeout,command.clientLimit,command.channelId,command.token);
                    break
                }
                case "deleteChannel": {
                    this.onDeleteChannel(command.channelId);
                    break
                }
                case "message": {
                    let channel=this.getChannel(command.channelId);
                    if(channel != null)
                        channel.handleRemoteMessage(command.data, command.clients, command.cycle);
                    break
                }
                case "clientConnect": {
                    let channel=this.getChannel(command.channelId);
                    if(channel != null)
                        channel.addRemoteClient(command.clientId);
                    break
                }
                case "clientDisconnect": {
                    let channel=this.getChannel(command.channelId);
                    if(channel != null)
                        channel.deleteClient(command.clientId);
                    break
                }
                default: {
                    break
                }
            }
        });
    }

    /**
     * get External HTTP(S) Server
     * @param server
     */
    setHttpServer(server){
        this.httpserver = server;
        //this.addUpgradeHandler();
    }



    /**
     * handle Upgrade from external HTTP Server
     * @param id        channel id
     * @param request   request for WS Handshake
     * @param socket    socket
     * @param head      head
     */
    handleUpgrade(id, request, socket, head){
        // check if channel present
        console.log(id);
        if (this.channels.has(id)) {
            let channel = this.channels.get(id);
            channel.handleUpgrade(request, socket, head);
        }
    }

    /**
     * Create a new Channel
     * @param pattern
     * @param timeout
     * @param clientLimit
     * @param id
     * @param token
     * @returns {Channel}
     */
    createChannel(pattern,timeout = -1,clientLimit = -1, id = "", token = ""){
        console.log(`p:${pattern} i:${id} t: ${token}`)
        if(id === "") {
            id = `${this.node.id}-${gen(process.env.WRS_ID_LENGTH)}`;
        }
        let channel = new Channel(this.port,pattern,timeout,clientLimit,id,token);
        this.channels.set(channel.id, channel);
        console.log(`Relay Server: Channel created`);
        this.addChannelListeners(channel);
        if(token === "")
        this.node.command({
            type: "addChannel",
            channelId: channel.id,
            pattern: pattern,
            timeout: timeout,
            clientLimit: clientLimit,
            token: channel.token
        }).then((res)=>{});
        return channel;
    }

    /**
     *  called on node command event "createChannel"
     *  creates channel if not present
     * @param pattern
     * @param timeout
     * @param clientLimit
     * @param id
     * @param token
     * @return {Channel}
     */
    onCreateChannel(pattern,timeout = -1,clientLimit = -1, id = "", token = ""){
        if(this.getChannel(id) === undefined)
            this.createChannel(pattern,timeout,clientLimit, id, token);
    }

    /**
     *  adds Listeners on the channels events
     * @param channel
     */
    addChannelListeners(channel){
        channel.on("message",(m)=>{
            this.node.command({
                type: "message",
                channelId: m.channelId,
                data: m.data,
                clients: m.clients,
                cycle: m.cycle,
            });
        });
        channel.on("clientConnect",(c)=>{
            this.node.command({
                type: "clientConnect",
                channelId: c.channelId,
                clientId: c.clientId
            })
        });
        channel.on("clientDisconnect",(c)=>{
            this.node.command({
                type: "clientDisconnect",
                channelId: c.channelId,
                clientId: c.clientId
            })
        });
        channel.on("end",(e)=>{
            this.channels.delete(e.channelId);
            this.node.command({
                type: "deleteChannel",
                channelId: e.channelId
            })
        });
    };

    /*
    run(){
        this.initHttpServer();
        this.httpserver.listen(this.port);
        return this;
    }
    */

    /**
     * returns all Channels
     * @returns {Map<Channel>}
     */
    getAllChannels(){
        return this.channels;
    }

    /**
     * returns Channel by ID
     * @param id
     * @returns {Channel}
     */
    getChannel(id){
        return this.channels.get(id);
    }

    /**
     * deletes Channel with id
     * @param id
     * @return {boolean} true if successful
     */
    deleteChannel(id){
        let channel = this.channels.get(id);
        if(channel != null) {
            this.node.command({
                type: "deleteChannel",
                channelId: id
            });
            return true;
        }
        else
            return false;
    }

    /**
     * deletes Channel with id
     * @param id
     * @return {boolean} true if successful
     */
    onDeleteChannel(id){
        let channel = this.channels.get(id);
        if(channel != null){
            this.channels.delete(id);
            channel.delete();
            console.log(`Relay Server: Channel deleted`);

            return true;
        }else{
            return false
        }
    }

    /**
     * stops Relay Server
     * @return {Promise}
     */
    stop(){
        return new Promise(resolve => {
            this.channels.forEach(c=>c.delete());
            console.log("RelayServer ended");
            resolve();
        })
    }
}

module.exports = {RelayServer: RelayServer};