/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Function:        randomID
 * Description:
 * a Tool to generate random IDs of given length
 *--------------------------------------------------------------------------------------------------------------------*/

const crypto = require("crypto");

/**
 * Length of token
 * @param {number} length [16]
 * @return {string}
 */
function randomID(length = 16){
    return crypto.randomBytes(length/2).toString('hex').toUpperCase();
}

module.exports = {randomID: randomID};
