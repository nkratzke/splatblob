/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           RaftNode
 * Description:
 * Implements a Node referring to the Raft-Algorithm
 *--------------------------------------------------------------------------------------------------------------------*/

const EventEmitter = require("events").EventEmitter;
const gen = require('./idGenerator.js').randomID;
const rpc = require('axon-rpc');
const axon = require('axon');
const Node = require('./RemoteNode.js').RemoteNode;
const publicIp = require('public-ip');
const fs = require("fs");

/**
 * My own Raft implementation
 */
class RaftNode extends EventEmitter{

    /// ------------------------------------
    ///     CONSTRUCTOR
    /// ------------------------------------
    /**
     * Create Node
     * @param {String} address
     * @param {Number} port
     */
    constructor(address, port) {
        super();

        (async () => {
            this.publicAddress = await publicIp.v4();
        })();

        // identity
        this.id = gen(process.env.WRS_ID_LENGTH);
        this.address = address;
        this.port = port;

        // state
        this.nodes = [];
        this.state = 0;
        this.knownLeader = null;
        this.currentTerm = 1;
        this.votedFor = null;

        // log
        this.log = [];
        this.commitIndex = 0;
        this.lastApplied = 0;
        this.snapshots = {
            present: false,
            path: "./",
            files: [],
            lastIncludedIndex: -1,
            lastIncludedTerm: -1,
        };

        // timeouts
        this.maxElectionTimeout = process.env.WRS_NODE_MAX_ELECTION_TIMEOUT || 2000;
        this.minElectionTimeout = process.env.WRS_NODE_MIN_ELECTION_TIMEOUT || 1000;
        this.randomElctionTimeout = (Math.floor(Math.random() * Math.floor(Math.floor(this.maxElectionTimeout) - Math.ceil(this.minElectionTimeout)))) + 1 + Math.ceil(this.minElectionTimeout);
        this.heartbeat = process.env.WRS_NODE_HEARTBEAT || 700;
        this.lastActivity = null;

        // misc
        this.intend = null;

        //most dirty thing I've done!!!!!
        //TODO: shame to death
        global.node = this;
        this.functions = {
            appendEntries: function (term, leaderId, prevLogIndex, prevLogTerm, entries, leaderCommit, cb) {
                let result = global.node.appendEntries(term, leaderId, prevLogIndex, prevLogTerm, entries, leaderCommit, cb);
                cb(result[0],result[1],result[2],result[3]);
            },
            requestVote: function (term, candidateID, lastLogIndex, lastLogTerm, cb) {
                let result = global.node.requestVote(term, candidateID, lastLogIndex, lastLogTerm, cb);
                cb(result[0],result[1],result[2]);
            },
            installSnapshot: function (term, leaderId, lastIncludedIndex, lastIncludedTerm, offset, data, done, cb) {
                let result = global.node.installSnapshot(term, leaderId, lastIncludedIndex, lastIncludedTerm, offset, data, done, cb);
                cb(result[0],result[1]);
            },
            addServer: function (id,address,publicAddress,port,cb) {
                let result = global.node.addServer(id,address,publicAddress,port,cb);
                cb(result[0],result[1],result[2],result[3]);
            },
            removeServer: function (id, cb) {
                let result = global.node.removeServer(id, cb);
                cb(result[0], result[1], result[2]);
            },
            clientRequest: function (id,sequenceNum, command, cb) {
                let result = global.node.clientRequest(id,sequenceNum, command, cb);
                cb(result[0], result[1], result[2], result[3]);
            }
        };

        // start server
        let socket = axon.socket('rep',{identity: this.id});
        this.server = new rpc.Server(socket);
        socket.bind(this.port, this.address,(s)=>{
            console.log(`${this.id} listening on ${this.address}:${this.port} - ${s}`);
        });

        this.server.expose("appendEntries",this.functions.appendEntries);
        this.server.expose("requestVote",this.functions.requestVote);
        this.server.expose("installSnapshot",this.functions.installSnapshot);
        this.server.expose("addServer",this.functions.addServer);
        this.server.expose("removeServer",this.functions.removeServer);
        this.server.expose("clientRequest",this.functions.clientRequest);

        this.setTimeout();
        this.setHeartbeat();
    }

    /// ------------------------------------
    ///  REMOTE PROCEDURE CALL METHODS
    /// ------------------------------------
    // uses axon-rpc: https://www.npmjs.com/package/axon-rpc
    /**
     * Invoked by leader to replicate log entries (§5.3); also used as heartbeat (§5.2).
     * @param {number} term             leader’s term
     * @param {String} leaderId         so follower can redirect clients
     * @param {number} prevLogIndex     index of log entry immediately preceding new ones
     * @param {number} prevLogTerm      term of prevLogIndex entry
     * @param {Array}  entries          log entries to store (empty for heartbeat; may send more than one for efficiency)
     * @param {number} leaderCommit     leader’s commitIndex
     * @param {Function} cb                        Callback Function returns:
     *                                      {number}    term        currentTerm, for leader to update itself
     *                                      {boolean}   success     true if follower contained entry matching prevLogIndex and prevLogTerm
     * @return {[Error, Number, Boolean]} [Error, Term, success]
     * @public
     */
    appendEntries(term, leaderId, prevLogIndex, prevLogTerm, entries, leaderCommit, cb){
        //if(entries.length > 0) // filter heartbeats
            console.log(`${this.id}:${RaftNode.states[this.state]} <= appendEntries: T:${term} L:${leaderId} pi:${prevLogIndex} pt:${prevLogTerm} e:${JSON.stringify(entries)} c:${leaderCommit}`);

            if(term < this.currentTerm)
                return [null, this.currentTerm, false];

            switch (this.state) {
                // We are LEADER
                case RaftNode.states.indexOf("LEADER"): {
                    // append update
                    if(entries.length > 0 && entries[0].config !== undefined){
                        switch (entries[0].config.intend) {
                            case "update":{
                                // other LEADER?
                                return [null, this.currentTerm, true];
                            }
                        }
                    }
                    // Heartbeat from new Leader
                    if(entries.length === 0){
                        if(term >= this.currentTerm && prevLogIndex >= this.log.length){
                            this.makeLeader(leaderId);
                            this.currentTerm = term;
                            return [null, this.currentTerm, true];
                        }
                    }

                }
                // We are FOLLOWER
                case RaftNode.states.indexOf("FOLLOWER"): {
                    // previous Entry does not match
                    if(prevLogIndex >= 0 && (this.getLogEntry(prevLogIndex)===undefined || !(this.getLogEntry(prevLogIndex).term === prevLogTerm))) {
                        console.log("previous Entry does not match");
                        this.removeConflictLog(prevLogIndex);
                        this.updateActivity();
                        return [null, this.currentTerm, false];
                    }

                    // is Entry of index 0
                    if(prevLogIndex === -1){
                        console.log("Entry of index 0");
                        this.removeConflictLog(0);
                    }
                    // Is Config
                    if(entries.length > 0 && entries[0].config !== undefined) {
                        if (leaderId === this.knownLeader || this.knownLeader === null) {
                            this.updateActivity();
                            this.applyConfig(entries[0].config);
                            this.addLogEntry(entries[0], true);
                        }
                        this.updateActivity();
                        return [null, this.currentTerm, true];
                    }

                    // is Command
                    if(entries.length > 0 && entries[0].command !== undefined ){
                        this.addLogEntry(entries[0].command);
                        return [null, this.currentTerm, true];
                    }

                    // is Heartbeat from new Leader
                    if(entries.length === 0 && leaderId !== this.knownLeader){
                        if(term >= this.currentTerm && prevLogIndex >= this.log.length){
                            this.makeLeader(leaderId);
                        }
                    }

                    // is Heartbeat
                    this.updateActivity();
                    this.currentTerm = term;

                    while(leaderCommit >= this.lastApplied && this.lastApplied < this.log[this.log.length-1].index ){
                        console.log("Check for Commit: L " + leaderCommit + " LA " + this.lastApplied);
                        this.commit(this.lastApplied++);
                        this.commitIndex++;
                    }
                    return [null, this.currentTerm, true];
                }
                // We are CANDIDATE
                case RaftNode.states.indexOf("CANDIDATE"): {
                    // Heartbeat from new Leader
                    if(leaderId !== null) {
                        if (term >= this.currentTerm && prevLogIndex >= this.log.length-1) {
                            this.makeLeader(leaderId);
                            this.currentTerm = term;
                            this.updateActivity();
                            return [null, term, true];
                        } else {
                            return [null, term, true];
                        }
                    } else {
                        return [new Error("not voted yet"), this.currentTerm, false];
                    }
                }
                case RaftNode.states.indexOf('CONNECTING'): {
                        // if we have no Leader (Connect)
                        if (this.knownLeader == null) {
                            this.makeLeader(leaderId);
                        }
                        /*
                        console.log(prevLogIndex , this.getLogEntry(prevLogIndex))
                        if((this.getLogEntry(prevLogIndex) === undefined && prevLogIndex >= 0) || !(this.getLogEntry(prevLogIndex).term === prevLogTerm)) {
                            this.removeConflictLog(prevLogIndex);
                            this.updateActivity();
                            return [null, this.currentTerm, false];
                        }
                       */


                    return [null, 0, true];
                }
            }
    }

    /**
     *  requestVote RPC
     * @param term          term
     * @param candidateID   id of candidate
     * @param lastLogIndex  last log index
     * @param lastLogTerm   last log term
     * @param cb            callbackFunction
     * @public
     * @returns {[Error,Number,Boolean]} [error,term,voteGranted]
     */
    requestVote(term, candidateID, lastLogIndex, lastLogTerm, cb){
        console.log(`${this.id}:${RaftNode.states[this.state]} <= requestVote: T:${term} C:${candidateID} li:${lastLogIndex} lt:${lastLogTerm}`);
        switch (this.state) {
            case RaftNode.states.indexOf("LEADER"): {
                if(term >= this.currentTerm)
                    if(this.votedFor === candidateID || this.votedFor === null){
                        this.votedFor = candidateID;
                        return [null,term,true];
                    }
                else
                    return [null,this.currentTerm,false];
            }
            case RaftNode.states.indexOf("FOLLOWER"): {
                if(candidateID !== null) {
                    if(this.votedFor === candidateID || this.votedFor === null){
                        this.votedFor = candidateID;
                        return [null,term,true];
                    }
                }
            }
            case RaftNode.states.indexOf("CANDIDATE"): {
                return [null,term,false];
            }
            case RaftNode.states.indexOf("CONNECTING"): {
                return [null,term,false];
            }
        }
        this.updateActivity();
        return [null,this.currentTerm,false];
    }

    /**
     *  installSnapshot RPC
     * @param term              current term
     * @param leaderId          leader ID
     * @param lastIncludedIndex last included index
     * @param lastIncludedTerm  last included term
     * @param offset            offset
     * @param data              data
     * @param done              done
     * @param cb                callbackFunction
     * @public
     * @returns {[Error,Number]} [error,term]
     */
    installSnapshot(term, leaderId, lastIncludedIndex, lastIncludedTerm, offset, data, done, cb){

        // if we have no Leader (Connect)
        if (this.knownLeader == null) {
            this.makeLeader(leaderId);
        }

        let json = JSON.parse(data);
        console.log("installing "+json.file);
        if(this.log.length > 0 && json.log[0].index === 0){
            this.log = [];
            this.commitIndex = 0;
            this.lastApplied = 0;
        }
        if(this.log.length === 0 || json.log[0].index === this.log[this.log.length-1].index+1) {
            json.log.forEach((e)=>{
                if(e.config !== undefined)
                    this.applyConfig(e.config);
            });

            this.log = this.log.concat(json.log);
        }
        console.log(JSON.stringify(this.log,null,0));
        this.currentTerm = json.file.lastIncludedTerm;
        return [null,term];
    }

    /**
     *  addServer RPC
     * @param id                id of node to add
     * @param address           address of node to add
     * @param publicAddress     public address to node to add
     * @param port              port
     * @param cb                callbackFunction
     * @returns {[Error,String,Object]} [error,status,leaderHint]
     */
    addServer(id, address, publicAddress, port, cb) {
        console.log(`${this.id}:${RaftNode.states[this.state]} <= addServer: i:${id} a:${address} p:${port}`);
        if(this.isLeader()) {
            // add Server
            let node = this.addNode(id,address,publicAddress,port);
            if(node !== undefined) {
                node.nextIndex = this.log[this.log.length-1].index;
                // Broadcast new Config
                this.addLogEntry(this.createConfig(), true);
                // let new Server catch up
                this.tryAppendEntries(node, []).then(() => {
                    console.log("resolved!")


                });
                return [null, "OK", null];
            } else {
                return [null, "WRONG_ARGUMENT", null]
            }
        } else {
            return [null,"REDIRECT",this.getNodeById(this.knownLeader).getAddress()];
        }
    }

    /**
     *  removeServer RPC
     * @param id    id of node to remove
     * @param cb    callbackFunction
     * @returns {[Error,String,Object]} [error,status,leaderHint]
     */
    removeServer(id, cb) {
        console.log(`${this.id}:${RaftNode.states[this.state]} <= removeServer: i:${id}`);
        if(this.isLeader()) {
            let found = this.removeNode(id);
            if(found){
                let entry = {
                    config: {
                        intend: "update",
                        nodes: this.getNodeAddresses(true)
                    }
                };
                this.addLogEntry(entry,true);
                return [null,"OK", null];
            } else {
                return [null,"NotFound", null];
            }
        } else {
            return [null,"REDIRECT",this.getNodeById(this.knownLeader).getAddress()];
        }
    }

    /**
     * client Request RPC is called to Request a new command commit
     * @param {String} id           node id
     * @param {Number} sequenceNum  sequence number
     * @param {Object} command      command
     * @param {Function} cb         callbackFunction
     * @return {[Error,String,Object,Object]} [error,status,response,leaderHint]
     */
    clientRequest(id, sequenceNum, command, cb){
        console.log(`${this.id}:${RaftNode.states[this.state]} <= clientRequest: i:${id} seq:${sequenceNum} c:{command}`);
        if(this.isLeader()) {
                // add Entry like your own
                this.addLogEntry(command);
                return [null, "OK", {}, null];
        } else {
            return [null,"REDIRECT", null, this.getNodeById(this.knownLeader).getAddress()];
        }
    }


    /// ------------------------------------
    ///     TIMEOUT & HEARTBEAT
    /// ------------------------------------
    /**
     *  set Timeout Interval
     */
    setTimeout() {
        this.tInterval = setInterval(
            (interval) => {
                //console.log((new Date().getTime()) - this.lastActivity +" "+ this.randomElctionTimeout)
                if(!(this.state === RaftNode.states.indexOf("LEADER"))){ // ||this.state === RaftNode.states.indexOf("CONNECTING")
                    //console.log(this.randomElctionTimeout)
                    if( ((new Date().getTime()) - this.lastActivity) > this.randomElctionTimeout) {
                        this.doTimeout();
                        this.randomElctionTimeout = (Math.floor(Math.random() * Math.floor(Math.floor(this.maxElectionTimeout) - Math.ceil(this.minElectionTimeout)))) + 1 + Math.ceil(this.minElectionTimeout);

                        this.updateActivity();
                    }
                }
            }, 100);
    }

    /**
     *  set Heartbeat Interval
     */
    setHeartbeat() {
        this.hInterval = setInterval(
            (interval) => {
                if(this.isLeader()){
                    this.doHeartbeat();
                }
            }, this.heartbeat);
    }

    /**
     *  send empty appendEntry RPC on Heartbeat
     */
    doHeartbeat(){
        this.nodes.forEach((n)=>{
            this.tryAppendEntries(n,[]);
        });
    };

    /**
     * Try to send Entry to Node
     * on reject try until match, then update
     * @param node
     * @param entries
     */
    tryAppendEntries(node, entries){
        return new Promise((resolve,reject)=>{
            console.log(`log.length:${this.log[this.log.length-1].index} nextIndex: ${node.nextIndex} log[nexI-1]: ${JSON.stringify(this.getLogEntry(node.nextIndex-1))} entries: ${JSON.stringify(entries)}`);
            // if snapshots present send it
            if(this.snapshots.present && this.snapshots.lastIncludedIndex >= node.nextIndex){
                this.sendSnapshots(node).then(()=> {
                    console.log("updated logs continie at "+(this.snapshots.lastIncludedIndex+1));
                    node.nextIndex = this.snapshots.lastIncludedIndex+1;
                    this.tryAppendEntries(node, [this.getLogEntry(node.nextIndex)]).then(() => {
                        resolve(true)
                    });
                });
            } else {
                // start appendEntry
                let ret = node.appendEntries(this.currentTerm, this.id, node.nextIndex - 1, ((node.nextIndex > 0) ? (this.snapshots.lastIncludedIndex >= node.nextIndex - 1) ? this.snapshots.lastIncludedTerm : this.getLogEntry(node.nextIndex - 1).term : undefined), entries, this.lastApplied);
                ret.then((res) => {
                    // Try to catch up
                    if (!res.success && node.nextIndex > 0) {
                        node.nextIndex--;
                        this.tryAppendEntries(node, [this.getLogEntry(node.nextIndex)]).then(() => {
                            resolve(true)
                        });
                    } else {
                        if (entries.length !== 0 && this.getLogEntry(node.nextIndex)!==undefined) node.nextIndex++;
                        if (node.nextIndex <= this.log[this.log.length-1].index) {
                            // update Follower until consistent
                            this.tryAppendEntries(node, [this.getLogEntry(node.nextIndex)]).then(() => {
                                resolve(true)
                            });
                        } else {
                            // up to date
                            resolve(true);
                        }
                    }
                })
            }
        });
    }

    /**
     * sends a Snapshot to the given node using the installSnapshot RPC
     * @param node      node
     * @param offset    offset to last Snapshot
     * @return {Promise<any>}
     */
    sendSnapshots(node, offset = -1){
        return new Promise((resolve)=>{
            console.log(offset);
            offset = offset > -1 ? offset : this.snapshots.files.length-1;
            let index = this.snapshots.files.length-1 - offset;
            let file = this.snapshots.files[index];
            console.log("sending " + file.name);
            let data = fs.readFileSync(`${this.snapshots.path}${file.name}`, 'utf8');
            //console.log(data);
            node.installSnapshot(this.currentTerm,this.knownLeader,this.snapshots.lastIncludedIndex,this.snapshots.lastIncludedTerm,offset,data,offset <= 0).then(()=>{
                if(--offset >= 0) {
                    this.sendSnapshots(node, offset)
                } else {
                    node.nextIndex = this.snapshots.lastIncludedIndex+1;
                    resolve(true);
                }
            });
        })
    }

    /**
     * reset last activity timestamp
     */
    updateActivity(){
        this.lastActivity = new Date().getTime();
    }

    /**
     * execute on timeout
     */
    doTimeout() {
        console.log("Timeout!!! - nodes: " + this.nodes.length);
        if(this.nodes.length === 0) {
            // on Startup be a knownLeader
            this.makeLeader(this.id);
        } else {
            this.vote();
        }
    }

    /**
     * start Vote
     */
    vote(){
        this.state = RaftNode.states.indexOf("CANDIDATE");
        this.votedFor = this.id;
        let voteTerm = this.currentTerm++;
        let responses = 0;
        this.nodes.forEach((n)=>{
               let ret = n.requestVote(this.currentTerm++,this.id,this.log.length-1,this.getLogEntry(this.log.length-1).term);
               ret.then((res)=>{
                   if(res.voteGranted)
                       responses++;

                   if(responses > this.nodes.length/2) {
                       this.makeLeader(this.id);
                   }
               });
            }
        );

    }


    /// ------------------------------------
    ///     NODE MANAGEMENT
    /// ------------------------------------

    /**
     * add a new node to known cluster
     * @param {String} id
     * @param {string} address
     * @param {String} publicAddress
     * @param {Number} port
     * @private
     */
    addNode(id, address, publicAddress, port) {
        if (id === this.id)
            return null;
        if (this.nodes.find(n => {
            return n.id === id
        }) === undefined) {
            try {
                let node = new Node(id, address, publicAddress, port);

                node.nextIndex = this.log[this.log.length-1].index;
                this.nodes.push(node);
                console.log(`added node - nodes: ` + this.nodes.length);

                return node
            }catch (e) {
                return null;
            }
        } else {
            return null;
        }
    }

    /**
     * Removes Node with id
     * @param {String} id
     * @return {boolean} true if found an d removed
     */
    removeNode(id) {
        if (id === this.id)
            return false;

        if (this.nodes.find(n => {
            return n.id === id
        }) === undefined) {
            console.log(`node not found `);
            return false
        } else {
            this.nodes = this.nodes.filter((n) => {return n.id !== id});
            console.log(`removed node - nodes: ` + this.nodes.length);
            return true
        }
    }

    /**
     * returns Node with id or null
     * @param id
     * @return {Node} Node or null
     */
    getNodeById(id) {
        return this.nodes.find(n => {
            return n.id === id
        })
    }

    /**
     *  Removes Address Object Array of all Nodes in cluster
     * @param {boolean} self        self included
     * @return {Array}  Array of Objects
     */
    getNodeAddresses(self = true) {
        let nodes = [];
        if(self) nodes.push({
            id: this.id,
            address: this.address,
            publicAddress: this.publicAddress,
            port: this.port
        });
        this.nodes.forEach(n => {
            nodes.push(n.getAddress());
        });
        return nodes;
    }

    /// ------------------------------------
    ///     LEADER
    /// ------------------------------------

    /**
     * Makes Node with id LEADER
     * @param id    id
     */
    makeLeader(id){
        this.knownLeader = id;
        this.votedFor = null;
        if(this.id === id){
            this.state = RaftNode.states.indexOf("LEADER");
            this.nodes.forEach((n)=>{
               n.nextIndex = this.log.length;
            });
            // find out last commited entry
            this.addLogEntry("no-op");
        } else {
            this.state = RaftNode.states.indexOf("FOLLOWER");
        }
        console.log(`${this.id}: ${id} is now leader`);
    }

    isLeader() {
        return this.state === RaftNode.states.indexOf("LEADER");
    }

    /**
     *  creates Config of current cluster
     * @returns {{config: {nodes: Array, intend: string}}}
     */
    createConfig(){
        return {config: {
            intend: "update",
                nodes: this.getNodeAddresses(true)
            }};
    }

    /// ------------------------------------
    ///     PUBLIC
    /// ------------------------------------

    /**
     * run node without connecting
     * @public
     */
    run() {

    };

    /**
     * Connect to another Node
     * @param {String} address
     * @param {int} port
     * @returns {Promise<Object>}
     * @public
     */
    join(address, port) {
        return new Promise(resolve => {
            setTimeout(()=>{
                resolve({success: false, error: "Response timed out"});
            },1000);
            if(isNaN(port) || port < 0 || port > 65536) resolve({success: false, error: "Port NaN or out of bounds"});
            if(address === undefined || address === '') resolve({success: false, error: "Empty Address"});
            // prune progression
            this.nodes = [];
            this.log = [];
            this.lastApplied = 0;
            this.currentTerm = 1;

            let node = new Node("?", address, address, port);
            console.log(`connecting to ${address}:${port} ...`);

            this.state = RaftNode.states.indexOf("CONNECTING");
            this.knownLeader = null;
            let ret = node.addServer(this.id, this.address, this.publicAddress, this.port);
            ret.then((res) => {
                console.log(`response`);
                this.removeNode("?");
                if (res.status === "OK") {
                    console.log(`connected`);
                    resolve({success: true, error: ""});
                    // ok
                } else {
                    if (res.leaderHint !== undefined) {
                        // follow redirect
                        this.join(res.leaderHint.address, res.leaderHint.port).then(r=>resolve(r));
                        this.updateActivity();
                    } else {
                        resolve({success: false, error: "Redirect does not contain leaderHint"});
                    }
                }
            });
            this.updateActivity();
        });
    }

    /**
     * removes Node from cluster
     * @param id node id
     * @return {Promise<Object>}
     */
    remove(id){
        return new Promise(resolve => {
            if(this.isLeader()) {
                if(this.removeNode(id)) {
                    let entry = {
                        config: {
                            intend: "update",
                            nodes: this.getNodeAddresses(true)
                        }
                    };
                    this.nodes.forEach(n => n.appendEntries(this.currentTerm, this.knownLeader, n.nextIndex - 1, this.getLogEntry(n.nextIndex - 1).term, [entry], this.lastApplied));
                    resolve({success: true});
                } else {
                    resolve({success: false});
                }
            }else {
                if(this.getNodeById(id) !== null) {
                    this.getNodeById(this.knownLeader).removeServer(id);
                    resolve({success: true});
                }else {
                    resolve({success: false});
                }
            }
        })
    }

    /**
     * Stop Node and disconnect
     * @public
     * @returns Promise
     */
    stop(){
        return new Promise(resolve =>{
            clearInterval(this.tInterval);
            clearInterval(this.hInterval);

            this.snapshots.files.forEach((f)=>{
                console.log(`deleting: ${this.snapshots.path}${f.name}`);
                fs.unlinkSync(`${this.snapshots.path}${f.name}`);
            });

            this.remove(this.id).then(res => {
                this.server.sock.close();
                console.log("Node ended correctly");
                this.server.sock.on("close",()=>resolve());

            });
        })
    }

    /**
     * Add Command to log
     * @param {Object} obj command to store
     * @returns Promise
     */
    command(obj){
        let ret = new Promise((resolve)=>{
            if (this.isLeader()){
                // save
                this.addLogEntry(obj);
                resolve(true);
            } else {
                // request
                if (this.knownLeader !== null) {
                    this.getNodeById(this.knownLeader).clientRequest(this.id,0,obj).then((res)=>{
                        if(res.status === "OK")
                            resolve(true);
                        else
                        // TODO follow redirect
                            resolve(false);
                    });
                    resolve(true);
                } else
                    resolve(false);
            }
        });
        return ret;
    }

    /// ------------------------------------
    ///     Log Management
    /// ------------------------------------

    /**
     * Adding Log Entry
     * @param {Object} obj
     * @param {boolean} config [false]
     * @private
     */
    addLogEntry(obj,config=false) {
        var index = 0;
        let prevLogEntry = this.log[this.log.length-1];
        //console.log(prevLogEntry)
        if(this.log.length !== 0)
            index = prevLogEntry.index + 1;

        let entry = {
            term: this.currentTerm,
            index: index,
            leader: this.knownLeader,
        };
        if(config)
            entry.config = obj.config;
        else
            entry.command = obj;
        this.log.push(entry);
        console.log("added log entry: " + JSON.stringify(entry));
        let responses = 0;
        if (this.isLeader())
            this.nodes.forEach((n)=>{
                    let ret = n.appendEntries(this.currentTerm,this.knownLeader,prevLogEntry.index,prevLogEntry.term,[entry],this.lastApplied);
                    n.nextIndex = index+1;
                    ret.then((res)=>{

                        if(res.success) {
                            responses++;
                        }

                        if(responses >= this.nodes.length/2) {
                            this.lastApplied = index;
                            this.commitIndex = index;
                            this.commit(index);
                        }
                    })
                }
            );
        if(this.nodes.length === 0) {
            this.lastApplied = index;
            this.commitIndex = index;
            this.commit(index);
        }
        if(this.log.length > process.env.WRS_NODE_SNAPSHOT_LENGTH) this.createSnapshot();
    }

    /**
     * Returns LogEntry with index, not at index position
     * necessary because snapshots changes indexing
     * @param index
     * @return {Object}
     */
    getLogEntry(index){
        return this.log.filter((e)=>e.index === index)[0];
    }

    /**
     * removes log entry at index and all following
     * @param index index
     */
    removeConflictLog(index){
        this.log.slice(index,this.log.length-1);
        console.log("removed Entries from "+index+" - log: " + this.log.length);
    };

    /**
     * Creates Snapshot and saves it to the File System.
     */
    createSnapshot(){
        //console.log('old log', this.log);
        console.log('snapshots: \n', this.snapshots);
        var firstIndex = this.log[0].index;
        var lastIndex = this.commitIndex-1;
        var lastTerm = this.getLogEntry(lastIndex).term;
        console.log("creating Snapshot to index: " + lastIndex);
        return new Promise(()=>{
            var saveLog = this.log.splice(0,this.log.indexOf(this.getLogEntry(lastIndex+1)));
            //console.log('log data:', saveLog);
            // update snapshots
            var file = {
                name: `snapshot_${firstIndex}-${lastIndex}.json`,
                lastIncludedIndex: lastIndex,
                lastIncludedTerm: lastTerm
            };
            this.snapshots.present = true;
            this.snapshots.files.push(file);
            this.snapshots.lastIncludedIndex = lastIndex;
            this.snapshots.lastIncludedTerm = lastTerm;
            // write snapshots
            fs.writeFileSync(`${this.snapshots.path}${file.name}`, JSON.stringify({
                file: file,
                log: saveLog
            },null,2));
            console.log('new log data:', this.log);
        });
    }



    /**
     * Commit Entry
     * @param {Number} index
     */
    commit(index){
        let obj = this.getLogEntry(index);
        console.log("committing: " + JSON.stringify(obj));
        if(obj.command !== undefined && obj.command !== "no-op") {
            this.emit("commit", obj.command);
        }
    }

    applyConfig(config){
        let nodes = config.nodes;
        // add new
        nodes.forEach((n) => {
            if (this.getNodeById(n.id) === undefined) {
                this.addNode(n.id, n.address,n.publicAddress, n.port);
            }
        });
        // delete old
        this.nodes.forEach(n => {
            if (nodes.find(o => o.id === n.id) === undefined)
                this.removeNode(n.id);
        })
    }
}
RaftNode.states = ['FOLLOWER', 'LEADER', 'CANDIDATE', 'CONNECTING'];

module.exports = {
    Node: RaftNode,
    appendEntries: this.appendEntries,
    requestVote: this.requestVote,
    installSnapshot: this.installSnapshot
};