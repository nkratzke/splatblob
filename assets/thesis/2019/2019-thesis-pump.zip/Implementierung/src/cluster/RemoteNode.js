/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           RemoteNode
 * Description:
 * The RemoteNode represents other Nodes in the Raft-Cluster.
 * the RPC Methods can be used to execute the corresponding RPCs on the remote node.
 *--------------------------------------------------------------------------------------------------------------------*/

const rpc = require('axon-rpc');
const axon = require('axon');

class RemoteNode {
    /**
     * Constructor
     * @param {String} id       ID
     * @param {String} address  IP-Address
     * @param {String} publicAddress public IP-Address
     * @param {Number} port     Port
     * @public
     */
    constructor(id ,address, publicAddress, port){
        this.address = address;
        this.publicAddress = publicAddress;
        this.port = port;
        this.id = id;
        try {
            this.client = this.createClient();
        } catch (e) {
            throw new Error("Wrong Address arguments")
        }
        this.nextIndex = 0;
        this.matchIndex = 0;
        this.votePermission = false;
    }

    /**
     * Creates RPC Client using axon
     * @returns {Client}
     * @private
     */
    createClient(){
        let socket = axon.socket('req',{});
        let client = new rpc.Client(socket);
        socket.connect(this.port,this.address,()=>{});
        return client;
    }

    /**
     * String representation
     * @returns {String}
     */
    toString(){
        return JSON.stringify(`${this.id} - ${this.address}:${this.port}`);
    }

    /**
     * returns address object
     * @return {{address: String, port: Number, publicAddress: String, id: String}}
     */
    getAddress(){
        return {id: this.id, address: this.address, publicAddress: this.publicAddress, port: this.port};
    }

    // -------------------
    //      RPCs
    // -------------------

    /**
     * Invoked by leader to replicate log entries (§5.3); also used as heartbeat (§5.2).
     * @param {number} term             leader’s term
     * @param {String} leaderId         so follower can redirect clients
     * @param {number} prevLogIndex     index of log entry immediately preceding new ones
     * @param {number} prevLogTerm      term of prevLogIndex entry
     * @param {Array}  entries          log entries to store (empty for heartbeat; may send more than one for efficiency)
     * @param {number} leaderCommit     leader’s commitIndex
     * @return {Promise<Object>}
     */
    appendEntries(term, leaderId, prevLogIndex, prevLogTerm, entries, leaderCommit){
        let ret = new Promise((resolve,reject)=>{
            this.client.call('appendEntries', term, leaderId, prevLogIndex, prevLogTerm, entries, leaderCommit, function(err, term, success, redirect=null){
                resolve({error: err,term: term, success: success, redirect: redirect});
            });
        });
        return ret;
    }

    /**
     *  vote Request RPC
     * @param term
     * @param candidateID
     * @param lastLogIndex
     * @param lastLogTerm
     * @return Promise<Object>
     */
    requestVote(term, candidateID, lastLogIndex, lastLogTerm){
        let ret = new Promise((resolve,reject)=>{
            this.client.call('requestVote', term, candidateID, lastLogIndex, lastLogTerm, function(err, term, voteGranted){
                resolve({term: term, voteGranted: voteGranted});
            });});
        return ret;
    }

    /**
     *  install Snapshot RPC
     * @param term
     * @param leaderId
     * @param lastIncludedIndex
     * @param lastIncludedTerm
     * @param offset
     * @param data
     * @param done
     * @returns {Promise<Object>}
     */
    installSnapshot(term, leaderId, lastIncludedIndex, lastIncludedTerm, offset, data, done){
        let ret = new Promise((resolve,reject)=>{
            this.client.call('installSnapshot', term, leaderId, lastIncludedIndex, lastIncludedTerm, offset, data, done, function(err, term){
                resolve({term: term})
            });
        });
        return ret;
    }

    /**
     *  addServer RPC
     * @param id
     * @param address
     * @param port
     * @param publicAddress
     * @return {Promise<Object>}
     */
    addServer(id, address, publicAddress, port){
        let ret = new Promise((resolve,reject)=> {
            this.client.call('addServer', id, address,publicAddress, port, function (err, status, leaderHint) {
                resolve({status: status, leaderHint: leaderHint})
            });
        });
        return ret;
    }

    /**
     *  removeServer RPC
     * @param id
     * @return {Promise<Object>}
     */
    removeServer(id){
        let ret = new Promise((resolve,reject)=> {
            this.client.call('removeServer', id, function (err, status, leaderHint) {
                resolve({status: status, leaderHint: leaderHint})
            });
        });
        return ret;
    }

    /**
     *  clientRequest RPC
     * @param id
     * @param sequenceNum
     * @param command
     * @return {Promise<Object>}
     */
    clientRequest(id, sequenceNum, command){
        let ret = new Promise((resolve,reject)=> {
            this.client.call('clientRequest', id, sequenceNum,command, function (err, status, response, leaderHint) {
                resolve({status: status, response: response, leaderHint: leaderHint})
            });
        });
        return ret;
    }

}

module.exports = {RemoteNode: RemoteNode};