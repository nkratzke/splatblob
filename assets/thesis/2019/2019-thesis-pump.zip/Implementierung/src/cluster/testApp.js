const Node = require("./RaftNode").Node;
argv = require('argh').argv;

async function main() {

    var node = new Node(argv.host || "localhost", argv.port || 5000);

    if(!argv.join)
        node.run();
    else
        node.join(argv.join.toString().split(':')[0],Number.parseInt(argv.join.toString().split(':')[1]));

    let int = setInterval(
        (interval) => {
            //node.command({timestamp: new Date()});
        }, 10000);

    process.on('SIGINT', ()=>{
        node.stop();
        process.exit();
    });
    node.on("commit",(o)=>{console.log("listener: "+JSON.stringify(o))});
}



function sleep(ms){
    return new Promise(resolve=>{
        setTimeout(resolve,ms)
    })
}

main();


