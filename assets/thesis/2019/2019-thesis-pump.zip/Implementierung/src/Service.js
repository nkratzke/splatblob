/*---------------------------------------------------------------------------------------------------------------------/
 * Bachelor thesis: Websocket Relay Service
 * Author:          Cedric Pump
 *
 * Class:           Service
 * Description:
 * The Service capsules the three main modules of the WRS:
 *  - RestApi
 *  - RelayServer
 *  - RaftNode
 * The service starts and connects the Modules separably, searches fro existing clusters an ends all components
 * correctly on process end
 *--------------------------------------------------------------------------------------------------------------------*/

const RestApi = require("./api/RestApi.js").RestApi;
const RelayServer = require("./model/RelayServer.js").RelayServer;
const RaftNode = require("./cluster/RaftNode.js").Node;
const packJson = require('../package.json');



class WebsocketRelayService {
    /**
     * empty constructor
     * execute .run() to init Server
     */
    constructor(){
        this.version = packJson.version;
        this.addressNode = require("ip").address();
        this.api = null;
        this.node = null;
        this.relayServer = null;
        this.portApi = JSON.parse(process.env.WRS_API_PORT);
        this.portNode = JSON.parse(process.env.WRS_NODE_PORT);
        this.domain = process.env.WRS_DOMAIN;
    }

    /**
     * run and try to join to cluster
     * @return {Promise<Service>} returns service when ready
     */
    run(){
        return new Promise(resolve => {
            this.node = new RaftNode(this.addressNode, Number.parseInt(process.env.WRS_NODE_PORT));
            this.relayServer = new RelayServer(process.env.WRS_API_PORT, JSON.parse(process.env.WRS_SSL), node);
            setTimeout(()=>{
                this.findCluster().then(()=>{
                if(this.api === null) {
                    this.api = new RestApi(this.relayServer, this.portApi, JSON.parse(process.env.WRS_SSL), node, this.version).run();
                    resolve(this);
                }
            });
            },Math.floor(Math.random() * process.env.WRS_MAX_STARTUP_DELAY));

        });
    }

    /**
     * ends service correctly and disconnects node
     * @returns Promise
     */
    end(){
        return new Promise((resolve)=>{
            this.node.stop().then(()=>
                this.relayServer.stop().then(()=>
                    this.api.stop().then(()=>
                        resolve())));
        })
    }

    /**
     * Try to find existing cluster on domain
     * @return {Promise<Boolean>} true ist successful else false
     */
    findCluster(protocol = ""){
        return new Promise(resolve => {
            let waiting = true;
            if(protocol === "") protocol = JSON.parse(process.env.WRS_PUBLIC_SSL) ? "https" : "http";
            // check if cluster running and join
            const options = {
                hostname: this.domain,
                port: Number.parseInt(process.env.WRS_PUBLIC_API_PORT),
                path: '/cluster',
                token: process.env.WRS_AUTH_TOKEN,
                rejectUnauthorized: false
            };

            console.log(`${this.node.id}: requesting ${protocol}://${options.hostname}:${options.port}/cluster`);
            setTimeout(()=>{
                console.log("-timeout-");
                if(protocol === "http") {
                    // try again with https
                     this.findCluster("https").then(r=>resolve(r));
                } else {
                    if (waiting) waiting = false, resolve(false);
                }
            },3000);

            require(protocol).get(options, (res) => {
                let data = '';
                res.on('data', (chunk) => {
                    data += chunk;
                });
                res.on('end', () => {
                    try {
                        let json = JSON.parse(data);
                        console.log(JSON.stringify(json,null,2));
                        if (json.data.leader != null && json.data.leader !== node.id) {
                            let leader = json.data.nodes.filter((n => n.id === json.data.leader))[0];
                            console.log("connecting to leader: " + JSON.stringify(leader));
                            // Try connecting to local address
                            node.join(leader.address, leader.port).then((res)=>{
                                if(res.success){
                                    if(waiting) waiting = false, resolve(true);
                                } else {
                                    // Try connecting to public address
                                    node.join(leader.publicAddress, leader.port).then((res)=>{
                                        if(res.success){
                                            if(waiting) waiting = false, resolve(true);
                                        } else {
                                            if(waiting) waiting = false, resolve(false);
                                        }
                                    });
                                }
                            });

                        } else {
                            console.log("Requested self");
                            if(waiting) waiting = false, resolve(false);
                        }
                    } catch (e) {
                        console.log(data);
                        console.log("no connection possible");
                        if(waiting) waiting = false, resolve(false);
                    }
                });
            }).on("error", (err) => {
                console.log("Error: " + err.message);
                if(waiting) waiting = false, resolve(false);
            });


        });
    }
}

module.exports = {WebsocketRelayService: WebsocketRelayService};