const stdio = require("stdio");
const ws = require("ws");
const ip = require("ip");
const https = require('https');
const fs = require("fs");
const url = require("url");
let mport;
var authToken;

// Command Line Parameters
const ops = stdio.getopt({
    'port': {key: 'p', args: 1, description: 'Port to be used'},
    'token': {key: 't', args: 1, description: 'token for auth'}
});

if(ops.port == null)
    mport = process.env.PORT;
else
    mport = ops.port;

if(ops.token == null)
    authToken = process.env.TOKEN;
else
    authToken = ops.token;

var server;

var authFunction = function (info, cb) {
    var token = url.parse(info.req.url, true).query.token;
    if (!token)
        cb(false, 401, 'Unauthorized')
    else {
        if (token !== authToken) {
            cb(false, 401, 'Unauthorized')
        } else {
            cb(true)
        }
    }
};

useHTTPS = JSON.parse(process.env.USE_HTTPS);

if(useHTTPS) {
    let options = {
        cert: fs.readFileSync(process.env.HTTPS_CERT_PATH),
        key: fs.readFileSync(process.env.HTTPS_KEY_PATH)
    };
    httpsServer = new https.createServer(options);
    server = new ws.Server(
        {
            server: httpsServer,
            verifyClient: authFunction
        }
);
    httpsServer.listen(mport)
} else {
    server = new ws.Server(
        {
            port: mport,
            verifyClient: authFunction
        }
        );
}


server.on("connection", function (s, req) {
    console.log(`${s._socket.remoteAddress} connected`)
    s.on('message', function incoming(data) {
        console.log(`> ${s._socket.remoteAddress}: ${data}`);
        s.send(`${data}`);
    });
});

server.on("close", function (s) {
    console.log(`${s._socket.remoteAddress} disconnected`)
})

console.log(`Server running on ip: ${ip.address()}:${mport}`);
console.log(`auth token: ${authToken}`);


if(useHTTPS){
    console.log(`HTTPS active`);
    console.log(`to connect use: wss://${ip.address()}:${mport}?token=${authToken}`);
}else{
    console.log(`to connect use: ws://${ip.address()}:${mport}?token=${authToken}`);
}
