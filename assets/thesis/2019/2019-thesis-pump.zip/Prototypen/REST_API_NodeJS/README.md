# Web Socket Service Registry

## Usage

### List Channels

**Definition**

`GET /channel`

**Response**

- `200 OK` on success

```json
[
   {
       "id": "abc123",
       "port": "9999",
       "pattern": "bradcast",
       "connected": [{"ip": "0.0.0.0"}]
   },
   {
       "id": "abc124",
       "port": "9998",
       "pattern": "post/subscribe",
       "connected": [{"ip": "1.2.3.4"}]
   }
]
```

### Create new Channel

**Definition**

`POST /Channel`

**Arguments**

`{"port": 4321, "pattern": "bradcast"}`

If a WS with the given identifier already exists, the existing WS will be overwritten.

**Response**

- `201 Created` on success

```json
{"id":"abc125","port":4321,"pattern":"bradcast","connected":[]}
```

### Get Channel by ID

**Definition**

`GET /Channel/<id>`

**Response**

- `404 Not Found` if the WS does not exist
- `200 OK` on success


```json
{"id":"abc123","port":9999,"pattern":"bradcast","connected":[{"ip":"0.0.0.0"}]}
```


### Delete Channel

**Definition**

`DELETE /Channel/<id>`

**Response**

- `404 Not Found` if the WS does not exist
- `200 OK` on success

## Auth

if token authentication is activated use token argument in body to authenticate

`{"token": "<token>"}`

add a Authorization Header to your request

`'authorization': 'Bearer <token>'`

or add it as parameter for simple use with Browsers

`GET localhost:5000/channel/<id>?token=<token>`