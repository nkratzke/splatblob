var bodyParser = require('body-parser');
var stdio = require('stdio');
var express = require('express');
var markdown = require("markdown-js");
var morgan = require("morgan");
var fs = require("fs");
var checkToken = require('./check-token');
var https = require("https");

useHTTPS = JSON.parse(process.env.USE_HTTPS);

var options

if(useHTTPS) {
    options = {
        cert: fs.readFileSync(process.env.HTTPS_CERT_PATH),
        key: fs.readFileSync(process.env.HTTPS_KEY_PATH)
    }
}

// Example Channels
var ids = 125;
var channels = [
    {
        id: "abc123",
        port: 9999,
        pattern: "bradcast",
        connected: [{ip: "0.0.0.0"}]
    },
    {
        id: "abc124",
        port: 9998,
        pattern: "post/subscribe",
        connected: [{ip: "1.2.3.4"}]
    }
];

// Command Line Parameters
var ops = stdio.getopt({
    'port': {key: 'p', args: 1, description: 'Port to be used'},
    'auth': {key: 'a', args: 1, description: 'Enables token authentication'},
    'token': {key: 't', args: 1, description: 'Token to access resource'}
});

if(ops.port == null)
    port = process.env.USE_PORT;
else
    port = ops.port;

if(ops.auth == null)
    auth = JSON.parse(process.env.USE_AUTH);
else
    auth = ops.auth;

if(ops.token == null)
    sToken = process.env.SECURITY_TOKEN;
else
    sToken = ops.token;

// build Server
app = express();

app.use(morgan('dev'));

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());



app.get("/", (request, response, next) => {
    response.status(200).send(markdown.makeHtml(fs.readFileSync("README.md", "utf8")));
});


app.get("/channel", checkToken, (request, response, next) => {
    response.status(200).send(JSON.stringify(channels));
});


app.get("/channel/:id", checkToken, (request, response, next) => {
    chn = channels.filter(function (chn) {
        return chn.id === request.params.id;
    });
    //console.log(chn[0]);
    if(chn[0] != null)
        response.status(200).send(JSON.stringify(chn[0]));
    else
        response.status(404).send("Not found!")
});

app.delete("/channel/:id", checkToken, (request, response,next) => {
    chn = channels.filter(function (chn) {
        return chn.id === request.params.id;
    });

    if(chn[0] != null){
        var i = channels.indexOf(chn[0]);
        delete channels[i];
        console.log(`removed ${chn[0]}`);
        channels.splice(i,1);
        response.status(200).send("Success! Channel was found and deleted.")
    } else
        response.status(404).send("Channel not found!")
});

app.post("/channel", checkToken, (request, response, next) => {
    try {
        var json = request.body;
        console.log(Object.keys(json));

        if((Object.keys(json).indexOf('port') < 0) || (Object.keys(json).indexOf('pattern') < 0))
            response.status(400).send(`Failed!\nMake sure port and pattern attributes are present`)

        var channel = {
            id: `abc${ids}`,
            port: json.port,
            pattern: json.pattern,
            connected: []
        };

        console.log(`${channel} created`);
        ids++;
        channels.push(channel);
        createChannel(channel);
        response.status(201).send("Success!\n" + JSON.stringify(channel))
    } catch (e) {
        console.log(e);
        response.status(400).send(`Failed!`)
    }
});


if(useHTTPS){
    https.createServer(options, app).listen(port,()=>{
        console.log(`server is running on port: ${port}`);
        console.log(`HTTPS activated`);
        if (auth)
            console.log(`auth activated, security token: ${sToken}`);
    });
}else {
    app.listen(port, () => {
        console.log(`server is running on port: ${port}`);
        if (auth)
            console.log(`auth activated, security token: ${sToken}`);
    });
}


function createChannel(channel) {}