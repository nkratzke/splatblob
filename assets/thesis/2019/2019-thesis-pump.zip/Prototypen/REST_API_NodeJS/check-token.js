module.exports = (req, res, next) => {
    if(auth) {
        try {
            let success = false;
            if(req.headers.authorization != null && req.headers.authorization.split(' ')[1] === sToken){
                success = true;
            } else if(req.query.token != null && req.query.token === sToken){
                success = true;
            } else if(req.body.token != null && req.body.token === sToken){
                success = true;
            }

            if (success) {
                console.log('auth success!');
                next();
            } else {
                return res.status(401).json({
                    message: 'UNAUTHORIZED'
                })
            }
        } catch (e) {
            return res.status(401).json({
                message: 'UNAUTHORIZED ' + e.message
            })
        }
    } else {
        next();
    }
};