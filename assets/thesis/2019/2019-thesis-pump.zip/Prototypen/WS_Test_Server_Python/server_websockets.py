import asyncio
import websockets
import socket

async def response(websocket, path):
    while True:
        msg = await websocket.recv()
        # print(f'Message: {msg}')
        await websocket.send(f"{msg}")

ip = socket.gethostbyname(socket.gethostname())
port = 4000;
print(f"ip: ws://{ip}:{port}/")
server = websockets.serve(response, ip, port)

asyncio.get_event_loop().run_until_complete(server)
print("Server running ...")
asyncio.get_event_loop().run_forever()
