from flask import Flask 
from flask_socketio import SocketIO, send

app = Flask(__name__)
app.config['SECRET_KEY'] = 'qweasd'
socketio = SocketIO(app)

@socketio.on('message')
def handleMessage(msg):
	# print(f'Message: {msg}')
	send(msg, broadcast=True)

if __name__ == '__main__':
	socketio.run(app,port=4001)