import asyncio
import websockets

async def test():
    async with websockets.connect('ws://localhost:4000') as websocket:


        while True:
            mgs = input("message: ")
            await websocket.send(mgs)
            text = await websocket.recv()
            print(f"< {text}")



asyncio.get_event_loop().run_until_complete(test())