import markdown
import os
import sys

# Import the framework
from flask import Flask, g, request
from flask_restful import Resource, Api, reqparse

# Create an instance of Flask
app = Flask(__name__)

# Create the API
api = Api(app)

class Index():
    ids = 125

channels = [
    {
        "id": "abc123",
        "port": 9999,
        "pattern": "bradcast",
        "connected": [{"ip": "0.0.0.0"}]
    },
    {
        "id": "abc124",
        "port": 9998,
        "pattern": "post/subscribe",
        "connected": [{"ip": "1.2.3.4"}]
    }
];

@app.route("/")
def index():
    with open(os.path.dirname(app.root_path) + '/README.md', 'r') as readme:
        return markdown.markdown(readme.read()), 200


class Channel(Resource):
    def get(self, id):
        channel = [x for x in channels if x['id'] == id]
        print(f'Get request /channel/{id}')

        if (channel == []):
            return {'message': 'channel not found', 'data': {}}, 404

        return {'message': 'channel found', 'data': channel[0]}, 200

    def delete(self, id):
        print(f'Delete request /channel/{id}')

        channel = [x for x in channels if x['id'] == id]

        print(channel)

        if (channel == []):
            return {'message': 'channel was not found', 'data': {}}, 200

        channels.remove(channel[0])
        return {'message': 'success! channel found and deleted'}, 200




class Channels(Resource):
    def get(self):
        print(f'Get request /channel')
        return {'message': 'Channel found', 'data': channels}, 200

    def post(self):
        try:

            parser = reqparse.RequestParser()

            parser.add_argument('port', type=int, required=True)
            parser.add_argument('pattern', required=True)

            args = parser.parse_args()
            print(f'Post request /channel args={args}')

            channel = {
                'id': f'abc{Index.ids}',
                'port': args['port'],
                'pattern': args['pattern'],
                'connected': []
            }

            Index.ids = Index.ids + 1

            channels.append(channel)
            return {'message': 'success!', 'data': channel}, 201
        except:
            print('Parsing error!')
            return {'message': 'Bad Request', 'data': {}}, 400



api.add_resource(Channel, '/channel/<string:id>')
api.add_resource(Channels, '/channel')

if __name__ == '__main__':
    app.run(debug=True)


