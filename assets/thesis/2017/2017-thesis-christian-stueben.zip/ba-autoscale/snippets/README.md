# Snippets

Hier sind einige kleinere Code-Schnipsel, die sich bei der Recherche und der Verifikation entwickelt haben. 
