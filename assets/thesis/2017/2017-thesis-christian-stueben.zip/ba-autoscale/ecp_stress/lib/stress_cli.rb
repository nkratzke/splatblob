require 'commander'
require 'yaml'


class Stress_Cli
  include Commander::Methods

  STRESS_DEFAULT='../config/stress.conf'
  STRESS_CONFIG='stress.conf'
  STRESS_LOCATION='/home/stuebenc/stress'

  def read_config(config_file = STRESS_CONFIG)
    file = File.join(Dir.pwd,config_file)
    file = File.join(File.dirname(File.expand_path(__FILE__)), STRESS_DEFAULT) unless File.exist?(file)
    r = ConfigParser.new file
    @config_hash = r.config_hash

    unless @config_hash['general-verbose'].nil?
      @verbose = @config_hash['general-verbose'].to_b
    end

    @config_hash['general-stress-location'].nil? ?
        @stress_location = STRESS_LOCATION :
        @stress_location = @config_hash['general-stress-location']



    Utils::LOG.log_level(@verbose ? Logger::DEBUG : Logger::INFO)

  end

  def run
    program :version, '0.0.1'
    program :description, 'ecp_stress'

    global_option('-c', '--config FILE', 'Load config file for monitor configuration') do |file|
      read_config(file)
    end

    command :start do |c|
      c.syntax = 'ecp_stress start'
      c.option '--cluster-file STRING', String, 'Reads a cluster-file'
      c.option '--credential-file STRING', String, 'ecp_deployer credentials'
      c.option '--schedule-file STRING', String, 'stress schedule'
      c.summary = 'starts stress on deployed cluster'
      c.description = 'Starts stress schedule defined by json.'
      c.example 'example:', 'ecp_deploy start --cluster-file test.yml --credential-file creds.json'

      c.action do |args, options|

        raise IOError.new('No cluster file given') if options.cluster_file.nil?
        raise IOError.new('No schedule file given') if options.schedule_file.nil?

        read_config if @config_hash.nil?

        cluster = YAML::load(File.open(options.cluster_file))
        credentials = options.credential_file

        sched = Scheduler.new(cluster,credentials)
        sched.config_hash = @config_hash
        #sched.stress_location = STRESS_LOCATION

        sched.start(options.schedule_file)

      end
    end
    command :debug do |c|
      c.syntax = 'ecp_stress debug'
      c.option '--cluster-file STRING', String, 'Reads a cluster-file'
      c.option '--credential-file STRING', String, 'ecp_deployer credentials'
      c.option '--schedule-file STRING', String, 'stress schedule'
      c.summary = 'debugs stress on deployed cluster'
      c.description = 'Debugs stress schedule defined by json.'
      c.example 'example:', 'ecp_deploy debug --cluster-file test.yml --credential-file creds.json'

      c.action do |args, options|

        raise IOError.new('No cluster file given') if options.cluster_file.nil?
        raise IOError.new('No schedule file given') if options.schedule_file.nil?

        read_config if @config_hash.nil?

        cluster = YAML::load(File.open(options.cluster_file))
        credentials = options.credential_file

        sched = Scheduler.new(cluster,credentials)
        sched.config_hash = @config_hash
        #sched.stress_location = STRESS_LOCATION

        #sched.start(options.schedule_file)

        sched.debug
      end
    end
    run!
  end
end