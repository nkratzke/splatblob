/**
 * Created by schazahdah mokhlis on 02.05.17.
 */


// constants which describe the content of the mapArray
const WALKABLE_AREA = 1;
const OBSTACLE = 3;
const START_POSITION = 4;
const ITEM = 6;
const NEW_ITEM = 6.5;
const CHECKABLE_FIELD = 7;

var bot = new Bot();
var game = new Game();
var view = new View(bot,game);
var controller = new Controller(bot,game);

/*
 levelNow is the level at the moment
 levelMax is the last level
 maxLoops is the limit of loops, which a player can chose
 */
var levelNow = 0;
var levelMax = 30;
var maxLoops = 5;

// eventListeners for the clickable action-elements
var moveEl = document.getElementById("move");
moveEl.addEventListener("click", controller.moveAction);

var turnLeftEl = document.getElementById("turnLeft");
turnLeftEl.addEventListener("click", controller.turnLeftAction);

var turnRightEl = document.getElementById("turnRight");
turnRightEl.addEventListener("click", controller.turnRightAction);

var collectEl = document.getElementById("collectItem");
collectEl.addEventListener("click", controller.collectItemAction);

var checkFieldEl = document.getElementById("checkField");
checkFieldEl.addEventListener("click", controller.checkFieldAction);

var collectNewElementEl = document.getElementById("collectNewItem");
collectNewElementEl.addEventListener("click", controller.collectNewItem);

var moveTillObstacleEl = document.getElementById("moveTillObstacle");
moveTillObstacleEl.addEventListener("click", controller.moveTillObstacleAction);

var procedureEl = document.getElementById("proc");
procedureEl.addEventListener("click", controller.procedureAction);

var deleteEl = document.getElementById("delete");
deleteEl.addEventListener("click", controller.deleteActions);

// eventListeners for the "+" and "-" signs of the loopCounter
var minusEl = document.getElementById("minusIcon");
minusEl.addEventListener("click", loopDecrement);

var plusEl = document.getElementById("plusIcon");
plusEl.addEventListener("click", loopIncrement);

// loads the level from the JSON-file and calls the view to update the new status of the game
function levelLoader() {
    if (levelNow <= levelMax) {
        $.getJSON("levels/lvl" + levelNow + ".json", function (json) {
            var data = json;
            bot.actions = [];
            game.mapArray = data.mapArray;
            game.maxActions = data.maxActions;
            game.maxProcActions = data.maxProcActions;
            game.neededItems = data.neededItems;
            game.lvlUp = false;
            game.loopCounter = 1;
            game.showLoopInfo = data.showLoopInfo;
            game.showCheckField = data.showCheckField;
            game.showMoveTillObstacle = data.showMoveTillObstacle;
            game.showProc = data.showProc;
            game.mainTab = true;
            view.updateElements();
            bot.createBot(data.playerYpos, data.playerXpos, data.playerFaceDir, data.mapArray);
            view.update(data.mapArray);
            view.updateInfo();
            view.showMain();
            view.showGame();
        });
    }
}

levelLoader();

// checks every 500 ms if a level is done to call the levelLoader with the next level
function gameLoop() {
    setInterval(function () {
        if (game.lvl === game.nextLevel && game.lvlUp === false && game.neededItems === 0) {
            game.lvlUp = true;
            game.nextLevel++;
            levelNow++;
            levelLoader();
        }
    }, 500);
}

gameLoop();