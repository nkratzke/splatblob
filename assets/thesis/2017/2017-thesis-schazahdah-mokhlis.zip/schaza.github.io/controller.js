/**
 * Created by schazahdah mokhlis on 02.05.17.
 */


function Controller(bot, game) {
    /*
     reads the actionsContainer and adds the chosen-actions into the actions-array of the bot
     after it the view is called to update the game
     */
    this.readActionsContainer = function () {
        var tempYpos = bot.yPos;
        var tempXpos = bot.xPos;
        var lastAction = -1;
        var tempMap = [];

        // creates a temporary copy of the mapArray
        for (var i = 0; i < game.mapArray.length; i++) {
            tempMap[i] = game.mapArray[i].slice();
        }

        this.actionLoops();
        for (var j = 0; j < document.getElementById("actionsContainer").children.length; j++) {
            if (document.getElementById("actionsContainer").children[j].id === "move") {
                if (bot.tempFaceDir === "left") {
                    bot.actions.push(0);
                    tempXpos--;
                } else if (bot.tempFaceDir === "right") {
                    bot.actions.push(1);
                    tempXpos++;
                } else if (bot.tempFaceDir === "up") {
                    bot.actions.push(2);
                    tempYpos--;
                } else if (bot.tempFaceDir === "down") {
                    bot.actions.push(3);
                    tempYpos++;
                }
            } else if (document.getElementById("actionsContainer").children[j].id === "turnLeft") {
                if (bot.tempFaceDir === "left") {
                    bot.tempFaceDir = "down";
                } else if (bot.tempFaceDir === "down") {
                    bot.tempFaceDir = "right";
                } else if (bot.tempFaceDir === "right") {
                    bot.tempFaceDir = "up";
                } else if (bot.tempFaceDir === "up") {
                    bot.tempFaceDir = "left";
                }
                bot.actions.push(4);
            } else if (document.getElementById("actionsContainer").children[j].id === "turnRight") {
                if (bot.tempFaceDir === "left") {
                    bot.tempFaceDir = "up";
                } else if (bot.tempFaceDir === "down") {
                    bot.tempFaceDir = "left";
                } else if (bot.tempFaceDir === "right") {
                    bot.tempFaceDir = "down";
                } else if (bot.tempFaceDir === "up") {
                    bot.tempFaceDir = "right";
                }
                bot.actions.push(5);
            } else if (document.getElementById("actionsContainer").children[j].id === "collectItem") {
                bot.actions.push(6);
                tempMap[tempYpos][tempXpos] = WALKABLE_AREA;
            } else if (document.getElementById("actionsContainer").children[j].id === "checkField") {
                bot.actions.push(7);
            } else if (document.getElementById("actionsContainer").children[j].id === "collectNewItem") {
                bot.actions.push(8);
                tempMap[tempYpos][tempXpos] = WALKABLE_AREA;
            } else if (document.getElementById("actionsContainer").children[j].id === "moveTillObstacle") {

                //a move action is added into the actions-array, while the bot can move forward
                while (tempMap[tempYpos][tempXpos] === START_POSITION || tempMap[tempYpos][tempXpos] === WALKABLE_AREA) {
                    if (bot.tempFaceDir === "left") {
                        bot.actions.push(0);
                        tempXpos--;
                        lastAction = 0;
                    } else if (bot.tempFaceDir === "right") {
                        bot.actions.push(1);
                        tempXpos++;
                        lastAction = 1;
                    } else if (bot.tempFaceDir === "up") {
                        bot.actions.push(2);
                        tempYpos--;
                        lastAction = 2;
                    } else if (bot.tempFaceDir === "down") {
                        bot.actions.push(3);
                        tempYpos++;
                        lastAction = 3;
                    }
                }

                //if the next position of the bot would be an obstacle, the next move action is canceled and the bot stays on the current position
                if (tempMap[tempYpos][tempXpos] === OBSTACLE) {
                    switch (lastAction) {
                        case 0:
                            tempXpos++;
                            break;
                        case 1:
                            tempXpos--;
                            break;
                        case 2:
                            tempYpos++;
                            break;
                        case 3:
                            tempYpos--;
                            break;
                        default:
                            break;
                    }
                    bot.actions.pop();
                    lastAction = -1;
                }

                // creates a procedure and adds it in the actionsContainer at the index of the "proc1" element
            } else if (document.getElementById("actionsContainer").children[j].id === "proc1") {
                // creates a temporary procedure for every procedure which is added to the actionsContainer
                var tempProc = document.createElement("A");
                tempProc.id = "tempProc";

                var proc1 = document.getElementById("proc1");
                proc1.replaceWith(tempProc);

                // adds the elements of the procedureContainer to the temporary procedure
                var length = document.getElementById("procedureContainer").children.length;
                if(length > 0) {
                    var elem = document.createElement("A");
                    elem.id = document.getElementById("procedureContainer").children[0].id;
                    document.getElementById("tempProc").appendChild(elem);
                }
                for (var k = 0; k < length; k++) {
                    var newElem = document.createElement("A");
                    newElem.id = document.getElementById("procedureContainer").children[k].id;
                    document.getElementById("tempProc").appendChild(newElem);
                }

                // replaces the temporary procedure with it's children (the actions)
                var element = document.getElementById("tempProc");
                var fragment = document.createDocumentFragment();
                while(element.firstChild) {
                    fragment.appendChild(element.firstChild);
                }
                element.parentNode.replaceChild(fragment, element);
            }
        }

        bot.actions.push(9);
        view.updateBot();
        this.deleteActions();
    };

    //tells the view to create an element in the actionsContainer with the id "move"
    this.moveAction = function () {
        view.updateAction("move", "geradeaus gehen");
    };

    //tells the view to create an element in the actionsContainer with the id "turnLeft"
    this.turnLeftAction = function () {
        view.updateAction("turnLeft", "nach links drehen");
    };

    //tells the view to create an element in the actionsContainer with the id "turnRight"
    this.turnRightAction = function () {
        view.updateAction("turnRight", "nach rechts drehen");
    };

    //tells the view to create an element in the actionsContainer with the id "collectItem"
    this.collectItemAction = function () {
        view.updateAction("collectItem", "Apfel aufheben");
    };

    //tells the view to create an element in the actionsContainer with the id "checkField"
    this.checkFieldAction = function () {
        view.updateAction("checkField", "Feld überprüfen");
    };

    //tells the view to create an element in the actionsContainer with the id "collectNewItem"
    this.collectNewItem = function () {
        view.updateAction("collectNewItem", "neue Frucht aufheben");
    };

    //tells the view to create an element in the actionsContainer with the id "moveTillObstacle"
    this.moveTillObstacleAction = function () {
        view.updateAction("moveTillObstacle", "bis zum nächsten Hindernis gehen");
    };

    //tells the view to create an element in the actionsContainer with the id "proc1"
    this.procedureAction = function () {
        view.updateAction("proc1", "deine Prozedur");
    };

    /*
     goes through the actionsContainer and creates for every loopThroug a new element with the same id at the end
     of the actionsContainer
     */
    this.actionLoops = function () {
        var loopTroughs = game.loopCounter - 1;
        var length = document.getElementById("actionsContainer").children.length * loopTroughs;
        for (var i = 0; i < length; i++) {
            var newElem = document.createElement("A");
            newElem.id = document.getElementById("actionsContainer").children[i].id;
            document.getElementById("actionsContainer").appendChild(newElem);
        }
    };

    //deletes all chosen-Actions from the actionsContainer
    this.deleteActions = function () {
        var mainTab = document.getElementById("actionsContainer");
        var procTab = document.getElementById("procedureContainer");
        while (mainTab.firstChild) {
            mainTab.removeChild(mainTab.firstChild);
        }
        while (procTab.firstChild) {
            procTab.removeChild(procTab.firstChild);
        }
    };
}