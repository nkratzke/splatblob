/**
 * Created by schazahdah mokhlis on 11.05.17.
 */


/*
 mapArray -> the map of the game (2D Array filled with values of each cell in the table)
 maxActions -> number of maximum actions a player can choose (in the level)
 maxProcActions -> number of maximum actions a player can choose (in the level) for the procedure
 neededItems -> number of items, which a player needs to pass the level
 lvl -> the level of the game
 nextLevel -> nextLevel of the game
 lvlUp -> boolean with the information, if a level is done
 loopCounter -> number of the loops
 showLoopInfo -> boolean, which checks if the information about the loop should be shown in a level
 showCheckField -> boolean, which checks if the checkField-action should be shown in a level
 showMoveTillObstacle -> boolean, whick checks if the moveTillObstacle-action should be shown in a level
 showProc -> boolean, which checks if the procedure should be shown in a level
 */
function Game() {
    this.mapArray = [];
    this.maxActions = undefined;
    this.maxProcActions = undefined;
    this.neededItems = undefined;
    this.lvl = 0;
    this.nextLevel = 1;
    this.lvlUp = false;
    this.loopCounter = undefined;
    this.showLoopInfo = false;
    this.showCheckField = false;
    this.showMoveTillObstacle = false;
    this.showProc = undefined;
    this.mainTab = true;
}

/*
 xPos -> the position of the bot on the X-Axis
 yPos -> the position of the bot on the Y-Axis
 actions -> the array which contains all the chosen-actions
 usedAction -> the action, which is used by the bot at the moment
 destinationX -> destination of the bot on the X-Axis
 destinationY -> destination of the bot on the Y-Axis
 faceDirection -> the face-direction of the bot
 tempFaceDir -> the temporary face-direction of the bot
 */
function Bot() {
    this.xPos = undefined;
    this.yPos = undefined;
    this.usedAction = undefined;
    this.actions = [];
    this.destinationX = undefined;
    this.destinationY = undefined;
    this.faceDirection = undefined;
    this.tempFaceDir = undefined;

    // creates the bot in the map at the start-position
    this.createBot = function (yPos, xPos, faceDir, mapArray) {
        if (xPos < 0 || xPos > mapArray.length - 1) return;
        if (yPos < 0 || yPos > mapArray.length - 1) return;
        this.faceDirection = faceDir;
        this.tempFaceDir = faceDir;
        this.xPos = xPos;
        this.yPos = yPos;
        mapArray[yPos][xPos] = START_POSITION;
    };

    // calls the actions
    this.callAction = function (actionNr) {
        var x = this.xPos;
        var y = this.yPos;

        switch (actionNr) {
            case 0:                     //moveLeft
                x--;
                break;
            case 1:                     //moveRight
                x++;
                break;
            case 2:                     //moveUp
                y--;
                break;
            case 3:                     //moveDown
                y++;
                break;
            case 4:
                this.turnLeft();
                break;
            case 5:
                this.turnRight();
                break;
            case 6:
                this.collectItem();
                break;
            case 7:
                this.checkField();
                break;
            case 8:
                this.collectNewItem();
                break;
            case 9:
                this.checkMove();
                break;
            default:
                break;
        }

        this.destinationX = x;
        this.destinationY = y;
    };

    // turns the bot to the left depending on the former faceDirection
    this.turnLeft = function () {
        if (this.faceDirection === "left") {
            this.faceDirection = "down";
        } else if (this.faceDirection === "down") {
            this.faceDirection = "right";
        } else if (this.faceDirection === "right") {
            this.faceDirection = "up";
        } else if (this.faceDirection === "up") {
            this.faceDirection = "left";
        }
    };

    // turns the bot to the right depending on the former faceDirection
    this.turnRight = function () {
        if (this.faceDirection === "left") {
            this.faceDirection = "up";
        } else if (this.faceDirection === "down") {
            this.faceDirection = "left";
        } else if (this.faceDirection === "right") {
            this.faceDirection = "down";
        } else if (this.faceDirection === "up") {
            this.faceDirection = "right";
        }
    };

    // collects the collectible item and decrements the counter of collectedItems
    this.collectItem = function () {
        if (game.mapArray[this.yPos][this.xPos] === ITEM) {
            game.mapArray[this.yPos][this.xPos] = WALKABLE_AREA;
            this.usedAction = 1;
            game.neededItems--;
        }
    };

    // checks the field for the new collectible item
    this.checkField = function () {
        if (game.mapArray[this.yPos][this.xPos] === CHECKABLE_FIELD) {
            game.mapArray[this.yPos][this.xPos] = NEW_ITEM;
            this.usedAction = 3;
        }
    };

    // collects the new item and decrements the counter of collectedItems
    this.collectNewItem = function () {
        if (game.mapArray[this.yPos][this.xPos] === NEW_ITEM) {
            game.mapArray[this.yPos][this.xPos] = WALKABLE_AREA;
            this.usedAction = 2;
            game.neededItems--;
        }
    };

    // checks if the bot has moved
    this.checkMove = function () {
        if(!(game.mapArray[this.yPos][this.xPos] === START_POSITION) || this.usedAction === 0){
            alert("Deine Befehle haben leider nicht ausgereicht. \n Versuch es noch einmal!");
            levelLoader();
        }
    };
}