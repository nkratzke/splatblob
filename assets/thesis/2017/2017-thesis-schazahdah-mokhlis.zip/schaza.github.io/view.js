/**
 * Created by schazahdah mokhlis on 11.05.17.
 */

// classes of the cells, which are needed for the background-image of the cell
var cellClasses = ["decorationBackground", "walkableArea", "start", "finish", "obstacle", "fruitField"];

//images and class of the obstacles
var obstacleImages = ["pictures/mountain.png", "pictures/bush.png"];
var obstacleClass = ["obstacle0", "obstacle1"];

//images and ids of the collectible Items
var collectibleItemImg = ["pictures/apple.png", "pictures/banana.png", "pictures/orange.png", "pictures/pear.png", "pictures/strawberry.png", "pictures/watermelon.png"];
var collectibleItemId = "collectible";

//images and the id of the bot (from left to down)
var botImages = ["pictures/farmerLeft.png", "pictures/farmerUp.png", "pictures/farmerRight.png", "pictures/farmerDown.png"];
var botId = "player";

/*
 0 = decoration
 1 = walkable area
 2 = obstacle 1
 3 = obstacle 2
 4 = bot
 5 = finish
 6 = collectible item
 7 = checkable fruitfield
 */
function View(bot, game) {
    var table = document.createElement("table");
    table.id = "map";
    var tbody = document.createElement("tbody");
    tbody.id = "tbody";
    table.appendChild(tbody);

    //creates and updates the table (map of the game)
    this.update = function (mapArr) {
        $("#tbody").empty();
        mapArr.forEach(function (subArr, rowIndex) {
            var row = document.createElement("tr");
            tbody.appendChild(row);
            subArr.forEach(function (number, colIndex) {
                var cell = document.createElement("td");
                row.appendChild(cell);
                cell.className = number;
                cell.id = "cell" + colIndex + rowIndex;
                if (number === 0) {
                    cell.className = cellClasses[0];
                } else if (number === 1) {
                    cell.className = cellClasses[1];
                } else if (number === 2) {
                    cell.className = cellClasses[4];
                    var obstacleImage = document.createElement("img");
                    obstacleImage.src = obstacleImages[0];
                    obstacleImage.className = obstacleClass[0];
                    cell.appendChild(obstacleImage);
                } else if (number === 3) {
                    cell.className = cellClasses[4];
                    var obstacleImg = document.createElement("img");
                    obstacleImg.src = obstacleImages[1];
                    obstacleImg.className = obstacleClass[1];
                    cell.appendChild(obstacleImg);
                }
                else if (number === 4) {
                    cell.className = cellClasses[2];
                    var botImg = document.createElement("img");
                    if (bot.tempFaceDir === "left") {
                        botImg.src = botImages[0];
                    } else if (bot.tempFaceDir === "up") {
                        botImg.src = botImages[1];
                    } else if (bot.tempFaceDir === "right") {
                        botImg.src = botImages[2];
                    } else if (bot.tempFaceDir === "down") {
                        botImg.src = botImages[3];
                    }
                    botImg.id = botId;
                    cell.appendChild(botImg);
                } else if (number === 5) {
                    cell.className = cellClasses[3];
                } else if (number === 6) {
                    cell.className = cellClasses[1];
                    var itemImg = document.createElement("img");
                    itemImg.id = collectibleItemId;
                    itemImg.src = collectibleItemImg[0];
                    cell.appendChild(itemImg);
                } else if (number === 7) {
                    cell.className = cellClasses[5];
                }
            });
        });
        document.getElementById("map").appendChild(table);
    };

    //reads the actions-array and updates the bot every 500 ms until the last action is executed
    this.updateBot = function () {
        var interval = setInterval(function () {
            if (bot.actions.length) {
                bot.callAction(bot.actions.shift());
                if (document.getElementById("cell" + bot.destinationX + bot.destinationY).className === cellClasses[4]) {
                    document.getElementById("cell" + bot.destinationX + bot.destinationY).style.opacity = "0.5";
                    setTimeout(function () {
                        document.getElementById("cell" + bot.destinationX + bot.destinationY).style.opacity = "1";
                    }, 1000);
                    bot.actions = [];
                    alert("Du bist gegen ein Hindernis gestoßen! \n Versuch es noch einmal!");
                    setTimeout(levelLoader, 1000);
                } else {
                    bot.xPos = bot.destinationX;
                    bot.yPos = bot.destinationY;
                    document.getElementById("cell" + bot.destinationX + bot.destinationY).appendChild(document.getElementById(botId));
                    setTimeout(view.checkFinish, 200);
                }
                view.updatePic();
                view.updateField();
                view.updateInfo();
            }
            else {
                clearInterval(interval);
            }
        }, 500);
    };

    //updates the field, on which the bot has used an action (for example collect item -> the item is removed from the field)
    this.updateField = function () {
        var botId = $("#player");
        if (botId.parent().attr("class") !== cellClasses[2] && (bot.usedAction === 1 || bot.usedAction === 2 )) {
            if (document.getElementById("cell" + bot.destinationX + bot.destinationY).firstElementChild.id === collectibleItemId) {
                var list = document.getElementById("cell" + bot.destinationX + bot.destinationY);
                list.removeChild(list.firstChild);
            }
        } else if (botId.parent().attr("class") === "fruitField" && bot.usedAction === 3) {
            botId.parent().attr("class", "walkableArea");
            var fruitImg = document.createElement("img");
            fruitImg.id = collectibleItemId;
            var randomNum = Math.floor((Math.random() * (collectibleItemImg.length - 1)) + 1);
            fruitImg.src = collectibleItemImg[randomNum];
            botId.parent().append(fruitImg);
        }
        bot.usedAction = 0;
    };

    // updates the picture of the bot depending on the faceDirection
    this.updatePic = function () {
        var playerImg = document.getElementById("player");
        if (bot.faceDirection === "left") {
            playerImg.src = botImages[0];
        } else if (bot.faceDirection === "up") {
            playerImg.src = botImages[1];
        } else if (bot.faceDirection === "right") {
            playerImg.src = botImages[2];
        } else if (bot.faceDirection === "down") {
            playerImg.src = botImages[3];
        }
    };

    // updates the information of the collectedItems and the loopCounter
    this.updateInfo = function () {
        document.getElementById("itemCounter").innerHTML = game.neededItems;
        document.getElementById("loopCounter").innerHTML = game.loopCounter;
    };

    // updates the visibility of the elements
    this.updateElements = function () {
        var loopInfo = document.getElementById("loopInfo");
        if (game.showLoopInfo === false) {
            loopInfo.style.visibility = "hidden";
        } else {
            loopInfo.style.visibility = "initial";
        }

        var checkField = document.getElementById("checkField");
        var collectNewItem = document.getElementById("collectNewItem");
        if (game.showCheckField === false) {
            checkField.style.display = "none";
            collectNewItem.style.display = "none";
        } else {
            checkField.style.display = "inline-block";
            collectNewItem.style.display = "inline-block";
        }

        var moveTillObstacle = document.getElementById("moveTillObstacle");
        if (game.showMoveTillObstacle === false) {
            moveTillObstacle.style.display = "none";
        } else {
            moveTillObstacle.style.display = "inline-block";
        }

        var proc = document.getElementById("proc");
        var procButton = document.getElementById("procButton");
        if (game.showProc === false && game.mainTab === true) {
            procButton.style.display = "none";
            proc.style.display = "none";
        } else if (game.showProc === true && game.mainTab === false) {
            procButton.style.display = "inline-block";
            proc.style.display = "none";
        } else {
            procButton.style.display = "inline-block";
            proc.style.display = "inline-block";
        }
    };

    //updates and adds the chosen actions to the Containers
    this.updateAction = function (id, text) {
        var tab = "";
        var actionsLength = 0;
        if (game.mainTab === true) {
            tab = "actionsContainer";
            actionsLength = game.maxActions;
        } else {
            tab = "procedureContainer";
            actionsLength = game.maxProcActions;
        }
        if (document.getElementById(tab).children.length < actionsLength) {
            var elem = document.createElement("A");
            elem.id = id;
            document.getElementById(tab).appendChild(elem);
            document.getElementById("app_status").innerHTML = "Du hast (" + text + ") hinzugefügt."
        }
    };

    // checks if the bot is done with the level and alerts a message
    this.checkFinish = function () {
        if ($("#player").parent().attr("class") === cellClasses[3] && game.neededItems === 0) {
            alert("Glückwunsch, du hast " + "Level " + (levelNow + 1) + " erfolgreich abgeschlossen.");
            bot.actions = [];
            game.lvl++;
        }
    };


    //displays the game in the view
    this.showGame = function () {
        document.getElementById("tutorial").style.display = "none";
        document.getElementById("level").style.display = "initial";
    };

    //displays the tutorial in the view
    this.showTutorial = function () {
        document.getElementById("level").style.display = "none";
        document.getElementById("tutorial").style.display = "initial";
    };

    //shows the mainTab
    this.showMain = function () {
        document.getElementById("procedureContainer").style.display = "none";
        document.getElementById("actionsContainer").style.display = "initial";
        game.mainTab = true;
        document.getElementById("mainButton").className = "w3-button w3-blue w3-small w3-opacity";
        document.getElementById("procButton").className = "w3-button w3-grey w3-small w3-opacity";
        view.updateElements();
    };

    //shows the procedureTab
    this.showProcedure = function () {
        document.getElementById("actionsContainer").style.display = "none";
        document.getElementById("procedureContainer").style.display = "initial";
        game.mainTab = false;
        document.getElementById("procButton").className = "w3-button w3-blue w3-small w3-opacity";
        document.getElementById("mainButton").className = "w3-button w3-grey w3-small w3-opacity";
        view.updateElements();
    }
}

// decrements the the loopCounter
function loopDecrement() {
    if (game.loopCounter > 1) {
        game.loopCounter--;
    }
    document.getElementById("loopCounter").innerHTML = game.loopCounter;
}

// increments the loopCounter
function loopIncrement() {
    if (game.loopCounter < maxLoops) {
        game.loopCounter++;
    }
    document.getElementById("loopCounter").innerHTML = game.loopCounter;
}