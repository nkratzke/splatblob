

# Unshift so that local files load instead of something in gems
$LOAD_PATH.unshift File.dirname(__FILE__) + '/../lib'





