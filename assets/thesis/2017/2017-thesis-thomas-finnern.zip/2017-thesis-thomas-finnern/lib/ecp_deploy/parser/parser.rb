#!/usr/bin/env ruby

gem "json", ">= 1.8.3"
require 'json'

require_relative "../cluster/cluster"
require_relative "../cluster/machine"

require_relative "../credentials/credentials.rb"
require_relative "../credentials/OpenStack_credentials.rb"
require_relative "../credentials/AWS_credentials.rb"
require_relative "../credentials/GCE_credentials.rb"


# This class reads given files and parse them to usable objects. 

# Author:: Arne Salveter, Christian-Friedrich Stüben, Thomas Finnern
class Parser

	attr_accessor :inputHash, :inputHashPath, :cluser, :machines, :clusterWasYAML
	attr_accessor :statusFile, :statusHash
	attr_accessor :credentialsFile, :credentialsHash, :credentialObject


	# Create the parser object
  #
  # @param new_cluster_path Path to description file.
	# @param sec_group Path to credential file.
	def initialize(new_cluster_path, credentialsPath)
    @credentials = Array.new
		unless new_cluster_path==''
      @inputHashPath = new_cluster_path
    end
		@credentialsFile = File.read(credentialsPath)
		@credentialsHash = JSON.parse(@credentialsFile)
		prepare_multiple_credentials(@credentialsHash)
	end


    def getCluster
      begin
        @clusterWasYAML = false
        new_cluster = readCluster
      rescue JSON::ParserError => e
        begin
          @clusterWasYAML = true
          new_cluster = YAML::load(File.open(@inputHashPath))
        rescue Exception => e
          Cli::LOG.fatal(self) { "The given json/yaml is not well formed." }
          Cli::LOG.fatal(self) { "Error reading cluster-description: #{e.message}" }
          exit(false)
       end
      end
      Cli::LOG.debug(self) { "Is given object a valid instance of \"Cluster\": #{new_cluster.instance_of? Cluster}" }
      return new_cluster
    end


	# Create a cluster from a description file.
	def readCluster
    @inputHash = JSON.parse(File.read(@inputHashPath))

		begin
			clhash = @inputHash["cluster"]
			mahash = @inputHash["master"]
			nodehash = @inputHash["nodes"]
      storagehash = @inputHash["storage"]

      raise IOError.new('Missing cluster description') if clhash.nil?
      raise IOError.new('Missing master description') if mahash.nil?
      raise IOError.new('Missing nodes description') if nodehash.nil?

      cluster = Cluster.new(clhash["name"])
      
      unless storagehash.nil?
        storagehash.each do |hash|
          count = 1
          hash["number"].times do
            cluster.addMachine(Machine.new(hash["provider"],hash["storage_cluster"],hash["image"],hash["flavor"],hash["role"],"#{hash['role']}#{count}"))
            cluster.storage_cluster = hash["storage_cluster"]
            count += 1
          end
        end
      end

      mahash.each do |hash|
        count = 1
        hash["nodes"].times do
          cluster.addMachine(Machine.new(hash["provider"], nil, hash["image"], hash["flavor"], hash["role"],"#{hash['role']}#{count}"))
          count +=1
        end
        cluster.master_count = hash["nodes"]
      end
      nodehash.each do |hash|
        count = 1
        hash["number"].times do
          cluster.addMachine(Machine.new(hash["provider"], nil, hash["image"], hash["flavor"], hash["role"],"#{hash['role']}#{count}"))
          count +=1
        end
      end
      cluster.open_ports=clhash["openports"]
    rescue IOError=>e
      Cli::LOG.fatal(self) { "Error parsing cluster file: #{e.inspect}" }
      exit(false)
    end
    return cluster
  end


  # Prepare credentials parsed from file and create
  # credentials objects
  def prepare_multiple_credentials(credentials_hash)
    hash = credentials_hash['credentials']
    if hash.nil?
      prepareCredential(credentials_hash)
    else
      hash.each do |creds|
        prepareCredential(creds)
      end
    end

    #TODO: Use multiple credentials and remove this
    @credentialObject = @credentials[0]

  end


  # Find credentials for specific provider
  def credentials_by_provider_name(provider_name)
    @credentials.find{ |cred| cred.name == provider_name}
  end

  # Map the credentials from a Hash to the 	internal
  # attributes.
  def prepareCredential(credentials_hash)
    begin
      name = credentials_hash["provider"]
      acchash = credentials_hash["account"]

      raise IOError.new('Cannot find provider') if name.nil?
      raise IOError.new('Cannot find account values') if acchash.nil?

      id = acchash["id"]
      password = acchash["password"]

      if name.downcase == "openstack"
        tenant = acchash["tenant"]
        auth_url = acchash["auth-url"]
        ip_pool = acchash["ip-pool"]
        project_domain = acchash["project-domain"]
        user_domain = acchash["user-domain"]
        network_name = acchash["network-name"]
        network_CIDR = acchash["network-CIDR"]
        volume_name = acchash["volume-name"]
        key_name = acchash["key-name"]

        if id.nil? || id==''
          raise IOError.new('No user id set. Aborting.')
        end

        if password.nil? || password==''
          raise IOError.new('No password set. Aborting.')
        end

        if tenant.nil? || tenant==''
          raise IOError.new('No project set. Aborting.')

        end

        if auth_url.nil? || auth_url==''
          raise IOError.new('No authentication url set. Aborting.')
        end

        if project_domain.nil? || project_domain==''
          Cli::LOG.warn(self) { "No project domain set. Using 'default'." }
          project_domain = 'default'
        end

        if user_domain.nil? || user_domain==''
          Cli::LOG.warn(self) { "No user domain set. Using 'default'." }
          user_domain = 'default'
        end

				if network_name.nil? || network_name==''
					Cli::LOG.warn(self){'No network name set. Will cause error when multiple networks are available.'}
				end

        tmp_creds = OSCredentials.new(name, id, password, tenant, auth_url,ip_pool)#
        tmp_creds.project_domain = project_domain
        tmp_creds.user_domain = user_domain
        tmp_creds.network_name = network_name
        tmp_creds.network_CIDR = network_CIDR
        tmp_creds.key_name = key_name
        tmp_creds.volume_name = volume_name
				Cli::LOG.warn('No key-name set in credentials. You may not be able to use ssh.') if key_name.nil?
        @credentials.push(tmp_creds)

      end
      if name.downcase == 'aws'
        output = acchash["output"]
        Cli::LOG.warn(self) { "No output format set. Using default." } if (output.nil? || output=='')

        region = acchash["region"]
        Cli::LOG.warn(self) { "No region set. Using default." } if (region.nil? || region=='')

        key_pair = acchash["key_pair"]
        Cli::LOG.warn(self) { 'No key-pair set in credentials. You may not be able to use ssh.' } if (key_pair.nil?||key_pair=='')

        volume_name = acchash["volume_name"]
        Cli::LOG.warn(self) {'No volume set. You may not be able to use storage cluster'} if (volume_name.nil? || volume_name=='')
          
        network_CIDR = acchash["network_CIDR"]
        Cli::LOG.warn(self) {'No network CIDR set. You may not be able to use storage cluster'} if (network_CIDR.nil? || network_CIDR=='')

        @credentials.push(AWSCredentials.new(name, id, password, region, output, key_pair,network_CIDR,volume_name))
      end
      if name.downcase == 'gce'
        region = acchash["region"]
        Cli::LOG.warn(self) { "No region set. Using default." } if (region.nil? || region=='')

				image_project = acchash["image_project"]
				Cli::LOG.warn(self) { "No image_project set. Using default." } if (image_project.nil? || image_project=='')

        key_pair = acchash["key_pair"]
        Cli::LOG.warn(self) { 'No key-pair set in credentials. You may not be able to use ssh.' } if (key_pair.nil?||key_pair=='')

				project_id = id
				service_account =  acchash["service_account"]
				key_file_path  =  acchash["key_file_path"]

        @credentials.push(GCECredentials.new(name, project_id,  service_account, key_file_path, region, key_pair, image_project))
      end
    end
  rescue IOError => e
    Cli::LOG.fatal(self) { "Error reading credentials: #{e.inspect}" }
    exit(false)
  end

end
