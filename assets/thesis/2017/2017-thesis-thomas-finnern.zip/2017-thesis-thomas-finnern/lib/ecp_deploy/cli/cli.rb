#!/usr/bin/env ruby

require_relative '../parser/parser'
require_relative '../analyser/OpenStack_analyser'
require_relative '../analyser/AWS_analyser'
require_relative '../analyser/GCE_analyser'

require_relative '../provider/OpenStack_provider'
require_relative '../provider/AWS_provider'
require_relative '../provider/GCE_provider'
require_relative '../cluster/cluster'
require_relative '../cluster/machine'
require_relative '../log/multi_logger'

gem 'commander', '>= 4.4.0'
require 'commander'
require 'logger'
require 'timeout'

class ConfigReader

  attr_accessor :config_hash

  def initialize(config_file)
    @config_hash = Hash.new
    _file = File.join(File.dirname(File.expand_path(__FILE__)), config_file)
    parse_config_path _file
  end

  # recursive search for config files
  def parse_config_path(_path)
    if File.directory?(_path)
      Dir.foreach(_path) do |file|
        parse_config_path("#{_path}/#{file}") unless (file.to_s == '.' or file.to_s == '..')
      end
    else
      parse_config(_path)
    end
  end

  # parse config file into config hash
  def parse_config(_file)
    if _file.to_s.end_with?('.conf')
      Cli::LOG.debug(self){"Found config file: #{_file}"}
      _file = File.read _file
      prefix = ''
      _file.each_line do |line|
        _line=line.chomp
        if _line[0] == '['
          prefix = _line
        else
          @config_hash[prefix + _line.split('=')[0]] = _line.split('=')[1] unless _line[0]=='#'
        end
      end
    end
  end
end

class Cli
  include Commander::Methods

  # Configure Log constants
  @log_file ='deployer.log'
  @verbose = false

  LOG=MultiLogger.new

  def initialize
    _cr = ConfigReader.new '../../../config'
    @verbose = _cr.config_hash['verbose'].to_boolean unless _cr.config_hash['verbose'].nil?
    @log_file = _cr.config_hash['deployer_log_file'] unless _cr.config_hash['deployer_log_file'].nil?
    #puts _cr.config_hash
  end


  def getCluster(path)
    begin
      cluster = YAML::load(File.open(path))
      puts cluster
      rescue Psych::SyntaxError => e
        puts e.message
    end
    return cluster
  end


  # Setup Info/Debug Log
  def inputhelper(options)
    _stdout_log = Logger.new($stdout)
    _file_log = Logger.new(@log_file)

    if options.verbose or @verbose
      _stdout_log.level = Logger::DEBUG
      _file_log.level = Logger::DEBUG
    else
      _stdout_log.level = Logger::INFO
      _file_log.level = Logger::INFO
    end

    Cli::LOG.addlogger(_file_log)
    Cli::LOG.addlogger(_stdout_log)
  end


  def self.user_input_helper(question, timeout)
    begin
      if timeout.nil?
        Cli::LOG.debug(self) { 'Timeout was nil' }
        timeout = 0.001 # if 0, then wait endless
      end
      Cli::LOG.debug(self) { "parameters are: #{question} an #{timeout}" }
      Cli::LOG.info(question)
      userinput = ''
      Timeout::timeout(timeout) do
        userinput = $stdin.readline
        Cli::LOG.debug(self) { "Input was: #{userinput}" }
        userinput
      end
    rescue Timeout::Error => e
      Cli::LOG.debug(self) { "Timeout Exception: #{e.inspect}" }
      nil
    end
  end


  def create_provider(main_provider, reader)
    provider = nil
    if main_provider.downcase == 'openstack'
      provider = OpenStack.new(reader.credentialObject)
    end
    if main_provider.downcase == 'aws'
      provider = AwsProvider.new(reader.credentialObject)
    end
    if main_provider.downcase == 'gce'
      provider = GceProvider.new(reader.credentialObject)
    end
    Cli::LOG.debug(self) { "Using provider: #{provider.to_s}" }
    provider
  end


  def create_analyser(main_provider, reader)
    analyser = nil
    if main_provider.downcase == 'openstack'
      analyser = OSanalyser.new(reader.credentialObject)
    end
    if main_provider.downcase == 'aws'
      analyser = AWSanalyser.new(reader.credentialObject)
    end
    if main_provider.downcase == 'gce'
      analyser = GCEanalyser.new(reader.credentialObject)
    end
    Cli::LOG.debug(self) { "Using analyser: #{analyser.to_s}" }
    analyser
  end

  def run
    program :version, '0.0.1'
    program :description, 'ecp_deploy'

    begin
      command :create do |c|
        global_option '--verbose'
        c.syntax = 'ecp_deploy create <credentials.json> <inputFile.json> <statusFile.yaml>'
        c.summary = 'creates cluster'
        c.description = 'Creates the cluster described in inputfile and saves it to statusfile'
        c.example 'example:', 'ecp_deploy create data/credentials.json data/simpleCluster.json data/cluster/mycluster.yaml'
        c.action do |args, options|

          raise IOError.new('Missing credential file') if args[0].nil?
          raise IOError.new('Missing input file') if args[1].nil?
          raise IOError.new('Missing status file') if args[2].nil?

          credential_file=args[0]
          new_cluster_json=args[1]
          current_cluster_yaml=args[2]

          inputhelper(options)

          parser = Parser.new(new_cluster_json, credential_file)
          cluster = parser.readCluster
          puts "Is a cluster: #{cluster.instance_of? Cluster}"
          provider = create_provider(cluster.getmaster.provider, parser)

          if provider == nil
            Cli::LOG.fatal(self) { "Unknown provider: #{cluster.getmaster.provider}" }
            exit(false)
          else
            provider.createCluster(cluster, current_cluster_yaml)
          end
          provider.readyCheck(cluster)
					provider.lastOrder()
        end
      end

      command :check do |c|
        global_option '--verbose'
        c.syntax = 'ecp_deploy check <credentials.json> <statusFile.yaml>'
        c.summary = 'checks if cluster is running'
        c.description = 'Checks if all servers of the cluster are up and running'
        c.example 'example:', 'ecp_deploy check data/credentials.json data/cluster/mycluster.yaml'
        c.action do |args, options|

          raise IOError.new('Missing credential file') if args[0].nil?
          raise IOError.new('Missing status file') if args[1].nil?

          credential_file=args[0]
          current_cluster_yaml=args[1]
          inputhelper(options)

          parser = Parser.new("", credential_file)
          cluster=YAML::load(File.open(current_cluster_yaml))
          analyser = create_analyser(cluster.getmaster.provider, parser)
          if analyser == nil
            Cli::LOG.fatal(self) { "Unknown provider: #{cluster.getmaster.provider}" }
            exit(false)
          else
            analyser.checkstatus(cluster)
          end
					provider.lastOrder()
        end
      end

      command :update do |c|
        c.syntax = 'ecp_deploy update <credentials.json> <inputFile.json> <statusFile.yaml>'
        c.summary = 'updates cluster'
        c.description = 'Calculates differences of inputfile and statusfile and modifies cluster accordingly'
        c.example 'example:', 'ecp_deploy update data/credentials.json data/simpleCluster.json data/cluster/mycluster.yaml'
        c.action do |args, options|

          raise IOError.new('Missing credential file') if args[0].nil?
          raise IOError.new('Missing input file') if args[1].nil?
          raise IOError.new('Missing status file') if args[2].nil?

          credential_file=args[0]
          new_cluster_path=args[1]
          current_cluster_path=args[2]
          inputhelper(options)

          Cli::LOG.info("Starting cluster update")
          parser = Parser.new(new_cluster_path, credential_file)
          current_cluster = YAML::load(File.open(current_cluster_path))
          new_cluster = parser.getCluster
          analyser = create_analyser(new_cluster.getmaster.provider, parser)
          provider = create_provider(new_cluster.getmaster.provider, parser)

          if analyser != nil && provider != nil
            analyser.registerprovider(provider)

            if parser.clusterWasYAML
              cluster = analyser.compareYAML(current_cluster, new_cluster)
            else
              cluster = analyser.compare(current_cluster, new_cluster)
            end
            provider.savecluster(cluster, current_cluster_path)
          else
            Cli::LOG.fatal(self) { "Unknown provider: #{new_cluster.getmaster.provider}" }
            exit(false)
            provider.readyCheck(cluster)
            provider.lastOrder()
          end
        end
       end


      command :teardown do |c|
        global_option '--verbose'
        c.syntax = 'Cli teardown <credentials.json> <statusFile.yaml>'
        c.summary = 'Shuts down cluster'
        c.description = 'Terminates all servers of the cluster'
        c.example 'example:', 'ecp_deploy teardown data/credentials.json data/cluster/mycluster.yaml'
        c.action do |args, options|

          raise IOError.new('Missing credential file') if args[0].nil?
          raise IOError.new('Missing status file') if args[1].nil?

          credential_file=args[0]
          current_cluster_yaml=args[1]
          inputhelper(options)

          Cli::LOG.info("Shutting down cluster")

          parser = Parser.new("", credential_file)
          current_cluster = YAML::load(File.open(current_cluster_yaml))
          provider = create_provider(current_cluster.getmaster.provider, parser)

          if provider == nil
            Cli::LOG.error(self) { "Unknown provider: #{current_cluster.getmaster.provider}" }
          else
            provider.deletecluster(current_cluster, current_cluster_yaml)
          end
					provider.lastOrder()
        end
      end

      command :debug do |c|
        global_option '--verbose'
        c.action do |args, options|
          inputhelper(options)
          credential_file=args[0]
          parser = Parser.new('',credential_file)
          $stdout.puts parser.credentialObject
          #$stdout.puts(Cli::user_input_helper('Bitte innerhalb von 5 Sekunden eine Eingabe tätigen!', 5))
          # Debug command for testing only
        end
      end
    rescue IOError => e
      Cli::LOG.fatal(self) { "Input error: #{e.inspect}" }
    end

    run!
  end
end
