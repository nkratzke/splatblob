require 'securerandom'

# Basic class that holds the data for a kubernetes cluster
#

# Author:: Arne Salveter, Christian-Friedrich Stüben

class Cluster
  attr_accessor :name, :machines, :public_ipv4, :storage_cluster, :storage_cluster_network, :keypair, :secgrp_name, :open_ports
  attr_accessor :ssl_path, :ca_pem, :ca_key, :adm_pem, :adm_key, :volume_name, :master_count

  # Constructor needs a name for this cluster
  # @param A nameto describe the cluster.
  def initialize(name)
    @name = name
    @public_ipv4=''
    @storage_cluster=nil
    @storage_cluster_network=''
    @volume_name=''
    @keypair=''
    @machines = Array.new
    @secgrp_name = ''
	end

	def self.getInstanceID
		SecureRandom::hex(5)
	end


  # Adds a machine to the cluster
  # @param machine Add this machine to this cluster.
  def addMachine(machine)
    @machines.push(machine)
  end

  # Human readable status string
  def to_s
    "#{@name}@#{@public_ipv4} \n" + @machines.to_s.gsub(',', "\n")
  end

  def getmaster
    @machines.find { |m| m.role.downcase =="master" }
  end

  # Removes a machine from cluster using machine-object or a machine-uid
  def rmmachine(var)
    if var.kind_of? Machine
      @machines.delete(var)
    else
      @machines.delete_if { |m| m.uid==var }
    end
  end

  def rmAllMachine()
    @machines.clear
  end


end
