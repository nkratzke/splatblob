#!/usr/bin/env ruby

require_relative '../credentials/credentials.rb'
require_relative '../parser/parser.rb'

gem 'json', '>= 1.8.3'
require 'json'

gem 'hashdiff', '>= 0.0.6'
require 'hashdiff'

# Basic analyer class that mainly compare two cluster objects.


# Author:: Arne Salveter, Christian-Friedrich Stüben
class Analyser

  attr_accessor :credentials, :notworking, :providers

  def initialize(credentials)
    @credentials = credentials
    @notworking = Array.new
    @providers = Hash.new
  end


  def checkstatus(cluster)

  end


  # Compare two clusters
  #
  # * Generates a differential cluster object
  # * check witch machine ist running or down
  #
  # @param cl_read Cluster form the object file.
  # @param cl_parsed Cluster from parsed json file.
  def compare(cl_read, cl_parsed)
    Cli::LOG.info('Comparing running cluster with new configuration. This may take a while.')
    parsed_machine_num = Hash.new
    read_machine_num = Hash.new

    # create role map for parsed cluster
    cl_parsed.machines.each do |machine|
      parsed_machine_num[machine.role] = (parsed_machine_num[machine.role]) ? parsed_machine_num[machine.role]+1 : 1
    end

    # remove machines in error state
    checkstatus(cl_read).each do |machine|
      cl_read.rmmachine(machine)
      Cli::LOG.info("Removing malfunctioning machine: #{machine}")
    end

    # create role map for parsed cluster
    cl_read.machines.each do |machine|
      read_machine_num[machine.role] = (read_machine_num[machine.role]) ? read_machine_num[machine.role]+1 : 1
    end

    Cli::LOG.info("Current cluster: #{read_machine_num.to_s}")
    Cli::LOG.info("Cluster after update: #{parsed_machine_num.to_s}")

    # Calculate differences
    diff = HashDiff.diff(parsed_machine_num, read_machine_num)

    # Remmove differences
    diff.each do |entry|

      case entry[0]
        when '+'
          # Additional role found, remove all unused machines.
          Cli::LOG.info("Removing unsused role #{entry[1]}")
          tmp = cl_read.machines.select {|m| m.role==entry[1]}
          tmp.each do |machine|
            @providers[machine.provider].deletemachine(machine)
            cl_read.rmmachine(machine)
          end
        when '-'
          Cli::LOG.info("Starting new machines for new role #{entry[1]}")
          # Missing role found, start all machines of this role
          tmp = cl_parsed.machines.select {|m| m.role == entry[1]}
          prov = @providers[tmp[0].provider]
          prov.master_ip = cl_read.public_ipv4
          prov.name = cl_read.name
          prov.set_ca_files(cl_read)


          tmp.each do |machine|
            prov.generateSlaveUserdata(machine.hostname)
            prov.generateSlave(machine, cl_read.secgrp_name)
            cl_read.machines.push(machine)
          end
          prov.deleteuserdata
        when '~'
          Cli::LOG.info("Changing number of machines for role #{entry[1]}")
          # Number of role-machines updated
          if entry[2] > entry[3]
            # Missing machines, starting new ones
            tmp = cl_parsed.machines.select {|m| m.role == entry[1]}
            prov = @providers[tmp[0].provider]
            prov.master_ip = cl_read.public_ipv4
            prov.name = cl_read.name
            prov.set_ca_files(cl_read)



            $i = 0
            while $i<(entry[2]-entry[3]) do
              if entry[1].downcase == 'master'
                prov.updatemaster(tmp[$i], cl_read.secgrp_name)
              else
                prov.generateSlaveUserdata(tmp[$i].hostname)
                prov.generateSlave(tmp[$i], cl_read.secgrp_name)
              end

              cl_read.machines.push(tmp[$i])
              $i +=1
            end
            prov.deleteuserdata
          else
            # Too many machines for this role, remove some
            tmp = cl_read.machines.select {|m| m.role==entry[1]}

            $i = 0
            while $i<(entry[3]-entry[2]) do
              @providers[tmp[$i].provider].deletemachine(tmp[$i])
              cl_read.rmmachine(tmp[$i])
              $i +=1
            end

          end
        else
          raise RuntimeError.new 'Unexpected entry in hasdiff'
      end
    end

    cl_read
  end


  # Compare two clusters
  #
  # * Generates a differential cluster object
  # * check witch machine ist running or down
  #
  # @param cl_read Cluster form the object file.
  # @param cl_parsed Cluster from parsed json file.
  def compareYAML(cl_read, cl_parsed)
    Cli::LOG.info('Comparing running cluster with new configuration. This may take a while.')
    parsed_machine_num = Hash.new
    read_machine_num = Hash.new
    old_instances = Array.new
    new_instances = Array.new

    Cli::LOG.info("Current machines in the cluster: #{cl_read.machines.size}")
    Cli::LOG.info("Cluster after update: #{cl_parsed.machines.size}")


    cl_read.machines.each {|current_machine|
      old_instances.push(current_machine.private_ipv4)
    }

    cl_parsed.machines.each {|new_machine|
      unless new_machine.private_ipv4.nil? || new_machine.private_ipv4==''
        new_instances.push(new_machine.private_ipv4)
      end
    }

    old = old_instances - new_instances

    Cli::LOG.debug("alt: #{old_instances}\nneu: #{new_instances}\njetzt: n#{old}")
    old.each do |ip|

      tmp = cl_read.machines.select {|m| m.private_ipv4 == ip}[0]
      Cli::LOG.info("Delete machine #{tmp.uid} with ip: #{tmp.private_ipv4}.")
      @providers[tmp.provider].deletemachine(tmp)
      cl_read.rmmachine(tmp)
      cl_read.machines.delete_if {|m| m.private_ipv4 == tmp.private_ipv4}
    end


    # create role map for parsed cluster
    cl_parsed.machines.each do |machine|
      parsed_machine_num[machine.role] = (parsed_machine_num[machine.role]) ? parsed_machine_num[machine.role]+1 : 1
    end
    # remove machines in error state
    checkstatus(cl_read).each do |machine|
      cl_read.rmmachine(machine)
      Cli::LOG.info("Removing malfunctioning machine: #{machine}")
    end

    cl_read.machines.each do |machine|
      read_machine_num[machine.role] = (read_machine_num[machine.role]) ? read_machine_num[machine.role]+1 : 1
    end

    # Calculate differences
    diff = HashDiff.diff(parsed_machine_num, read_machine_num)

    diff.each do |entry|

      puts entry.to_s

    end

    # Remmove differences
    diff.each do |entry|

      case entry[0]
        when '+'
          # Additional role found, remove all unused machines.
          # Cli::LOG.info("Removing unsused role #{entry[1]}")
          # tmp = cl_read.machines.select{|m| m.role==entry[1]}
          # tmp.each do |machine|
          #   @providers[machine.provider].deletemachine(machine)
          #   cl_read.rmmachine(machine)
          # end
        when '-'
          Cli::LOG.info("Starting new machines for new role #{entry[1]}")
          # Missing role found, start all machines of this role


          tmp = cl_parsed.machines.select {|m| m.role == entry[1]}
          prov = @providers[tmp[0].provider]
          prov.master_ip = cl_read.public_ipv4
          prov.name = cl_read.name
          prov.set_ca_files(cl_read)


          tmp.each do |machine|
            prov.generateSlaveUserdata(machine.hostname)
            prov.generateSlave(machine, cl_read.secgrp_name)
            cl_read.machines.push(machine)
            machine.starting_time = Time.now.to_i
          end
          prov.deleteuserdata

        when '~'

          Cli::LOG.info("Changing number of machines for role #{entry[1]}")
          # Number of role-machines updated
          if entry[2] > entry[3]

            # Missing machines, starting new ones
            tmp = cl_parsed.machines.select {|m| m.role == entry[1]}
            prov = @providers[tmp[0].provider]
            prov.master_ip = cl_read.public_ipv4
            prov.name = cl_read.name
            prov.set_ca_files(cl_read)



            $i = 0
            while $i<(entry[2]-entry[3]) do
              if entry[1].downcase == 'master'
                prov.updatemaster(tmp[$i], cl_read.secgrp_name)
              else
                prov.generateSlaveUserdata(tmp[$i].hostname)
                prov.generateSlave(tmp[$i], cl_read.secgrp_name)
              end

              tmp[$i].starting_time = Time.now.to_i
              cl_read.machines.push(tmp[$i])
              tmp[$i].private_ipv4 = prov.get_machine_ip(tmp[$i])

              $i +=1
            end
            prov.deleteuserdata

          else
          end
        else
          raise RuntimeError.new 'Unexpected entry in hasdiff'
      end
    end
    cl_read
  end

  # Register a provider at the local object structur
  #
  # @param provider Instance of a special provider.
  def registerprovider(provider)
    @providers[provider.provideruid] = provider unless @providers.has_key?(provider.provideruid)
    Cli::LOG.debug(self) {"Register provider: #{provider}"}
  end

end

