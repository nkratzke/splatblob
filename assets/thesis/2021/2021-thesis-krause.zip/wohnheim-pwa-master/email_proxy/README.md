# email_proxy

This is the README.md of the email_proxy

## Date in emails

The date format in a email is like %a, %d %b %Y %H:%M:%S %z (Wed, 30 Dec 2020 14:46:16 +0000).