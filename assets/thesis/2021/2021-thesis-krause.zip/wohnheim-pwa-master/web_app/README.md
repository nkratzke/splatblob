# Prototype PWA

You can read all about the pwa and the email-proxy in the documentation of the thesis.


# Environments

You can set PROD or LOCAL in the .env ENVIRONMENT field.

# Custom email-proxy

You can set a custom url in the .env file.