import { WebWorkerLogic } from './WebWorker/WebWorkerLogic';

new WebWorkerLogic();
