<template>
	<div>
		<button @click="click" class="button is-primary">
			<font-awesome-icon :icon="icon" size="2x"></font-awesome-icon>
		</button>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Ad } from 'src/email/Ad';

@Component({
	components: {},
})
export default class FloatingButton extends Vue {
	@Prop() private icon: string;

	private click() {
		this.$emit('click');
	}
}
</script>

<style lang="scss" scoped>
$padding: 0.5rem;

.button {
	position: absolute;
	right: 0 + $padding;
	bottom: 0 + $padding;
	height: 3rem;
	width: 3rem;
	border-radius: 100%;
}
</style>
