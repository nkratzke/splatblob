<template>
	<div :class="containerClass" ref="messageContainer">
		<MessageItem
			v-for="message in sortedMessages"
			:key="message.messageId"
			:message="message"
			class=""
		/>
	</div>
</template>

<script lang="ts">
import { Utils } from '../../../email/utils';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { IMessage } from '../../../email/dexie_interfaces/IMessage';
import MessageItem from './MessageItem.vue';

@Component({
	components: { MessageItem },
})
export default class MessageList extends Vue {
	@Prop() private messages: IMessage[];
	private messageContainer: HTMLDivElement;
	private inited: boolean = false;

	mounted() {
		console.log(this.$refs.messageContainer);
		this.messageContainer = this.$refs.messageContainer as HTMLDivElement;
		this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
		this.inited = true;
	}

	updated() {
		this.messageContainer.scrollTo({ top: this.messageContainer.scrollHeight });
	}

	get containerClass() {
		return `mb-3 message-container ${this.inited ? 'smooth-scroll' : ''}`;
	}

	get sortedMessages() {
		return this.messages.sort(
			(b, a) =>
				Utils.timeStringToDate(b.messageDate).toMillis() -
				Utils.timeStringToDate(a.messageDate).toMillis(),
		);
	}
}
</script>

<style lang="scss">
.message-container {
	overflow: scroll;
	overflow-x: hidden;
	height: calc(100vh - 7rem);
	padding-bottom: 2rem;
}

.smooth-scroll {
	scroll-behavior: smooth;
}
</style>
