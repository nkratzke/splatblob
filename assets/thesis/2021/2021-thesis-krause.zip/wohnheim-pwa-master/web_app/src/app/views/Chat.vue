<template>
	<div>
		<div class="container" v-if="chat.type == 'NORMAL'">
			<MessageList :messages="chat.messages"></MessageList>
			<SendMessage
				:chat-id="chatId"
				v-if="
					!chat.onlyAdminsCanSend ||
					(chat.onlyAdminsCanSend && chat.isAdmin(currentUser))
				"
			></SendMessage>
		</div>
		<div v-else>
			<div class="container content-height">
				<div class="hero is-light" v-if="chat.ads.length == 0">
					<div class="hero-body">
						<div class="container">
							<h1 class="title">Es gibt noch keine Inserate in diesem Chat</h1>
							<h2 class="subtitle">
								Hast du etwas zu verkaufen, zu verschenken, zu verleihen oder
								etwas anders anzubieten?
							</h2>
							<button @click="newAd" class="button">Neues Inserat</button>
						</div>
					</div>
				</div>
				<div class="columns" v-for="(adRow, index) in adColumns" :key="index">
					<div v-for="ad in adRow" :key="ad.id" class="column">
						<AdOverviewContainer :ad="ad"></AdOverviewContainer>
					</div>
				</div>
			</div>
			<FloatingButton icon="plus" @click="newAd"></FloatingButton>
		</div>
	</div>
</template>

<script lang="ts">
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { Component, Prop, Vue } from 'vue-property-decorator';
import MessageList from '../components/MessageView/MessageList.vue';
import SendMessage from '../components/SendMessage.vue';
import AdOverviewContainer from '../components/AdOverviewContainer.vue';
import { AChat } from '../../email/AChat';
import { AdChat } from '../../email/AdChat';
import FloatingButton from '../components/FloatingButton.vue';
import { AppUtils } from '../AppUtils';

@Component({
	components: { SendMessage, MessageList, AdOverviewContainer, FloatingButton },
})
export default class Chat extends Vue {
	@Prop() private chatId: string;

	get adColumns() {
		if (this.chat.type == ChatType.AD) {
			return AppUtils.toColumns((this.chat as AdChat).ads, 2);
		}
		return [];
	}

	get chat(): AChat {
		return this.$store.getters.getChat(this.chatId);
	}

	get chatTypes() {
		return ChatType;
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	private newAd() {
		this.$router.push(`/chat/${this.chat.id}/new-ad`);
	}

	backToHome() {
		this.$router.push('/');
	}

	private clickOnMenu() {
		this.$router.push(`/chat-details/${this.chat.id}`);
	}
}
</script>

<style lang="scss" scoped></style>

<i18n>
{
	"en": {

	},
	"de": {
		
	}
}
</i18n>
