<template>
	<div class="container">
		<h1 class="title">Neuen Chat erstellen</h1>
		<div>
			<div class="field">
				<div class="controler">
					<label class="label">Name</label>
					<input
						class="input"
						type="text"
						placeholder="Gib einen Namen ein"
						v-model="chatName"
					/>
				</div>
			</div>

			<div class="container">
				<label class="checkbox">
					<input type="checkbox" class="checkbox" v-model="isPublic" />
					Ist ein öffentlicher chat
				</label>
			</div>

			<div class="container mb-3">
				<label class="checkbox">
					<input type="checkbox" class="checkbox" v-model="onlyAdminsCanSend" />
					Nur Administratoren können Nachrichten senden
				</label>
			</div>

			<div class="field">
				<div class="controler">
					<label class="label">Art des Chats</label>
					<div class="select">
						<select v-model="chatType">
							<option :value="chatTypes.AD">Inserat Chat</option>
							<option :value="chatTypes.NORMAL" selected>Normaler Chat</option>
						</select>
					</div>
				</div>
			</div>

			<label class="label mb-3">Neue Mitglieder:</label>
			<ul class="container">
				<li class="level is-mobile mb-3" v-if="emails.length === 0">
					Bislang ist niemand in der Liste
				</li>
				<li v-for="email in emails" :key="email" class="level is-mobile mb-3">
					<div class="level-item">
						<p>
							{{ email }}
						</p>
					</div>
					<div class="level-item">
						<button class="button" @click="remove(email)">Entfernen</button>
					</div>
				</li>
			</ul>

			<div class="field has-addons mb-3">
				<div class="control is-expanded">
					<input
						:class="editEmailClass"
						type="text"
						placeholder="Tipp eine E-Mail ein"
						:value="editEmail"
						@input="changeEditEmail"
					/>
					<p v-if="emailAlreadyInclueded" class="help is-danger">
						Die E-Mail ist bereits in der Liste!
					</p>
					<p v-else-if="!editMailIsValid" class="help is-danger">
						Ist keine valide E-Mail.
					</p>
				</div>

				<p class="control">
					<button class="button" @click="addNew" :disabled="!editMailIsValid">
						Hinzufügen
					</button>
				</p>
			</div>
		</div>

		<div class="field">
			<div class="control" v-if="chatsWithSameUsers.length == 0">
				<button class="button" :disabled="!canSend" @click="createChat">
					Neuen Chat erstellen
				</button>
			</div>
		</div>

		<div class="hero is-danger" v-if="chatsWithSameUsers.length > 0">
			<div class="hero-body">
				<h1 class="title is-5">
					Du bist bereits in einem Chat mit den gleichen Mitgliedern!<span
						v-if="emails.length > 1"
						>s</span
					>!
					<a class="has-text-info" @click="createChat"
						>Ich möchte ihn trotzdem erstellen!</a
					>
				</h1>
				<ul>
					<li v-for="chat in chatsWithSameUsers" :key="chat.id">
						{{ chat.name }}
					</li>
				</ul>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { ActionTypes } from '../store/ActionTypes';
import { User } from '../../email/User';
import InputField from '../components/InputField.vue';
import { Utils } from '../../email/utils';
import { CustomPromise } from '../routes/CustomPromise';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { Notification } from '../Notification';

@Component({
	components: { InputField },
})
export default class NewChat extends Vue {
	private chatName: string = '';
	private emails: string[] = [];
	private isPublic: boolean = false;
	private onlyAdminsCanSend: boolean = false;
	private editEmail: string = '';
	private editMailIsValid: boolean = false;
	private chatType: ChatType = ChatType.NORMAL;

	private changeEditEmail(event: InputEvent) {
		this.editEmail = (event.target as HTMLInputElement).value;
		this.editMailIsValid =
			Utils.isValidEmailAddress(this.editEmail) && !this.emailAlreadyInclueded;
	}

	addNew() {
		this.emails.push(this.editEmail);
		this.editEmail = '';
	}

	private remove(removeEmail: string) {
		this.emails = this.emails.filter((email) => email !== removeEmail);
	}

	get emailAlreadyInclueded() {
		return (
			this.emails.includes(this.editEmail) ||
			this.currentUser.email == this.editEmail
		);
	}

	get editEmailClass() {
		return `input ${this.editMailIsValid ? 'is-valid' : 'is-danger'}`;
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get currentParticipants() {
		return this.emails
			.map((email) => {
				return email ? new User(email, email) : null;
			})
			.filter((user) => !!user);
	}

	get chatsWithSameUsers() {
		console.log(this.currentParticipants);
		const chats = this.$store.getters.getChatWithExactUserMatch(
			this.currentParticipants.concat([this.currentUser]),
		);
		return chats;
	}

	get canSend() {
		return this.emails.length > 0 && this.chatName.length > 0;
	}

	get chatTypes() {
		return ChatType;
	}

	private createChat() {
		if (this.canSend) {
			const callback: CustomPromise = {
				thenCallback: (chatId: string) => {
					this.$router.push(`/chat/${chatId}`);
				},
				catchCallBack: (err: any) => {
					this.$store.dispatch(
						ActionTypes.CREATE_NOTIFICATION,
						new Notification(
							'Fehler beim erstellen des Chats',
							`Der Chat ${this.chatName} konnte nicht erstellt werden! `,
							3,
							'danger',
						),
					);
					console.error('NewChat', err);
				},
			};
			this.$store.dispatch(ActionTypes.CREATE_CHAT, {
				name: this.chatName,
				inviteMembers: this.emails,
				isPublic: this.isPublic,
				onlyAdminsCanSend: this.onlyAdminsCanSend,
				type: this.chatType,
				callbackPromise: callback,
			});
		}
	}
}
</script>

<style lang="scss"></style>
