<template>
	<section>
		<h1 class="title">Send news to {{ chat.name }}</h1>
		<InputField
			label="Title"
			placeholder="A news title"
			type="text"
			errorText="Is not a valid title!"
			validator="NOT_EMPTY"
			defaultValue=""
			id="title"
			@valueChanged="valueChanged"
			@validChanged="validChanged"
		></InputField>

		<TextAreaField
			label="Message"
			placeholder="A message for your news"
			errorText="The message can't be empty"
			defaultValue=""
			id="message"
			@valueChanged="valueChanged"
			@validChanged="validChanged"
		>
		</TextAreaField>

		<ButtonField
			@click="send"
			content="Send news"
			:disabled="!canSend"
			classExtend="is-primary"
		>
		</ButtonField>
	</section>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { UseMailbox } from '../../email/UseMailbox';
import { ActionTypes } from '../store/ActionTypes';
import InputField from '../components/InputField.vue';
import TextAreaField from '../components/TextAreaField.vue';
import ButtonField from '../components/ButtonField.vue';
import { NewsMessage } from '../../email/content_messages/NewsMessage';
import { Utils } from '../../email/utils';
import { EMail } from '../../email';
import { CustomPromise } from '../routes/CustomPromise';
import { Notification } from '../Notification';

@Component({
	components: { InputField, TextAreaField, ButtonField },
})
export default class SendNewsMessage extends Vue {
	@Prop() private chatId: string;
	private title: string = '';
	private titleValid: boolean = false;
	private message: string = '';
	private messageValid: boolean = false;

	get chat() {
		return this.$store.getters.getChat(this.chatId);
	}

	private updateUseMailbox(mailbox: UseMailbox) {
		mailbox.use = !mailbox.use;
		this.$store.dispatch(ActionTypes.CHANGE_USE_MAILBOX, mailbox);
	}

	private valueChanged(payload: { from: string; value: any }) {
		switch (payload.from) {
			case 'title':
				this.title = payload.value;
				break;
			case 'message':
				this.message = payload.value;
				break;
		}
	}

	private validChanged(payload: { from: string; value: any }) {
		switch (payload.from) {
			case 'title':
				this.titleValid = payload.value;
				break;
			case 'message':
				this.messageValid = payload.value;
				break;
		}
	}

	private getBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}

	private send() {
		if (this.canSend) {
			const callback: CustomPromise = {
				thenCallback: () => {
					console.log('Open');
					this.$router.go(-1);
				},
				catchCallBack: (err) => {
					this.$store.dispatch(
						ActionTypes.CREATE_NOTIFICATION,
						new Notification(
							'Fehler beim versenden der Nachricht',
							`Die Nachricht konnte nicht versendet werden! `,
							3,
							'danger',
						),
					);
					console.error('CaretakerRequest.sendToChat', err);
				},
			};
			this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
				message: new NewsMessage(
					this.$store.state.loginUser,
					EMail.genId(this.getBaseUrl()),
					this.chatId,
					Utils.dateToTimeString(Utils.getCurrentDateTime()),
					this.title,
					this.message,
				),
				callbackPromise: callback,
			});
		}
	}

	get canSend() {
		return this.titleValid && this.messageValid;
	}
}
</script>

<style lang="scss"></style>
