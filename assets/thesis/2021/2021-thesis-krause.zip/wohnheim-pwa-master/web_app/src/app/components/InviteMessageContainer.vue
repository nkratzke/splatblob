<template>
	<div>
		<p>{{ new Date(inviteMessage.joinDate).toDateString() }}</p>
		<p>{{ inviteMessage.sender.nickname }} invite you to the group!</p>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { InviteMessage } from '../../email/content_messages/InviteMessage';

@Component({
	components: {},
})
export default class InviteMessageContainer extends Vue {
	@Prop() private inviteMessage: InviteMessage;
}
</script>

<style lang="scss"></style>
