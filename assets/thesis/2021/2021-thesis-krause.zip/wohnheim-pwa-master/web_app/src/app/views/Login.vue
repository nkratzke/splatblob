<template>
	<div class="container">
		<div v-if="loginUser.email.length > 0">
			<p>
				Du bist mit der E-Mail
				<b class="ml-1">{{ loginUser.email }}</b> eingeloggt.
			</p>

			<button class="button" @click="backToHome">Zurück zur Home-Page</button>
			<DoubleClickButton
				content="Ausloggen und Datenbank löschen"
				contentFirstClick="Bist du dir sicher?"
				firstClickClass="is-danger"
				@click="logOutUser"
			></DoubleClickButton>
		</div>
		<div v-else>
			<h1 class="title">Login</h1>
			<form>
				<!-- LoginName -->
				<div class="field">
					<label class="label">Login-Name / Matrikelnummer</label>
					<div class="control has-icons-left has-icons-right">
						<input
							:class="loginNameClass"
							type="text"
							placeholder="Login Name"
							:value="loginName"
							@input="setLoginName"
							:disabled="emailEqualsLogin"
						/>
						<span class="icon is-small is-left">
							<font-awesome-icon icon="user" />
						</span>
					</div>
					<p v-if="!validLoginName" class="help">Ungültiger Login-Name</p>
				</div>

				<!-- LoginName equals E-Mail -->
				<div class="field">
					<label class="checkbox">
						<div class="control">
							<input type="checkbox" v-model="emailEqualsLogin" checked />
							E-Mail und Login-Name sind gleich
						</div>
					</label>
				</div>

				<!-- E-Mail -->
				<div class="field">
					<label class="label">E-Mail</label>
					<div class="control has-icons-left has-icons-right">
						<input
							:class="emailClass"
							type="email"
							placeholder="E-Mail"
							:value="email"
							@input="setEmail"
						/>
						<span class="icon is-small is-left">
							<font-awesome-icon icon="envelope" />
						</span>
						<span v-if="validEmail" class="icon is-small is-right">
							<font-awesome-icon icon="check" />
						</span>
						<span v-else class="icon is-small is-right">
							<font-awesome-icon icon="times" />
						</span>
					</div>
					<p v-if="!validEmail" class="help">Ungülige E-Mail</p>
				</div>

				<!-- Password -->
				<div class="field">
					<label class="label">Password</label>
					<div class="control has-icons-left has-icons-right">
						<input
							:class="passwordClass"
							type="password"
							placeholder="Password"
							:value="password"
							@input="setPassword"
						/>
						<span class="icon is-small is-left">
							<font-awesome-icon icon="key" />
						</span>
						<span v-if="validPassword" class="icon is-small is-right">
							<font-awesome-icon icon="check" />
						</span>
						<span v-else class="icon is-small is-right">
							<font-awesome-icon icon="times" />
						</span>
					</div>
					<p v-if="!validPassword" class="help">Ungültiges Passwort</p>
				</div>

				<!-- Stay logged in -->
				<div class="field">
					<div class="control">
						<label class="checkbox">
							<input type="checkbox" v-model="stayLoggedIn" />
							Bleib eingeloggt
							<span class="notice">
								<span class="has-text-danger">ACHTUNG</span>, diese App ist in
								einem frühen Entwicklungsstadium. Das angegebene Passwort und
								alle Inhalte werden unverschlüsselt in deinem Browser
								gespeichert
							</span>
						</label>
					</div>
				</div>

				<!-- providers -->
				<label class="label">Wähle deinen Provider</label>
				<div class="field has-addons">
					<div class="control">
						<div class="select is-primary">
							<select v-model="chosenProviderId">
								<option
									v-if="providers.length === 0"
									value="none"
									selected
									disabled
								>
									Keine Provider verfügbar :(
								</option>
								<option
									v-else
									v-for="provider in providers"
									:key="provider.id"
									:value="provider.id"
								>
									{{ provider.name || provider.id }}
								</option>
							</select>
						</div>
					</div>

					<div class="control">
						<button class="button is-primary" @click="addNewProvider">
							Provider erstellen
						</button>
					</div>
				</div>

				<h3 class="h3 subtitle is-danger" v-if="getLoginFail">
					{{ getLoginFail }}
				</h3>

				<!-- Submit Button -->
				<div class="field">
					<div class="control">
						<button
							class="button is-primary"
							@click="sendLoginAction"
							:disabled="!canLogin"
						>
							Einloggen
						</button>
					</div>
				</div>
			</form>

			<section class="hero is-info mt-5">
				<div class="hero-body">
					<p class="title">Weißt du nicht weiter?</p>
					<p class="subtitle">
						Dann besuche die <a class="link" @click="toAbout">About-Seite.</a>
					</p>
					<button class="button" @click="toAbout">Zur About-Seite</button>
				</div>
			</section>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { ActionTypes } from '../store/ActionTypes';
import { Utils } from '../../email/utils';
import DoubleClickButton from '../components/DoubleClickButton.vue';

@Component({
	components: { DoubleClickButton },
})
export default class Login extends Vue {
	private email: string = '';
	private validEmail: boolean = true;
	private password: string = '';
	private validPassword: boolean = true;
	private loginName: string = '';
	private validLoginName: boolean = true;
	private chosenProviderId: string = '';
	private stayLoggedIn: boolean = false;
	private emailEqualsLogin: boolean = true;

	mounted() {
		const lastLoginUser = this.$store.state.loginUser;
		this.email = lastLoginUser.email;
		this.loginName = this.emailEqualsLogin ? '' : lastLoginUser.loginName;
		this.password = lastLoginUser.password;
		this.chosenProviderId = lastLoginUser.chosenProviderId;
	}

	get emailClass() {
		return `input ${!this.validEmail ? 'is-danger ' : 'is-success'}`;
	}

	get passwordClass() {
		return `input ${!this.validPassword ? 'is-danger' : 'is-success'}`;
	}

	get loginNameClass() {
		if (this.emailEqualsLogin) {
			return 'input';
		}
		return `input ${!this.validLoginName ? 'is-danger' : 'is-success'}`;
	}

	toAbout() {
		this.$router.push('/about');
	}

	setEmail(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.validEmail = Utils.isValidEmailAddress(value);
		this.email = value;
	}

	setPassword(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.validPassword = value.length > 0;
		this.password = value;
	}

	setLoginName(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.validPassword = value.length > 0;
		this.loginName = value;
	}

	get getLoginUser() {
		return this.$store.state.loginUser;
	}

	get getLoginFail() {
		return this.$store.state.loginFailed.reason;
	}

	get proxyStatus() {
		return this.$store.state.proxyStatus;
	}

	get loginUser() {
		return this.$store.state.loginUser;
	}

	get providers() {
		return this.$store.state.providers;
	}

	get canLogin() {
		return (
			this.validPassword &&
			this.validLoginName &&
			this.validEmail &&
			this.chosenProviderId != ''
		);
	}

	private clear() {
		this.email = '';
		this.validEmail = true;
		this.loginName = '';
		this.validLoginName = true;
		this.password = '';
		this.validPassword = true;
	}

	public sendLoginAction(event: MouseEvent) {
		event.preventDefault();
		const payload = {
			email: this.email.toLowerCase(),
			nickname: 'You',
			password: this.password,
			loginName: this.emailEqualsLogin ? this.email : this.loginName,
			savePassword: this.stayLoggedIn,
			chosenProviderId: this.chosenProviderId,
		};
		this.$store.dispatch(ActionTypes.LOGIN_USER, payload);
	}

	private logOutUser(event: MouseEvent) {
		event.preventDefault();
		this.$store.dispatch(ActionTypes.LOGOUT_USER);
		this.clear();
	}

	private addNewProvider(event: MouseEvent) {
		event.preventDefault();
		this.$router.push('/custom-provider');
	}

	private backToHome() {
		this.$router.push('/');
	}
}
</script>

<style lang="scss">
.notice {
	color: red;
}

.link {
	text-decoration: underline;
}
</style>
