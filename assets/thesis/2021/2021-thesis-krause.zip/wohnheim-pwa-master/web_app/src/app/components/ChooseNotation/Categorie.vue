<template>
	<div>
		<div v-if="categorie.extraContent">
			<ExtraFields
				:options="categorie.extraContent"
				@valueChanged="valueChangedOptions"
			></ExtraFields>
		</div>
		<CategorieRoot
			v-if="categorie.subCategories"
			:categories="categorie.subCategories"
			@valueChanged="valueChangedCategorie"
		></CategorieRoot>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import {
	ICategorie,
	ExtraFieldResult,
	ICategorieResult,
} from '../../ChooseNotation';
import ExtraFields from './ExtraFields.vue';

@Component({
	components: {
		CategorieRoot: () => import('./Root.vue'),
		ExtraFields: () => import('./ExtraFields.vue'),
	},
})
export default class Categorie extends Vue {
	@Prop() private categorie: ICategorie;
	private currentReturn: ICategorieResult = {
		iCategorie: this.categorie,
		extraContentResults: [],
	};

	mounted() {
		this.clearExtraContent();
		this.clearSubCategories();
	}

	private clearExtraContent() {
		this.currentReturn.extraContentResults = [];
	}

	private clearSubCategories() {
		this.currentReturn.subCategorieResult = undefined;
	}

	private valueChangedOptions(payload: ExtraFieldResult[]) {
		this.clearExtraContent();
		this.currentReturn.extraContentResults = payload;
		this.emitChange();
	}

	private valueChangedCategorie(payload: ICategorieResult) {
		this.clearSubCategories();
		this.currentReturn.subCategorieResult = payload;
		this.emitChange();
	}

	private emitChange() {
		this.$emit('valueChanged', this.currentReturn);
	}
}
</script>

<style lang="scss" scoped></style>
