<template>
	<div class="container">
		<div>
			<h1 class="subtitle">Erstellt am {{ chat.creationDate }}</h1>
			<h2 class="subtitle is-7">Chat-ID: {{ chat.id }}</h2>

			<div class="container">
				<label class="checkbox" disabled>
					<input
						type="checkbox"
						class="checkbox"
						:checked="chat.isPublic"
						disabled
					/>
					Ist ein öffentlicher Chat
				</label>
			</div>

			<div class="container">
				<label class="checkbox" disabled>
					<input
						type="checkbox"
						class="checkbox"
						:checked="chat.onlyAdminsCanSend"
						disabled
					/>
					Nur Administratoren können Nachrichten senden.
				</label>
			</div>

			<h1 class="subtitle">Aktuelle Mitglieder</h1>
			<div class="container mb-3">
				<ChatUserItem
					v-for="participant in chat.participants"
					:key="participant.email"
					:user="participant"
					:chat="chat"
					class="mb-2"
				>
				</ChatUserItem>
			</div>
		</div>
		<div class="container" v-if="loggedInUserIsAdmin">
			<h1 class="subtitle">Personen einladen</h1>
			<div class="field has-addons">
				<div class="control is-expanded">
					<input
						:class="inviteEmailClass"
						type="email"
						placeholder="Tippe eine E-Mail-Adresse ein"
						:value="inviteEmail"
						@input="inputEmail"
					/>
				</div>
				<div class="control">
					<button
						class="button"
						:disabled="!inviteEmailValid"
						@click="sendInviteToUser"
					>
						Nutzer einladen
					</button>
				</div>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { ActionTypes } from '../store/ActionTypes';
import { Chat } from '../../email/Chat';
import { LoginUser } from '../../email/LoginUser';
import { User } from '../../email/User';
import { InviteMessage } from '../../email/content_messages/InviteMessage';
import { CustomPromise } from '../routes/CustomPromise';
import ChatUserItem from '../components/ChatUserItem.vue';
import InputField from '../components/InputField.vue';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { AdChat } from '../../email/AdChat';
import { EMail } from '../../email';
import { Utils } from '../../email/utils';
import { IEMail } from '../../email/dexie_interfaces/IEMail';
import { NewAdMessage } from '../../email/content_messages/NewAdMessage';
import { Notification } from '../Notification';

@Component({
	components: { ChatUserItem, InputField },
})
export default class ChatDetails extends Vue {
	@Prop() private chatId: string;
	private inviteEmail: string = '';
	private inviteEmailValid: boolean = false;

	inputEmail(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.inviteEmailValid = value.length > 0;
		this.inviteEmail = value;
	}

	get inviteEmailClass() {
		return `input ${!this.inviteEmailValid ? 'is-danger' : 'is-success'}`;
	}

	get chat(): Chat {
		return this.$store.getters.getChat(this.chatId);
	}

	get loggedInUser(): LoginUser {
		return this.$store.state.loginUser;
	}

	get loggedInUserIsAdmin(): boolean {
		return this.userIsAdmin(this.loggedInUser as User);
	}

	getCurrentProviderBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}

	userIsAdmin(user: User) {
		return (
			this.chat.admins.filter((admin) => admin.email === user.email).length > 0
		);
	}

	sendInviteToUser() {
		if (this.inviteEmailValid) {
			const message = InviteMessage.fromChat(this.chat, this.loggedInUser, [
				new User(this.inviteEmail, this.inviteEmail),
			]);
			console.log(message);

			const callback: CustomPromise = {
				thenCallback: (data: any) => {
					this.inviteEmail = '';
				},
				catchCallBack: (err: any) => {
					this.$store.dispatch(
						ActionTypes.CREATE_NOTIFICATION,
						new Notification(
							'Fehler beim einladen des Nutzers',
							`Der Nutzer ${this.inviteEmail} konnte dem Chat nicht hinzugefügt werden! `,
							3,
							'danger',
						),
					);
					console.log('Send invite error', err);
					this.inviteEmail = '';
				},
			};
			this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
				message: message,
				callbackPromise: callback,
			});
		}
	}
}
</script>

<style lang="scss">
.notice {
	color: red;
}
</style>
