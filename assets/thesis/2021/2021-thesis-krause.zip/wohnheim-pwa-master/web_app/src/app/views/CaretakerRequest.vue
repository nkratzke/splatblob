<template>
	<div class="container">
		<h1 class="title">Meldungen an den Hausmeister</h1>
		<h2 class="subtitle">Gibt es Probleme oder Schäden in deiner Wohnung?</h2>

		<CategorieRoot
			class="container mb-5"
			:categories="careTakerCategories"
			@valueChanged="valueChanged"
		></CategorieRoot>

		<div class="container mb-5">
			<div v-if="!currentResultString">
				<p class="has-text-danger hero">
					Bislang wurde keine Nachricht ausgewählt. Um fortzufahren, musst du
					etwas selektieren.
				</p>
			</div>
			<div v-else>
				<h1 class="title is-4">
					Die folgende Nachricht wird an den Hausmeister geschickt
				</h1>
				<h2 class="has-text-danger subtitle">
					Die Nachrichten werden aktuell an den Entwickler geschickt!
				</h2>
				<p>
					<span style="color: gray">{{ defaultMessagePart }}</span
					>{{ currentResultString }}
				</p>
			</div>
		</div>

		<div>
			<div class="field" v-if="chatsWithSameUsers.length == 0">
				<div class="control">
					<button class="button" @click="createNewChat" :disabled="disabled">
						Neuen Chat mit
						<span class="is-hidden-mobile mx-1">{{ userString }}</span>
						erstellen
					</button>
				</div>
			</div>

			<div class="field" v-if="chatsWithSameUsers.length == 1">
				<div class="control">
					<button
						class="button"
						@click="sendToChat(chatsWithSameUsers[0].id)"
						:disabled="disabled"
					>
						Nachricht in Chat {{ chatsWithSameUsers[0].name }} senden
					</button>
				</div>
			</div>

			<div class="field" v-if="chatsWithSameUsers.length > 1">
				<div class="control">
					<ul>
						<li
							class="block has-text-centered"
							v-for="chat in chatsWithSameUsers"
							:key="chat.id"
							@click="sendToChat(chat.id)"
						>
							<button class="button" :disabled="disabled">
								Nachricht in Chat {{ chat.name }} senden
							</button>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { developer as caretaker } from '../importantContacts';
import InputField from '../components/InputField.vue';
import { User } from '../../email/User';
import { ActionTypes } from '../store/ActionTypes';
import { CustomPromise } from '../routes/CustomPromise';
import { TextMessage } from '../../email/content_messages/TextMessage';
import { EMail } from '../../email';
import { LoginUser } from '../../email/LoginUser';
import { Utils } from '../../email/utils';
import CategorieRoot from '../components/ChooseNotation/Root.vue';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import CreateOpenChat from '../components/CreateOpenChat.vue';
import { Notification } from '../Notification';
import {
	caretakerRequest,
	categorieResultToString,
	ICategorieResult,
} from '../ChooseNotation';

enum RequestTypes {
	AD = 'AD',
	OTHER = 'OTHER',
}

enum Uebliches {
	HERD_DAMAGED = 'HERD_DAMAGED',
	OFEN_DAMAGED = 'OFEN_DAMAGED',
	WASSER_HAHN = 'WASSER_HAHN',
}

@Component({
	components: { InputField, CategorieRoot, CreateOpenChat },
})
export default class CaretakerRequest extends Vue {
	private currentResultObject: ICategorieResult | null = null;

	private valueChanged(payload: any) {
		this.currentResultObject = payload;
	}

	get currentResultString() {
		if (!this.currentResultObject) {
			return null;
		}
		let returnString = categorieResultToString(this.currentResultObject).trim();
		if (
			returnString.charAt(returnString.length - 1) == ',' ||
			returnString.charAt(returnString.length - 1) == '.'
		) {
			returnString = returnString.substring(0, returnString.length - 1);
		}
		return returnString;
	}

	get defaultMessagePart() {
		return (
			`Moin Herr ${caretaker.name}, \n` +
			'wir haben folgendes Problem im Haus / in unserer Wohnung feststellen können:\n'
		);
	}

	get sendMessage() {
		return `${this.defaultMessagePart} ${this.currentResultString}.`;
	}

	get requestTypes() {
		return RequestTypes;
	}

	get ueblichesTypes() {
		return Uebliches;
	}

	get currentUser(): LoginUser {
		return this.$store.state.loginUser;
	}

	get caretakerUser() {
		return new User(caretaker.email, caretaker.name);
	}

	get disabled() {
		return !this.currentResultString;
	}

	private sendToChat(chatId: string) {
		const callback: CustomPromise = {
			thenCallback: () => {
				console.log('Open');
				this.openChat(chatId);
			},
			catchCallBack: (err) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Fehler beim erstellen des Chats',
						`Der Chat ${name} konnte nicht erstellt werden! `,
						3,
						'danger',
					),
				);
				console.error('CaretakerRequest.sendToChat', err);
			},
		};

		this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
			message: new TextMessage(
				this.currentUser,
				EMail.genId(this.$store.getters.getCurrentProviderBaseUrl()),
				chatId,
				Utils.dateToTimeString(Utils.getCurrentDateTime()),
				this.sendMessage,
			),
			callbackPromise: callback,
		});
	}

	private openChat(chatId: string) {
		this.$router.push(`/chat/${chatId}`);
	}

	get careTakerCategories() {
		return caretakerRequest;
	}

	get chatsWithSameUsers() {
		const chats = this.$store.getters.getChatWithExactUserMatch(this.users);
		return chats;
	}

	get users() {
		return [this.currentUser, caretaker];
	}

	get userString() {
		let ret = '';
		this.users.forEach((user: any) => {
			ret += `${user.email}, `;
		});
		return ret.substring(0, ret.length - 2);
	}

	private createNewChat() {
		const name = `Caretaker-Chat with ${this.userString}`;
		const callback: CustomPromise = {
			thenCallback: (chatId: string) => {
				this.sendToChat(chatId);
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Erstellung des neuen Chats schlug fehl',
						`Der Chat ${name} konnte nicht erstellt werden! `,
						3,
						'danger',
					),
				);
				console.error('CreateOpenChat.createNewChat', err);
			},
		};
		this.$store.dispatch(ActionTypes.CREATE_CHAT, {
			name: name,
			inviteMembers: [caretaker.email],
			isPublic: false,
			onlyAdminsCanSend: false,
			type: ChatType.NORMAL,
			callbackPromise: callback,
		});
	}
}
</script>

<style lang="scss"></style>
