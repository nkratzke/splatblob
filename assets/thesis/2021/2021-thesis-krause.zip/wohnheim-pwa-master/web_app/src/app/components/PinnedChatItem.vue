<template>
	<div class="card">
		<div class="card-content">
			<h1 class="subtitle">{{ pinnedChat.name }}</h1>
			<p>{{ pinnedChat.description }}</p>
		</div>
		<div class="card-footer">
			<div
				class="card-footer-item has-text-success has-text-centered is-unselectable"
				v-if="clicked && !chat"
			>
				<a>
					<ClickChangingContent
						:content="clickContent"
						:resetAfterXSeconds="5"
					></ClickChangingContent>
				</a>
			</div>
			<div class="card-footer-item" v-else-if="pinnedChat.disabled">
				Chat beitreten ist deaktiviert
			</div>
			<div class="card-footer-item" v-else-if="!pinnedChat.disabled && !chat">
				<a @click="joinChat"> Chat beitreten </a>
			</div>
			<div class="card-footer-item" v-else-if="!pinnedChat.disabled && chat">
				<a @click="openChat">Chat öffnen</a>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { EMailDefaults } from '../../Config';
import { EMail } from '../../email';
import { ChatContentTypes } from '../../email/ChatContentTypes';
import { Utils } from '../../email/utils';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { PinnedChat } from '../PinnedChats';
import { ActionTypes } from '../store/ActionTypes';
import { CustomPromise } from '../routes/CustomPromise';
import ClickChangingContent from './ClickChangeComponent/ClickChangeingContent.vue';
import {
	ClickContentObject,
	pinnedChatClickTriage,
} from './ClickChangeComponent/ClickChangeModel';

@Component({
	components: { ClickChangingContent },
})
export default class PinnedChatItem extends Vue {
	@Prop() private pinnedChat: PinnedChat;
	private clicked: boolean = false;
	private interval: any;

	private joinChat() {
		const subject = `${this.currentUser.email} whats to join the chat ${this.pinnedChat.chatId}`;
		const email = new EMail(
			{
				from: this.currentUser.email,
				to: [this.pinnedChat.adminEmail],
				subject: subject,
				date: Utils.dateToTimeString(Utils.getCurrentDateTime()),
				messageId: EMail.genId(this.currentProviderBaseUrl),
				mimeVersion: EMailDefaults.mimeVersion,
				contentType: EMailDefaults.contentType,
				chatVersion: EMailDefaults.chatVersion,
				chatId: this.pinnedChat.chatId,
				chatContent: ChatContentTypes.JOIN_REQUEST,
			},
			subject,
		);
		const promise: CustomPromise = {
			thenCallback: () => {
				this.clicked = true;
			},
			catchCallBack: () => {},
		};
		this.$store.dispatch(ActionTypes.SEND_EMAIL, {
			email: email,
			callbackPromise: promise,
		});
	}

	private openChat() {
		if (this.chat) {
			this.$router.push(`/chat/${this.chat.id}`);
		}
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get chat() {
		return this.$store.getters.getChat(this.pinnedChat.chatId);
	}

	get currentProviderBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}

	get clickContent(): ClickContentObject[] {
		return pinnedChatClickTriage;
	}
}
</script>

<style lang="scss"></style>
