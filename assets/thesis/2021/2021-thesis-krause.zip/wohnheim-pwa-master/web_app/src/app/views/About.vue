<template>
	<div class="container">
		<h1 class="title">Was ist diese App?</h1>
		<p>
			Die App ist ein Prototyp für eine Anwendung, die für soziale und
			organisatorische Belange in Studentenwohnheimen genutzt werden kann. Sie
			baut dabei nicht wie Facebook und Co auf klassischen zentralen
			Server-Systeme auf, sondern arbeitet dezentral über E-Mails. Das hat den
			Vorteil, dass deine Daten bei dir liegen und nicht bei den Betreibern der
			App.
		</p>

		<p>
			Unter anderen bietet die App die Möglichkeit, Chats zwischen zwei oder
			mehrere Personen zu führen. Viel interessanter sind jedoch die Funktionen,
			<i>Meldungen an den Hausmeister</i> und Inserat-Chats, über die
			Kleinanzeigen, eine Paketsuchzentrale, ein Foodsharing-Programm und noch
			vieles mehr abgebildet werden kann. Auf der Startseite findest du ein paar
			öffentliche Chats, den du gerne beitreten kannst!
		</p>

		<p>
			Auch ist ein Kontaktregister für wichtige Kontaktdaten rund um das
			Studentendorf Lübeck und die Lübecker Hochschulen enthalten
		</p>

		<h1 class="title mt-4">Wie logge ich mich ein?</h1>
		<p>
			Da diese App über E-Mails arbeitet, brauchst du dich nur bei einem
			E-Mail-Provider registrieren, bspw. web.de oder gmx. Du kannst natürlich
			auch deine E-Mail-Adresse deiner Hochschule verwenden. Gib einfach deine
			E-Mail-Adresse und das Passwort zu deinem Konto an und die App kann
			loslegen zu arbeiten. Der aktuelle Prototyp bietet leider noch einen
			geringen Ausbau an Sicherheit, weshalb die Daten, solange die App läuft,
			unverschlüsselt in deinem Browser liegen!
		</p>

		<h3 class="subtitle mt-4">TH-Lübeck</h3>
		Die TH-Lübeck benutzt statt der E-Mail die Matrikelnummer, um sich
		einzuloggen. Du musst einfach nur das Feld "E-Mail und Login-Name sind
		gleich" abhaken und deine Matrikelnummer und die E-Mail separat voneinander
		eintragen.

		<button class="button mt-4" @click="goBack">Zurück</button>
	</div>
</template>

<script lang="ts">
import Vue from 'vue';
import Component from 'vue-class-component';

@Component({})
export default class About extends Vue {
	private goBack() {
		this.$router.go(-1);
	}
}
</script>
