<template>
	<footer class="card-footer">
		<a
			class="card-footer-item"
			@click="startChatWithContact"
			v-if="chatsWithSameUsers.length == 0"
		>
			Start a chat with <b class="ml-1">{{ matchingUsersAsString }}</b>
		</a>
		<a
			class="card-footer-item"
			v-if="chatsWithSameUsers.length == 1"
			@click="openChat(chatsWithSameUsers[0].id)"
		>
			Reply over <b class="mb-1">{{ chatsWithSameUsers[0].name }}</b>
		</a>
		<div class="card-footer-item" v-if="chatsWithSameUsers.length > 1">
			<ul>
				<li
					class="block has-text-centered"
					v-for="chat in chatsWithSameUsers"
					:key="chat.id"
					@click="openChat(chat.id)"
				>
					<a
						>Reply over <b class="mb-1">{{ chat.name }}</b></a
					>
				</li>
			</ul>
		</div>
	</footer>
</template>

<script lang="ts">
import { User } from '../../email/User';
import { Utils } from '../../email/utils';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { CustomPromise } from '../routes/CustomPromise';
import { ActionTypes } from '../store/ActionTypes';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { AChat } from 'src/email/AChat';
import { Notification } from '../Notification';

@Component({
	components: {},
})
export default class CardFooterStartChat extends Vue {
	@Prop() private matchingUsers: User[];

	private startChatWithContact() {
		const callback: CustomPromise = {
			thenCallback: (chatId: string) => {
				this.openChat(chatId);
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Fehler beim erstellen des Chats',
						`Es ist ein Fehler beim erstellen des Chats aufgetreten! `,
						3,
						'danger',
					),
				);
				console.error('CardFooterStartChat', err);
			},
		};
		this.$store.dispatch(ActionTypes.CREATE_CHAT, {
			name: `Chat with ${this.matchingUsersAsString} and ${this.currentUser.email}`,
			inviteMembers: this.matchingUsers.map((user) => user.email),
			isPublic: false,
			onlyAdminsCanSend: false,
			type: ChatType.NORMAL,
			callbackPromise: callback,
		});
	}

	private openChat(chatId: string) {
		this.$router.push(`/chat/${chatId}`);
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get chatsWithSameUsers() {
		// only normal chats will displyed
		const chats = this.$store.getters
			.getChatWithExactUserMatch(this.matchingUsers.concat(this.currentUser))
			.filter((chat: AChat) => chat.type == ChatType.NORMAL);
		return chats;
	}

	get matchingUsersAsString() {
		return Utils.userArrayToString(this.matchingUsers);
	}
}
</script>
