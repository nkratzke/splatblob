<template>
	<div class="field" :id="id">
		<label class="label">{{ label }}</label>
		<div class="controller">
			<textarea
				:class="inputClass"
				:placeholder="placeholder"
				:value="value"
				@input="setValue"
			></textarea>
		</div>
		<p v-if="!valid" class="help">{{ errorText }}</p>
	</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component({
	components: {},
})
/**
 * Custom Events:
 *  valueChanged: string => if the value has changed
 *  validChanged: boolean => if the valid status has changed
 */
export default class TextAreaField extends Vue {
	@Prop() private label: string;
	@Prop() private placeholder: string;
	@Prop() private errorText: string;
	@Prop() private defaultValue: string;
	@Prop() private id: string;
	private value = '';
	private valid = false;

	mounted() {
		this.value = this.defaultValue;
	}

	setValue(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.value = value;
		this.valid = value.length > 0;
		this.$emit('valueChanged', { value: this.value, from: this.id });
		this.$emit('validChanged', { value: this.valid, from: this.id });
	}

	get inputClass() {
		return `textarea ${this.valid ? 'is-success' : 'is-danger'}`;
	}
}
</script>

<style lang="scss"></style>
