<template>
	<div>
		<p>Email Pull Controller</p>
		<button v-if="!pulls" @click="startPull" class="button">Start</button>
		<button v-else @click="stopPull" class="button">Stop</button>
		<input
			class="input"
			style="width: 50px"
			type="number"
			v-model="interval"
			min="2"
		/>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { WebWorkerResponseListener } from '../../WebWorkerEvents/WebWorkerResponseListener';
import { WebWorkerEventType } from '../../WebWorkerEvents/WebWorkerEventType';
import { WebWorkerEvent } from '../../WebWorkerEvents/WebWorkerEvent';
import { Config } from '../../Config';

@Component({
	components: {},
})
export default class PullController extends Vue {
	private responseListener: WebWorkerResponseListener = new WebWorkerResponseListener();
	private pulls: boolean = true;
	private intervalTime: number = Config.defaultEmailPullInterval;

	get interval() {
		return this.intervalTime;
	}

	set interval(newValue: number) {
		this.intervalTime = newValue;
		this.changeIntervalTime(newValue);
	}

	changeIntervalTime(newTime: number) {
		this.responseListener
			.sendEvent(
				new WebWorkerEvent(
					WebWorkerEventType.CHANGE_PULL_INTERVAL,
					{
						interval: newTime,
					},
					this.responseListener,
					false,
				),
			)
			.then(() => {
				this.pulls = true;
			});
	}

	startPull() {
		this.responseListener
			.sendEvent(
				new WebWorkerEvent(
					WebWorkerEventType.START_PULL,
					{},
					this.responseListener,
					false,
				),
			)
			.then(() => {
				this.pulls = true;
			});
	}

	stopPull() {
		this.responseListener
			.sendEvent(
				new WebWorkerEvent(
					WebWorkerEventType.STOP_PULL,
					{},
					this.responseListener,
					false,
				),
			)
			.then(() => {
				this.pulls = false;
			});
	}
}
</script>

<style lang="scss" scoped>
p {
	font-size: 0.8rem;
	text-align: left;
}

.pull-controller {
	z-index: 1000;
	position: absolute;
	top: 0;
	right: 0;
	background-color: lightgray;
	padding: 0.5rem;
	box-shadow: 1px 1px 3px black;
}
</style>
