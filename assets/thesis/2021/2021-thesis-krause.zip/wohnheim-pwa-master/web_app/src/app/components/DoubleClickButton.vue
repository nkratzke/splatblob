<template>
	<button @click="click" :class="buttonClass">
		<span v-if="!firstClick">{{ content }}</span>
		<span v-else>{{ contentFirstClick }}</span>
	</button>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({})
export default class DoubleClickButton extends Vue {
	@Prop() private time: number;
	@Prop() private firstClickClass: string;
	@Prop() private content: string;
	@Prop() private contentFirstClick: string;
	private firstClick = false;

	private click(event: MouseEvent) {
		if (!this.firstClick) {
			this.firstClick = true;
			setTimeout(() => {
				this.firstClick = false;
			}, this.time || 1000);
		} else {
			this.$emit('click', event);
		}
	}

	get buttonClass() {
		return `button ${this.firstClick ? this.firstClickClass : ''}`;
	}
}
</script>
