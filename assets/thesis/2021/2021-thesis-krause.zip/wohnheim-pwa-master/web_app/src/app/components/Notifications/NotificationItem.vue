<template>
	<div :class="messageClass">
		<div class="message-header">
			<p>{{ notification.title }}</p>
			<button class="delete" aria-label="delete" @click="remove"></button>
		</div>
		<div class="message-body">
			{{ notification.message }}
		</div>
	</div>
</template>

<script lang="ts">
import { Notification } from '../../Notification';
import { ActionTypes } from '../../store/ActionTypes';
import Vue from 'vue';
import Component from 'vue-class-component';
import { Prop } from 'vue-property-decorator';
@Component({
	components: {},
})
export default class NotificationItem extends Vue {
	@Prop() private notification: Notification;

	private remove() {
		this.$store.dispatch(ActionTypes.REMOVE_NOTIFICATION, this.notification);
	}

	get messageClass() {
		const color = this.notification.color.includes('is-')
			? this.notification.color.substring(3)
			: this.notification.color;
		return `message is-${color}`;
	}
}
</script>
