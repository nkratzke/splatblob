<template>
	<div class="container columns chat-overview-item is-mobile" @click="viewChat">
		<font-awesome-icon
			:icon="icon"
			class="column chat-overview-image is-narrow is-vcentered"
		></font-awesome-icon>
		<div class="column">
			<h1 v-if="filterSubStrings">
				<p>
					{{ filterSubStrings[0]
					}}<b class="has-text-success">{{ filterSubStrings[1] }}</b
					>{{ filterSubStrings[2] }}
				</p>
			</h1>
			<h1 v-else>
				<b>{{ chat.name }}</b>
			</h1>
			<div v-if="chat.type == chatTypes.NORMAL">{{ lastMessageString }}</div>
		</div>
	</div>
</template>

<script lang="ts">
import { ChatType } from '../../../email/dexie_interfaces/IChat';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Chat } from '../../../email/Chat';

@Component({
	components: {},
})
export default class ChatOverviewItem extends Vue {
	@Prop() private chat: Chat;

	get lastMessage() {
		return this.chat.lastMessage;
	}

	get lastMessageString() {
		let lastMessage = this.lastMessage.toString().trim();
		if (lastMessage.length > 40) {
			lastMessage = `${lastMessage.substring(0, 40)}...`;
		}
		return lastMessage;
	}

	viewChat() {
		this.$router.push(`/chat/${this.chat.id}`);
	}

	get filterSubStrings() {
		const filter = this.$store.state.filter;
		const name = this.chat.name;
		const index = name.toLowerCase().indexOf(filter);
		console.log(name, filter, index);
		if (index >= 0) {
			return [
				name.substring(0, index),
				name.substring(index, index + filter.length),
				name.substring(index + filter.length),
			];
		} else {
			return null;
		}
	}

	get icon() {
		return this.chat.type === ChatType.AD ? 'boxes' : 'user';
	}

	get chatTypes() {
		return ChatType;
	}
}
</script>

<style lang="scss">
@import 'node_modules/bulma/sass/utilities/initial-variables';
.chat-overview-item {
	min-height: 80px;
	background-color: $grey-light;
	&:hover {
		background-color: $grey-lighter;
	}
}

.chat-overview-image {
	fill: green;
	height: 80px;
	width: auto !important;
}
</style>
