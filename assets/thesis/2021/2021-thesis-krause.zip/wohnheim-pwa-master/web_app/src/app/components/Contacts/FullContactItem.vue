<template>
	<div class="card mb-4">
		<header class="card-header" @click="toggleContentIsVisible">
			<p class="card-header-title">
				<span v-if="fullContact.position" class="mr-1"
					>{{ fullContact.position }} -
				</span>
				{{ fullContact.name }}
			</p>
			<a :class="headerIconClass">
				<font-awesome-icon icon="angle-down"></font-awesome-icon>
			</a>
		</header>
		<div class="card-content" v-if="contentIsVisible">
			<div class="content">
				<p v-if="fullContact.email">
					<b>E-Mail: </b> <span>{{ fullContact.email }}</span>
				</p>
				<p v-if="fullContact.phoneNumber">
					<b>Phone number: </b> <span>{{ fullContact.phoneNumber }}</span>
				</p>
				<p v-if="fullContact.office">
					<b>Office: </b><span>{{ fullContact.office }}</span>
				</p>
				<div class="ml-3" v-if="fullContact.open">
					<div v-if="fullContact.open.from && fullContact.open.to">
						<p>
							<b>Opened between:</b> {{ fullContact.open.from }} -
							{{ fullContact.open.to }}
						</p>
					</div>
					<div v-if="fullContact.open.asString">
						{{ fullContact.open.asString }}
					</div>
				</div>
			</div>
		</div>
		<CardFooterStartChat
			v-if="contentIsVisible && fullContact.email"
			:matchingUsers="[contactUser]"
		></CardFooterStartChat>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { IFullContact } from '../../importantContacts';
import { User } from '../../../email/User';
import CardFooterStartChat from '../CardFooterStartChat.vue';

@Component({
	components: { CardFooterStartChat },
})
export default class FullContactItem extends Vue {
	@Prop() private fullContact: IFullContact | null;
	private contentIsVisible: boolean = false;

	private toggleContentIsVisible() {
		this.contentIsVisible = !this.contentIsVisible;
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get contactUser() {
		return new User(
			this.fullContact?.email || '',
			this.fullContact?.email || '',
		);
	}

	get headerIconClass() {
		return `card-header-icon ${this.contentIsVisible ? 'rotated' : ''}`;
	}
}
</script>
