<template>
	<section class="container">
		<h1 class="title">Auswahl der Postfächer</h1>
		<p class="subtitle">
			In welchen Postfächern dürfen wir nach neuen E-Mails für dich suchen?
		</p>

		<p>
			Wenn keine neuen E-Mails gefunden werden, kann das auch daran liegen, dass
			die E-Mails in einem Postfach landen, welches wir nicht durchsuchen
			dürfen!
		</p>

		<div
			class="mt-4 columns"
			v-for="(mailboxRow, index) in useMailboxes"
			:key="index"
		>
			<div v-for="mailbox in mailboxRow" :key="mailbox.mailbox" class="column">
				<label class="checkbox">
					<input
						type="checkbox"
						:checked="mailbox.use"
						@change="updateUseMailbox(mailbox)"
					/>
					{{ mailbox.mailbox }}
				</label>
			</div>
		</div>
		<div class="field mt-4">
			<div class="control">
				<button @click="goHome" class="button">Speichern</button>
			</div>
		</div>
	</section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { UseMailbox } from '../../email/UseMailbox';
import { AppUtils } from '../AppUtils';
import { ActionTypes } from '../store/ActionTypes';

@Component({
	components: {},
})
export default class Mailboxes extends Vue {
	get useMailboxes() {
		return AppUtils.toColumns(this.$store.state.mailboxes, 3);
	}

	private goHome() {
		this.$router.push('/');
	}

	private updateUseMailbox(mailbox: UseMailbox) {
		mailbox.use = !mailbox.use;
		this.$store.dispatch(ActionTypes.CHANGE_USE_MAILBOX, mailbox);
	}
}
</script>

<style lang="scss"></style>
