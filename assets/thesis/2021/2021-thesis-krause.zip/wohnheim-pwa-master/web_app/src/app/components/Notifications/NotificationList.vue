<template>
	<div class="container notification-list">
		<NotificationItem
			v-for="notification in notifications"
			:key="notification.id"
			:notification="notification"
		></NotificationItem>
	</div>
</template>

<script lang="ts">
import Vue from 'vue';
import Component from 'vue-class-component';
import NotificationItem from './NotificationItem.vue';
@Component({
	components: { NotificationItem },
})
export default class NotificationList extends Vue {
	get notifications() {
		return this.$store.state.notifications;
	}
}
</script>

<style lang="scss" scoped>
.notification-list {
	position: absolute;
	max-width: 100%;
	width: 50rem;
	top: 0;
	left: 50%;
	transform: translate(-50%, 0);
	z-index: 40;
}
</style>
