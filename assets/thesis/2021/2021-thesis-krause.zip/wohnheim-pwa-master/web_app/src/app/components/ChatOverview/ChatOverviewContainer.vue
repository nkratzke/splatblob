<template>
	<div class="container">
		<div v-if="!chats.length > 0">
			<div v-if="filter.length > 0">
				<div class="box">
					<p>
						Mit dem Filter "{{ filter }}" konnten keine Chats gefunden werden.
						😅
					</p>
					<p>Probier es mit einem anderen aus</p>
					<button class="button" @click="clearFilter">Filter löschen</button>
				</div>

				<div v-if="isFilterEmail" class="box">
					<p>Du kannst einen Chat mit {{ filter }} beginnen.</p>

					<CreateOpenChat :sameUsers="[userFromFilter]"></CreateOpenChat>
				</div>
			</div>
			<div v-else>Du bist leider in keinem Chat 😞</div>
		</div>
		<ChatOverviewItem
			v-else
			v-for="chat in chats"
			:key="chat.id"
			:chat="chat"
		/>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import InviteMessageContainer from '../InviteMessageContainer.vue';
import ChatOverviewItem from './ChatOverviewItem.vue';
import { Chat } from '../../../email/Chat';
import { ChatType } from '../../../email/dexie_interfaces/IChat';
import { MutationTypes } from '../../store/MutationTypes';
import { Utils } from '../../../email/utils';
import CreateOpenChat from '../CreateOpenChat.vue';
import { User } from '../../../email/User';

@Component({
	components: { InviteMessageContainer, ChatOverviewItem, CreateOpenChat },
})
export default class ChatOverviewContainer extends Vue {
	@Prop() private chatTypeFilter: ChatType;

	private clearFilter() {
		this.$store.commit(MutationTypes.CHANGE_FILTER, '');
	}

	get filter(): string {
		return this.$store.state.filter;
	}

	get userFromFilter(): User {
		return new User(this.filter, this.filter);
	}

	get isFilterEmail(): boolean {
		return Utils.isValidEmailAddress(this.filter);
	}

	get chats() {
		if (this.chatTypeFilter) {
			return this.$store.state.chats.filter((chat: Chat) => {
				return (
					chat.name.toLowerCase().search(this.filter.toLowerCase()) != -1 &&
					chat.type == this.chatTypeFilter
				);
			});
		}
		if (this.filter.length > 0) {
			return this.$store.state.chats.filter((chat: Chat) => {
				return chat.name.toLowerCase().search(this.filter.toLowerCase()) != -1;
			});
		} else {
			return this.$store.state.chats;
		}
	}
}
</script>

<style lang="scss"></style>
