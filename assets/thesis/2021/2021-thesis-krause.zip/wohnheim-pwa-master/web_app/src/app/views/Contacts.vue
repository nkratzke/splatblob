<template>
	<div class="container">
		<h1 class="title">Contacts</h1>

		<div class="tabs is-fullwidth">
			<ul>
				<li :class="generalContactTabClass">
					<a @click="showGeneralContacts">
						<span class="icon"
							><i class="fas fa-image" aria-hidden="true"></i
						></span>
						<span>Allgemeine Kontakte</span>
					</a>
				</li>
				<li :class="yourContactsTabClass">
					<a @click="showYourContacts">
						<span class="icon"
							><i class="fas fa-music" aria-hidden="true"></i
						></span>
						<span>Deine Kontakte</span>
					</a>
				</li>
			</ul>
		</div>

		<div v-if="generalContactsVisible">
			<div class="tabs is-toggle is-fullwidth">
				<ul>
					<li :class="allIsAcitve">
						<a @click="changeList(lists.ALL)">
							<span class="icon is-small">
								<font-awesome-icon icon="globe"></font-awesome-icon>
							</span>
							<span>Alle</span>
						</a>
					</li>
					<li :class="wohnheimIsActive" @click="changeList(lists.WOHNHEIM)">
						<a>
							<span class="icon is-small">
								<font-awesome-icon icon="house-user"></font-awesome-icon>
							</span>
							<span>Studentenwohnheim Lübeck</span>
						</a>
					</li>
					<li :class="thLuebeckIsActive" @click="changeList(lists.TH_LUEBECK)">
						<a>
							<span class="icon is-small">
								<img
									src="https://www.th-luebeck.de/fileadmin/favicons/favicon.ico"
									alt=""
								/>
							</span>
							<span>Technische Hochschule Lübeck</span>
						</a>
					</li>
					<li
						:class="uniLuebeckIsAcitve"
						@click="changeList(lists.UNI_LUEBECK)"
					>
						<a>
							<span class="icon is-small">
								<img
									src="https://www.uni-luebeck.de/favicon.ico"
									alt="Logo Universität zu Lübeck"
								/>
							</span>
							<span>University Lübeck</span>
						</a>
					</li>
					<li
						:class="musikLuebeckIsAcitve"
						@click="changeList(lists.MUSIK_LUEBECK)"
					>
						<a>
							<span class="icon is-small">
								<img
									src="https://www.mh-luebeck.de/fileadmin/templates/mhl/images/favicon.ico"
									alt=""
								/>
							</span>
							<span>Musik Hochschule Lübeck</span>
						</a>
					</li>
					<li>
						<a :class="otherIsAcitve" @click="changeList(lists.OTHER)">
							<span class="icon is-small">
								<font-awesome-icon icon="globe"></font-awesome-icon>
							</span>
							<span>Andere</span>
						</a>
					</li>
				</ul>
			</div>

			<div>
				<div
					v-for="(contactRow, index) in currentListInColumns"
					:key="index"
					class="columns"
				>
					<div
						v-for="(contact, i) in contactRow"
						:key="contact.name + i"
						class="column"
					>
						<FullContactItem :fullContact="contact"> </FullContactItem>
					</div>
				</div>
			</div>
		</div>

		<div v-if="yourContactsVisible">
			<div
				class="columns"
				v-for="(contactsRow, index) in contacts"
				:key="index"
			>
				<div class="column" v-for="contact in contactsRow" :key="contact.email">
					<ContactItem :user="contact"> </ContactItem>
				</div>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import {
	IFullContact,
	wohnheim,
	thluebeck,
	uniluebeck,
	musikluebeck,
	other,
} from '../importantContacts';
import ContactItem from '../components/Contacts/ContactItem.vue';
import FullContactItem from '../components/Contacts/FullContactItem.vue';
import { AppUtils } from '../AppUtils';

enum Lists {
	ALL = 'ALL',
	WOHNHEIM = 'WOHNHEIM',
	TH_LUEBECK = 'TH_LUEBECK',
	UNI_LUEBECK = 'UNI_LUEBECK',
	MUSIK_LUEBECK = 'MUSIK_LUEBECK',
	OTHER = 'OTHER',
}

@Component({
	components: { ContactItem, FullContactItem },
})
export default class Contacts extends Vue {
	private generalContactsVisible: boolean = true;
	private yourContactsVisible: boolean = false;
	private allContacts: IFullContact[] = [].concat(
		wohnheim,
		thluebeck,
		uniluebeck,
		other,
		musikluebeck,
	);
	private currentList: IFullContact[] = this.allContacts;
	private currentListType: Lists = Lists.ALL;

	private changeList(list: Lists) {
		this.currentListType = list;
		switch (list) {
			case Lists.ALL:
				this.currentList = this.allContacts;
				break;
			case Lists.WOHNHEIM:
				this.currentList = wohnheim;
				break;
			case Lists.TH_LUEBECK:
				this.currentList = thluebeck;
				break;
			case Lists.UNI_LUEBECK:
				this.currentList = uniluebeck;
				break;
			case Lists.MUSIK_LUEBECK:
				this.currentList = musikluebeck;
				break;
			case Lists.OTHER:
				this.currentList = other;
				break;
		}
	}

	private showYourContacts() {
		this.yourContactsVisible = true;
		this.generalContactsVisible = false;
	}

	private showGeneralContacts() {
		this.generalContactsVisible = true;
		this.yourContactsVisible = false;
	}

	get currentListInColumns() {
		return AppUtils.toColumns(this.currentList, 2);
	}

	get allIsAcitve() {
		return `${this.currentListType === Lists.ALL ? 'is-active' : ''}`;
	}

	get wohnheimIsActive() {
		return `${this.currentListType === Lists.WOHNHEIM ? 'is-active' : ''}`;
	}

	get thLuebeckIsActive() {
		return `${this.currentListType === Lists.TH_LUEBECK ? 'is-active' : ''}`;
	}

	get uniLuebeckIsAcitve() {
		return `${this.currentListType === Lists.UNI_LUEBECK ? 'is-active' : ''}`;
	}

	get musikLuebeckIsAcitve() {
		return `${this.currentListType === Lists.MUSIK_LUEBECK ? 'is-active' : ''}`;
	}

	get otherIsAcitve() {
		return `${this.currentListType === Lists.OTHER ? 'is-active' : ''}`;
	}

	get lists() {
		return Lists;
	}

	get generalContactTabClass() {
		return this.generalContactsVisible ? 'is-active' : '';
	}

	get yourContactsTabClass() {
		return this.yourContactsVisible ? 'is-active' : '';
	}

	get contacts() {
		return AppUtils.toColumns(this.$store.state.users, 2);
	}
}
</script>

<style lang="scss" scoped></style>
