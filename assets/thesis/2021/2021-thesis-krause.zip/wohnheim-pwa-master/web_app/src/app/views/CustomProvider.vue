<template>
	<section>
		<h1 class="title">Nutze einen anderen Provider</h1>
		<button @click="back" class="button">Zurück</button>

		<form>
			<div class="field">
				<label class="checkbox">
					<div class="control">
						<input type="checkbox" v-model="customId" />
						Spezifische ID?
					</div>
				</label>
			</div>

			<!-- id -->
			<InputField
				label="Spezielle Provider-ID"
				placeholder="web.de-12345"
				type="text"
				errorText="Ist keine valide ID."
				validator="NOT_EMPTY"
				:defaultValue="provider.id"
				id="id"
				@valueChanged="valueChanged"
				@validChanged="validChanged"
				v-if="customId"
			>
			</InputField>

			<!-- Name -->
			<InputField
				label="Provider-Name"
				placeholder="Web.de"
				type="text"
				errorText="Ist kein valider Name."
				validator="NOT_EMPTY"
				:defaultValue="provider.name"
				id="name"
				@valueChanged="valueChanged"
				@validChanged="validChanged"
			>
			</InputField>

			<!-- Base URL -->
			<InputField
				label="Basis URL"
				placeholder="web.de"
				type="text"
				errorText="Ist keine valide URL!"
				validator="NOT_EMPTY"
				:defaultValue="provider.baseUrl"
				id="baseUrl"
				@valueChanged="valueChanged"
				@validChanged="validChanged"
			>
			</InputField>
			<div
				aria-label="IMAP connection data"
				class="field is-grouped is-grouped-multiline"
			>
				<!-- IMAP URL -->
				<InputField
					label="IMAP URL"
					placeholder="imap.web.de"
					type="text"
					errorText="Ist keine valide URL!"
					validator="NOT_EMPTY"
					:defaultValue="provider.imapUrl"
					id="imapUrl"
					@valueChanged="valueChanged"
					@validChanged="validChanged"
				>
				</InputField>
				<!-- IMAP Port -->
				<NumberInputField
					label="IMAP Port"
					errorText="Wähle einen Port größer als 0 aus!"
					:defaultValue="provider.imapPort"
					min="0"
					id="imapPort"
					@valueChanged="valueChanged"
					@validChanged="validChanged"
				>
				</NumberInputField>
				<!-- IMAP Encryption -->
				<div class="field">
					<label class="label">IMAP Encryption</label>
					<div class="select">
						<select v-model="provider.imapEncryption">
							<option :value="encryption.SSL_TLS" selected>
								{{ encryption.SSL_TLS }}
							</option>
							<option :value="encryption.STARTTLS">
								{{ encryption.STARTTLS }}
							</option>
						</select>
					</div>
				</div>
			</div>
			<!-- SMTP connection -->
			<div
				aria-label="SMTP connection data"
				class="field is-grouped is-grouped-multiline"
			>
				<!-- SMTP URL -->
				<InputField
					label="SMTP URL"
					placeholder="smtp.web.de"
					type="text"
					errorText="Ist keine valide URL!"
					validator="NOT_EMPTY"
					:defaultValue="provider.smtpUrl"
					id="smtpUrl"
					@valueChanged="valueChanged"
					@validChanged="validChanged"
				>
				</InputField>
				<!-- SMTP Port -->
				<NumberInputField
					label="SMTP Port"
					errorText="Wähle einen Port größer als 0 aus!"
					:defaultValue="provider.smtpPort"
					min="0"
					id="smtpPort"
					@valueChanged="valueChanged"
					@validChanged="validChanged"
				>
				</NumberInputField>
				<!-- SMTP Encryption -->

				<div class="field">
					<label class="label">SMTP Verschlüsselung</label>
					<div class="select">
						<select v-model="provider.smtpEncryption">
							<option :value="encryption.SSL_TLS">
								{{ encryption.SSL_TLS }}
							</option>
							<option :value="encryption.STARTTLS" selected>
								{{ encryption.STARTTLS }}
							</option>
						</select>
					</div>
				</div>
			</div>
			<div class="field">
				<label class="checkbox">
					<div class="control">
						<input type="checkbox" v-model="shareProvider" disabled />
						Teile ihn mit anderen Nutzern
					</div>
				</label>
			</div>
		</form>

		<div v-if="providerEdit.isValid">
			{{ providerEdit.reason }}
		</div>

		<!-- Submit Button -->
		<div class="field is-grouped mb-5">
			<div class="control">
				<button
					class="button is-primary"
					@click="checkProvider"
					:disabled="!canSend"
				>
					Speiche den Provider
				</button>
			</div>
			<div class="control">
				<button class="button is-light" @click="back">Zurück zum Login</button>
			</div>
		</div>
	</section>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import InputField from '../components/InputField.vue';
import NumberInputField from '../components/NumberInputField.vue';
import { IProvider } from '../../email/dexie_interfaces/IProvider';
import { MutationTypes } from '../store/MutationTypes';
import { ActionTypes } from '../store/ActionTypes';
import { Encryption } from '../../email/interfaces/provider';
import { CustomPromise } from '../routes/CustomPromise';
import { Notification } from '../Notification';

@Component({
	components: { InputField, NumberInputField },
})
export default class CustomProvider extends Vue {
	private providerValid = {
		id: false,
		name: false,
		baseUrl: false,
		smtpUrl: false,
		smtpPort: true,
		smtpEncryption: true,
		imapUrl: false,
		imapPort: true,
		imapEncryption: true,
	};

	private shareProvider: boolean = true;
	private customId: boolean = false;

	back() {
		this.$router.push('/login');
	}

	get encryption() {
		return Encryption;
	}

	get provider() {
		return this.$store.state.providerEdit.provider;
	}

	get providerEdit() {
		return this.$store.state.providerEdit;
	}

	valueChanged(payload) {
		if (payload.from === 'name' && !this.customId) {
			const id = (payload.value as string).toLowerCase();
			this.$store.commit(MutationTypes.CHANGE_PROVIDER_EDIT_FIELD_VALUE, {
				field: 'id',
				value: id,
			});
		}
		this.$store.commit(MutationTypes.CHANGE_PROVIDER_EDIT_FIELD_VALUE, {
			field: payload.from,
			value: payload.value,
		});
	}

	validChanged(payload) {
		if (payload.from === 'name' && !this.customId) {
			this.providerValid['id'] = payload.value;
		}
		this.providerValid[payload.from] = payload.value;
	}

	get canSend() {
		return (
			Object.keys(this.providerValid).filter((key) => {
				return !this.providerValid[key];
			}).length == 0
		);
	}

	checkProvider() {
		const callback: CustomPromise = {
			thenCallback: () => {
				this.$router.go(-1);
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Fehler beim erstellen des Providers',
						err.data,
						-1,
						'danger',
					),
				);
			},
		};
		this.$store.dispatch(ActionTypes.CREATE_PROVIDER, {
			provider: this.provider,
			share: this.shareProvider,
			callbackPromise: callback,
		});
	}
}
</script>

<style lang="scss">
.notice {
	color: red;
}
</style>
