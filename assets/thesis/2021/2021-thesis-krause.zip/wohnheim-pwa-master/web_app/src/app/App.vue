<template>
	<div id="app" style="overflow: scroll; height: 100vh">
		<div v-if="!proxyStatus.available" class="container">
			<div class="">
				<EmailInAJar></EmailInAJar>
				<h1 class="loading">Loading</h1>
			</div>
		</div>
		<div v-else-if="showRouterView" class="">
			<AppNavbar></AppNavbar>
			<router-view class="mt-6 content-height"></router-view>
		</div>
		<div v-else>
			<div>Please login :)</div>
			<router-link class="button is-primary" to="/login">Login</router-link>
		</div>
		<NotificationList></NotificationList>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import EmailInAJar from './components/EmailInAJar.vue';
import AppNavbar from './components/AppNavbar.vue';
import FloatingButton from './components/FloatingButton.vue';
import NotificationList from './components/Notifications/NotificationList.vue';

@Component({
	components: {
		EmailInAJar,
		AppNavbar,
		FloatingButton,
		NotificationList,
	},
})
export default class App extends Vue {
	get showRouterView() {
		return (
			(this.loginUser && this.loginUser.password) ||
			this.$route.name === 'Login' ||
			this.$route.name === 'CustomProvider' ||
			this.$route.name === 'About' ||
			this.$route.name === 'Contacts'
		);
	}

	get proxyStatus() {
		return this.$store.state.proxyStatus;
	}

	get loginUser() {
		return this.$store.state.loginUser;
	}
}
</script>

<style lang="scss">
.content-height {
	height: calc(100vh- 1.5rem - 3.5rem);
	padding: 0.75rem;
}
</style>
