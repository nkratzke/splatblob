<template>
	<span @click="onClick">{{ currentMessage }}</span>
</template>

<script lang="ts">
import Vue from 'vue';
import Component from 'vue-class-component';
import { Prop } from 'vue-property-decorator';
import { ClickContentObject } from './ClickChangeModel';

@Component({})
export default class ClickChangingContent extends Vue {
	@Prop() private content: ClickContentObject[];
	@Prop() private resetAfterXSeconds: number;
	private counter: number = 0;
	private timeout: any;
	private defaultMessage: string;
	private currentMessage = 'Empty message';

	mounted() {
		this.defaultMessage = this.content[0].message;
		this.resetCounter();
	}

	private onClick() {
		this.counter += 1;
		clearTimeout(this.timeout);
		this.timeout = setTimeout(
			this.resetCounter,
			(this.resetAfterXSeconds || 5) * 1000,
		);

		this.content.forEach((content) => {
			if (content.onCount <= this.counter) {
				this.currentMessage = content.message;
			}
		});
	}

	private resetCounter() {
		this.counter = 0;
		this.currentMessage = this.defaultMessage;
	}
}
</script>
