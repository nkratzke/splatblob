<template>
	<div class="has-background-primary is-fixed-top">
		<nav
			class="navbar mb-0 container has-background-primary is-fixed-top"
			role="navigation"
			aria-label="main navigation"
		>
			<div class="navbar-brand">
				<a
					class="navbar-item fixed-width"
					@click="goBack"
					v-if="currentRoute !== '/'"
				>
					<font-awesome-icon
						v-if="isChat"
						icon="arrow-left"
						size="2x"
					></font-awesome-icon>
					<font-awesome-icon v-else icon="home" size="2x"></font-awesome-icon>
				</a>
				<img alt="Logo" v-else src="../mail.svg" class="navbar-item" />

				<div
					class="navbar-menu is-active has-background-primary chat-menu"
					v-if="isChat"
				>
					<div class="navbar-start">
						<a
							class="navbar-item"
							@click="toChatDetails"
							role="button"
							v-if="!isChatDetail"
						>
							<span class="no-word-wrap">{{ currentChat.name }}</span>
						</a>
						<div class="navbar-item" @click="toChatDetails" v-else>
							<span class="no-word-wrap">{{ currentChat.name }}</span>
						</div>
					</div>
				</div>

				<!-- only visible if the window width is small enough-->
				<a
					role="button"
					:class="navbarBurger"
					@click="toggleNavbar"
					v-if="!isChat"
				>
					<span aria-hidden="true"></span>
					<span aria-hidden="true"></span>
					<span aria-hidden="true"></span>
				</a>

				<div
					role="button"
					class="navbar-burger"
					v-if="isChat && !isChatDetail"
					@click="toChatDetails"
				>
					<a aria-hidden="true" class="visit-chat navbar-item">
						<font-awesome-icon
							v-if="isChat"
							icon="info"
							size="2x"
						></font-awesome-icon>
					</a>
				</div>
			</div>

			<div :class="navbarMenu">
				<div class="navbar-start" v-if="!isChat">
					<!--<a class="navbar-item" @click="createChat"> Create Chat </a>-->

					<a class="navbar-item" @click="toContacts"> Kontakte </a>

					<a class="navbar-item" @click="toMailboxes"> Mailboxes </a>

					<a class="navbar-item" @click="toAbout"> About </a>

					<div class="navbar-item has-dropdown is-hoverable">
						<a class="navbar-link"> Mehr </a>

						<div class="navbar-dropdown has-background-primary-light">
							<a class="navbar-item" @click="joinChat"> Join Chat </a>

							<a class="navbar-item" @click="pullMessages"> Pull manuel </a>

							<hr class="navbar-divider" />

							<a class="navbar-item">
								<pull-controller></pull-controller>
							</a>

							<hr class="navbar-divider" />

							<a
								class="navbar-item"
								v-if="chatsWithSameUsers.length == 0"
								@click="startChatWithContact"
							>
								Fehler melden
							</a>

							<a
								class="navbar-item"
								v-if="chatsWithSameUsers.length == 1"
								@click="openChat(chatsWithSameUsers[0].id)"
							>
								<span
									>Fehler über
									<b ml-2 mr-2>{{ chatsWithSameUsers[0].name }}</b> melden</span
								>
							</a>

							<div
								class="navbar-item has-dropdown"
								v-if="chatsWithSameUsers.length > 1"
							>
								<div class="navbar-item">Fehler melden über</div>
								<div class="navbar-dropdown">
									<div
										class="navbar-item"
										v-for="chat in chatsWithSameUsers"
										:key="chat.id"
										@click="openChat(chatsWithSameUsers[chat.id])"
									>
										{{ chat.name }}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="navbar-end">
					<a
						class="navbar-item"
						v-if="currentRoute != '/login' && !isChat"
						@click="logout"
					>
						Ausloggen
					</a>
					<a
						class="navbar-item"
						v-if="isChat && !isChatDetail"
						@click="toChatDetails"
					>
						<font-awesome-icon icon="info" size="2x"></font-awesome-icon>
					</a>
				</div>
			</div>
		</nav>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import MessageList from '../components/MessageView/MessageList.vue';
import SendMessage from '../components/SendMessage.vue';
import PullController from '../components/PullController.vue';
import { WebWorkerEventHub } from '../../WebWorkerEvents/WebWorkerEventHub';
import { WebWorkerEvent } from '../../WebWorkerEvents/WebWorkerEvent';
import { WebWorkerEventType } from '../../WebWorkerEvents/WebWorkerEventType';
import { CustomPromise } from '../routes/CustomPromise';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { Utils } from '../../email/utils';
import { ActionTypes } from '../store/ActionTypes';
import { AChat } from 'src/email/AChat';
import { IFullContact, developer } from '../importantContacts';
import { User } from '../../email/User';
import { Notification } from '../Notification';

@Component({
	components: { SendMessage, MessageList, PullController },
})
export default class AppNavbar extends Vue {
	private showNavbar: boolean = false;
	private developer: IFullContact = developer;

	get currentRoute() {
		return this.$route.path;
	}

	get navbarBurger() {
		return `navbar-burger ${this.showNavbar ? 'is-active' : ''}`;
	}

	get navbarMenu() {
		return `navbar-menu ${this.showNavbar ? 'is-active' : ''}`;
	}

	get isChat() {
		return this.currentRoute.search('/chat') === 0;
	}

	get isChatDetail() {
		return this.currentRoute.search('/chat-details/') === 0;
	}

	get chatIdFromUrl() {
		return this.isChat ? this.currentRoute.split('/')[2] : 'no-chat-found';
	}

	get currentChat() {
		if (this.isChat) {
			return this.$store.getters.getChat(this.chatIdFromUrl);
		}
		return null;
	}

	private createChat() {
		this.goTo('/new-chat');
	}

	private joinChat() {
		this.goTo('/join_chat');
	}

	private toAbout() {
		this.goTo('/about');
	}

	private logout() {
		this.goTo('/login');
	}

	private toMailboxes() {
		this.goTo('/mailboxes');
	}

	private toContacts() {
		this.goTo('/contacts');
	}

	private toChatDetails() {
		if (this.isChat && !this.isChatDetail) {
			this.goTo(`/chat-details/${this.currentChat.id}`);
		}
	}

	private goTo(path: string) {
		if (this.$router.currentRoute.path !== path) {
			this.$router.push(path);
		}
		this.hideNavbar();
	}

	private goBack() {
		if (this.isChat) {
			this.$router.go(-1);
		} else {
			this.goHome();
		}
	}

	private goHome() {
		this.goTo('/');
	}

	private hideNavbar() {
		this.showNavbar = false;
	}

	private pullMessages() {
		WebWorkerEventHub.sendEvent(
			new WebWorkerEvent(WebWorkerEventType.PULL, {}, null, false),
		);
	}

	private toggleNavbar() {
		this.showNavbar = !this.showNavbar;
	}

	private startChatWithContact() {
		const callback: CustomPromise = {
			thenCallback: (chatId: string) => {
				this.openChat(chatId);
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Fehler beim erstellen des Chats',
						`Es ist ein Fehler beim erstellen des Chats aufgetreten! `,
						3,
						'info',
					),
				);
				console.error('CardFooterStartChat', err);
			},
		};
		this.$store.dispatch(ActionTypes.CREATE_CHAT, {
			name: `Chat with ${this.developer.email} and ${this.currentUser.email}`,
			inviteMembers: [this.developer.email],
			isPublic: false,
			onlyAdminsCanSend: false,
			type: ChatType.NORMAL,
			callbackPromise: callback,
		});
	}

	private openChat(chatId: string) {
		this.goTo(`/chat/${chatId}`);
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get chatsWithSameUsers() {
		// only normal chats will displyed
		const chats = this.$store.getters
			.getChatWithExactUserMatch([
				this.currentUser,
				new User(this.developer.email || '', this.developer.name),
			])
			.filter((chat: AChat) => chat.type == ChatType.NORMAL);
		return chats;
	}
}
</script>

<style lang="scss" scoped>
.chat-menu {
	box-shadow: none;
}

img {
	height: auto;
	width: 52px;
}

.visit-chat {
	top: 0.25rem;
	left: 0.6rem;
	position: relative;
	display: flex;
	align-items: center;
	background-color: unset;
}

.fixed-width {
	width: 4rem;
}

.no-word-wrap {
	white-space: nowrap;
	overflow: hidden;
}
</style>
