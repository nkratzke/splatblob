<template>
	<div>
		<div class="one-div"></div>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
	components: {},
})
export default class EmailInAJar extends Vue {}
</script>

<style lang="scss" scoped>
@import '../colors.scss';
$glass-size: 200px;
$glass-color: lightgray;
$glass-image: url('../mail.svg');
$glass-height: $glass-size / 4;
$glass-width: $glass-size / 2;

.center {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}

.one-div::before {
	content: '';
	position: absolute;
	height: $glass-size / 10;
	width: $glass-size;
	background-color: white;
	z-index: 1;
}

.one-div {
	position: relative;
	width: $glass-size;
	height: $glass-size;
	border-radius: 100%;
	background-color: $glass-color;
}

.one-div::after {
	content: '';
	position: absolute;
	top: 75px;
	left: 50px;
	width: $glass-width;
	height: $glass-height;
	background-image: $glass-image;
	background-size: contain;
	background-repeat: no-repeat;
	animation: swimming 3s infinite;
	animation-timing-function: linear;
}

@keyframes swimming {
	0% {
		top: 85px;
		left: 0px;
		transform: scaleX(0) rotate(45deg);
	}
	12.5% {
		top: 100px;
		transform: scaleX(1) rotate(22.5deg);
	}
	25% {
		top: 115px;
		left: 50px;
		transform: rotate(0deg) scaleX(1);
	}
	37.5% {
		top: 110px;
		transform: scaleX(1) rotate(-30deg);
	}
	50% {
		top: 85px;
		left: 110px;
		transform: scaleX(0) rotate(-40deg);
	}
	62.5% {
		top: 50px;
		transform: scaleX(-1) rotate(-30deg);
	}
	75% {
		top: 30px;
	}
	87.5% {
		top: 55px;
		transform: scaleX(-1) rotate(20deg);
	}
	100% {
		top: 85px;
		left: 0px;
		transform: scaleX(0) rotate(45deg);
	}
}

ul {
	position: absolute;
	bottom: 0.2rem;
	left: 0.2rem;
	width: 35%;
	color: gray;
	font-size: 0.7rem;
	padding: 0;
	margin: 0.5rem;
	list-style: none;
}

a {
	color: gray;
}
</style>
