<template>
	<div class="message-item-container">
		<!-- 
			invite
			promote
			delete 
		-->
		<div
			class="block note"
			v-if="
				message.chatContent === chatContents.INVITE ||
				message.chatContent === chatContents.PROMOTE ||
				message.chatContent === chatContents.DELETE_USER_FROM_CHAT
			"
		>
			<p>{{ message.toString().trim() }}</p>
		</div>

		<!-- text message -->
		<div
			:class="textClass"
			v-else-if="message.chatContent === chatContents.TEXT_MESSAGE"
		>
			<p :class="showSender">
				<span v-if="user.nickname">{{ user.nickname }}</span>
				<span v-else>{{ user.email }}</span>
			</p>
			<p>
				{{ message.toString().trim() }}
			</p>
		</div>

		<!-- news -->
		<div
			v-else-if="message.chatContent === chatContents.NEWS"
			class="hero is-info"
		>
			<div class="hero-body">
				<div class="container">
					<h1 class="title">{{ message.title }}</h1>
					<h2 class="subtitle">{{ message.message }}</h2>
					<p class="show-sender">
						From:
						<span v-if="message.sender.nickname">{{
							message.sender.nickname
						}}</span>
						<span v-else>{{ message.sender.email }}</span>
					</p>
				</div>
			</div>
		</div>

		<!-- unhandled! -->
		<div v-else>
			<p class="note">Unhandled message design</p>
			<p>{{ message.toString().trim() }}</p>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { IMessage } from '../../../email/dexie_interfaces/IMessage';
import { ChatContentTypes } from '../../../email/ChatContentTypes';

@Component({
	components: {},
})
export default class MessageItem extends Vue {
	@Prop() private message: IMessage;

	get youAreTheSender() {
		return this.loginUser.email === this.message.sender.email;
	}

	get textClass() {
		const base = 'block message-item';
		if (this.youAreTheSender) {
			return `${base} right`;
		} else {
			return `${base} left`;
		}
	}

	get showSender() {
		return `show-sender ${this.youAreTheSender ? 'right' : 'left'}`;
	}

	get loginUser() {
		return this.$store.state.loginUser;
	}

	get chatContents() {
		return ChatContentTypes;
	}

	get user() {
		return this.$store.getters.getUser(this.message.sender.email);
	}
}
</script>

<style lang="scss">
.message-item {
	background-color: lightgray;
	padding: 0.5rem;
	border-radius: 0.5rem;
	p {
		word-wrap: anywhere;
		white-space: pre-line;
	}
}

.message-item-container {
	padding: 0.75rem;
	clear: both;
}

.note {
	text-align: center;
	font-size: 0.7rem;
}

.right {
	float: right;
}

.left {
	float: left;
}

.show-sender {
	font-size: 0.5rem;
}
</style>
