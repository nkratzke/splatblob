<template>
	<div>
		<ExtraField
			v-for="option in options"
			:key="option.label"
			:option="option"
			@valueChanged="valueChanged"
		></ExtraField>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import {
	ICategorie,
	ExtraField as EX,
	ExtraFieldTypes,
	ExtraFieldResult,
} from '../../ChooseNotation';
import Categorie from './Categorie.vue';

@Component({
	components: {
		ExtraField: () => import('./ExtraField.vue'),
	},
})
export default class ExtraFields extends Vue {
	@Prop() private options: EX[];
	private currentReturn: ExtraFieldResult[] = [];

	mounted() {
		this.clearOptions();
	}

	private clearOptions() {
		this.currentReturn = [];
	}

	private valueChanged(payload: ExtraFieldResult) {
		this.clearOptions();
		this.currentReturn.push(payload);
		this.$emit('valueChanged', this.currentReturn);
	}

	get extraFieldTypes() {
		return ExtraFieldTypes;
	}
}
</script>

<style lang="scss" scoped></style>
