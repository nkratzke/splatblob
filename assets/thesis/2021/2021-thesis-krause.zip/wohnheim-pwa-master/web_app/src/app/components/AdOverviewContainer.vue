<template>
	<div :class="cardClass">
		<header class="card-header" @click="toggleContentIsVisible">
			<div class="card-header-icon-first">
				<font-awesome-icon :icon="currentTypeValue.icon"></font-awesome-icon>
			</div>
			<h1 class="card-header-title">{{ currentTitle }}</h1>

			<a :class="headerIconClass">
				<font-awesome-icon icon="angle-down"></font-awesome-icon>
			</a>
		</header>

		<div class="card-content" v-if="contentIsVisible">
			<div class="content">
				<span class="is-size-7">Created by {{ ad.creator.displayName }}</span>
				<p>{{ ad.description }}</p>
				<div
					v-if="
						ad.priceAmount != 'NO_VALUE' &&
						(ad.priceType == priceType.SELL || ad.priceType == priceType.CHANGE)
					"
				>
					<span class="is-size-7">Preise</span>
					<p>{{ ad.priceAmount }}</p>
				</div>
			</div>
		</div>
		<CardFooterStartChat
			v-if="!isYourOwnAd && contentIsVisible"
			:matchingUsers="[ad.creator]"
		></CardFooterStartChat>
		<footer v-else-if="isYourOwnAd && contentIsVisible" class="card-footer">
			<a class="card-footer-item" @click="editAd"> Edit </a>
			<a
				class="card-footer-item has-text-danger"
				v-if="!firstClickDelete"
				@click="deleteAd"
			>
				<span>Delete</span>
			</a>
			<a
				class="card-footer-item has-text-centered has-background-danger has-text-white"
				v-else
				@click="deleteAd"
			>
				<span>Click again to delete</span>
			</a>
		</footer>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Ad } from '../../email/Ad';
import CardFooterStartChat from './CardFooterStartChat.vue';
import { LoginUser } from '../../email/LoginUser';
import { ActionTypes } from '../store/ActionTypes';
import { DeleteAdMessage } from '../../email/content_messages/DeleteAdMessage';
import { EMail } from '../../email';
import { Utils } from '../../email/utils';
import { adValues, PriceType } from '../../email/dexie_interfaces/IAd';

@Component({
	components: { CardFooterStartChat },
})
export default class AdOverviewContainer extends Vue {
	@Prop() private ad: Ad;
	private contentIsVisible: boolean = false;
	private firstClickDelete: boolean = false;

	private toggleContentIsVisible() {
		this.contentIsVisible = !this.contentIsVisible;
	}

	private editAd() {
		this.$router.push(`/chat/${this.ad.chatId}/new-ad/${this.ad.id}`);
	}

	private deleteAd() {
		if (!this.firstClickDelete) {
			this.firstClickDelete = true;
			setTimeout(() => {
				this.firstClickDelete = false;
			}, 1000);
		} else {
			this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
				message: new DeleteAdMessage(
					this.currentUser,
					EMail.genId(this.$store.getters.getCurrentProviderBaseUrl()),
					this.ad.chatId,
					Utils.dateToTimeString(Utils.getCurrentDateTime()),
					this.ad.id,
					this.ad.title,
				),
			});
		}
	}

	get cardClass() {
		// your ads are a little bit lighter
		return `card ${this.isYourOwnAd ? '' : 'has-background-grey-lighter'}`;
	}

	get currentTitle() {
		return this.currentTypeValue.description.replace('%s', this.ad.title);
	}

	get currentTypeValue() {
		return adValues[this.ad.priceType.toString()];
	}

	get isYourOwnAd() {
		return this.ad.creator.email === this.currentUser.email;
	}

	get headerIconClass() {
		return `card-header-icon ${this.contentIsVisible ? 'rotated' : ''}`;
	}

	get currentUser(): LoginUser {
		return this.$store.state.loginUser;
	}

	get priceType() {
		return PriceType;
	}
}
</script>

<style lang="scss" scoped>
.card-header-icon-first {
	padding: 0.75rem 0.25rem;
}
</style>
