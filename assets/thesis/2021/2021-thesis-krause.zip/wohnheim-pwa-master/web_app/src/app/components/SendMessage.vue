<template>
	<div class="container send-message columns is-mobile">
		<div class="column">
			<textarea
				class="input"
				:value="content"
				placeholder="Type your message"
				@keyup="keyUp"
			/>
		</div>
		<div class="column is-narrow buttons">
			<button
				class="button is-narrow is-primary"
				@click="send"
				:disabled="!canSend"
			>
				<font-awesome-icon icon="paper-plane" class="icon"></font-awesome-icon>
			</button>
			<button class="button is-narrow is-dark" @click="goToSendNewsMessage">
				<font-awesome-icon icon="plus" class="icon"></font-awesome-icon>
			</button>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { ActionTypes } from '../store/ActionTypes';
import { TextMessage } from '../../email/content_messages/TextMessage';
import { EMail } from '../../email';
import { Chat } from '../../email/Chat';
import { Utils } from '../../email/utils';
import { CustomPromise } from '../routes/CustomPromise';
import { LoginUser } from '../../email/LoginUser';
import { Notification } from '../Notification';

@Component({
	components: {},
})
export default class SendMessage extends Vue {
	//@ts-ignore
	@Prop() private chatId: string;
	private content: string = '';

	getBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}

	goToSendNewsMessage() {
		this.$router.push(`/chat/${this.chatId}/send-news-message`);
	}

	get canSend() {
		return this.content.length > 0;
	}

	get currentUser(): LoginUser {
		return this.$store.state.loginUser;
	}

	private keyUp(event: KeyboardEvent) {
		// keyCode 13 is enter
		if (event.keyCode === 13 && !event.shiftKey && !event.ctrlKey) {
			this.send();
		} else {
			this.content = (event.target as HTMLTextAreaElement).value;
		}
	}

	send() {
		if (this.canSend) {
			const callback: CustomPromise = {
				thenCallback: () => {
					this.content = '';
				},
				catchCallBack: (err) => {
					this.$store.dispatch(
						ActionTypes.CREATE_NOTIFICATION,
						new Notification(
							'Die Nachricht kontte nicht verschickt werden',
							``,
							3,
							'danger',
						),
					);
					console.error('SendMessage.send', err);
				},
			};
			this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
				message: new TextMessage(
					this.currentUser,
					EMail.genId(this.getBaseUrl()),
					this.chatId,
					Utils.dateToTimeString(Utils.getCurrentDateTime()),
					this.content,
				),
				callbackPromise: callback,
			});
		}
	}
}
</script>

<style lang="scss" scoped>
@import 'src/app/colors';
$padding: 0.5rem;
.send-message {
	padding: 0 $padding $padding $padding;
	position: fixed;
	bottom: 0;
	width: 100%;
	textarea {
		max-height: 4rem;
		resize: vertical;
	}
}

button {
	&font-awsome-icon {
		width: 100px;
		height: 100px;
	}
	border: none;
	border-radius: 100%;
}
</style>
