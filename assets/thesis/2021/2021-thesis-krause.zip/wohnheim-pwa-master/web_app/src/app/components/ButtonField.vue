<template>
	<div class="field" :id="id">
		<label class="label">{{ label }}</label>
		<div class="controller">
			<button :class="buttonClass" @click="click" :disabled="disabled">
				{{ content }}
			</button>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component({
	components: {},
})
export default class ButtonField extends Vue {
	@Prop() private label: string;
	@Prop() private classExtend: string;
	@Prop() private content: string;
	@Prop() private id: string;
	@Prop() private disabled: boolean;

	private click() {
		this.$emit('click');
	}

	get buttonClass() {
		return `button ${this.classExtend}`;
	}
}
</script>

<style lang="scss"></style>
