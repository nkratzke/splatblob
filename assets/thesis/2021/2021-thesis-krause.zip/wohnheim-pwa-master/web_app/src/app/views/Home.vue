<template>
	<section>
		<section
			class="hero is-fullheight is-danger"
			v-if="hasNoSubscriptedMailboxes"
		>
			<div class="hero-body">
				<div class="container">
					<h1 class="title">Keine Postfächer ausgewählt!</h1>
					<h2 class="subtitle">
						Damit die App arbeiten kann, musst du auswählen welche Postfächer
						sie durchsuchen darf.
					</h2>
					<button @click="toMailboxes" class="button">
						Mailboxen einrichten
					</button>
				</div>
			</div>
		</section>

		<div class="container tabs is-centered">
			<ul>
				<li :class="getClass(tabs.GENERAL)">
					<a @click="choseTab(tabs.GENERAL)">Allgemein</a>
				</li>
				<li :class="getClass(tabs.CHATS)">
					<a @click="choseTab(tabs.CHATS)">Text-Chats</a>
				</li>
				<li :class="getClass(tabs.OTHER)">
					<a @click="choseTab(tabs.OTHER)">Andere</a>
				</li>
			</ul>
		</div>

		<div v-if="currentTab === tabs.CHATS">
			<!-- chat overview -->
			<div class="container content-height">
				<ChatOverviewWithSearchBar
					chatTypeFilter="NORMAL"
				></ChatOverviewWithSearchBar>
			</div>
			<FloatingButton
				icon="plus"
				@click="newChat"
				class="is-hidden-desktop"
			></FloatingButton>
		</div>

		<div v-if="currentTab === tabs.OTHER">
			<!-- chat overview -->
			<div class="container content-height">
				<ChatOverviewWithSearchBar
					chatTypeFilter="AD"
				></ChatOverviewWithSearchBar>
			</div>
			<FloatingButton
				icon="plus"
				@click="newChat"
				class="is-hidden-desktop"
			></FloatingButton>
		</div>

		<div class="container content-height" v-if="currentTab === tabs.GENERAL">
			<div class="hero is-light">
				<div class="hero-body">
					<h1 class="title">Schäden in der Wohnung oder im Haus?</h1>
					<h2 class="subtitle">
						Dann melde diese Schäden einfach an den Hausmeister!
					</h2>
					<button class="button" @click="toCaretakerRequest">
						Meldung erstellen
					</button>
				</div>
			</div>

			<div class="mt-3">
				<h1 class="title has-text-centered">Angepinnte Chats</h1>
				<div class="columns" v-for="(row, index) in pinnedChats" :key="index">
					<div class="column" v-if="index == 0">
						<div class="card mb-5">
							<div class="card-header">
								<h1 class="card-header-title">
									Wichtige Information zu den angepinnten Chats
								</h1>
								<a class="card-header-icon blink-icon">
									<font-awesome-icon
										icon="exclamation-triangle"
									></font-awesome-icon>
								</a>
							</div>
							<div class="card-content">
								Um einem Chat beizutreten, wird eine E-Mail an den Administrator
								des Chats geschickt. Erst wenn dieser dir eine Einladung zurück
								schickt, bist du dem Chat beigetreten.
								<br />
								Dieser Vorgang dauert solange bis der Administrator der Gruppe
								online geht!
							</div>
						</div>
					</div>
					<div class="column" v-for="chat in row" :key="chat.name">
						<PinnedChatItem :pinnedChat="chat"></PinnedChatItem>
					</div>
				</div>
			</div>
		</div>
	</section>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { IUseMailbox } from '../../email/dexie_interfaces/IUseMailbox';
import { PinnedChat, pinnedChats } from '../PinnedChats';
import PinnedChatItem from '../components/PinnedChatItem.vue';
import ChatOverviewWithSearchBar from '../components/ChatOverview/ChatOverviewWithSearchBar.vue';
import FloatingButton from '../components/FloatingButton.vue';
import { MutationTypes } from '../store/MutationTypes';

enum Tabs {
	GENERAL = 'GENERAL',
	CHATS = 'CHATS',
	OTHER = 'OTHER',
}

@Component({
	components: { ChatOverviewWithSearchBar, PinnedChatItem, FloatingButton },
})
export default class Login extends Vue {
	private chatName: string = '';
	private secondMember: string = '';
	private currentTab: Tabs = Tabs.GENERAL;

	mounted() {
		this.currentTab = this.$store.state.currentHomeTab || Tabs.GENERAL;
	}

	private toMailboxes() {
		this.$router.push('/mailboxes');
	}

	private toCaretakerRequest() {
		this.$router.push('/caretaker-request');
	}

	private choseTab(tab: Tabs) {
		this.currentTab = tab;
		this.$store.commit(MutationTypes.CHANGE_CURRENT_HOME_TAB, tab);
	}

	private getClass(tabType: Tabs) {
		return this.currentTab === tabType ? 'is-active' : '';
	}

	private newChat() {
		this.$router.push('/new-chat');
	}

	get chats() {
		return this.$store.state.chats;
	}

	get mailboxes(): IUseMailbox[] {
		return this.$store.state.mailboxes;
	}

	get hasNoSubscriptedMailboxes(): boolean {
		const subs =
			this.mailboxes.filter((mailboxes) => mailboxes.use).length == 0;
		return subs;
	}

	get tabs() {
		return Tabs;
	}

	get pinnedChats() {
		let columns: PinnedChat[][] = [];
		let column: PinnedChat[] = [];
		pinnedChats.forEach((pinnedChat) => {
			column.push(pinnedChat);
			if (column.length == 2) {
				columns.push(column);
				column = [];
			}
		});
		columns.push(column);
		return columns;
	}
}
</script>

<style lang="scss" scoped>
.blink-icon {
	animation-name: blink;
	animation-duration: 1s;
	animation-iteration-count: infinite;
}

@keyframes blink {
	0% {
		color: red;
	}
	50% {
		color: darkred;
	}
	100% {
		color: red;
	}
}
</style>
