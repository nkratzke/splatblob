<template>
	<div class="container">
		<h1 class="title" v-if="adId">Bearbeite das Inserat</h1>
		<h1 class="title" v-else>Neues Inserat</h1>

		<div class="field is-grouped">
			<div class="control">
				<label class="label"> Typ des Inserates </label>
				<div class="select">
					<select v-model="currentPriceType" @change="canSend">
						<option
							v-for="key in priceTypeArray"
							:key="priceType[key]"
							:value="priceType[key]"
						>
							{{ getPriceTypeValue(priceType[key]).title }}
						</option>
					</select>
				</div>
			</div>
		</div>

		<div>
			<label class="label">Titel</label>
			<div class="field is-horizontal">
				<div class="field-body">
					<div class="field is-expanded">
						<div class="field has-addons">
							<p class="control">
								<a
									class="button is-static"
									v-if="currentPriceTypeDescriptionParts.length > 0"
								>
									{{ currentPriceTypeDescriptionParts[0] }}
								</a>
							</p>
							<p class="control is-expanded">
								<input
									v-if="valueValid.title.valid"
									class="input is-success"
									type="text"
									placeholder="etwas total tolles"
									:value="valueValid.title.value"
									@input="changeTitle"
								/>
								<input
									v-else
									class="input is-danger"
									type="text"
									placeholder="etwas total tolles"
									:value="valueValid.title.value"
									@input="changeTitle"
								/>
							</p>
							<a
								class="button is-static"
								v-if="currentPriceTypeDescriptionParts.length > 1"
							>
								{{ currentPriceTypeDescriptionParts[1] }}
							</a>
						</div>
						<p v-if="!valueValid.title.valid" class="help">
							Darf nicht leer sein!
						</p>
					</div>
				</div>
			</div>
		</div>

		<InputField
			label="Description"
			placeholder="Beschreibe dein Inserat"
			type="text"
			errorText="Not a valid description"
			validator="NOT_EMPTY"
			id="description"
			:defaultValue="valueValid.description.value"
			@valueChanged="valueChanged"
			@validChanged="validChanged"
		></InputField>

		<InputField
			v-if="canAdAmount"
			label="Amount"
			placeholder="Was möchtest du für dein Inserat haben?"
			type="text"
			errorText="Not a valid amount"
			validator="NOT_EMPTY"
			id="amount"
			:defaultValue="valueValid.amount.value"
			@valueChanged="valueChanged"
			@validChanged="validChanged"
		></InputField>

		<div class="field is-grouped">
			<div class="control">
				<button class="button is-primary" :disabled="!isValid" @click="send">
					Absenden
				</button>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { adValues, PriceType } from '../../email/dexie_interfaces/IAd';
import { Component, Prop, Vue } from 'vue-property-decorator';
import InputField from '../components/InputField.vue';
import { ActionTypes } from '../store/ActionTypes';
import { NewAdMessage } from '../../email/content_messages/NewAdMessage';
import { EMail } from '../../email';
import { Utils } from '../../email/utils';
import { Ad } from '../../email/Ad';
import { CustomPromise } from '../routes/CustomPromise';
import { Notification } from '../Notification';
@Component({
	components: { InputField },
})
export default class Chat extends Vue {
	@Prop() private chatId: string;
	@Prop() private adId: string;

	private currentPriceType: PriceType = this.currentAd
		? this.currentAd.priceType
		: PriceType.SELL;

	private valueValid: any = {
		title: {
			value: this.currentAd ? this.currentAd.title : '',
			valid: this.currentAd ? true : false,
		},
		description: {
			value: this.currentAd ? this.currentAd.description : '',
			valid: this.currentAd ? true : false,
		},
		amount: {
			value: this.currentAd ? this.currentAd.priceAmount : '',
			valid: this.currentAd ? true : false,
		},
	};
	private isValid: boolean = false;

	private valueChanged(payload: { from: string; value: any }) {
		this.valueValid[payload.from].value = payload.value;
	}

	private validChanged(payload: { from: string; value: boolean }) {
		this.valueValid[payload.from].valid = payload.value;
		this.canSend();
	}

	private canSend() {
		let canSend: boolean = true;
		Object.keys(this.valueValid).forEach((key) => {
			if (key === 'amount' && !this.canAdAmount) {
				canSend = true;
			} else if (!this.valueValid[key].valid) {
				canSend = false;
			}
		});
		if (canSend) {
			if (!this.currentPriceType) {
				canSend = false;
			}
		}
		this.isValid = canSend;
	}

	private send() {
		if (this.isValid) {
			const message = new NewAdMessage(
				this.$store.state.loginUser,
				EMail.genId(this.$store.getters.getCurrentProviderBaseUrl()),
				this.chatId,
				Utils.dateToTimeString(Utils.getCurrentDateTime()),
				this.currentAd?.id || Ad.genId(),
				this.valueValid.title.value,
				this.valueValid.description.value,
				this.currentPriceType,
				this.valueValid.amount.value || '',
			);
			const callback: CustomPromise = {
				thenCallback: (result: any) => {
					console.log('Add ad successfully!');
					this.goBack();
				},
				catchCallBack: (err: any) => {
					this.$store.dispatch(
						ActionTypes.CREATE_NOTIFICATION,
						new Notification(
							'Fehler beim erstellen des Inserats',
							`Das Inserat ${this.valueValid.title.value} konnte nicht erstellt werden! `,
							3,
							'danger',
						),
					);
					console.log(err);
				},
			};
			this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
				message: message,
				callbackPromise: callback,
			});
		}
	}

	private getPriceTypeValue(priceType: PriceType) {
		return adValues[priceType];
	}

	private goBack() {
		this.$router.go(-1);
	}

	private changeTitle(input: InputEvent) {
		this.valueValid.title.value = (input.target as HTMLInputElement).value;
		this.valueValid.title.valid = this.valueValid.title.value.length > 0;
		this.canSend();
	}

	get currentAd(): Ad | null {
		return this.adId ? this.$store.getters.getAd(this.adId) : null;
	}

	get canAdAmount() {
		return (
			this.currentPriceType == PriceType.SELL ||
			this.currentPriceType == PriceType.CHANGE
		);
	}

	get currentPriceTypeValue() {
		return this.getPriceTypeValue(this.currentPriceType);
	}

	get currentPriceTypeDescriptionParts() {
		return this.currentPriceTypeValue.description
			.split('%s')
			.map((description) => description.trim())
			.filter((description) => description.length > 0);
	}

	get chat() {
		return this.$store.getters.getChat(this.chatId);
	}

	get priceType() {
		return PriceType;
	}

	get priceTypeArray() {
		return Object.keys(PriceType);
	}
}
</script>

<style lang="scss" scoped></style>
