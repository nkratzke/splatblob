<template>
	<div class="mt-4">
		<div class="field">
			<div class="control">
				<div class="select">
					<select v-model="currentCategorie" @change="categorieChange">
						<option
							v-for="categorie in categories"
							:key="categorie.name"
							:value="categorie.enum"
						>
							{{ categorie.name }}
						</option>
					</select>
				</div>
			</div>
		</div>

		<div v-if="currentChosenCategorie">
			<Categorie
				:categorie="currentChosenCategorie"
				@valueChanged="valueChanged"
			></Categorie>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { ICategorie, ICategorieResult } from '../../ChooseNotation';

@Component({
	components: {
		Categorie: () => import('./Categorie.vue'),
	},
})
export default class CategorieRoot extends Vue {
	@Prop() private categories: ICategorie[];
	private currentCategorie: string = '';

	get currentChosenCategorie(): ICategorie | undefined {
		return this.categories.find(
			(categorie) => categorie.enum == this.currentCategorie,
		);
	}

	private valueChanged(payload: ICategorieResult) {
		this.emitPayload({
			iCategorie: this.categories.find(
				(categorie) => categorie.enum == this.currentCategorie,
			),
			subCategorieResult: payload,
		} as ICategorieResult);
		this.emitPayload(payload);
	}

	private emitPayload(payload: any) {
		this.$emit('valueChanged', payload);
	}

	private categorieChange() {
		this.emitPayload({
			iCategorie: this.categories.find(
				(categorie) => categorie.enum == this.currentCategorie,
			),
		} as ICategorieResult);
	}
}
</script>

<style lang="scss" scoped></style>
