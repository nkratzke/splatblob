export interface CustomPromise {
	thenCallback: any;
	catchCallBack: any;
}
