<template>
	<div class="box is-horizontal">
		<p>
			{{ user.email }}
			<span v-if="currentUser.email == user.email" class="tag is-info"
				>You</span
			>
		</p>
		<p v-if="!editNickname">{{ user.nickname }}</p>
		<InputField
			v-else
			placeholder="Nickname"
			type="text"
			errorText="Please type in a nickname"
			validator="NOT_EMPTY"
			:defaultValue="user.nickname"
			@valueChanged="valueChanged"
			@validChanged="validChanged"
		>
		</InputField>
		<button class="button" @click="toggleEdit" v-if="!editNickname">
			<span>Edit</span>
		</button>

		<button
			class="button is-success"
			@click="toggleEdit"
			v-if="editNickname && hasChanged"
		>
			Edit
		</button>

		<button class="button" @click="cancleEdit" v-if="editNickname">
			Cancel
		</button>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { Chat } from '../../../email/Chat';
import { User } from '../../../email/User';
import InputField from '../InputField.vue';
import { ActionTypes } from '../../store/ActionTypes';

@Component({
	components: { InputField },
})
export default class ContactItem extends Vue {
	@Prop() private user: User;
	private editNickname: boolean = false;
	private oldNickname: string = '';
	private editedNickname: string = '';
	private editedNicknameIsValid: boolean = false;

	private valueChanged(payload: { from: string; value: any }) {
		this.editedNickname = payload.value;
	}
	private validChanged(payload: { from: string; value: boolean }) {
		this.editedNicknameIsValid = payload.value;
	}

	get hasChanged() {
		return (
			this.oldNickname !== this.editedNickname && this.editedNicknameIsValid
		);
	}

	private toggleEdit() {
		if (this.editNickname) {
			console.log(
				this.oldNickname,
				this.editedNickname,
				this.editedNicknameIsValid,
			);
			if (this.hasChanged) {
				this.$store.dispatch(ActionTypes.CHANGE_USER_NICKNAME, {
					email: this.user.email,
					nickname: this.editedNickname,
				});
			} else {
				console.log('Do nothing');
			}
		} else {
			this.oldNickname = this.user.nickname;
			this.editedNickname = this.user.nickname;
			this.editedNicknameIsValid = this.editedNickname.length > 0;
		}
		this.editNickname = !this.editNickname;
	}

	private cancleEdit() {
		this.editNickname = false;
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}
}
</script>

<style lang="scss" scoped></style>
