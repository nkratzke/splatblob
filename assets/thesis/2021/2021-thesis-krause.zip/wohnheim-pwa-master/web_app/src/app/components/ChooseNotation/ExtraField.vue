<template>
	<div>
		<div v-if="option.type == 'TEXT'">
			<InputField
				:label="option.label"
				:placeholder="option.label"
				:id="option.label"
				@valueChanged="valueChanged"
			></InputField>
		</div>
		<div v-if="option.type == 'NUMBER'">
			<NumberInputField
				:label="option.label"
				:placeholder="option.label"
				:id="option.label"
				@valueChanged="valueChanged"
			></NumberInputField>
		</div>
		<div v-if="option.type == 'SELECT'">
			<CategorieRoot
				:categories="option.options"
				@valueChanged="changeCategorie"
			></CategorieRoot>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import {
	ICategorie,
	ExtraField as EX,
	ExtraFieldTypes,
	ExtraFieldResult,
	ICategorieResult,
} from '../../ChooseNotation';
import Categorie from './Categorie.vue';
import InputField from '../InputField.vue';
import NumberInputField from '../NumberInputField.vue';
import CategorieRoot from './Root.vue';

@Component({
	components: { InputField, NumberInputField, CategorieRoot },
})
export default class ExtraField extends Vue {
	@Prop() private option: EX;
	private currentCategorie: string = '';

	private valueChanged(payload: { from: string; value: any }) {
		this.emitPayload(payload);
	}

	private emitPayload(payload: { from: string; value: any }) {
		this.$emit('valueChanged', {
			extraField: this.option,
			result: payload.value,
		} as ExtraFieldResult);
	}

	private changeCategorie(payload: ICategorieResult) {
		this.$emit('valueChanged', {
			extraField: this.option,
			result: payload.iCategorie.name,
		} as ExtraFieldResult);
	}

	get extraFieldTypes() {
		return ExtraFieldTypes;
	}
}
</script>

<style lang="scss" scoped></style>
