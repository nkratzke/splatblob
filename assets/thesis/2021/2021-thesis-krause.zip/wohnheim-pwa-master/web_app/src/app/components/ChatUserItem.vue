<template>
	<div class="card">
		<div class="card-header" @click="toggleVisibility">
			<h1 class="card-header-title">
				{{ user.displayName }}
				<span class="ml-1 has-text-info" v-if="userIsAdmin(user)">
					- Admin</span
				>
			</h1>
			<a :class="headerIconClass">
				<font-awesome-icon icon="angle-down"></font-awesome-icon>
			</a>
		</div>
		<div class="card-footer" v-if="!isVisible">
			<a
				:class="promoteClass"
				v-if="!userIsAdmin(user) && loggedInUserIsAdmin"
				@click="clickPromoteUser"
			>
				<span v-if="!firstPromoteClick">Zum Admin befördern</span>
				<span v-else>Klick erneut zum Befördern</span>
			</a>
			<a
				:class="promoteClass"
				v-else-if="userIsAdmin(user) && loggedInUserIsAdmin"
				@click="clickPromoteUser"
			>
				<span v-if="!firstPromoteClick">Von den Admins entfernen</span>
				<span v-else>Klick erneut zum Entfernen</span>
			</a>
			<a
				:class="deleteClass"
				v-if="currentUser.email == user.email"
				@click="clickDeleteUser"
			>
				<span v-if="!firstRemoveClick">Chat verlassen</span>
				<span v-else>Klick erneut zum Verlassen</span>
			</a>
			<a
				:class="deleteClass"
				v-else-if="loggedInUserIsAdmin"
				@click="clickDeleteUser"
			>
				<span v-if="!firstRemoveClick">Aus dem Chat entfernen</span>
				<span v-else>Klick erneut zum Entfernen</span>
			</a>
			<!--<a
                class="card-footer-item"
            >
                Start single chat
            </a>-->
		</div>
	</div>
</template>

<script lang="ts">
import { EMail } from '../../email';
import { AdChat } from '../../email/AdChat';
import { DeleteMessage } from '../../email/content_messages/DeleteMessage';
import { PromoteMessage } from '../../email/content_messages/PromoteMessage';
import { IUser } from '../../email/dexie_interfaces/IUser';
import { Utils } from '../../email/utils';
import { Component, Vue, Prop } from 'vue-property-decorator';
import { CustomPromise } from '../routes/CustomPromise';
import { ActionTypes } from '../store/ActionTypes';
import { Notification } from '../Notification';

@Component({
	components: {},
})
export default class ChatUserItem extends Vue {
	@Prop() private user: IUser;
	@Prop() private chat: AdChat;
	private firstRemoveClick: boolean = false;
	private firstPromoteClick: boolean = false;

	private isVisible: boolean = true;

	private toggleVisibility() {
		this.isVisible = !this.isVisible;
	}

	private userIsAdmin(user: IUser) {
		return (
			this.chat.admins.filter((admin) => admin.email === user.email).length > 0
		);
	}

	private clickPromoteUser() {
		if (!this.firstPromoteClick) {
			this.firstPromoteClick = true;
			setTimeout(() => {
				this.firstPromoteClick = false;
			}, 1000);
		} else {
			this.promoteUser();
		}
	}

	private promoteUser() {
		const callback: CustomPromise = {
			thenCallback: (data: any) => {
				console.log('Promote', data);
			},
			catchCallBack: (err: any) => {
				const isPormote = !this.userIsAdmin(this.user);
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						isPormote
							? 'Beförderung ist Fehlgeschlagen'
							: 'Degradierung ist fehlgeschlagen',
						`${
							isPormote
								? `Die Beförderung von ${this.user.email} schlug fehl.`
								: `Die Degradierung von ${this.user.email} schlug fehl.`
						}.  `,
						3,
						'danger',
					),
				);
				console.log('Promote error', err);
			},
		};
		this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
			message: new PromoteMessage(
				this.$store.state.loginUser,
				EMail.genId(this.getCurrentProviderBaseUrl),
				this.chat.id,
				Utils.dateToTimeString(Utils.getCurrentDateTime()),
				this.user.email,
				!this.userIsAdmin(this.user),
			),
			callbackPromise: callback,
		});
	}

	private clickDeleteUser() {
		if (!this.firstRemoveClick) {
			this.firstRemoveClick = true;
			setTimeout(() => {
				this.firstRemoveClick = false;
			}, 1000);
		} else {
			this.deleteUser();
		}
	}

	deleteUser() {
		const callback: CustomPromise = {
			thenCallback: (data: any) => {
				if (this.currentUser.email === this.user.email) {
					this.$router.push('/');
				}
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Löschen schlug fehl',
						`Der Nutzer ${this.user.email} konnte nicht entfernt werden. `,
						3,
						'danger',
					),
				);
				console.log('Promote error', err);
			},
		};
		this.$store.dispatch(ActionTypes.SEND_MESSAGE, {
			message: new DeleteMessage(
				this.$store.state.loginUser,
				EMail.genId(this.getCurrentProviderBaseUrl),
				this.chat.id,
				Utils.dateToTimeString(Utils.getCurrentDateTime()),
				this.user.email,
			),
			callbackPromise: callback,
		});
	}

	get promoteClass() {
		return `card-footer-item ${
			this.firstPromoteClick ? 'has-background-success has-text-white' : ''
		}`;
	}

	get deleteClass() {
		return `card-footer-item ${
			this.firstRemoveClick ? 'has-background-danger has-text-white' : ''
		}`;
	}

	get loggedInUserIsAdmin(): boolean {
		return this.userIsAdmin(this.currentUser as IUser);
	}

	get currentUser() {
		return this.$store.state.loginUser;
	}

	get headerIconClass() {
		return `card-header-icon ${this.isVisible ? 'rotated' : ''}`;
	}

	get getCurrentProviderBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}
}
</script>
