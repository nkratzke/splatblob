<template>
	<div>
		<div class="field" v-if="chatsWithSameUsers.length == 0">
			<div class="control">
				<button class="button" @click="createNewChat" :disabled="disabled">
					Neuen Chat mit
					<span class="is-hidden-mobile mx-1">{{ userString }}</span> erstellen
				</button>
			</div>
		</div>

		<div class="field" v-if="chatsWithSameUsers.length == 1">
			<div class="control">
				<button
					class="button"
					@click="sendToChat(chatsWithSameUsers[0].id)"
					:disabled="disabled"
				>
					Nachricht in Chat {{ chatsWithSameUsers[0].name }} senden
				</button>
			</div>
		</div>

		<div class="field" v-if="chatsWithSameUsers.length > 1">
			<div class="control">
				<ul>
					<li
						class="block has-text-centered"
						v-for="chat in chatsWithSameUsers"
						:key="chat.id"
						@click="sendToChat(chat.id)"
					>
						<button class="button" :disabled="disabled">
							Nachricht in Chat {{ chat.name }} senden
						</button>
					</li>
				</ul>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import { developer as caretaker } from '../importantContacts';
import InputField from '../components/InputField.vue';
import { User } from '../../email/User';
import { ActionTypes } from '../store/ActionTypes';
import { CustomPromise } from '../routes/CustomPromise';
import { LoginUser } from '../../email/LoginUser';
import { ChatType } from '../../email/dexie_interfaces/IChat';
import { Notification } from '../Notification';

@Component({
	components: { InputField },
})
export default class CreateOpenChat extends Vue {
	@Prop() private sameUsers: User[];
	@Prop() private disabled: boolean;

	get currentUser(): LoginUser {
		return this.$store.state.loginUser;
	}

	get chatsWithSameUsers() {
		const chats = this.$store.getters.getChatWithExactUserMatch(this.users);
		return chats;
	}

	get users() {
		return this.sameUsers.concat([this.currentUser]);
	}

	get userString() {
		let ret = '';
		this.users.forEach((user) => {
			ret += `${user.email}, `;
		});
		return ret.substring(0, ret.length - 2);
	}

	private createNewChat() {
		const name = `Caretaker-Chat with ${this.userString}`;
		const callback: CustomPromise = {
			thenCallback: (chatId: string) => {
				this.openChat(chatId);
			},
			catchCallBack: (err: any) => {
				this.$store.dispatch(
					ActionTypes.CREATE_NOTIFICATION,
					new Notification(
						'Erstellung des neuen Chats schlug fehl',
						`Der Chat ${name} konnte nicht erstellt werden! `,
						3,
						'danger',
					),
				);
				console.error('CreateOpenChat.createNewChat', err);
			},
		};
		this.$store.dispatch(ActionTypes.CREATE_CHAT, {
			name: name,
			inviteMembers: [caretaker.email],
			isPublic: false,
			onlyAdminsCanSend: false,
			type: ChatType.NORMAL,
			callbackPromise: callback,
		});
	}
	private openChat(chatId: string) {
		this.$router.push(`/chat/${chatId}`);
	}
}
</script>
