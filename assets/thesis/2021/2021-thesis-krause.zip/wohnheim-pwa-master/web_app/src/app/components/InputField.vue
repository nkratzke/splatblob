<template>
	<div class="field" :id="id">
		<label class="label">{{ label }}</label>
		<div :class="classControll">
			<input
				:class="inputClass"
				:type="type"
				:placeholder="placeholder"
				:value="value"
				@input="setValue"
				:disabled="disabled"
			/>
			<span v-if="leftIcon" class="icon is-small is-left">
				<font-awesome-icon :icon="leftIcon" />
			</span>
			<span v-if="rightIcon" class="icon is-small is-right">
				<font-awesome-icon :icon="rightIcon" />
			</span>
		</div>
		<p v-if="!valid" class="help">{{ errorText }}</p>
	</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Utils } from '../../email/utils';

export enum Validator {
	EMAIL = 'EMAIL',
	NOT_EMPTY = 'NOT_EMPTY',
	NO_VALIDATION = 'NO_VALIDATION',
}

@Component({
	components: {},
})
/**
 * Custom Events:
 *  valueChanged: string => if the value has changed
 *  validChanged: boolean => if the valid status has changed
 */
export default class InputField extends Vue {
	@Prop() private label: string;
	@Prop() private placeholder: string;
	@Prop() private type: string;
	@Prop() private errorText: string;
	@Prop() private validator: Validator;
	@Prop() private leftIcon: string;
	@Prop() private rightIcon: string;
	@Prop() private defaultValue: string;
	@Prop() private id: string;
	@Prop() private disabled: boolean;
	private value = '';
	private valid = false;

	mounted() {
		this.value = this.defaultValue || '';
		this.validateValue();
	}

	setValue(event: InputEvent) {
		const value = (event.target as HTMLInputElement).value;
		this.value = value;
		this.validateValue();
		this.$emit('valueChanged', { value: this.value, from: this.id });
		this.$emit('validChanged', { value: this.valid, from: this.id });
	}

	private validateValue() {
		switch (this.validator) {
			case Validator.EMAIL:
				this.valid = Utils.isValidEmailAddress(this.value);
				break;
			case Validator.NOT_EMPTY:
				this.valid = this.value.length > 0;
				break;
			case Validator.NO_VALIDATION:
				this.valid = true;
				break;
			default:
				this.valid = true;
				break;
		}
	}

	get inputClass() {
		return `input ${this.valid ? 'is-success' : 'is-danger'}`;
	}

	get classControll() {
		return `control ${this.rightIcon ? 'has-icons-right' : ''}${
			this.leftIcon ? 'has-icons-left' : ''
		}`;
	}
}
</script>

<style lang="scss"></style>
