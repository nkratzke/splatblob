<template>
	<div class="field" :id="id">
		<label class="label">{{ label }}</label>
		<div :class="classControll">
			<input
				:class="inputClass"
				type="number"
				:max="max"
				:min="min"
				:value="value"
				@input="setValue"
			/>
		</div>
		<p v-if="!valid" class="help">{{ errorText }}</p>
	</div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Utils } from '../../email/utils';

@Component({
	components: {},
})
/**
 * Custom Events:
 *  valueChanged: string => if the value has changed
 *  validChanged: boolean => if the valid status has changed
 */
export default class NumberInputField extends Vue {
	@Prop() private label: string;
	@Prop() private max: string;
	@Prop() private min: string;
	@Prop() private errorText: string;
	@Prop() private leftIcon: string;
	@Prop() private rightIcon: string;
	@Prop() private defaultValue: string;
	@Prop() private id: string;
	private value: string = '0';
	private valid = true;

	mounted() {
		this.value = this.defaultValue;
	}

	setValue(event: InputEvent) {
		const value: number = Number((event.target as HTMLInputElement).value);
		this.value = String(value);
		this.valid =
			((this.min && Number(this.min) <= value) || (!this.min && true)) &&
			((this.max && Number(this.max) >= value) || (!this.max && true));
		this.$emit('valueChanged', { value: this.value, from: this.id });
		this.$emit('validChanged', { value: this.valid, from: this.id });
	}

	get inputClass() {
		return `input ${this.valid ? 'is-success' : 'is-danger'}`;
	}

	get classControll() {
		return `control ${this.rightIcon ? 'has-icons-right' : ''}${
			this.leftIcon ? 'has-icons-left' : ''
		}`;
	}
}
</script>

<style lang="scss"></style>
