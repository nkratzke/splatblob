<template>
	<div class="container">
		<!-- search chat field -->
		<div class="field has-addons">
			<div class="control is-expanded">
				<input
					type="text"
					class="input"
					:value="this.$store.state.filter"
					@input="setFilter"
					placeholder="Search in chat name"
				/>
			</div>
			<div class="control" v-if="filter.length > 0">
				<button class="button" @click="clearFilter">Filter löschen</button>
			</div>
			<div class="control is-hidden-touch">
				<button class="button" @click="newChat">Neuer Chat</button>
			</div>
		</div>
		<!-- chat overview container  -->
		<ChatOverviewContainer
			class="mt-5"
			:chatTypeFilter="chatTypeFilter"
		></ChatOverviewContainer>
	</div>
</template>

<script lang="ts">
import { ChatType } from 'src/email/dexie_interfaces/IChat';
import { Component, Prop, Vue } from 'vue-property-decorator';
import { MutationTypes } from '../../store/MutationTypes';
import ChatOverviewContainer from './ChatOverviewContainer.vue';

@Component({
	components: { ChatOverviewContainer },
})
export default class ChatOverviewWithSearchBar extends Vue {
	@Prop() private chatTypeFilter: ChatType;

	private newChat() {
		this.$router.push('/new-chat');
	}

	private clearFilter() {
		this.$store.commit(MutationTypes.CHANGE_FILTER, '');
	}

	setFilter(event: InputEvent) {
		this.$store.commit(
			MutationTypes.CHANGE_FILTER,
			(event.target as HTMLInputElement).value,
		);
	}

	get filter() {
		return this.$store.state.filter;
	}
}
</script>

<style lang="scss"></style>
