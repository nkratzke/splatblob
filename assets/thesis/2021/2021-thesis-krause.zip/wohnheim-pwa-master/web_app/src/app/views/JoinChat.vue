<template>
	<div class="container">
		<h1 class="title">Join a chat</h1>

		<InputField
			label="Chat Id"
			placeholder="wohnheimpwa-1234566789-asd2mf123n3n"
			type="text"
			errorText="Is not a valid chat id"
			validator="NOT_EMPTY"
			leftIcon="envelope"
			id="chat-id"
			@validChanged="validChange"
			@valueChanged="valueChange"
		>
		</InputField>

		<InputField
			label="Adminestrator e-mail address"
			placeholder="somebody@example.net"
			type="email"
			errorText="Is not a valid email"
			validator="EMAIL"
			leftIcon="envelope"
			id="email"
			@validChanged="validChange"
			@valueChanged="valueChange"
		>
		</InputField>

		<div class="field">
			<div class="control">
				<button
					class="button"
					:disabled="!dataIsValid"
					@click="sendJoinRequest"
				>
					Send Request
				</button>
			</div>
		</div>
	</div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { ActionTypes } from '../store/ActionTypes';
import { Utils } from '../../email/utils';
import { JoinRequestMessage } from '../../email/content_messages/JoinRequestMessage';
import { EMail } from '../../email';
import { EMailDefaults } from '../../Config';
import { ChatContentTypes } from '../../email/ChatContentTypes';
import InputField from '../components/InputField.vue';

@Component({
	components: { InputField },
})
export default class NewChat extends Vue {
	private chatId: string = '';
	private chatIdIsValid: boolean = false;
	private adminEmail: string = '';
	private adminEmailIsValid: boolean = false;

	private valueChange(payload: { from: string; value: any }) {
		switch (payload.from) {
			case 'chat-id':
				this.chatId = payload.value;
				break;
			case 'email':
				this.adminEmail = payload.value;
				break;
		}
	}

	private validChange(payload: { from: string; value: boolean }) {
		switch (payload.from) {
			case 'chat-id':
				this.chatIdIsValid = payload.value;
				break;
			case 'email':
				this.adminEmailIsValid = payload.value;
				break;
		}
	}

	private sendJoinRequest() {
		const subject = `${this.loggedInUser.email} whats to join the chat ${this.chatId}`;
		const email = new EMail(
			{
				from: this.loggedInUser.email,
				to: [this.adminEmail],
				subject: subject,
				date: Utils.dateToTimeString(Utils.getCurrentDateTime()),
				messageId: EMail.genId(this.getCurrentProviderBaseUrl()),
				mimeVersion: EMailDefaults.mimeVersion,
				contentType: EMailDefaults.contentType,
				chatVersion: EMailDefaults.chatVersion,
				chatId: this.chatId,
				chatContent: ChatContentTypes.JOIN_REQUEST,
			},
			subject,
		);
		this.$store.dispatch(ActionTypes.SEND_EMAIL, {
			email: email,
		});
	}

	get loggedInUser() {
		return this.$store.state.loginUser;
	}

	get chatIdClass() {
		return `input ${!this.chatIdIsValid ? 'is-danger ' : 'is-success'}`;
	}

	get adminEmailClass() {
		return `input ${!this.adminEmailIsValid ? 'is-danger ' : 'is-success'}`;
	}

	get dataIsValid() {
		return this.chatIdIsValid && this.adminEmailIsValid;
	}

	getCurrentProviderBaseUrl() {
		return this.$store.getters.getCurrentProviderBaseUrl();
	}
}
</script>

<style lang="scss"></style>
