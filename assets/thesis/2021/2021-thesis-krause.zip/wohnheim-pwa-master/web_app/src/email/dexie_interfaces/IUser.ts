export interface IUser {
	email: string; // pk
	nickname?: string;
}
