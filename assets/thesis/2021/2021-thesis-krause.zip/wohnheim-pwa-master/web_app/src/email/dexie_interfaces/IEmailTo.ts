export interface IEmailTo {
	email: string; // fk of an user
	messageId: string; // fk of an email
}
