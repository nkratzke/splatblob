export interface ISetting {
	key: string;
	value: any;
}
