## Aufbau
#
- bachelorarbeit -> Source des Bachelorarbeit in Form eines LaTeX Projekts
- email_proxy -> E-Mail-Proxy Source Code, Dockerfile und Pipelines
- web_app -> PWA Source Code, Dockerfile und