# {{ project_name }}

Your project runs inside of your dedicated namespace ```{{ namespace }}``` in the Kubernetes cluster. The FQDN (Fully Qualified Domain Name) allocated for this project is ```{{ namespace_fqdn }}```. A certificate has also been issued to enable secure connections. You can find the details in the ```kubernetes_manifests/ingress.yaml``` file, which defines the Ingress resource.

To find out more about how to use the Ingress resource, head over to the the Kubernetes documentation on [Ingress resources](https://kubernetes.io/docs/concepts/services-networking/ingress/), or to the [Nginx Ingress Controller](https://kubernetes.github.io/ingress-nginx/user-guide/basic-usage/) documentation. In the latter you will find help on specific annotations you can use in your Ingress resource.

Currently, the Ingress resource exposes your application service{% if user_interface != "none" %} and user interface service at the following URLs:{% else %} at the following URL:{% endif %}

- Application: {{ application_url }} **(It may take a moment until your app is running)**{% if user_interface != "none" %}
- User interface: {{ user_interface_url }}{% endif %}

## Project Structure

- **application**: This directory contains the source code of your application. Additionally, it contains the ```Dockerfile``` to build the container image of your application.
{% if job %}  - **jobs**: This subdirectory containing a job manifest file is located inside of your source code so that the application has access to it. The application loads the manifest to be able to create a new job via the Kubernetes API. See [here](https://kubernetes.io/docs/concepts/workloads/controllers/job/) for more information about the job workload.
{% endif %}{% if cron_job %}- **cron_job**: This directory contains the source code for tasks that you want to run as cron jobs. Additionally, it contains the ```Dockerfile``` to build the container image of your cron job.
{% endif %}- **kubernetes_manifests**: This directory contains the manifest files that describe your desired cluster state. These manifests make use of the following Kubernetes concepts (defined by the ```kind``` property):
  - [Deployment](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)
  - [Service](https://kubernetes.io/docs/concepts/services-networking/service/)
  {% if cron_job %}- [CronJob](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/)
  {% endif %}{% if persistence %}- [PersistentVolumeClaim](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)
  {% endif %}- [Ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/)
{% if user_interface != "none" %}- **user_interface**: This directory contains the source code of your user interface. The containing ```Dockerfile``` builds and packages the html files into an Nginx container image.
{% endif %}- **.editorconfig**: This file configures the formatting behavior of your IDE. See [here](https://editorconfig.org/) for more information.
- **.gitlab-ci.yml**: This file configures the continuos integration and deployment pipeline. See [here](https://docs.gitlab.com/ce/ci/yaml/) for more information.

## Connecting to the cluster

This project contains two variables ([Settings -> CI/CD -> Variables]({{ project_url }}/-/settings/ci_cd)) that are used by the CI/CD pipeline runners and that you can use for your local setup.

- The ```K8S_NAMESPACE``` variable associates this project with a namespace and gives the ability to delete the namespace in the ```Delete Namespace``` job (see in the ```.gitlab-ci.yml``` file).
- The ```KUBECONFIG``` variable actually is a file and keeps the credentials of your service account. It represents a configuration for your chosen tool and sets a default context so that the tool knows in which namespace it should execute the commands.

Two helpful and recommended tools for working with the cluster are [Kubectl](https://kubernetes.io/docs/reference/kubectl/overview/) and [Lens](https://k8slens.dev/).

### Kubectl

With the ```kubectl``` tool you can directly create and modify the resources in the cluster from your local device. After you have [installed kubectl](https://kubernetes.io/docs/tasks/tools/install-kubectl/), you need to configure it. By default, its corresponding ```config``` file is located in the ```.kube``` folder in your home path. The easiest way to connect to the cluster is to copy the content of the ```KUBECONFIG``` variable into this ```config``` file. Kubectl will then automatically connect to the default context. However, if you have previously connected to other clusters, it is better to [add another context](https://kubernetes.io/docs/tasks/access-application-cluster/configure-access-multiple-clusters/) to the ```config``` file.

### Lens

Lens is a useful tool to inspect and debug your whole cluster state through an intuitive graphical user interface. After you have installed the tool, you can connect to a cluster by pressing the left "+" button. The easiest way is to copy the content of the ```KUBECONFIG``` variable into the text field within the _Paste as text_ tab. If you have already configured kubectl, you can also select your local kubeconfig file. Now, when connected to your namespace, you can discover every resource and its state.

## Updating the deployment

When you push new code on to the master branch, the CI/CD pipeline will automatically build, tag, and push the new container image(s) to the GitLab registry. The pipeline will then apply the deployment manifests (from the ```/kubernetes_manifests``` directory) in your namespace. Kubernetes tries to match the current state of the cluster with the desired state defined in these manifests. But since Kubernetes cannot detect changes in the container images, it cannot automatically pull new images from the GitLab registry in case you have built a new image version.

Thus the Kubernetes cluster must somehow notice that a new version of the image is available.

- Option one, the preferred option, is to change the tag of the container image. The tag describes the version of an image and gets defined by the ```spec.containers[].image``` property in each deployment manifest. Make sure that the tags in your manifests match the ones in your build pipeline (described by the ```.gitlab-ci.yml``` file). This method ensures that Kubernetes updates the cluster state in a controlled manner according to the [deployment strategy](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy).

  - What you could also do is working with Git tags. You can change the ```only: ["master"]``` rule to ```only: ["tags"]``` and the pipeline will then only build and deploy changes when you tag a commit. The advantage is that you can then make use of the [predefined environment variables](https://docs.gitlab.com/ee/ci/variables/predefined_variables.html) of GitLab runners. Just change the tags (initially set to ```0.1.0```) in the ```.gitlab-ci.yml``` file to ```$CI_COMMIT_TAG```. Now you would only need to update the tag in the deployment manifests according to the Git tag.

- Option two, the quick and dirty option, is to manually delete the ReplicaSet or Pod of a Deployment after the build pipeline passed through. Kubernetes then tries to recondition the desired state by pulling the new image version and starting a new ReplicaSet and/or Pod. This only works when you have set the ```imagePullPolicy``` to ```Always``` (see [here](https://kubernetes.io/docs/concepts/containers/images/#updating-images) for more information) and means that your app will be down for a short moment.
