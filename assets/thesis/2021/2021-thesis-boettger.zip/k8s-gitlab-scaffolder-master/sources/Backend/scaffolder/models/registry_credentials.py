class RegistryCredentials:
    def __init__(self, user_name: str, user_password: str):
        self.name = user_name
        self.password = user_password
