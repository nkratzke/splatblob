import secrets
import string
from slugify import slugify


def get_slug(name: str):
    """
    Converts a given string into a slug. That means it removes all special characters or replaces them with
    alternatives. Blank characters are filled with hyphens. The purpose is to be able to use the string in URLs.

    :param name: The string to be converted into a slug
    :return: The resulting slug, e.g. 'Lübecker Straße' -> ' luebecker-strasse'
    """
    return slugify(name, replacements=[['Ü', 'ue'], ['ü', 'ue'],
                                       ['Ä', 'ae'], ['ä', 'ae'],
                                       ['Ö', 'oe'], ['ö', 'oe'],
                                       ['ß', 'ss']])


def get_random_str(size=16, chars=string.ascii_uppercase + string.digits):
    """
    Generate a cryptographically secure random string.

    The size should be set to at least 16 to prevent session hijacking through brute force attacks.

    The formula is: ((26 + 10)^size) / (guesses_per_second * valid_sessions) = seconds

    :param size: The length of the resulting string
    :param chars: A string of all possible characters to choose from
    :return: A cryptographically secure random string
    """
    return "".join(secrets.SystemRandom().choice(chars) for _ in range(size))
