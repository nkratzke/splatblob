package dev.thluebeck.crud;
{% if job %}
import dev.thluebeck.crud.jobs.AddNamesJob;
import dev.thluebeck.crud.jobs.JobMessage;{% endif %}
import dev.thluebeck.crud.model.Name;
import dev.thluebeck.crud.model.NameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@SpringBootApplication
@RestController
@RequestMapping("/api/names")
public class CrudApplication {

    @Autowired
    private NameRepository nameRepository;{% if job %}
    @Autowired
    private AddNamesJob addNamesJob;{% endif %}

    public static void main(String[] args) {
        SpringApplication.run(CrudApplication.class, args);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Name create(@RequestBody Name name) {
        return nameRepository.save(name);
    }

    @GetMapping
    public Iterable<Name> read() {
        return nameRepository.findAll();
    }

    @PutMapping("/{name_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void update(@PathVariable String name_id, @RequestBody Name updatedName) {
        Optional<Name> name = nameRepository.findById(name_id);
        if (name.isPresent()) {
            Name nameToUpdate = name.get();
            nameToUpdate.setName(updatedName.getName());
            nameRepository.save(nameToUpdate);
        }
    }

    @DeleteMapping("/{name_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String name_id) {
        nameRepository.deleteById(name_id);
    }{% if job %}

    @GetMapping("/createMany")
    public JobMessage createMany() {
        return addNamesJob.run();
    }{% endif %}
}
