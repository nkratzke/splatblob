import string
import random
from redis import Redis
import os


class Datastore:
    def __init__(self):
        self.connection: Redis = Redis(host=os.getenv("DATA_STORAGE_HOSTNAME"),
                                       port=6379,
                                       db=0,
                                       password=os.getenv("DATA_STORAGE_PASSWORD"))

    def add(self, name: str):
        new_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        self.connection.set(new_id, name)
        return {"name_id": new_id, "name": name}

    def get_all(self):
        names = []
        keys = self.connection.keys("*")
        for key in keys:
            names.append({"name_id": key, "name": self.connection.get(key)})
        return names

    def update(self, name_id, name):
        self.connection.set(name_id, name)

    def delete(self, name_id):
        self.connection.delete(name_id)

    def shutdown(self):
        self.connection.close()
