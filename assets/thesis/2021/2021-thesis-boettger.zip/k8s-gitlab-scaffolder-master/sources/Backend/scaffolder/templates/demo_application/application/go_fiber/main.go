{% set data_storage_class = "InMemory" if data_storage == "in_memory" else ("MySql" if data_storage == "mysql" else ("MongoDb" if data_storage == "mongo_db" else "Redis")) %}package main

import (
	"crud-app-go/data_access"{% if job %}
	"crud-app-go/jobs"{% endif %}
	"crud-app-go/model"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/gofiber/fiber/v2"
)

type Datastore interface {
	Init() error
	Create(name string) (model.Name, error)
	Read() ([]model.Name, error)
	Update(id, name string) error
	Delete(id string) error
	Shutdown()
}

func main() {
	var store Datastore = &data_access.{{ data_storage_class }}{}
	if err := store.Init(); err != nil {
		log.Fatalln(err)
	}

	{% if job %}addNamesJob, err := jobs.NewAddNamesJob()
	if err != nil {
		log.Fatalln(err)
	}

	{% endif %}app := fiber.New()

	app.Get("/api/names", func(ctx *fiber.Ctx) error {
		names, err := store.Read()
		if err != nil {
			return err
		}
		return ctx.JSON(names)
	})

	app.Post("/api/names", func(ctx *fiber.Ctx) error {
		newName := &model.Name{}
		if err := ctx.BodyParser(newName); err != nil {
			return err
		}
		createdName, err := store.Create(newName.Name)
		if err != nil {
			return err
		}
		return ctx.Status(201).JSON(createdName)
	})

	app.Put("/api/names/:id", func(ctx *fiber.Ctx) error {
		id := ctx.Params("id")
		updatedName := &model.Name{}
		if err := ctx.BodyParser(updatedName); err != nil {
			return err
		}
		if err := store.Update(id, updatedName.Name); err != nil {
			return err
		}
		return ctx.SendStatus(204)
	})

	app.Delete("/api/names/:id", func(ctx *fiber.Ctx) error {
		id := ctx.Params("id")
		if err := store.Delete(id); err != nil {
			return err
		}
		return ctx.SendStatus(204)
	}){% if job %}

	app.Get("/api/names/createMany", func(ctx *fiber.Ctx) error {
		return ctx.JSON(addNamesJob.Run())
	}){% endif %}

	// Run http web server
	go func() {
		if err := app.Listen(":80"); err != nil {
			log.Panicln(err)
		}
	}()

	// Prepare graceful shutdown
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)

	// Block until shutdown signal received
	_ = <-c
	log.Println("Shutting down...")
	if err := app.Shutdown(); err != nil { // Note: does not shut down before clients close keep-alive connections
		log.Println(err)
	}
	store.Shutdown()
}
