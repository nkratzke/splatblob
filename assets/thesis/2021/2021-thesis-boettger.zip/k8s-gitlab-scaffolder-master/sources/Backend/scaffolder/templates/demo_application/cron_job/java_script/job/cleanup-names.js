const axios = require("axios").default

const applicationUrl = process.env.APP_URL
const maximumLength = parseInt(process.env.MAXIMUM_LENGTH)

axios.get(applicationUrl + "/names")
    .then(response => {
        response.data
            .slice(maximumLength)
            .forEach(async entry => await axios.delete(`${applicationUrl}/names/${entry.name_id}`))
    })
    .catch(error => console.log(error))
