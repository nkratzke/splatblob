package dev.thluebeck.crud.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.Id;

import java.util.UUID;

public class Name {
    @Id
    private String id;
    private String name;

    public Name(String name) {
        this.id = UUID.randomUUID().toString().replace("-", "").substring(10);
        this.name = name;
    }

    public Name() {
    }

    @JsonProperty("name_id")
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
