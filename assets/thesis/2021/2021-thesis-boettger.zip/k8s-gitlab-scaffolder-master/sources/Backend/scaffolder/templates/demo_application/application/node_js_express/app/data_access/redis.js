const redis = require("redis")
const { promisify } = require("util")


class RedisDatastore {
    async add(name) {
        const newId = (+new Date).toString(36)
        await this.redisSet(newId, name)
        return { name_id: newId, name: name }
    }

    async getAll() {
        const keys = await this.redisKeys("*")
        let names = []
        for (const key of keys) {
            names.push({ name_id: key, name: await this.redisGet(key) })
        }
        return names
    }

    async update(id, name) {
        await this.redisSet(id, name)
    }

    async delete(id) {
        await this.redisDel(id)
    }

    async connect() {
        console.log("Initialize connection to Redis datastore")
        this.client = redis.createClient({
            host: process.env.DATA_STORAGE_HOSTNAME,
            password: process.env.DATA_STORAGE_PASSWORD
        })

        this.client.on("error", function (error) {
            console.error(error);
        })

        console.log("Promisifying the needed Redis client commands")
        this.redisSet = promisify(this.client.set).bind(this.client)
        this.redisDel = promisify(this.client.del).bind(this.client)
        this.redisGet = promisify(this.client.get).bind(this.client)
        this.redisKeys = promisify(this.client.keys).bind(this.client)
        this.redisQuit = promisify(this.client.quit).bind(this.client)
    }

    async shutdown() {
        await this.redisQuit()
    }
}

module.exports = RedisDatastore
