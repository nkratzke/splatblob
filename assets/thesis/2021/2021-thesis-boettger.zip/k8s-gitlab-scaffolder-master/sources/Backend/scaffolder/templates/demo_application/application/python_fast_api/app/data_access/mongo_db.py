from bson import ObjectId
from pymongo import MongoClient
import os


class Datastore:
    def __init__(self):
        host = os.getenv("DATA_STORAGE_HOSTNAME")
        pw = os.getenv("DATA_STORAGE_PASSWORD")
        url = f"mongodb://root:{pw}@{host}:27017/"
        self.connection: MongoClient = MongoClient(url)
        self.collection = self.connection.get_database("names_list").get_collection("names_list")

    def add(self, name: str):
        response = self.collection.insert_one({"name": name})
        return {"name_id": str(response.inserted_id), "name": name}

    def get_all(self):
        names = []
        for entry in self.collection.find():
            names.append({"name_id": str(entry["_id"]), "name": entry["name"]})
        return names

    def update(self, name_id, name):
        self.collection.update_one({"_id": ObjectId(name_id)}, {"$set": {"name": name}})

    def delete(self, name_id):
        self.collection.delete_one({"_id": ObjectId(name_id)})

    def shutdown(self):
        self.connection.close()
