import pymysql
import os
from dbutils.pooled_db import PooledDB


class Datastore:
    def __init__(self):
        self.pooledConnection: PooledDB = PooledDB(pymysql, 1,
                                                   host=os.getenv("DATA_STORAGE_HOSTNAME", ""),
                                                   user="root",
                                                   password=os.getenv("DATA_STORAGE_PASSWORD", ""),
                                                   db="names_db",
                                                   charset="utf8mb4",
                                                   cursorclass=pymysql.cursors.DictCursor)

    def add(self, name: str):
        con: pymysql.Connection = self.pooledConnection.connection()
        with con.cursor() as cursor:
            sql = "INSERT INTO some_names (name) VALUES (%s);"
            cursor.execute(sql, (name,))
            insert_id = cursor.lastrowid
        con.commit()
        con.close()
        return {"name_id": insert_id, "name": name}

    def get_all(self):
        con = self.pooledConnection.connection()
        with con.cursor() as cursor:
            cursor.execute("SELECT * FROM some_names;")
            names = cursor.fetchall()
        con.close()
        return names

    def update(self, name_id, name):
        con = self.pooledConnection.connection()
        with con.cursor() as cursor:
            sql = "UPDATE some_names SET name = %s WHERE name_id = %s;"
            cursor.execute(sql, (name, name_id))
        con.commit()
        con.close()

    def delete(self, name_id):
        con = self.pooledConnection.connection()
        with con.cursor() as cursor:
            sql = "DELETE FROM some_names WHERE name_id = %s;"
            cursor.execute(sql, (name_id,))
        con.commit()
        con.close()

    def shutdown(self):
        self.pooledConnection.close()
