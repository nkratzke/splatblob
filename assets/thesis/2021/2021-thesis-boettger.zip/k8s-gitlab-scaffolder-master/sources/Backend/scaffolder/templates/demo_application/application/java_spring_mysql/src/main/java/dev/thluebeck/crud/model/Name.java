package dev.thluebeck.crud.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;

@Entity
@Table(name = "some_names")
public class Name {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long name_id;
    private String name;

    public Name(String name) {
        this.name = name;
    }

    public Name() {
    }

    public long getName_id() {
        return name_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
