class CreatedProject:
    def __init__(self, id_: int, name: str, web_url: str, path: str, path_with_namespace: str):
        self.id = id_
        self.name = name
        self.web_url = web_url
        self.path = path
        self.path_with_namespace = path_with_namespace
