import json
import httpx
import redis
from nameparser import HumanName
from scaffolder import config
from scaffolder.models.session_check import SessionCheck
from scaffolder.services import utils

redis_sessions = redis.Redis(host=config.REDIS_HOSTNAME, db=0, password=config.REDIS_PASSWORD.split()[1])
redis_oauth_states = redis.Redis(host=config.REDIS_HOSTNAME, db=1, password=config.REDIS_PASSWORD.split()[1])


def get_login_redirect_url():
    """
    Creates a URL to which the user should get forwarded to in order to log in. It leads to the OAuth-specific log in
    page of GitLab on which the user can log in and grant API rights to the scaffolder app.

    :return: A URL as a string
    """
    state = utils.get_random_str()
    redis_oauth_states.setex(state, config.LOGIN_TTL, "")
    url = config.GITLAB_SERVER_URL + \
          f"/oauth/authorize?client_id={config.GITLAB_APP_ID}&redirect_uri={config.REDIRECT_URL}&response_type=code&state={state}&scope=api"
    return url


def is_state_param_present(state: str):
    """
    Checks if the unique state parameter is present in the database. The unique state parameter is used to prevent CSRF
    attacks. See in the OAuth 2.0 specification for more information about the state parameter:
    https://tools.ietf.org/html/rfc6749#section-10.12

    :param state: A string that the client passes as query parameter when logging in
    :return: Boolean if the state parameter is present
    """
    present = True if redis_oauth_states.exists(state) else False
    redis_oauth_states.delete(state)
    return present


def get_new_session(code: str):
    """
    Creates a new user session after the user successfully authorized the scaffolder app. The session automatically
    expires after config.SESSION_TTL seconds of inactivity.

    :param code: The authorization code that gets set by GitLab in the authorization redirect
    :return: A new session ID as string
    """
    # request a new access token for the user
    params = {"client_id": config.GITLAB_APP_ID, "client_secret": config.GITLAB_APP_SECRET, "code": code,
              "grant_type": "authorization_code", "redirect_uri": config.REDIRECT_URL}
    resp = httpx.post(config.GITLAB_SERVER_URL + "/oauth/token", params=params)

    # create a new session
    session_id = utils.get_random_str() + str(resp.json()["created_at"])
    redis_sessions.setex(session_id, config.SESSION_TTL, resp.text)
    return session_id


def refresh_session(session_id: str):
    """
    Refresh the user session expiration on user interactions.

    :param session_id: The session ID string
    :return: Boolean, true if the session was found and refreshed, false if the refresh was not possible
    """
    return True if redis_sessions.expire(session_id, config.SESSION_TTL) else False


def is_session_valid(session_id: str):
    """
    Checks if the user session is still valid. That includes checking if the session is present in the database and
    that the user did not revoke the GitLab API rights.

    :param session_id: The session ID string
    :return: A SessionCheck object containing user details
    """
    # check if session is present
    session = redis_sessions.get(session_id)
    if session:
        access_token = json.loads(session)["access_token"]

        # check if the access token is still valid by requesting the user info
        headers = {"Authorization": "Bearer " + access_token}
        resp = httpx.get(config.GITLAB_SERVER_URL + "/api/v4/user", headers=headers)
        try:
            resp_json = resp.json()
            name: HumanName = HumanName(resp_json["name"])
            email: str = resp_json["email"]
            greet_name = f"{name.first} {name.middle}" if name.middle else f"{name.first}"
            return SessionCheck(True, greet_name, email)
        except KeyError:
            pass
    return SessionCheck(False)


def delete_session(session_id: str):
    """
    Invalidates the user session by deleting it from the database.

    :param session_id: The session ID string
    :return: None
    """
    redis_sessions.delete(session_id)


def get_access_token(session_id: str):
    """
    Returns the GitLab API access token for the particular user session.

    :param session_id: The session ID string
    :return: The GitLab API access token as string
    """
    session = redis_sessions.get(session_id)
    if session:
        access_token: str = json.loads(session)["access_token"]
        return access_token
    else:
        raise KeyError(f"Session with id '{session_id}' not present")
