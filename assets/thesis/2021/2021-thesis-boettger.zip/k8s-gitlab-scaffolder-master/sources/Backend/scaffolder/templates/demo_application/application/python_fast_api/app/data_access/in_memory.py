class Datastore:
    def __init__(self):
        self.datastore = {}
        self.highest_id = 0

    def add(self, name: str):
        self.highest_id += 1
        self.datastore[self.highest_id] = name
        return {"name_id": self.highest_id, "name": name}

    def get_all(self):
        names_list = []
        for name_id, name in self.datastore.items():
            names_list.append({"name_id": name_id, "name": name})
        return names_list

    def update(self, name_id, name):
        self.datastore[int(name_id)] = name

    def delete(self, name_id):
        self.datastore.pop(int(name_id), None)

    def shutdown(self):
        pass  # nothing to do here
