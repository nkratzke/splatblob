class Secret:
    def __init__(self, name: str, key: str, value: str):
        self.name = name
        self.key = key
        self.value = value
