from collections import defaultdict
from kubernetes import client as k8s_client, config as k8s_config, utils as k8s_utils
from kubernetes.utils import FailToCreateError
from pint import UnitRegistry
from scaffolder import config
from scaffolder.models.registry_credentials import RegistryCredentials
from scaffolder.services import utils
from jinja2 import Environment, PackageLoader, select_autoescape
import yaml
import base64

# load kubeconfig when module gets imported
if config.IN_CLUSTER:
    k8s_config.load_incluster_config()
else:
    k8s_config.load_kube_config(config.KUBECONFIG_LOCATION)

core_v1_client = k8s_client.CoreV1Api()
api_client = k8s_client.ApiClient()

# load and compile the templates
templates = Environment(
    loader=PackageLoader("scaffolder", "templates/namespace_creation"),
    autoescape=select_autoescape()
)

# load the unit registry to convert K8s units
ureg = UnitRegistry()
ureg.load_definitions("./scaffolder/files/kubernetes_units.txt")


def is_capacity_sufficient():
    """
    Checks if the requested cluster resources do not exceed 95% of all cluster capacities.

    :return: Boolean if cluster capacity is sufficient for a new namespace and deployment
    """
    allocated_resources = get_allocated_resources()
    for node in allocated_resources:
        print("Check capacity (in %): CPU=", float(node["cpu_req_percent"]), "MEM=", float(node["mem_req_percent"]))
        if float(node["cpu_req_percent"]) > 95. or float(node["mem_req_percent"]) > 95.:
            return False
    return True


def get_allocated_resources():
    """
    Retrieves all nodes and pods in the cluster, and computes the percentage used of the 'request' and 'limit' values
    for the 'cpu' and 'memory'.

    Source: https://gist.github.com/gorenje/dff508489c3c8a460433ad709f14b7db

    :return: A list of dicts (with each resource type) for each node in the cluster
    """
    Q_ = ureg.Quantity
    data = []

    for node in core_v1_client.list_node().items:
        stats = {}
        node_name = node.metadata.name
        allocatable = node.status.allocatable
        max_pods = int(int(allocatable["pods"]) * 1.5)
        field_selector = ("status.phase!=Succeeded,status.phase!=Failed," +
                          "spec.nodeName=" + node_name)

        stats["cpu_alloc"] = Q_(allocatable["cpu"])
        stats["mem_alloc"] = Q_(allocatable["memory"])

        pods = core_v1_client.list_pod_for_all_namespaces(limit=max_pods,
                                                          field_selector=field_selector).items

        # compute the allocated resources
        cpureqs, cpulmts, memreqs, memlmts = [], [], [], []
        for pod in pods:
            for container in pod.spec.containers:
                res = container.resources
                reqs = defaultdict(lambda: 0, res.requests or {})
                lmts = defaultdict(lambda: 0, res.limits or {})
                cpureqs.append(Q_(reqs["cpu"]))
                memreqs.append(Q_(reqs["memory"]))
                cpulmts.append(Q_(lmts["cpu"]))
                memlmts.append(Q_(lmts["memory"]))

        stats["cpu_req"] = sum(cpureqs)
        stats["cpu_lmt"] = sum(cpulmts)
        stats["cpu_req_percent"] = (stats["cpu_req"] / stats["cpu_alloc"] * 100)
        stats["cpu_lmt_percent"] = (stats["cpu_lmt"] / stats["cpu_alloc"] * 100)

        stats["mem_req"] = sum(memreqs)
        stats["mem_lmt"] = sum(memlmts)
        stats["mem_req_percent"] = (stats["mem_req"] / stats["mem_alloc"] * 100)
        stats["mem_lmt_percent"] = (stats["mem_lmt"] / stats["mem_alloc"] * 100)

        data.append(stats)

    return data


def is_name_available(name: str):
    """
    Checks if the namespace name is still available.

    :param name: The desired project name
    :return: Boolean if name available
    """
    name_slug = utils.get_slug(name)

    # "kube-" is reserved for Kubernetes system namespaces
    if name_slug.startswith("kube-"):
        return False

    namespaces = core_v1_client.list_namespace()
    for namespace in namespaces.items:
        if namespace.metadata.name == name_slug:
            return False
    return True


def get_new_namespace(namespace: str, user_email: str):
    """
    Creates a new namespace in the Kubernetes cluster. It does so by rendering the
    /templates/namespace_creation/namespace.yaml template and applying it in the cluster.

    :param namespace: The namespace's name
    :param user_email: The user email address
    :return: The yaml-formatted content of the kubeconfig with the access credentials of the service account in the newly created namespace
    """
    k8s_objects = templates.get_template("namespace.yaml").render({
        "namespace": namespace,
        "email_address": user_email.split("@")[0],
        "email_server": user_email.split("@")[1],
        "QUOTA_REQUESTS_MEM": config.QUOTA_REQUESTS_MEM,
        "QUOTA_REQUESTS_CPU": config.QUOTA_REQUESTS_CPU,
        "QUOTA_REQUESTS_STORAGE": config.QUOTA_REQUESTS_STORAGE,
        "QUOTA_LIMITS_MEM": config.QUOTA_LIMITS_MEM,
        "QUOTA_LIMITS_CPU": config.QUOTA_LIMITS_CPU,
        "QUOTA_PVC": config.QUOTA_PVC,
        "QUOTA_PODS": config.QUOTA_PODS,
        "DEFAULT_REQUEST_MEM": config.DEFAULT_REQUEST_MEM,
        "DEFAULT_REQUEST_CPU": config.DEFAULT_REQUEST_CPU,
        "DEFAULT_LIMIT_MEM": config.DEFAULT_LIMIT_MEM,
        "DEFAULT_LIMIT_CPU": config.DEFAULT_LIMIT_CPU,
        "MAX_LIMIT_MEM": config.MAX_LIMIT_MEM,
        "MAX_LIMIT_CPU": config.MAX_LIMIT_CPU
    })

    yaml_documents = yaml.safe_load_all(k8s_objects)
    failures = []
    for yaml_document in yaml_documents:
        try:
            k8s_utils.create_from_dict(api_client, yaml_document, verbose=True)
        except FailToCreateError as failure:
            failures.extend(failure.api_exceptions)

    for failure in failures:
        print(failure.reason, failure.body)

    return __get_kubeconfig(namespace)


def __get_kubeconfig(namespace: str):
    """
    Returns the kubeconfig for the default service account of a namespace.

    :param namespace: The namespace's name
    :return: A string with the yaml-formatted content of the kubeconfig
    """
    secret_default_service_account = core_v1_client.list_namespaced_secret(namespace).items[0].data

    kubeconfig = templates.get_template("kubeconfig.yaml").render({
        "namespace": namespace,
        "ca_certificate": secret_default_service_account["ca.crt"],
        "token": base64.b64decode(secret_default_service_account["token"]).decode("utf-8"),
        "KUBERNETES_API_SERVER_URL": config.KUBERNETES_API_SERVER_URL
    })

    return kubeconfig


def set_registry_credentials(namespace: str, registry_cred: RegistryCredentials):
    """
    Creates a new secret in the particular namespace in the cluster. The created secret will be of type
    'kubernetes.io/dockerconfigjson'. It automatically builds a base64 encoded dockerconfig file that gets set as value
    in the secret.

    :param namespace: The namespace's name
    :param registry_cred: A RegistryCredentials object
    :return: None
    """
    registry_credentials_secret = templates.get_template("registry_credentials_secret.yaml").render({
        "docker_config_encoded": base64.b64encode(
            __get_docker_config_json(registry_cred.name, registry_cred.password).encode("utf-8")).decode("utf-8")
    })

    body = yaml.safe_load(registry_credentials_secret)
    core_v1_client.create_namespaced_secret(namespace, body=body)


def __get_docker_config_json(registry_user: str, registry_password: str):
    """
    Renders the /templates/namespace_creation/dockerconfig.json and returns the content.

    :param registry_user: The user name to access the registry
    :param registry_password: The user password to access the registry
    :return: A string with the dockerconfig's content
    """
    docker_config_json = templates.get_template("dockerconfig.json").render({
        "registry_user": registry_user,
        "registry_password": registry_password,
        "auth_encoded": base64.b64encode(f"{registry_user}:{registry_password}".encode("utf-8")).decode("utf-8"),
        "GITLAB_REGISTRY_FQDN": config.GITLAB_REGISTRY_FQDN,
        "GITLAB_REGISTRY_PORT": config.GITLAB_REGISTRY_PORT
    })

    return docker_config_json


def set_secret(namespace: str, name: str, key: str, value: str):
    """
    Creates a new secret in the particular namespace in the cluster. The created secret will be of type 'Opaque'.

    :param namespace: The namespace's name
    :param name: The secret's name
    :param key: The secret's key name
    :param value: The key's value
    :return: None
    """
    secret = templates.get_template("secret.yaml").render({
        "name": name,
        "key": key,
        "value": base64.b64encode(value.encode("utf-8")).decode("utf-8")
    })

    body = yaml.safe_load(secret)
    core_v1_client.create_namespaced_secret(namespace, body=body)
