from typing import Optional, List
from pydantic import BaseModel


class TechOption(BaseModel):
    value: str
    text: str
    disabled: Optional[bool] = None


class TechStackOptions(BaseModel):
    userInterface: List[TechOption]
    application: List[TechOption]
    dataStorage: List[TechOption]


class CheckCapacity(BaseModel):
    capacitySufficient: bool


class CheckName(BaseModel):
    projectNameAvailable: bool


class CheckSession(BaseModel):
    sessionValid: bool
    userName: Optional[str] = None


class ProjectDetails(BaseModel):
    projectName: str
    projectURL: str
