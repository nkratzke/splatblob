from typing import List
from fastapi import FastAPI, Response
from app.data_access.{{ data_storage }} import Datastore{% if job %}
from app.jobs.add_names import AddNamesJob{% endif %}
from app.models.create_name_request import Name{% if job %}
from app.models.created_many_names_response import CreatedManyMessage{% endif %}
from app.models.created_name_response import CreatedName

app = FastAPI()

ingressPath = "/api"
data = Datastore(){% if job %}
add_names_job = AddNamesJob(){% endif %}


@app.post(ingressPath + "/names", response_model=CreatedName, status_code=201)
def create(body: Name):
    return data.add(body.name)


@app.get(ingressPath + "/names", response_model=List[CreatedName])
def read():
    return data.get_all()


@app.put(ingressPath + "/names/{name_id}", status_code=204)
def update(name_id: str, body: Name):
    data.update(name_id, body.name)
    return Response(status_code=204)  # return empty Response instead of default JSONResponse type


@app.delete(ingressPath + "/names/{name_id}", status_code=204)
def delete(name_id: str):
    data.delete(name_id)
    return Response(status_code=204)

{% if job %}
@app.get(ingressPath + "/names/createMany", response_model=CreatedManyMessage)
def create_many_names():
    return add_names_job.run()
{% endif %}
