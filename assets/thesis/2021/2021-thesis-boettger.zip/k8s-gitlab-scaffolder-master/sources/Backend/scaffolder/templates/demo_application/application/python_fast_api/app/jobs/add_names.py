import os
import yaml
from kubernetes import config, client
from kubernetes.client import V1Job


class AddNamesJob:
    def __init__(self):
        self.namespace = os.getenv("POD_NAMESPACE")
        print("Current namespace:", self.namespace)

        config.load_incluster_config()
        self.batch_client = client.BatchV1Api()

        with open("./app/jobs/add_names.yaml", "r") as stream:
            try:
                self.job_body = yaml.safe_load(stream)
            except yaml.YAMLError as exception:
                print(exception)

    def run(self):
        try:
            response: V1Job = self.batch_client.create_namespaced_job(self.namespace, self.job_body)
            message = "Your job was successfully scheduled and is now working as '" + response.metadata.name + \
                      "'. Try to reload the page in a moment."
        except:
            message = "Unfortunately your job could not be scheduled."
        return {"message": message}
