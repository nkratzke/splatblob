class SessionCheck:
    def __init__(self, valid: bool, user_name: str = "", user_email: str = ""):
        self.valid = valid
        self.user_name = user_name
        self.user_email = user_email
