const { MongoClient, ObjectID } = require("mongodb")


class MongoDatabase {
    async add(name) {
        const response = await this.collection.insertOne({ name: name })
        return { name_id: response.insertedId, name: name }
    }

    async getAll() {
        const response = await this.collection.find({}).toArray()
        return response.map(entry => { return { name_id: entry._id, name: entry.name } })
    }

    async update(id, name) {
        await this.collection.updateOne({ _id: ObjectID(id) }, { $set: { name: name } })
    }

    async delete(id) {
        await this.collection.deleteOne({ _id: ObjectID(id) })
    }

    async connect() {
        console.log("Initialize connection to MongoDB")

        const url = `mongodb://root:${process.env.DATA_STORAGE_PASSWORD}@${process.env.DATA_STORAGE_HOSTNAME}:27017/`
        this.client = new MongoClient(url)

        try {
            await this.client.connect()
            await this.client.db("admin").command({ ping: 1 })
            this.collection = this.client.db("names_list").collection("names_list")
            console.log("Connected successfully to MongoDB")
        } catch {
            console.log("Failed to connect to MongoDB")
            await this.client.close()
        }
    }

    async shutdown() {
        await this.client.close()
    }
}

module.exports = MongoDatabase
