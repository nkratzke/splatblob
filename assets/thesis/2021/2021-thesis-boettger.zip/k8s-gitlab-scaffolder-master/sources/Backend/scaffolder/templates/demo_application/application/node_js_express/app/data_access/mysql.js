var mysql = require("mysql2/promise");


class MySqlDatabase {
    async add(name) {
        try {
            const response = await this.database.execute("INSERT INTO some_names (name) VALUES (?);", [name])
            return { name_id: response[0]["insertId"], name: name }
        } catch (error) {
            console.log(error)
        }
    }

    async getAll() {
        try {
            const response = await this.database.execute("SELECT * FROM some_names;")
            return response[0]
        } catch (error) {
            console.log(error)
        }
    }

    async update(id, name) {
        try {
            await this.database.execute("UPDATE some_names SET name = ? WHERE name_id = ?;", [name, id])
        } catch (error) {
            console.log(error)
        }
    }

    async delete(id) {
        try {
            await this.database.execute("DELETE FROM some_names WHERE name_id = ?;", [id])
        } catch (error) {
            console.log(error)
        }
    }

    async connect() {
        console.log("Initialize database connection")
        try {
            this.database = await mysql.createConnection({
                host: process.env.DATA_STORAGE_HOSTNAME,
                user: "root",
                password: process.env.DATA_STORAGE_PASSWORD,
                database: "names_db"
            })
            console.log("Successfully connected to database 'names_db'")
        } catch (error) {
            console.log(error)
        }
    }

    async shutdown() {
        try {
            await this.database.end()
        } catch (error) {
            console.log(error)
        }
    }
}

module.exports = MySqlDatabase
