package data_access;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import model.Name;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class MySql {

    private final HikariDataSource connectionPool;

    public MySql(String hostname, String password) {
        HikariConfig config = new HikariConfig();
        config.addDataSourceProperty("characterEncoding", "utf8");
        config.setJdbcUrl(String.format("jdbc:mysql://%s:3306/names_db", hostname));
        config.setUsername("root");
        config.setPassword(password);
        connectionPool = new HikariDataSource(config);
    }

    public Name createName(String name) {
        final String query = "INSERT INTO some_names (name) VALUES (?);";
        String newId = "";
        try {
            Connection con = this.connectionPool.getConnection();
            PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, name);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected == 0) {
                throw new SQLException("Inserting failed, no row affected.");
            }
            try (ResultSet generatedKeys = pst.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    newId = Long.toString(generatedKeys.getLong(1));
                } else {
                    throw new SQLException("Inserting failed, no ID obtained.");
                }
            }
            con.close();
        } catch (SQLException error) {
            System.out.println(error.toString());
        }
        return new Name(newId, name);
    }

    public List<Name> readNames() {
        List<Name> names = new LinkedList<>();
        try {
            Connection con = this.connectionPool.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM some_names");

            while (rs.next()) {
                names.add(new Name(Integer.toString(rs.getInt("name_id")), rs.getString("name")));
            }
            con.close();
        } catch (SQLException error) {
            System.out.println(error.toString());
        }
        return names;
    }

    public void deleteName(String id) {
        final String query = "DELETE FROM some_names WHERE name_id = ?;";
        try {
            Connection con = this.connectionPool.getConnection();
            PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, id);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected == 0) {
                throw new SQLException("Deleting failed, no row affected.");
            }
            con.close();
        } catch (SQLException error) {
            System.out.println(error.toString());
        }
    }

    public void updateName(String id, String name) {
        final String query = "UPDATE some_names SET name = ? WHERE name_id = ?;";
        try {
            Connection con = this.connectionPool.getConnection();
            PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(2, id);
            pst.setString(1, name);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected == 0) {
                throw new SQLException("Updating failed, no row affected.");
            }
            con.close();
        } catch (SQLException error) {
            System.out.println(error.toString());
        }
    }
}
