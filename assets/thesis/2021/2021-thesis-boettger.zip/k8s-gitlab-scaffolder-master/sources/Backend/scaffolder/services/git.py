from typing import Dict, List
import gitlab
import httpx
from scaffolder import config
from scaffolder.models.created_project import CreatedProject
from scaffolder.models.registry_credentials import RegistryCredentials
from scaffolder.services import utils


def is_name_available(access_token: str, name: str):
    """
    Checks if the desired GitLab project name is available.

    :param access_token: The API access token of the logged in GitLab user
    :param name: The desired project name
    :return: Boolean if the project name is available
    """
    lowered_name = name.lower()
    name_slug = utils.get_slug(name)

    with gitlab.Gitlab(config.GITLAB_SERVER_URL, oauth_token=access_token, per_page=100) as gl:
        projects = gl.projects.list(owned=True, simple=True, all=True)

    for project in projects:
        if project.name.lower() == lowered_name or project.path == name_slug:
            return False
    return True


def get_new_project(access_token: str, name: str, description: str, visibility: str, kubeconfig: str, namespace: str):
    """
    Creates a new GitLab project for the user and initializes it for the interaction between the Kubernetes cluster
    and the CI/CD pipeline. It thus creates environment variables and a so-called deploy token in the GitLab project.

    The deploy token can be used to access the project-internal container registry to which the CI/CD pipeline pushes
    the built container images. The Kubernetes cluster needs the credentials of this deploy token to be able to pull
    images from the user's container registry.

    :param access_token: The API access token of the logged in GitLab user
    :param name: The project name
    :param description: The project description
    :param visibility: The project visibility
    :param kubeconfig: The kubeconfig file's content that shall be set as an environment variable in the GitLab project
    :param namespace: The namespace in the Kubernetes cluster for which the project gets created
    :return: A tuple containing a 'CreatedProject' object and a 'RegistryCredentials' object
    """
    # Create a GitLab project
    headers = {"Authorization": "Bearer " + access_token}
    params = {
        "name": name,
        "path": utils.get_slug(name),
        "description": description,
        "visibility": visibility,
        "container_registry_enabled": True,
        "shared_runners_enabled": True,
        "builds_access_level": "enabled"
    }
    resp = httpx.post(config.GITLAB_SERVER_URL + "/api/v4/projects", headers=headers, params=params)
    if resp.status_code == 201:
        project_resp = resp.json()
        project = CreatedProject(int(project_resp["id"]), project_resp["name"], project_resp["web_url"],
                                 project_resp["path"], project_resp["path_with_namespace"])
    else:
        # raise CreationError("TODO insert information here and catch it accordingly")
        raise ConnectionError(resp)

    # Create an environment variable for the CI/CD runners to access the K8s cluster
    data = {
        "key": "KUBECONFIG",
        # https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/#the-kubeconfig-environment-variable
        "value": kubeconfig,
        "variable_type": "file"
    }
    resp = httpx.post(f"{config.GITLAB_SERVER_URL}/api/v4/projects/{project.id}/variables", headers=headers, data=data)
    if resp.status_code != 201:
        raise ConnectionError(resp)

    # Create an environment variable containing the namespace
    data = {
        "key": "K8S_NAMESPACE",
        "value": namespace,
        "variable_type": "env_var"
    }
    resp = httpx.post(f"{config.GITLAB_SERVER_URL}/api/v4/projects/{project.id}/variables", headers=headers,
                      data=data)
    if resp.status_code != 201:
        raise ConnectionError(resp)

    # Create a token that allows accessing the project-specific container registry
    registry_user_name = "kubernetes-image-puller"
    body = {
        "name": registry_user_name,
        "expires_at": "",
        "username": "kubernetes-image-puller",
        "scopes": [
            "read_registry"
        ]
    }
    resp = httpx.post(f"{config.GITLAB_SERVER_URL}/api/v4/projects/{project.id}/deploy_tokens", headers=headers,
                      json=body)
    if resp.status_code == 201:
        deployment_token: str = resp.json()["token"]
    else:
        raise ConnectionError(resp)

    return project, RegistryCredentials(registry_user_name, deployment_token)


def commit_and_push_files(access_token: str, project_id: int, files: List[Dict[str, str]]):
    """
    Creates a commit in the git repository (of 'project_id') containing all the files. All changes get pushed onto the
    master branch.

    :param access_token: The API access token of the logged in GitLab user
    :param project_id: The GitLab project id
    :param files: A list of files in the form of { "file_path": str, "content": str }
    :return: None
    """
    for file in files:
        file.update({"action": "create"})

    headers = {"Authorization": "Bearer " + access_token}
    body = {
        "branch": "master",
        "commit_message": "Initial commit from K8s Project Scaffolder",
        "actions": files
    }

    resp = httpx.post(f"{config.GITLAB_SERVER_URL}/api/v4/projects/{project_id}/repository/commits", headers=headers,
                      json=body)
    if resp.status_code != 201:
        return  # TODO see above

    return
