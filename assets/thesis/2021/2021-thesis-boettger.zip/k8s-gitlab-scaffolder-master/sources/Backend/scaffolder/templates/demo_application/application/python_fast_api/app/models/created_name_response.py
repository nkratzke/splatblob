from pydantic import BaseModel


class CreatedName(BaseModel):
    name_id: str
    name: str
