package data_access;

import io.lettuce.core.RedisClient;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import model.Name;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class Redis {

    private final RedisClient client;
    private final StatefulRedisConnection<String, String> connection;
    private final RedisCommands<String, String> synchronousCommands;

    public Redis(String hostname, String password) {
        this.client = RedisClient.create(String.format("redis://%s@%s:6379/0", password, hostname));
        this.connection = this.client.connect();
        this.synchronousCommands = this.connection.sync();
    }

    public Name createName(String name) {
        String id = UUID.randomUUID().toString().replace("-", "").substring(10);
        this.synchronousCommands.set(id, name);
        return new Name(id, name);
    }

    public List<Name> readNames() {
        List<Name> names = new LinkedList<>();
        this.synchronousCommands.keys("*").forEach(key -> {
            names.add(new Name(key, this.synchronousCommands.get(key)));
        });
        return names;
    }

    public void deleteName(String id) {
        this.synchronousCommands.del(id);
    }

    public void updateName(String id, String name) {
        this.synchronousCommands.set(id, name);
    }

    public void shutdown() {
        this.connection.close();
        this.client.shutdown();
    }
}
