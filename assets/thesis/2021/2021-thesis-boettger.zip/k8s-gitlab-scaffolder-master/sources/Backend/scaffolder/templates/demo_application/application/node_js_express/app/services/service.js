
class NamesService {
    async create(model, newName) {
        return model.add(newName)
    }

    async read(model) {
        return model.getAll()
    }

    async update(model, id, updatedName) {
        return model.update(id, updatedName)
    }

    async delete(model, id) {
        return model.delete(id)
    }{% if job %}

    async createMany(job) {
        return job.runJob()
    }{% endif %}
}

module.exports = NamesService
