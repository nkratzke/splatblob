import errno
import os
import random
from typing import Dict, List
from jinja2 import Environment, PackageLoader, select_autoescape
from scaffolder import config
from scaffolder.models.secret import Secret
from scaffolder.services import utils

# define all available demo application templates
tech_stack_options = {
    "userInterface": [
        {"value": "none", "text": "I don't need a user interface"},
        {"value": "vanilla_js", "text": "VanillaJS (Static website)"},
        # {"value": "vue_js", "text": "Vue.js (Single-page application)", "disabled": "true"},
        # {"value": "react_js", "text": "React (Single-page application)", "disabled": "true"},
    ],
    "application": [
        {"value": "python_fast_api", "text": "Python (with FastAPI)"},
        {"value": "node_js_express", "text": "Node.js (with Express)"},
        {"value": "java_javalin", "text": "Java (with Javalin Microframework)"},
        {"value": "java_spring", "text": "Java (with Spring Boot)"},
        {"value": "go_fiber", "text": "Go (with Fiber)"},
    ],
    "dataStorage": [
        {"value": "in_memory", "text": "I don't need a database"},
        {"value": "mysql", "text": "MySQL (Relational database)"},
        {"value": "mongo_db", "text": "MongoDB (NoSQL, document-based database)"},
        {"value": "redis", "text": "Redis (NoSQL, in-memory data structure store)"},
    ],
}

# define the key name of secrets that need to be created for each data storage choice
data_storage_key_name = {
    "mysql": "MYSQL_ROOT_PASSWORD",
    "mongo_db": "MONGO_INITDB_ROOT_PASSWORD",
    "redis": "REDIS_PASSWORD",
}

# define dict to translate the data storage names into javalin classes
javalin_data_storage_class_names = {
    "in_memory": "InMemory",
    "mongo_db": "MongoDb",
    "mysql": "MySql",
    "redis": "Redis"
}

# load and compile the templates
templates = Environment(
    loader=PackageLoader("scaffolder", "templates/demo_application"),
    autoescape=select_autoescape()
)


def get_tech_stack_options():
    """Returns the possible technology stack options that the user can choose from.

     :return: The returned dict matches the models.responses.TechStackOptions class."""
    return tech_stack_options


def get_source_code_files(project_name: str, project_url: str, namespace: str, user_interface: str, application: str,
                          data_storage: str, persistence: bool, job: bool, cron_job: bool):
    """
    Generates the project source code by rendering the filtered /templates/demo_application templates with the passed
    arguments. Besides returning the source code files, it also returns a list of secrets that must be created before
    the demo application gets deployed in the namespace.

    :param project_name: The GitLab project name
    :param project_url: The valid GitLab project URL
    :param namespace: The Kubernetes namespace that the project should be deployed to
    :param user_interface: The name of the desired user interface layer
    :param application: The name of the desired application layer
    :param data_storage: The name of the desired data storage layer
    :param persistence: If the user desires the data to be persisted in a persistent volume
    :param job: If the user desires to use asynchronous jobs in the project
    :param cron_job: If the user desires to use scheduled cron jobs in the project
    :return: A tuple consisting of a list with the files (as a dict in the form of { "file_path": str, "content": str }) and a list of secrets (models.secret.Secret class)
    """
    application_url = f"https://{namespace}.{config.KUBERNETES_INGRESS_CONTROLLER_FQDN}/api"
    namespace_fqdn = namespace + "." + config.KUBERNETES_INGRESS_CONTROLLER_FQDN
    project_url_parts = project_url.split("/")

    # create a data storage secret so that the application can access the database securely via password auth
    data_storage_secret = Secret("", "", "")
    secrets_to_be_created = []
    if data_storage != "in_memory":
        data_storage_secret = Secret(data_storage.replace("_", "-") + "-credentials",
                                     data_storage_key_name[data_storage],
                                     utils.get_random_str())
        secrets_to_be_created.append(data_storage_secret)
    if data_storage == "redis":
        redis_config = "requirepass " + data_storage_secret.value + ("\nappendonly yes" if persistence else "")
        secrets_to_be_created.append(Secret("redis-configuration", "redis.conf", redis_config))

    # Set the arguments dict for the template interpolation
    arguments = {
        "project_name": project_name,
        "project_url": project_url,
        "project_path": project_url_parts.pop(),
        "user_path": project_url_parts.pop(),
        "data_storage": data_storage,
        "application": application,
        "user_interface": user_interface,
        "job": job,
        "persistence": persistence,
        "cron_job": cron_job,
        "application_url": application_url,
        "user_interface_url": application_url[:-3],
        "namespace_fqdn": namespace_fqdn,
        "namespace": namespace,
        "data_storage_secret_name": data_storage_secret.name if data_storage != "in_memory" else None,
        "data_storage_secret_key": data_storage_secret.key if data_storage != "in_memory" else None,
        "data_storage_hostname": data_storage.replace("_", "-") + "-service",
        "random_minute": random.randrange(0, 59),
        "IMAGE_PULL_POLICY": config.IMAGE_PULL_POLICY,
        "CLUSTER_ISSUER": config.CLUSTER_ISSUER,
        "STORAGE_CLASS_FOR_PVC": config.STORAGE_CLASS_FOR_PVC,
        "GITLAB_REGISTRY_FQDN": config.GITLAB_REGISTRY_FQDN,
        "GITLAB_REGISTRY_PORT": config.GITLAB_REGISTRY_PORT,
    }

    files = []

    # Generate project root files
    files.extend(__generate_files_from_templates(arguments, lambda template_name: len(template_name.split("/")) == 1))

    # Generate Kubernetes manifest files
    files.extend(__generate_files_from_templates(arguments, lambda template_name: template_name.startswith(
        "kubernetes_manifests") and (template_name.count(data_storage) or template_name.count(
        application) or template_name.count(user_interface) or template_name.count("ingress") or template_name.count(
        "cron_job" if cron_job else application))))

    # Generate application files and filter out all unnecessary data access and job classes
    application_dir = application if application != "java_spring" else application + "_" + data_storage
    data_storage_name = data_storage if application != "java_javalin" else javalin_data_storage_class_names[
        data_storage]
    files.extend(__generate_files_from_templates(arguments, lambda template_name: template_name.startswith(
        f"application/{application_dir}") and (template_name.count("data_access/") == 0 or template_name.count(
        f"data_access/{data_storage_name}") == 1) and (template_name.count("jobs/") == 0 or template_name.count(
        "jobs/") == (1 if job else 0))))

    # Generate user interface files if desired
    if user_interface != "none":
        files.extend(__generate_files_from_templates(arguments, lambda template_name: template_name.startswith(
            f"user_interface/{user_interface}")))

    # Generate cron job files if desired
    if cron_job:
        files.extend(__generate_files_from_templates(arguments, lambda template_name: template_name.startswith(
            "cron_job")))

    return files, secrets_to_be_created


def __generate_files_from_templates(arguments: Dict[str, str], filter_function):
    """
    Generates a list of files by iterating through all jinja2 templates that are located in the demo_application
    directory. To exclude particular files you need to pass a filter function that excludes the templates by their
    name.

    Additionally, this function filters out internally used directories for templates. That means, for example, the
    file_path 'application/python_fast_api/app/main.py' will be converted to 'application/app/main.py'.

    :param arguments: A dict of arguments (variables) to fill the jinja2 templates
    :param filter_function: A function to filter the names of templates which are in the form of '/directory/**/file.extension'
    :return: A list of dicts that fulfil the requirements of the GitLab commit API, i.e. each dict is in the form of { "file_path": str, "content": str }
    """
    files = []

    filtered_templates: List[str] = templates.list_templates(filter_func=filter_function)
    for template in filtered_templates:
        file_content = templates.get_template(template).render(arguments)

        # extract the correct file path from the template name i.e. omit the middle path of the technology choice
        file_path_parts = template.split("/")
        file_path = file_path_parts[0] if len(file_path_parts) == 1 else file_path_parts[0] + "/" + "/".join(
            file_path_parts[2:])

        files.append({
            "file_path": file_path,
            "content": file_content
        })

    return files


def save_source_code_files(files: List[Dict[str, str]], directory: str = "generated/"):
    """
    Saves the source code files that were generated with the get_source_code_files() function to the specified path.

    It does not 'clean' the specified path before saving the files. That means you should ensure that the specified
    directory is empty -- also because this function simply overrides any clashing file.

    :param files: The first return value of get_source_code_files()
    :param directory: The default directory is ./generated/ from where you have started the application (or WSGI server)
    :return: None
    """
    for file in files:
        filepath = directory + file["file_path"]
        if not os.path.exists(os.path.dirname(filepath)):
            try:
                os.makedirs(os.path.dirname(filepath))
            except OSError as exc:
                if exc.errno != errno.EEXIST:
                    raise

        with open(filepath, "w", encoding="utf-8") as out:
            out.write(file["content"])
