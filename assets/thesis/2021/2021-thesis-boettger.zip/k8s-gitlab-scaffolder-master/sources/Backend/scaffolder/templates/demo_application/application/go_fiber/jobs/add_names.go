package jobs

import (
	"context"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/util/homedir"
	"os"
	"path/filepath"
	"time"
)

type AddNamesJob struct {
	client    *kubernetes.Clientset
	namespace *string
	job       *batchv1.Job
}

func NewAddNamesJob() (*AddNamesJob, error) {
	var config *rest.Config
	var err error

	namespace, ok := os.LookupEnv("POD_NAMESPACE")
	if !ok { // if environment variable is not set, configure for local development
		namespace = "{{ namespace }}"
		config, err = GetLocalConfig("", "") // You can optionally specify the name or path of your kubeconfig
	} else { // configure for in cluster environment
		config, err = GetInClusterConfig()
	}
	if err != nil {
		return &AddNamesJob{}, err
	}

	var clientset *kubernetes.Clientset
	clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		return &AddNamesJob{}, err
	}

	// Define the job
	deadlineSeconds := int64(120)
	backoffLimit := int32(1)
	job := batchv1.Job{
		ObjectMeta: metav1.ObjectMeta{
			GenerateName: "add-names-",
		},
		Spec: batchv1.JobSpec{
			ActiveDeadlineSeconds: &deadlineSeconds,
			BackoffLimit:          &backoffLimit,
			Template: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:  "add-names",
							Image: "curlimages/curl:7.72.0",
							Command: []string{
								"sh",
								"-c",
								"i=1; while [ $i -le $NUMBER ]; do curl --request POST \"$APP_URL\" --header \"Content-Type: application/json\" --data-raw \"{\\\"name\\\":\\\"Aladeen the $i.\\\"}\"; i=$((i + 1)); done",
							},
							Env: []corev1.EnvVar{
								{
									Name:  "APP_URL",
									Value: "{{ application_url }}/names",
								},
								{
									Name:  "NUMBER",
									Value: "20",
								},
							},
							Resources: corev1.ResourceRequirements{
								Limits: corev1.ResourceList{
									"cpu": resource.MustParse("100m"),
									"memory": resource.MustParse("10M"),
								},
							},
						},
					},
					RestartPolicy: "Never",
				},
			},
		},
	}

	return &AddNamesJob{client: clientset, namespace: &namespace, job: &job}, nil
}

func (j *AddNamesJob) Run() JobMessage {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	job, err := j.client.BatchV1().Jobs(*j.namespace).Create(ctx, j.job, metav1.CreateOptions{})
	if err != nil {
		return NewJobMessage(false, "")
	}
	return NewJobMessage(true, job.GetName())
}

func GetInClusterConfig() (*rest.Config, error) {
	return rest.InClusterConfig()
}

func GetLocalConfig(kubeconfigName, kubeconfigPath string) (*rest.Config, error) {
	if kubeconfigName == "" {
		kubeconfigName = "config" // default value
	}

	var kubeconfig string
	if home := homedir.HomeDir(); home != "" {
		kubeconfig = filepath.Join(home, ".kube", kubeconfigName)
	} else {
		kubeconfig = kubeconfigPath
	}

	return clientcmd.BuildConfigFromFlags("", kubeconfig)
}
