const applicationUrl = "{{ application_url }}"
const namesTableBody = document.getElementById("namesTableBody")

function createTableEntry(id, name) {
    return `<tr>
        <td>${id}</td>
        <td><input type="text" id="name-${id}" value="${name}" /></td>
        <td>
            <button class="update" onclick="updateName('${id}')" type="button">
                Update
            </button>
        </td>
        <td>
            <button class="delete" onclick="deleteName('${id}')" type="button">
                Delete
            </button>
        </td>
    </tr>
    `
}

function createName() {
    let newName = document.getElementById("newNameInput").value;
    if (newName !== "") {
        let myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        let raw = JSON.stringify({ "name": newName });

        let requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw
        };

        fetch(applicationUrl + "/names", requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result)
                readNames()
            })
            .catch(error => console.log("error", error));
    }
}
{% if job %}
function createManyNames() {
    fetch(applicationUrl + "/names/createMany", { method: "GET" })
        .then(response => response.json())
        .then(result => document.getElementById("createManyNamesOutput").innerHTML = result.message)
        .catch(error => console.log("error", error));
}
{% endif %}
function readNames() {
    let content = ""
    fetch(applicationUrl + "/names", { method: "GET" })
        .then(response => response.json())
        .then(data => {
            data.forEach(entry => {
                content = content + createTableEntry(entry.name_id, entry.name)
            })
            namesTableBody.innerHTML = content
        })
        .catch(error => console.log("error", error));
}

function deleteName(id) {
    fetch(`${applicationUrl}/names/${id}`, { method: "DELETE" })
        .then(response => response.text())
        .then(result => {
            console.log(result)
            readNames()
        })
        .catch(error => console.log("error", error));
}

function updateName(id) {
    let updatedName = document.getElementById("name-" + id).value;
    if (updatedName !== "") {
        let myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        let raw = JSON.stringify({ "name": updatedName });

        let requestOptions = {
            method: "PUT",
            headers: myHeaders,
            body: raw
        };

        fetch(`${applicationUrl}/names/${id}`, requestOptions)
            .then(response => response.text())
            .then(result => {
                console.log(result)
                readNames()
            })
            .catch(error => console.log("error", error));
    }
}

readNames();
