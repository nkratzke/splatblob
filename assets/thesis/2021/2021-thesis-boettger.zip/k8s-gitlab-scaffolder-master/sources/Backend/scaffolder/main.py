from fastapi import FastAPI, Cookie, Response, HTTPException
from fastapi.responses import RedirectResponse
from typing import Optional
from scaffolder import config
from scaffolder.services import auth, utils, cluster, git, scaffolder
from scaffolder.models import responses, requests

app = FastAPI()
auth_exception = HTTPException(status_code=401, headers={"WWW-Authenticate": "OAuth realm=\"Please log in.\""})
development_mode = not config.IN_CLUSTER


@app.get("/api/login")
def login():
    return RedirectResponse(auth.get_login_redirect_url())


@app.get("/api/auth")
def authorize(state: str, code: Optional[str] = None):
    if code is None or not auth.is_state_param_present(state):
        # in case the user denied the authorization or the state param is not valid
        return RedirectResponse("/")

    session_id = auth.get_new_session(code)
    redirect = RedirectResponse("/")
    redirect.set_cookie("sid", session_id, secure=config.SECURE_COOKIE, httponly=True, samesite="Strict")
    return redirect


@app.get("/api/check-session", response_model=responses.CheckSession)
def check_session(response: Response, sid: Optional[str] = Cookie(None)):
    if sid is None:
        return {"sessionValid": False}

    session = auth.is_session_valid(sid)
    if session.valid:
        auth.refresh_session(sid)
        return {"sessionValid": True, "userName": session.user_name}
    else:
        response.delete_cookie("sid")
        return {"sessionValid": False}


@app.get("/api/logout")
def logout(sid: Optional[str] = Cookie(None)):
    auth.delete_session(sid)
    redirect = RedirectResponse("/")
    redirect.delete_cookie("sid")
    return redirect


@app.get("/api/options", response_model=responses.TechStackOptions)
def options():
    return scaffolder.get_tech_stack_options()


@app.get("/api/check-capacity", response_model=responses.CheckCapacity)
def check_capacity():
    return {"capacitySufficient": cluster.is_capacity_sufficient()}


@app.get("/api/check-name", response_model=responses.CheckName)
def check_name(name: str, sid: Optional[str] = Cookie(None)):
    if sid is None or not auth.refresh_session(sid):
        raise auth_exception
    is_name_available = len(name) > 0 and cluster.is_name_available(name) and git.is_name_available(
        auth.get_access_token(sid), name)
    return {"projectNameAvailable": is_name_available}


@app.post("/api/project", response_model=responses.ProjectDetails, status_code=201)
def create_project(spec: requests.ProjectSpecification, sid: Optional[str] = Cookie(None)):
    if sid is None or not auth.refresh_session(sid):
        raise auth_exception

    access_token = auth.get_access_token(sid)
    session = auth.is_session_valid(sid)
    namespace = utils.get_slug(spec.name)

    if not development_mode:
        # Create the namespace and GitLab project
        kubeconfig = cluster.get_new_namespace(namespace, session.user_email)
        project, registry_credentials = git.get_new_project(access_token, spec.name, spec.description,
                                                            spec.visibility.value, kubeconfig, namespace)

        # Configure both according to the desired template
        cluster.set_registry_credentials(namespace, registry_credentials)
        files, secrets = scaffolder.get_source_code_files(spec.name, project.web_url, namespace, spec.userInterface,
                                                          spec.application, spec.dataStorage, spec.persistence,
                                                          spec.job, spec.cronJob)
        for secret in secrets:
            cluster.set_secret(namespace, secret.name, secret.key, secret.value)

        git.commit_and_push_files(access_token, project.id, files)

        return {"projectName": spec.name, "projectURL": project.web_url}
    else:
        print("Project Specification:", spec)
        debug_web_url = "https://git.mylab.th-luebeck.de/max-mustermann/cooles-projekt"
        files, secret = scaffolder.get_source_code_files(spec.name, debug_web_url, namespace, spec.userInterface,
                                                         spec.application, spec.dataStorage, spec.persistence, spec.job,
                                                         spec.cronJob)
        scaffolder.save_source_code_files(files)
        return {"projectName": spec.name, "projectURL": debug_web_url}
