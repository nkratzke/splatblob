from pydantic import BaseModel
from enum import Enum


class Visibility(str, Enum):
    private = "private"
    internal = "internal"
    public = "public"


class ProjectSpecification(BaseModel):
    name: str
    description: str
    visibility: Visibility
    userInterface: str
    application: str
    dataStorage: str
    persistence: bool
    job: bool
    cronJob: bool
