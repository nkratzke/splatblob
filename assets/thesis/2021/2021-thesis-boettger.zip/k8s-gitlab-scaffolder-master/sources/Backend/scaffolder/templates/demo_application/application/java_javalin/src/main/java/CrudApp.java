{% set data_storage_class = "InMemory" if data_storage == "in_memory" else ("MySql" if data_storage == "mysql" else ("MongoDb" if data_storage == "mongo_db" else "Redis")) %}import data_access.{{ data_storage_class }};
import io.javalin.Javalin;{% if job %}
import jobs.AddNamesJob;{% endif %}
import model.Name;

import java.util.Map;

public class CrudApp {
    public static void main(String[] args) {
        {% if data_storage != "in_memory" or job %}
        Map<String, String> envVariables = System.getenv();{% endif %}{% if data_storage != "in_memory" %}
        String dataStorageHostname = envVariables.get("DATA_STORAGE_HOSTNAME") != null ? envVariables.get("DATA_STORAGE_HOSTNAME") : "127.0.0.1";
        String dataStoragePassword = envVariables.get("DATA_STORAGE_PASSWORD") != null ? envVariables.get("DATA_STORAGE_PASSWORD") : "password";
        {% endif %}{% if job %}String podNamespace = envVariables.get("POD_NAMESPACE") != null ? envVariables.get("POD_NAMESPACE") : "{{ namespace }}";
        {% endif %}
        {{ data_storage_class }} store = new {{ data_storage_class }}({% if data_storage != "in_memory" %}dataStorageHostname, dataStoragePassword{% endif %});
        {% if job %}AddNamesJob job = new AddNamesJob(podNamespace);
        {% endif %}
        Javalin app = Javalin.create().start(80);

        app.get("/api/names", ctx -> ctx.json(store.readNames()));
        app.post("/api/names", ctx -> {
            Name newName = ctx.bodyAsClass(Name.class);
            ctx.json(store.createName(newName.getName()));
            ctx.status(201);
        });
        app.put("/api/names/:id", ctx -> {
            Name updatedName = ctx.bodyAsClass(Name.class);
            store.updateName(ctx.pathParam("id"), updatedName.getName());
            ctx.status(204);
        });
        app.delete("/api/names/:id", ctx -> {
            store.deleteName(ctx.pathParam("id"));
            ctx.status(204);
        });{% if job %}
        app.get("/api/names/createMany", ctx -> ctx.json(job.run()));{% endif %}
    }
}
