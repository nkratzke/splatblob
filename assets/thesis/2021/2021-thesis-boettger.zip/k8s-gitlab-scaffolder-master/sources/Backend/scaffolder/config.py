import os

REDIS_HOSTNAME = os.getenv("REDIS_HOSTNAME", "")
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")
LOGIN_TTL = int(os.getenv("LOGIN_TTL", "3600"))  # how long to keep the state param
SESSION_TTL = int(os.getenv("SESSION_TTL", "864000"))  # how long to keep the session
REDIRECT_URL = os.getenv("REDIRECT_URL", "")
GITLAB_APP_ID = os.getenv("GITLAB_APP_ID", "")
GITLAB_APP_SECRET = os.getenv("GITLAB_APP_SECRET", "")
GITLAB_SERVER_URL = os.getenv("GITLAB_SERVER_URL", "")
GITLAB_REGISTRY_FQDN = os.getenv("GITLAB_REGISTRY_FQDN", "")
GITLAB_REGISTRY_PORT = os.getenv("GITLAB_REGISTRY_PORT", "")
KUBERNETES_API_SERVER_URL = os.getenv("KUBERNETES_API_SERVER_URL", "")
KUBERNETES_INGRESS_CONTROLLER_FQDN = os.getenv("KUBERNETES_INGRESS_CONTROLLER_FQDN", "")
IMAGE_PULL_POLICY = os.getenv("IMAGE_PULL_POLICY", "")
STORAGE_CLASS_FOR_PVC = os.getenv("STORAGE_CLASS_FOR_PVC", "")
CLUSTER_ISSUER = os.getenv("CLUSTER_ISSUER", "")

# user namespace constraints
# # ResourceQuota
QUOTA_REQUESTS_MEM = os.getenv("QUOTA_REQUESTS_MEM", "1G")
QUOTA_REQUESTS_CPU = os.getenv("QUOTA_REQUESTS_CPU", "1")
QUOTA_REQUESTS_STORAGE = os.getenv("QUOTA_REQUESTS_STORAGE", "5G")
QUOTA_LIMITS_MEM = os.getenv("QUOTA_LIMITS_MEM", "2G")
QUOTA_LIMITS_CPU = os.getenv("QUOTA_LIMITS_CPU", "2")
QUOTA_PVC = os.getenv("QUOTA_PVC", "5")
QUOTA_PODS = os.getenv("QUOTA_PODS", "5")
# # LimitRange for type Container
DEFAULT_REQUEST_MEM = os.getenv("DEFAULT_REQUEST_MEM", "100M")
DEFAULT_REQUEST_CPU = os.getenv("DEFAULT_REQUEST_CPU", "100m")
DEFAULT_LIMIT_MEM = os.getenv("DEFAULT_LIMIT_MEM", "200M")
DEFAULT_LIMIT_CPU = os.getenv("DEFAULT_LIMIT_CPU", "200m")
MAX_LIMIT_MEM = os.getenv("MAX_LIMIT_MEM", "1G")
MAX_LIMIT_CPU = os.getenv("MAX_LIMIT_CPU", "1")
# https://trello.com/c/OxAvy9Cd/45-min-values-in-limitrange-should-be-avoided
# LIMIT_MIN_MEM
# LIMIT_MIN_CPU

# for local development purposes
SECURE_COOKIE = True if os.getenv("SECURE_COOKIE") == "true" or os.getenv("SECURE_COOKIE") == "True" else False
IN_CLUSTER = True if os.getenv("IN_CLUSTER") == "true" or os.getenv("IN_CLUSTER") == "True" else False
KUBECONFIG_LOCATION = "C:\\Users\\TCB\\.kube\\kubeconfigScaffolderNS.yaml"
