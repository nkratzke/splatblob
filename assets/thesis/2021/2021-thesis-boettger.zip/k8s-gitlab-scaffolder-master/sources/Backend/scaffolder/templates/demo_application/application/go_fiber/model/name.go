package model

type Name struct {
	Id   string `json:"name_id"{% if data_storage == "mongo_db" %} bson:"_id"{% endif %}`
	Name string `json:"name"`
}
