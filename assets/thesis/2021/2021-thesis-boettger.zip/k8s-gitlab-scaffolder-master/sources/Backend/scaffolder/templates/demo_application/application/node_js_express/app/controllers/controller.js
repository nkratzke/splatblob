const namesService = new (require("../services/service"))
const model = new (require("../data_access/{{ data_storage }}")){% if job %}
const job = new (require("../jobs/add-names")){% endif %}
const express = require("express")


const ingressPath = "/api" // necessary so that the Ingress controller does not need to rewrite incoming requests


async function init(app) {
    app.use(express.json()) // middleware for parsing application/json body

    await model.connect(){% if job %}
    await job.connect(){% endif %}

    console.log("Initialize each route with a controller")
    app.post(ingressPath + "/names", create)
    app.get(ingressPath + "/names", read)
    app.put(ingressPath + "/names/:id", update)
    app.delete(ingressPath + "/names/:id", delete_){% if job %}
    app.get(ingressPath + "/names/createMany", createMany){% endif %}
}


async function create(request, response) {
    try {
        const responseBody = await namesService.create(model, request.body.name)
        response.status(201).send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}


async function read(request, response) {
    try {
        const responseBody = await namesService.read(model)
        response.send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}


async function update(request, response) {
    try {
        await namesService.update(model, request.params.id, request.body.name)
        response.status(204).send()
    } catch (error) {
        response.status(500).send({ message: error })
    }
}


async function delete_(request, response) {
    try {
        await namesService.delete(model, request.params.id)
        response.status(204).send()
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

{% if job %}
async function createMany(request, response) {
    try {
        const responseBody = await namesService.createMany(job)
        response.send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

{% endif %}
module.exports.init = init
