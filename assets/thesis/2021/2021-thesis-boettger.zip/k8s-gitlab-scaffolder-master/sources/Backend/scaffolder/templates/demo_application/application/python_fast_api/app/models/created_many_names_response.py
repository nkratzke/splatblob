from pydantic import BaseModel


class CreatedManyMessage(BaseModel):
    message: str
