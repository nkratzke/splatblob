package dev.thluebeck.crud.jobs;

import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.BatchV1Api;
import io.kubernetes.client.openapi.models.V1Job;
import io.kubernetes.client.util.ClientBuilder;
import io.kubernetes.client.util.KubeConfig;
import io.kubernetes.client.util.Yaml;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class AddNamesJob {

    @Value("${kubernetes.kubeconfigPath}")
    private String kubeconfigPath;
    @Value("${kubernetes.namespace}")
    private String namespace;
    @Value("classpath:jobs/add_names.yaml")
    private Resource jobResource;
    private BatchV1Api batchClient;
    private V1Job addNamesJob;

    @PostConstruct
    private void init() throws IOException {
        // Uncomment the following line when developing locally
        // ApiClient client = ClientBuilder.kubeconfig(KubeConfig.loadKubeConfig(new FileReader(this.kubeconfigPath))).build();
        ApiClient client = ClientBuilder.cluster().build();
        Configuration.setDefaultApiClient(client);

        this.batchClient = new BatchV1Api();
        String jobYaml = new BufferedReader(new InputStreamReader(this.jobResource.getInputStream()))
                .lines()
                .collect(Collectors.joining("\n"));
        this.addNamesJob = (V1Job) Yaml.load(jobYaml);
    }

    public JobMessage run() {
        try {
            V1Job createdJob = this.batchClient.createNamespacedJob(this.namespace, this.addNamesJob, null, null, null);
            return new JobMessage(true, Objects.requireNonNull(createdJob.getMetadata()).getName());
        } catch (ApiException e) {
            return new JobMessage(false, "");
        }
    }

}
