const k8s = require("@kubernetes/client-node");
const fs = require("fs")
const yaml = require("js-yaml");

class AddNamesJob {
    async runJob() {
        let message = ""
        try {
            const response = await this.batch.createNamespacedJob(process.env.POD_NAMESPACE, this.addNamesJob)
            console.log(response.body)
            message = "Your job was successfully scheduled and is now working as '" + response.response.body.metadata.name + "'. Try to reload the page in a moment."
        } catch (error) {
            console.log(error.response.body)
            message = "Internal error. Error message from the K8s server:\n" + error.response.body.message
        }
        console.log(message)

        return { message: message }
    }

    async connect() {
        console.log("Initialize Kubernetes API connection")
        console.log("Pod's Current Namespace:", process.env.POD_NAMESPACE)

        this.kc = new k8s.KubeConfig();
        this.kc.loadFromDefault();
        this.batch = this.kc.makeApiClient(k8s.BatchV1Api)

        this.addNamesJob = yaml.safeLoad(fs.readFileSync(__dirname + "/add-names-job.yaml", "utf-8"))
    }

    async shutdown() {
        return // Nothing to do here
    }
}

module.exports = AddNamesJob
