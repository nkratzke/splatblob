module.exports = {
    self: "localhost:8081",
    "/api": {
        uri: "127.0.0.1:8000",
        preserveHost: true,
        preservePrefix: true
    },
    "/": {
        uri: "localhost:8080",
        preserveHost: true,
        preservePrefix: true
    }
};

// RUN IT by ```npx dprox```