<template>
  <b-row class="my-3">
    <b-col cols="12" md="4" class="d-flex pr-0">
      <b-row align-v="center">
        <b-col cols="12" class="pr-2">
          <label class="my-0" :for="getKebabCaseLabel">{{ label }}</label>
        </b-col>
      </b-row>
    </b-col>
    <b-col cols="12" md="8">
      <b-form-input
        :id="getKebabCaseLabel"
        :placeholder="placeholder"
        type="text"
        trim
        :state="valid"
        v-bind:value="value"
        v-on:update="$emit('input', $event)"
        :debounce="debounce"
      ></b-form-input>
      <!-- This will only be shown if the preceding input has an invalid state -->
      <b-form-invalid-feedback id="input-live-feedback" class="text-left">
        This name is not available anymore
      </b-form-invalid-feedback>
    </b-col>
  </b-row>
</template>

<script>
export default {
  name: "Input",
  props: ["label", "placeholder", "value", "valid", "debounce"],
  computed: {
    getKebabCaseLabel() {
      return this.label
        .replace(/([A-Z])([A-Z])/g, "$1-$2")
        .replace(/([a-z])([A-Z])/g, "$1-$2")
        .replace(/[\s_]+/g, "-")
        .toLowerCase();
    },
  },
};
</script>

<style scoped>
</style>