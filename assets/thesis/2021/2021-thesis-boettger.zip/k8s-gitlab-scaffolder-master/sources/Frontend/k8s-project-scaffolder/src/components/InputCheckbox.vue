<template>
  <b-row class="my-4">
    <b-col cols="7" md="4" class="d-flex pr-0">
      <b-row align-v="center">
        <b-col cols="12" class="pr-2">
          <label class="my-0" :for="getKebabCaseLabel">{{ label }}</label>
          <b-icon-info-circle
            class="ml-2"
            :id="getKebabCaseLabel"
            v-if="tooltip"
          ></b-icon-info-circle>
          <b-tooltip
            v-if="tooltip"
            :target="getKebabCaseLabel"
            triggers="hover"
          >
            <p class="my-0" v-if="!link">{{ tooltip }}</p>
            <p class="my-0" v-if="link">
              {{ tooltip }} See
              <a :href="link">here</a> for more information.
            </p>
          </b-tooltip>
        </b-col>
      </b-row>
    </b-col>
    <b-col cols="5" md="8">
      <div class="d-flex my-auto">
        <b-form-checkbox
          v-bind:checked="value"
          v-on:input="$emit('input', $event)"
        >
        </b-form-checkbox>
      </div>
    </b-col>
  </b-row>
</template>

<script>
export default {
  name: "InputCheckbox",
  props: ["label", "value", "tooltip", "link"],
  computed: {
    getKebabCaseLabel() {
      return this.label
        .replace(/([A-Z])([A-Z])/g, "$1-$2")
        .replace(/([a-z])([A-Z])/g, "$1-$2")
        .replace(/[\s_]+/g, "-")
        .toLowerCase();
    },
  },
  data() {
    return {
      checked: true,
    };
  },
};
</script>

<style scoped>
</style>