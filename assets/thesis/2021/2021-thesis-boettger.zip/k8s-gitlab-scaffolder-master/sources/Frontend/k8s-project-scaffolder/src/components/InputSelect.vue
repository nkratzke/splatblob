<template>
  <b-row class="my-3">
    <b-col cols="12" md="4" class="d-flex pr-0">
      <b-row align-v="center">
        <b-col cols="12" class="pr-2">
          <label class="my-0" :for="getKebabCaseLabel">{{ label }}</label>
          <b-icon-info-circle
            class="ml-2"
            :id="getKebabCaseLabel"
            v-if="tooltip"
          ></b-icon-info-circle>
          <b-tooltip
            v-if="tooltip"
            :target="getKebabCaseLabel"
            triggers="hover"
          >
            {{ tooltip }}
          </b-tooltip>
        </b-col>
      </b-row>
    </b-col>
    <b-col cols="12" md="8">
      <b-form-select
        v-bind:value="value"
        v-on:input="$emit('input', $event)"
        :options="options"
      ></b-form-select>
    </b-col>
  </b-row>
</template>

<script>
export default {
  name: "InputSelect",
  props: ["label", "value", "options", "tooltip"],
  computed: {
    getKebabCaseLabel() {
      return this.label
        .replace(/([A-Z])([A-Z])/g, "$1-$2")
        .replace(/([a-z])([A-Z])/g, "$1-$2")
        .replace(/[\s_]+/g, "-")
        .toLowerCase();
    },
  },
};
</script>

<style scoped>
</style>