<template>
  <b-row class="my-4">
    <b-col cols="12" md="4" class="d-flex pr-0">
      <b-row align-v="center">
        <b-col cols="12" class="pr-2">
          <label class="my-0" :for="getKebabCaseLabel">{{ label }}</label>
        </b-col>
      </b-row>
    </b-col>
    <b-col cols="12" md="8">
      <div class="d-flex">
        <b-form-group class="my-auto container-fluid p-0">
          <b-form-radio-group
            class="d-flex justify-content-between"
            v-bind:checked="value"
            v-on:input="$emit('input', $event)"
            :options="radioOptions"
            :name="getKebabCaseLabel"
          ></b-form-radio-group>
        </b-form-group>
      </div>
    </b-col>
  </b-row>
</template>

<script>
export default {
  name: "InputRadio",
  props: ["label", "value", "options"],
  computed: {
    getKebabCaseLabel() {
      return this.label
        .replace(/([A-Z])([A-Z])/g, "$1-$2")
        .replace(/([a-z])([A-Z])/g, "$1-$2")
        .replace(/[\s_]+/g, "-")
        .toLowerCase();
    },
    radioOptions() {
      let out = [];
      this.options.forEach((element) =>
        out.push({ text: element, value: element })
      );
      return out;
    },
  },
};
</script>

<style scoped>
</style>