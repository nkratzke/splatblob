<template>
  <div id="app">
    <NavBar />
    <div class="container-md">
      <Welcome v-if="!showCreateProjectPage" />
      <CreateProject v-if="showCreateProjectPage" />
      <Footer />
    </div>

    <!-- Beta Toast info / TODO delete in final release -->
    <b-toast
      id="beta-feedback-toast"
      title="Welcome To Our Beta 🚀"
      toaster="b-toaster-bottom-center"
      v-model="showBetaToast"
      solid
      no-auto-hide
    >
      Hey there! We have just started the beta and would love to hear your
      thoughts. If you have any recommendations or questions,
      <a
        href="mailto:tom.boettger@stud.th-luebeck.de?subject=Feedback - K8s Project Scaffolder"
        >send us an email</a
      >.
    </b-toast>
  </div>
</template>

<script>
import NavBar from "./components/NavBar.vue";
import Welcome from "./components/Welcome";
import Footer from "./components/Footer";
import CreateProject from "./components/CreateProject";

export default {
  name: "App",
  components: {
    NavBar,
    Welcome,
    Footer,
    CreateProject,
  },
  data() {
    return {
      showBetaToast: false,
    };
  },
  computed: {
    showCreateProjectPage() {
      return this.$store.state.showCreateProjectPage;
    },
  },
  mounted() {
    this.$store.dispatch("INITIALIZE_APP");

    // show beta toast info
    setTimeout(() => {
      this.showBetaToast = true;
    }, 10000);
  },
};
</script>

<style>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif; */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}
</style>
