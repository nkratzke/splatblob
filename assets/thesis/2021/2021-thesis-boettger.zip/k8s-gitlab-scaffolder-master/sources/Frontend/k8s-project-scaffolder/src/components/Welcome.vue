<template>
  <div class="pt-md-5 pt-3 pl-md-5 pr-md-5 ml-md-5 mr-md-5">
    <h1 class="font-weight-bold">
      Containerize Your Application and Host It on a Kubernetes Cluster
    </h1>
    <h6 class="mt-4">
      We offer you a virtual Kubernetes cluster for free. Simply configure your
      desired technology stack and start developing right away. We take care of
      the creation and configuration of your GitLab project, and your private
      namespace in the Kubernetes cluster.
    </h6>

    <!-- Initial state, the user opened the web app -->
    <b-button
      v-if="loading && capacitySufficient && !error"
      class="mt-5"
      variant="primary"
      disabled
    >
      {{ space }}
      <b-spinner small></b-spinner>
      {{ space }}</b-button
    >

    <!-- In case the cluster capacity is not sufficient, show an info box -->
    <b-alert :show="!capacitySufficient" variant="primary" class="mt-5">
      <h5 class="alert-heading">
        Unfortunately, our cluster capacity is currently exhausted.
      </h5>
      <hr />
      <p class="mb-0">
        We are aware of this and try to provide new capacities as soon as
        possible. Please check back in a while.
      </p>
    </b-alert>

    <!-- In case an error occurred on the backend side, show an info box -->
    <b-alert :show="error" variant="primary" class="mt-5">
      <h5 class="alert-heading">Unfortunately, something went wrong.</h5>
      <hr />
      <p class="mb-0">
        Try to reload the page in a moment. If the error still occurs, please
        contact us.
      </p>
    </b-alert>

    <!-- If the user is not logged in, show the log in button -->
    <b-button
      v-if="!loading && !loggedIn && capacitySufficient && !error"
      class="mt-5"
      variant="primary"
      :href="loginUrl"
      >Log in with GitLab</b-button
    >

    <!-- If the user is logged in, show the create project button -->
    <b-button
      v-if="!loading && loggedIn && capacitySufficient && !error"
      class="mt-5"
      variant="primary"
      @click="goToCreateProjectPage()"
      >Configure Your Project</b-button
    >
  </div>
</template>

<script>
export default {
  name: "Welcome",
  data() {
    return {
      loginUrl: "/api/login",
      space: "   ",
    };
  },
  methods: {
    goToCreateProjectPage() {
      this.$store.commit("GO_TO_CREATE_PROJECT_PAGE");
    },
  },
  computed: {
    loading() {
      return this.$store.state.loading;
    },
    capacitySufficient() {
      return this.$store.state.capacitySufficient;
    },
    loggedIn() {
      return this.$store.state.loggedIn;
    },
    error() {
      return this.$store.state.error;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h6 {
  color: rgb(100, 100, 100);
}
</style>
