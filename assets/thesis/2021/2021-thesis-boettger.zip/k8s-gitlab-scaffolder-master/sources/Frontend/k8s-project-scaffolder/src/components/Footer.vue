<template>
  <footer>
    <hr />
    <p>
      Hosted by <a :href="departmentUrl">{{ departmentName }}</a> at the
      <a :href="organizationUrl">{{ organizationName }}</a>

      <span>
        <a :href="repositoryUrl">Git Repository</a>
      </span>
    </p>
  </footer>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {
      organizationName: process.env.VUE_APP_ORGANIZATION_NAME,
      organizationUrl: process.env.VUE_APP_ORGANIZATION_URL,
      departmentName: process.env.VUE_APP_DEPARTMENT_NAME,
      departmentUrl: process.env.VUE_APP_DEPARTMENT_URL,
      repositoryUrl: process.env.VUE_APP_REPOSITORY_URL,
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
p {
    text-align: left;
}

span {
    float: right;
}

footer {
  margin-top: 3rem;
  margin-bottom: 5rem;
}
</style>
