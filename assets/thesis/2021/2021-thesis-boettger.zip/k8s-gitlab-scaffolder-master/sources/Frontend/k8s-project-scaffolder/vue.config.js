module.exports = {
    productionSourceMap: false
}