<template>
  <div class="pt-md-5 pt-3 pl-md-5 pr-md-5 ml-md-5 mr-md-5">
    <h3 class="font-weight-bold text-left mb-3">
      Configure your project and technology stack
    </h3>

    <h5 class="mt-2 text-left">Project Details</h5>
    <Input
      label="Name"
      placeholder="Your project's name"
      :valid="validProjectName"
      debounce="800"
      v-model="projectName"
    />
    <Input
      label="Description"
      placeholder="A short project description (optional)"
      v-model="projectDescription"
    />

    <h5 class="mt-2 text-left">Technology Stack</h5>
    <InputSelect
      label="User Interface"
      v-model="userInterface"
      :options="userInterfaceOptions"
      tooltip="The user interface implements a web app that allows you to interact with your application's HTTP API."
    />
    <InputSelect
      label="Application"
      v-model="application"
      :options="applicationOptions"
      tooltip="The application typically implements a web server that exposes an HTTP API. This layer is mandatory."
    />
    <InputSelect
      label="Data Storage"
      v-model="dataStorage"
      :options="dataStorageOptions"
      tooltip="The data storage layer provides the option to store the application state."
    />

    <b-button @click="advancedOptions = !advancedOptions"
      >Advanced Options
      <b-icon v-show="!advancedOptions" icon="chevron-down" />
      <b-icon v-show="advancedOptions" icon="chevron-up" />
    </b-button>
    <b-collapse
      id="collapse-advanced-options"
      v-model="advancedOptions"
      class="py-1"
    >
      <h5 class="mt-2 text-left">Advanced Options</h5>
      <InputCheckbox
        label="Persistence"
        v-model="persistence"
        tooltip="Stores the data in a persistent volume. This means, you can restart your database without loosing its state."
        link="https://kubernetes.io/docs/concepts/storage/persistent-volumes/"
      />
      <InputCheckbox
        label="Asynchronous Jobs"
        v-model="jobs"
        tooltip="Jobs allow you to execute tasks asynchronously in dedicated containers. These tasks will terminate after a certain time and are typically CPU-bound, so you do not want to execute them in your application."
        link="https://kubernetes.io/docs/concepts/workloads/controllers/job/"
      />
      <InputCheckbox
        label="Scheduled Jobs"
        v-model="cronJobs"
        tooltip="Scheduled jobs are based on cron expressions. You can schedule any tasks to run within short-lived containers."
        link="https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/"
      />
    </b-collapse>

    <b-form-checkbox class="mt-5" v-model="termsAccepted">
      I accept the
      <a v-b-modal.terms-modal class="blue" @click.prevent.stop>terms of use</a>
      and will respect the fair usage policy.
    </b-form-checkbox>

    <b-modal
      id="terms-modal"
      v-model="showTermsModal"
      size="lg"
      centered
      title="Terms of use"
    >
      <h5>Fair usage policy</h5>
      <p class="my-2">
        Although there is a resource quota for your namespace that you cannot
        exceed, we further ask you to keep the limits and requests of individual
        container resources as low as possible. It is especially important that
        you try to choose low values for the
        <code>resources.requests</code> object, as these requested resources are
        guaranteed only to you. To better distribute resources among all
        students, you can choose higher values for the
        <code>resources.limits</code> object instead so that your containers are
        burstable in resource usage. That is the only way we can guarantee that
        every student can host projects in our Kubernetes cluster for free. See
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="https://kubernetes.io/docs/tasks/configure-pod-container/quality-service-pod/"
          >here</a
        >
        for more information.
      </p>
      <p class="my-2">
        If you no longer work on your project, please consider deleting the
        namespace and all its resources. We have configured a manual pipeline
        stage in your project that you just need to run in order to delete
        everything.
      </p>
      <h5>Secrets</h5>
      <p class="my-2">
        Never store your private access data to online accounts in Kubernetes
        secrets. If you rely on external services (like APIs) that require you
        to authorize yourself, consider using API tokens with a minimal scope.
        That is because the secrets are not encrypted and are stored in plain
        text in the Kubernetes cluster. Cluster administrators theoretically
        have access to these secrets. Also, never store secrets in your
        repository. Always create them locally with the
        <code>kubectl create secret</code> CLI tool. See
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="https://kubernetes.io/docs/concepts/configuration/secret/#creating-a-secret"
          >here</a
        >
        for more information.
      </p>

      <template #modal-footer>
        <b-button variant="primary" @click="acceptTerms()">Accept</b-button>
      </template>
    </b-modal>

    <b-button
      class="mt-2"
      variant="primary"
      :disabled="!validProjectName || !termsAccepted || showProjectOutput"
      @click="createProject()"
      >Create Project</b-button
    >

    <!-- Project created output -->
    <b-collapse id="projectOutput" v-model="showProjectOutput" class="mt-2">
      <b-card v-if="loading">
        <div class="d-flex justify-content-center">
          <b-skeleton animation="wave" height="1.5rem" width="65%"></b-skeleton>
        </div>
        <hr />
        <div class="d-flex justify-content-center">
          <b-skeleton animation="wave" width="100%" class="my-1"></b-skeleton>
        </div>
        <div class="d-flex justify-content-center">
          <b-skeleton animation="wave" width="100%" class="my-1"></b-skeleton>
        </div>
      </b-card>
      <b-card v-if="!loading && !creationError">
        <h5>Your project got successfully created! 🎉</h5>
        <hr />
        <p class="my-1">
          The <code>README.md</code> contains the next steps. You can find it at
          the following address:
        </p>
        <p class="my-1">
          <a
            target="_blank"
            rel="noopener noreferrer"
            :href="createdProjectUrl"
            >{{ createdProjectUrl }}</a
          >
        </p>
      </b-card>
      <b-card v-if="!loading && creationError">
        <h5>Unfortunately, something went wrong. 😟</h5>
        <hr />
        <p class="my-1">Please reload the page in a moment and try it again.</p>
        <p class="my-1">If the error continues to occur, please contact us.</p>
      </b-card>
    </b-collapse>
  </div>
</template>

<script>
import Input from "./Input";
import InputSelect from "./InputSelect";
import InputCheckbox from "./InputCheckbox";

export default {
  name: "Welcome",
  components: {
    Input,
    InputSelect,
    InputCheckbox,
  },
  props: {
    loggedIn: Boolean,
    capacitySufficient: Boolean,
  },
  data() {
    return {
      projectName: "",
      projectDescription: "",
      projectVisibility: "private",
      userInterface: "vanilla_js",
      application: "python_fast_api",
      dataStorage: "mysql",
      persistence: false,
      jobs: false,
      cronJobs: false,
      termsAccepted: false,
      showTermsModal: false,
      showProjectOutput: false,
      advancedOptions: false,
    };
  },
  methods: {
    acceptTerms() {
      this.termsAccepted = true;
      this.showTermsModal = false;
    },
    createProject() {
      this.$store.dispatch("CREATE_PROJECT", {
        name: this.projectName,
        description: this.projectDescription,
        visibility: this.projectVisibility,
        userInterface: this.userInterface,
        application: this.application,
        dataStorage: this.dataStorage,
        persistence: this.persistence,
        job: this.jobs,
        cronJob: this.cronJobs,
      });

      this.showProjectOutput = true;
      window.scrollTo(0, document.body.scrollHeight);
    },
  },
  watch: {
    projectName: function () {
      this.$store.dispatch("CHECK_PROJECT_NAME_AVAILABILITY", this.projectName);
    },
  },
  computed: {
    loading() {
      return this.$store.state.loading;
    },
    creationError() {
      return this.$store.state.creationError;
    },
    userInterfaceOptions() {
      return this.$store.state.userInterfaceOptions;
    },
    applicationOptions() {
      return this.$store.state.applicationOptions;
    },
    dataStorageOptions() {
      return this.$store.state.dataStorageOptions;
    },
    validProjectName() {
      return this.$store.state.projectNameAvailable;
    },
    createdProjectUrl() {
      return this.$store.state.createdProjectUrl;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h6 {
  color: rgb(100, 100, 100);
}
.blue {
  color: primary;
}
</style>
