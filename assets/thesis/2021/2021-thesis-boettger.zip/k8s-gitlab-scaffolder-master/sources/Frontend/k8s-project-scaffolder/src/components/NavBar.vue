<template>
  <div>
    <b-navbar toggleable="sm" type="light" variant="light">
      <div class="container-md">
        <b-navbar-brand href="/">
          <img
            id="logo"
            src="../assets/favicon.png"
            class="d-inline-block align-top"
            alt="K8s Project Scaffolder Logo"
          />
          K8s Project Scaffolder
        </b-navbar-brand>

        <b-navbar-toggle
          v-if="loggedIn"
          target="nav-collapse"
        ></b-navbar-toggle>

        <b-collapse v-if="loggedIn" id="nav-collapse" is-nav>
          <!-- Right aligned nav items -->
          <b-navbar-nav class="ml-auto">
            <b-nav-item><strong>Hey {{ userName }} 👋</strong></b-nav-item>
          </b-navbar-nav>
          <b-navbar-nav>
            <b-nav-item :href="logoutUrl">Log out</b-nav-item>
          </b-navbar-nav>
        </b-collapse>
      </div>
    </b-navbar>
  </div>
</template>

<script>
export default {
  name: "NavBar",
  data() {
    return {
      logoutUrl: "/api/logout",
    };
  },
  computed: {
    loggedIn() {
      return this.$store.state.loggedIn;
    },
    userName() {
      return this.$store.state.userName;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#logo {
  width: 20pt;
}
</style>
