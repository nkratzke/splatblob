import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        loading: 0,
        loggedIn: false,
        userName: undefined,
        error: false,
        creationError: false,
        capacitySufficient: true,
        showCreateProjectPage: false,
        userInterfaceOptions: undefined,
        applicationOptions: undefined,
        dataStorageOptions: undefined,
        projectNameAvailable: undefined,
        createdProjectUrl: undefined,
    },
    mutations: {
        INCREMENT_LOADING(state) {
            state.loading += 1
        },
        DECREMENT_LOADING(state) {
            state.loading -= 1
        },
        SET_SESSION(state, loggedIn) {
            state.loggedIn = loggedIn
        },
        SET_USER_NAME(state, userName) {
            state.userName = userName
        },
        SET_CAPACITY_SUFFICIENT(state, capacitySufficient) {
            state.capacitySufficient = capacitySufficient
        },
        SET_TECH_OPTIONS(state, options) {
            state.userInterfaceOptions = options.userInterface
            state.applicationOptions = options.application
            state.dataStorageOptions = options.dataStorage
        },
        SET_PROJECT_NAME_AVAILABILITY(state, available) {
            state.projectNameAvailable = available
        },
        SET_ERROR(state, error) {
            state.error = error
        },
        SET_CREATION_ERROR(state, error) {
            state.creationError = error
        },
        GO_TO_CREATE_PROJECT_PAGE(state) {
            state.showCreateProjectPage = true
        },
        SET_CREATED_PROJECT_URL(state, projectUrl) {
            state.createdProjectUrl = projectUrl
        }
    },
    actions: {
        INITIALIZE_APP(context) {
            // Check session
            context.commit('INCREMENT_LOADING')
            axios.get("/api/check-session", { withCredentials: true })
                .then(response => {
                    context.commit('SET_SESSION', response.data.sessionValid)
                    context.commit('SET_USER_NAME', response.data.userName)
                }).catch(() => {
                    context.commit('SET_ERROR', true)
                }).then(() => {
                    context.commit('DECREMENT_LOADING')
                })

            // Check cluster capacity
            context.commit('INCREMENT_LOADING')
            axios.get("/api/check-capacity")
                .then(response => {
                    context.commit('SET_CAPACITY_SUFFICIENT', response.data.capacitySufficient)
                }).catch(() => {
                    context.commit('SET_ERROR', true)
                }).then(() => {
                    context.commit('DECREMENT_LOADING')
                })

            // Get the available technology stack options
            context.commit('INCREMENT_LOADING')
            axios.get("/api/options")
                .then(response => {
                    context.commit('SET_TECH_OPTIONS', response.data)
                }).catch(() => {
                    context.commit('SET_ERROR', true)
                }).then(() => {
                    context.commit('DECREMENT_LOADING')
                })
        },
        CHECK_PROJECT_NAME_AVAILABILITY(context, projectName) {
            axios.get("/api/check-name", { withCredentials: true, params: { name: projectName } })
                .then(response => {
                    context.commit('SET_PROJECT_NAME_AVAILABILITY', response.data.projectNameAvailable)
                }).catch(() => {
                    context.commit('SET_ERROR', true)
                })
        },
        CREATE_PROJECT(context, projectSpecification) {
            context.commit('INCREMENT_LOADING')
            axios.post("/api/project", projectSpecification, { withCredentials: true })
                .then(response => {
                    context.commit('SET_CREATED_PROJECT_URL', response.data.projectURL)
                }).catch(() => {
                    context.commit('SET_CREATION_ERROR', true)
                }).then(() => {
                    context.commit('DECREMENT_LOADING')
                })
        },
    },
})