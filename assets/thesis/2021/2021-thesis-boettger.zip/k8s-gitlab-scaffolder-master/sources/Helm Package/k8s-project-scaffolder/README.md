## Chart development
```
helm lint
helm template test . --namespace k8s-project-scaffolder -f ./values.local.yaml > test-output.yaml
```

## Installing a release
```
helm install [RELEASE_NAME] [CHART] --create-namespace --namespace k8s-project-scaffolder

helm install k8s-project-scaffolder . --create-namespace --namespace k8s-project-scaffolder -f ./values.local.yaml --dry-run

helm install k8s-project-scaffolder . --create-namespace --namespace k8s-project-scaffolder -f ./values.local.yaml
```

The templates don't derive the metadata.name from the .Release or .Chart object because only one running instance in the cluster (and the specified namespace) is desired.

## Upgrading a release
After changing the helm chart, update the version number accordingly and then run the following command:
```
helm upgrade k8s-project-scaffolder . --namespace k8s-project-scaffolder -f ./values.local.yaml
```