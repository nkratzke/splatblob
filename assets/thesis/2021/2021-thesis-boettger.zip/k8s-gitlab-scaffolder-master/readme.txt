This file explains the structure of this directory

- �documentation� for thesis document e.g. thesis.tex
- �material� for reference pdfs (data sheets, articles etc. downloaded from the Internet)
- �preperation� for the source files of the prepartion phase (the playground)
- �presentation� for presentations of the thesis (for the final examination)
- �sources� for your program sources, UML models

