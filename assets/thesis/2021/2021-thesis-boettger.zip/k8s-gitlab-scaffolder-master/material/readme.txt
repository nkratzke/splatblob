This folder contains reference pdfs or other documents
- articles,
- data sheets,
- webpages from the Internet

Everything that can be downloaded and does not violate copyrights