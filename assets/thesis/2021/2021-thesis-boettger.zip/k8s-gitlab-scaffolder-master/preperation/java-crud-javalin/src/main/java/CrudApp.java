import data_access.*;
import io.javalin.Javalin;
import jobs.AddNamesJob;
import model.Name;

import java.util.Map;

public class CrudApp {
    public static void main(String[] args) {
        Map<String, String> envVariables = System.getenv();
        String dataStorageHostname = envVariables.get("DATA_STORAGE_HOSTNAME") != null ? envVariables.get("DATA_STORAGE_HOSTNAME") : "127.0.0.1";
        String dataStoragePassword = envVariables.get("DATA_STORAGE_PASSWORD") != null ? envVariables.get("DATA_STORAGE_PASSWORD") : "password";
        String podNamespace = envVariables.get("POD_NAMESPACE") != null ? envVariables.get("POD_NAMESPACE") : "test-permission";

        DataStorage store = new Redis(dataStorageHostname, dataStoragePassword);
        AddNamesJob job = new AddNamesJob(podNamespace);

        Javalin app = Javalin.create().start(8081);

        app.get("/api/names", ctx -> ctx.json(store.readNames()));
        app.post("/api/names", ctx -> {
            Name newName = ctx.bodyAsClass(Name.class);
            ctx.json(store.createName(newName.getName()));
            ctx.status(201);
        });
        app.put("/api/names/:id", ctx -> {
            Name updatedName = ctx.bodyAsClass(Name.class);
            store.updateName(ctx.pathParam("id"), updatedName.getName());
            ctx.status(204);
        });
        app.delete("/api/names/:id", ctx -> {
            store.deleteName(ctx.pathParam("id"));
            ctx.status(204);
        });
        app.get("/api/names/createMany", ctx -> ctx.json(job.run()));
    }
}
