package data_access;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import model.Name;
import org.bson.*;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.util.LinkedList;
import java.util.List;

public class MongoDb implements DataStorage {

    private final MongoCollection<Document> collection;

    public MongoDb(String hostname, String password) {
        String uri = String.format("mongodb://root:%s@%s:27017/?authSource=admin", password, hostname);
        MongoClient mongoClient = new MongoClient(new MongoClientURI(uri));
        this.collection = mongoClient.getDatabase("names_list").getCollection("names_list");
    }

    @Override
    public Name createName(String name) {
        Document doc = new Document().append("name", name);
        this.collection.insertOne(doc);
        return new Name(doc.getObjectId("_id").toString(), name);
    }

    @Override
    public List<Name> readNames() {
        List<Name> names = new LinkedList<>();
        MongoCursor<Document> cursor = this.collection.find().iterator();
        while (cursor.hasNext()) {
            Document name = cursor.next();
            names.add(new Name(name.getObjectId("_id").toString(), name.getString("name")));
        }
        return names;
    }

    @Override
    public void deleteName(String id) {
        Bson query = new BsonDocument().append("_id", new BsonObjectId(new ObjectId(id)));
        this.collection.deleteOne(query);
    }

    @Override
    public void updateName(String id, String name) {
        Bson query = new BsonDocument().append("_id", new BsonObjectId(new ObjectId(id)));
        BsonDocument updatedProp = new BsonDocument().append("name", new BsonString(name));
        Bson setDoc = new BsonDocument().append("$set", updatedProp);
        this.collection.updateOne(query, setDoc);

    }
}
