package jobs;

import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.BatchV1Api;
import io.kubernetes.client.openapi.models.V1Job;
import io.kubernetes.client.util.ClientBuilder;
import io.kubernetes.client.util.KubeConfig;
import io.kubernetes.client.util.Yaml;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Scanner;

public class AddNamesJob {

    private static final String kubeconfigPath = "C:\\Users\\TCB\\.kube\\kubeconfigScaffolderNS.yaml";
    private final String namespace;
    private BatchV1Api batchClient;
    private V1Job addNamesJob;

    public AddNamesJob(String namespace) {
        this.namespace = namespace;
        try {
            // Uncomment the following line when developing locally
            ApiClient client = ClientBuilder.kubeconfig(KubeConfig.loadKubeConfig(new FileReader(kubeconfigPath))).build();
            // ApiClient client = ClientBuilder.cluster().build();
            Configuration.setDefaultApiClient(client);

            InputStream jobYamlStream = getClass().getResourceAsStream("/jobs/add_names.yaml");
            String jobYaml = new Scanner(jobYamlStream, "UTF-8").useDelimiter("\\A").next();
            this.addNamesJob = (V1Job) Yaml.load(jobYaml);
            this.batchClient = new BatchV1Api();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public JobMessage run() {
        if (this.batchClient != null) {
            try {
                V1Job createdJob = this.batchClient.createNamespacedJob(this.namespace, this.addNamesJob, null, null, null);
                return new JobMessage(true, Objects.requireNonNull(createdJob.getMetadata()).getName());
            } catch (ApiException error) {
                System.out.println(error.toString());
                return new JobMessage(false, "");
            }
        } else {
            return new JobMessage(false, "");
        }
    }
}
