package data_access;

import model.Name;

import java.util.List;

public interface DataStorage {
    public Name createName(String name);
    public List<Name> readNames();
    public void deleteName(String id);
    public void updateName(String id, String name);
}
