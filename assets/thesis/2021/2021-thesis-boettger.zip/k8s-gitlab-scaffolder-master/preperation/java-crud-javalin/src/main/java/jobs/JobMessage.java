package jobs;

public class JobMessage {

    private final String message;

    public JobMessage(boolean successful, String jobName) {
        this.message = successful ? "Your job was successfully scheduled and is now working as '" + jobName +
                "'. Try to reload the page in a moment." : "Unfortunately your job could not be scheduled.";
    }

    public String getMessage() {
        return message;
    }
}
