package data_access;

import model.Name;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public class InMemory implements DataStorage {

    private final Map<String, String> datastore = new HashMap<>();
    private final AtomicLong highestId = new AtomicLong();

    @Override
    public Name createName(String name) {
        String newId = Long.toString(this.highestId.incrementAndGet());
        this.datastore.put(newId, name);
        return new Name(newId, name);
    }

    @Override
    public List<Name> readNames() {
        List<Name> namesList = new LinkedList<>();
        this.datastore.forEach((id, name) -> namesList.add(new Name(id, name)));
        return namesList;
    }

    @Override
    public void deleteName(String id) {
        this.datastore.remove(id);
    }

    @Override
    public void updateName(String id, String name) {
        if (this.datastore.containsKey(id)) {
            this.datastore.put(id, name);
        }
    }
}
