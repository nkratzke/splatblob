package model

type Name struct {
	Id   string `json:"name_id" bson:"_id"`
	Name string `json:"name"`
}
