package jobs

import "fmt"

type JobMessage struct {
	Message string `json:"message"`
}

func NewJobMessage(successful bool, jobName string) JobMessage {
	var message string
	if successful {
		message = fmt.Sprintf("Your job was successfully scheduled and is now working as '%s'. Try to reload the page in a moment.", jobName)
	} else {
		message = "Unfortunately your job could not be scheduled."
	}
	return JobMessage{Message: message}
}
