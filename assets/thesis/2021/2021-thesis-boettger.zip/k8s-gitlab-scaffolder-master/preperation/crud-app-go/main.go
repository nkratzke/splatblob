package main

import (
	"crud-app-go/data_access"
	"crud-app-go/jobs"
	"crud-app-go/model"
	"github.com/gofiber/fiber/v2"
	"log"
	"os"
	"os/signal"
	"syscall"
)

type Datastore interface {
	Init() error
	Create(name string) (model.Name, error)
	Read() ([]model.Name, error)
	Update(id, name string) error
	Delete(id string) error
	Shutdown()
}

func main() {
	var store Datastore = &data_access.InMemory{}
	if err := store.Init(); err != nil {
		log.Fatalln(err)
	}

	addNamesJob, err := jobs.NewAddNamesJob()
	if err != nil {
		log.Fatal(err)
	}

	app := fiber.New()

	app.Get("/api/names", func(ctx *fiber.Ctx) error {
		names, err := store.Read()
		if err != nil {
			return err
		}
		return ctx.JSON(names)
	})

	app.Post("/api/names", func(ctx *fiber.Ctx) error {
		newName := &model.Name{}
		if err := ctx.BodyParser(newName); err != nil {
			return err
		}
		createdName, err := store.Create(newName.Name)
		if err != nil {
			return err
		}
		return ctx.Status(201).JSON(createdName)
	})

	app.Put("/api/names/:id", func(ctx *fiber.Ctx) error {
		id := ctx.Params("id")
		updatedName := &model.Name{}
		if err := ctx.BodyParser(updatedName); err != nil {
			return err
		}
		if err := store.Update(id, updatedName.Name); err != nil {
			return err
		}
		return ctx.SendStatus(204)
	})

	app.Delete("/api/names/:id", func(ctx *fiber.Ctx) error {
		id := ctx.Params("id")
		if err := store.Delete(id); err != nil {
			return err
		}
		return ctx.SendStatus(204)
	})

	app.Get("/api/names/createMany", func(ctx *fiber.Ctx) error {
		return ctx.JSON(addNamesJob.Run())
	})

	// Run http web server
	go func() {
		if err := app.Listen(":80"); err != nil {
			log.Panicln(err)
		}
	}()

	// Prepare graceful shutdown
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)

	// Block until shutdown signal received
	_ = <-c
	log.Println("Gracefully shutting down...")
	err = app.Shutdown() // Note: does not shut down before clients close keep-alive connections
	if err != nil {
		log.Println(err)
	}
	store.Shutdown()
}
