package data_access

import (
	"context"
	"crud-app-go/model"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	"log"
	"os"
	"time"
)

type MongoDb struct {
	client     *mongo.Client
	collection *mongo.Collection
}

func (m *MongoDb) Init() error {
	hostname, ok := os.LookupEnv("DATA_STORAGE_HOSTNAME")
	if !ok {
		hostname = "localhost"
	}
	password, ok := os.LookupEnv("DATA_STORAGE_PASSWORD")
	if !ok {
		password = "password"
	}

	// Connect to mongo db
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	uri := fmt.Sprintf("mongodb://root:%s@%s:27017/?authSource=admin", password, hostname)
	client, err := mongo.Connect(ctx, options.Client().ApplyURI(uri))
	if err != nil {
		return err
	}

	// Check connection
	m.client = client
	err = m.client.Ping(ctx, readpref.Primary())
	if err != nil {
		return err
	}

	// Set collection
	m.collection = m.client.Database("names_list").Collection("names_list")
	return nil
}

func (m *MongoDb) Create(name string) (model.Name, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	res, err := m.collection.InsertOne(ctx, bson.M{"name": name})
	if err != nil {
		return model.Name{}, err
	}
	id := res.InsertedID.(primitive.ObjectID).Hex()
	return model.Name{Name: name, Id: id}, nil
}

func (m *MongoDb) Read() ([]model.Name, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	names := []model.Name{} // declare empty slice via literal (instead of 'var names []model.Name') to avoid json marshalling resulting in "null"
	cursor, err := m.collection.Find(ctx, bson.M{})
	if err != nil {
		return names, err
	}
	defer cursor.Close(ctx)

	for cursor.Next(ctx) {
		var name model.Name
		err := cursor.Decode(&name)
		if err != nil {
			return names, err
		}
		names = append(names, model.Name{Id: name.Id, Name: name.Name})
	}
	if err := cursor.Err(); err != nil {
		return names, err
	}

	return names, nil
}

func (m *MongoDb) Update(id, name string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return err
	}
	filter := bson.M{"_id": objectId}
	update := bson.M{"$set": bson.M{"name": name}}
	result, err := m.collection.UpdateOne(ctx, filter, update)
	if err != nil {
		return err
	}
	if result.MatchedCount != 1 {
		return errors.New(fmt.Sprintf("Update affected %d documents instead of 1", result.MatchedCount))
	}
	return nil
}

func (m *MongoDb) Delete(id string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return err
	}
	filter := bson.M{"_id": objectId}
	result, err := m.collection.DeleteOne(ctx, filter)
	if err != nil {
		return err
	}
	if result.DeletedCount != 1 {
		return errors.New(fmt.Sprintf("Delete affected %d documents instead of 1", result.DeletedCount))
	}
	return nil
}

func (m *MongoDb) Shutdown() {
	log.Println("Closing mongo_db connection")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	err := m.client.Disconnect(ctx)
	if err != nil {
		log.Println("Error when closing mongo_db connection: ", err)
	}
}
