package data_access

import (
	"crud-app-go/model"
	"database/sql"
	"errors"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"log"
	"os"
	"strconv"
)

type MySql struct {
	db *sql.DB
}

func (m *MySql) Init() error {
	hostname, ok := os.LookupEnv("DATA_STORAGE_HOSTNAME")
	if !ok {
		hostname = "localhost"
	}
	password, ok := os.LookupEnv("DATA_STORAGE_PASSWORD")
	if !ok {
		password = "password"
	}

	db, err := sql.Open("mysql", fmt.Sprintf("root:%s@tcp(%s:3306)/names_db", password, hostname))
	if err != nil {
		return err
	}
	m.db = db

	err = db.Ping()
	if err != nil {
		return err
	}

	return nil
}

func (m *MySql) Create(name string) (model.Name, error) {
	res, err := m.db.Exec("INSERT INTO some_names (name) VALUES (?)", name)
	if err != nil {
		return model.Name{}, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return model.Name{}, err
	}
	return model.Name{Id: strconv.Itoa(int(id)), Name: name}, nil
}

func (m *MySql) Read() ([]model.Name, error) {
	names := []model.Name{} // declare empty slice via literal (instead of 'var names []model.Name') to avoid json marshalling resulting in "null"

	rows, err := m.db.Query("SELECT * FROM some_names")
	if err != nil {
		return names, err
	}
	defer rows.Close()

	var id string
	var name string
	for rows.Next() {
		err := rows.Scan(&id, &name)
		if err != nil {
			return names, err
		}
		names = append(names, model.Name{Id: id, Name: name})
	}

	err = rows.Err()
	if err != nil {
		return names, err
	}

	return names, nil
}

func (m *MySql) Update(id, name string) error {
	res, err := m.db.Exec("UPDATE some_names SET name = ? WHERE name_id = ?", name, id)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected != 1 {
		return errors.New(fmt.Sprintf("SQL update affected %d rows instead of 1 row", affected))
	}
	return nil
}

func (m *MySql) Delete(id string) error {
	res, err := m.db.Exec("DELETE FROM some_names WHERE name_id = ?", id)
	if err != nil {
		return err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if affected != 1 {
		return errors.New(fmt.Sprintf("SQL delete affected %d rows instead of 1 row", affected))
	}
	return nil
}

func (m *MySql) Shutdown() {
	log.Println("Closing mysql connection")
	err := m.db.Close()
	if err != nil {
		log.Println("Error when closing mysql connection: ", err)
	}
}
