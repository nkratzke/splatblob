package data_access

import (
	"context"
	"crud-app-go/model"
	"github.com/go-redis/redis/v8"
	"log"
	"math/rand"
	"os"
	"strconv"
)

type Redis struct {
	db *redis.Client
}

var ctx = context.Background()

func (r *Redis) Init() error {
	hostname, ok := os.LookupEnv("DATA_STORAGE_HOSTNAME")
	if !ok {
		hostname = "localhost"
	}
	password, ok := os.LookupEnv("DATA_STORAGE_PASSWORD")
	if !ok {
		password = "password"
	}

	r.db = redis.NewClient(&redis.Options{
		Addr:     hostname + ":6379",
		Password: password,
		DB:       0,
	})
	if _, err := r.db.Ping(ctx).Result(); err != nil {
		return err
	}
	return nil
}

func (r *Redis) Create(name string) (model.Name, error) {
	id := strconv.Itoa(rand.Int())
	err := r.db.Set(ctx, id, name, 0).Err()
	return model.Name{Id: id, Name: name}, err
}

func (r *Redis) Read() ([]model.Name, error) {
	names := []model.Name{} // declare empty slice via literal (instead of 'var names []model.Name') to avoid json marshalling resulting in "null"

	keys, err := r.db.Keys(ctx, "*").Result()
	if err != nil {
		return names, err
	}

	for _, key := range keys {
		name, err := r.db.Get(ctx, key).Result()
		if err != nil {
			return names, err
		}
		names = append(names, model.Name{Id: key, Name: name})
	}

	return names, nil
}

func (r *Redis) Update(id, name string) error {
	return r.db.Set(ctx, id, name, 0).Err()
}

func (r *Redis) Delete(id string) error {
	return r.db.Del(ctx, id).Err()
}

func (r *Redis) Shutdown() {
	log.Println("Closing redis connection")
	err := r.db.Close()
	if err != nil {
		log.Println("Error when closing redis connection: ", err)
	}
}
