package data_access

import (
	"crud-app-go/model"
	"strconv"
	"sync"
)

type InMemory struct {
	datastore map[string]string
	highestId int
	mutex     sync.RWMutex
}

func (i *InMemory) Init() error {
	i.datastore = make(map[string]string)
	return nil
}

func (i *InMemory) Create(name string) (model.Name, error) {
	i.mutex.Lock()
	defer i.mutex.Unlock()
	i.highestId++
	id := strconv.Itoa(i.highestId)
	i.datastore[id] = name
	return model.Name{Id: id, Name: name}, nil
}

func (i *InMemory) Read() ([]model.Name, error) {
	names := []model.Name{} // declare empty slice via literal (instead of 'var names []model.Name') to avoid json marshalling resulting in "null"
	i.mutex.RLock()
	defer i.mutex.RUnlock()
	for id, name := range i.datastore {
		names = append(names, model.Name{Id: id, Name: name})
	}
	return names, nil
}

func (i *InMemory) Update(id, name string) error {
	i.mutex.Lock()
	defer i.mutex.Unlock()
	i.datastore[id] = name
	return nil
}

func (i *InMemory) Delete(id string) error {
	i.mutex.Lock()
	defer i.mutex.Unlock()
	delete(i.datastore, id)
	return nil
}

func (i *InMemory) Shutdown() {
	return
}
