# k8s-gitlab-scaffolder

Nutzen Sie bitte dieses Repo für Ihre BA. Dieses Repo ist vorkonfiguriert.

- Ihr MicroK8S "Cluster" (Single Node) läuft unter der IP: 212.201.22.222 (bzw. scaffolder.th-luebeck.dev)
- Ihre Kubeconfig finden Sie unter [Einstellung -> CI/CD -> Variables](https://git.mylab.th-luebeck.de/thesis/kratzke/k8s-gitlab-scaffolder/-/settings/ci_cd).
- Eine gitlab-ci Pipeline ist eingerichtet, die zeigt wie Sie auf den Cluster mittels Gitlab CI Umgebungsvariablen zugreifen können. Die vorkonfigurierten Variablen sind:
    - `K8S_CONFIG` (Kubeconfig Datei)
    - `K8S_NAMESPACE` (anzulegender Namespace)

Sie können ferner auf die Web-UI des Clusters wie folgt von Ihrem lokalen Rechner zugreifen (Sie müssen dazu natürlich die Kubeconfig Datei lokal vorliegen haben)

```kubectl proxy```

Sie können dann mit einem beliebigen Web-Browser unter folgender Addresse zugreifen.

[http://localhost:8001/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/](http://localhost:8001/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/)

Den Access Token finden Sie in der kubeconfig.
