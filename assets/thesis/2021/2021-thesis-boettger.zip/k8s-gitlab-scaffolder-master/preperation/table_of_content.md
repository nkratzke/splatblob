<!-- omit in toc -->
# Table of Content
- [Introduction](#introduction)
  - [Motivation](#motivation)
  - [Objectives](#objectives)
  - [Structure of This Work](#structure-of-this-work)
- [Fundamentals of Cloud Native Applications](#fundamentals-of-cloud-native-applications)
  - [Containers](#containers)
  - [Container Orchestration](#container-orchestration)
  - [Continuous Integration](#continuous-integration)
  - [Continuous Deployment](#continuous-deployment)
  - [GitOps](#gitops)
- [Requirements Analysis](#requirements-analysis)
  - [Stakeholder Analysis](#stakeholder-analysis)
    - [End Users](#end-users)
    - [Software Developers](#software-developers)
    - [Software Maintainers](#software-maintainers)
    - [Server and Kubernetes Cluster Administrators](#server-and-kubernetes-cluster-administrators)
    - [Organization](#organization)
  - [Functional Requirements](#functional-requirements)
  - [Non-Functional Requirements](#non-functional-requirements)
  - [General Design Decisions](#general-design-decisions)
- [Architecture](#architecture)
  - [Preconditions](#preconditions)
  - [System Architecture](#system-architecture)
  - [Software Architecture](#software-architecture)
    - [Frontend](#frontend)
    - [Backend](#backend)
      - [Authentication through OAuth 2.0](#authentication-through-oauth-20)
      - [Project Creation](#project-creation)
        - [Kubernetes Namespace Creation](#kubernetes-namespace-creation)
        - [GitLab Repository Creation](#gitlab-repository-creation)
      - [Project Scaffolding](#project-scaffolding)
    - [Packaging as Helm Chart](#packaging-as-helm-chart)
      - [Resources](#resources)
      - [Configuration Options](#configuration-options)
- [Implementation](#implementation)
  - [TODO](#todo)
- [Extensibility](#extensibility)
  - [Open Application Programming Interface](#open-application-programming-interface)
  - [Supporting Multiple Git Hosting Providers](#supporting-multiple-git-hosting-providers)
  - [Supporting Various Kubernetes Cluster Configurations](#supporting-various-kubernetes-cluster-configurations)
  - [Deployment Environments](#deployment-environments)
- [Testing the Requirements Fulfillment](#testing-the-requirements-fulfillment)
  - [Methodology](#methodology)
  - [Test Results](#test-results)
- [Conclusion](#conclusion)
  - [Evaluation of the Outcome](#evaluation-of-the-outcome)
  - [Outlook](#outlook)

# Introduction

## Motivation
Why?

Real world applications/examples, possible outcome for developers and easier adoptions, (weaknesses of competing solutions => expects too much foreknowledge, should be kept on a higher level)

## Objectives
What?

Discuss multi tenancy on a higher level in the context of computing resources and Kubernetes in particular.

## Structure of This Thesis
How?

# Fundamentals of Cloud Native Applications
- Original Definition of the CNCF 
  - What does containerized mean? 
  - What is the definition of a cloud native application? 
  - What have Microservices and APIs to do with it (which should not be covered in detail because this thesis is more about the infrastructure and not the application layer, this should be mentioned so that the reader can follow the examples in the following sections about containerized applications)? 
- Statistics: (Showing relevance and for motivation)
  - how fast is the ecosystem growing 
  - how many companies are adopting it 
  - how many research papers are published around this topic 
- Comparison to traditional practices like Monoliths and On-premises/VM/Bare solutions
- Cloud native does not necessarily imply running applications in a public cloud

## Containers

## Container Orchestration
Valid for this and the former chapter:
- Based on open technologies (e.g. Docker, K8s) 
- Abstracts away the underlying infrastructure (Cloud, Hybrid, Multi, On-premises) 
- Prevents vendor lock-in 

## Continuous Integration

## Continuous Deployment

## GitOps
This is the result of the former chapters: 
- Declarative Infrastructure as Code 
- automated CI/CD 
- +common Git operations like code reviews, pull requests, and comments on changes of your infrastructure (Das schließt den Kreis zu GitLab) 


# Requirements Analysis
Outline the target group and the general environment for which the solution gets developed. In general, this chapter should not only focus on the specific environment but also take other use cases into account. This gives the opportunity to derive requirements with extensibility in mind. Maybe also discussing hard and soft multi tenancy in Kubernetes (regarding the control plane).

## Stakeholder Analysis
Define the environment and all involved parties.

### End Users
Define properties of the target group and its requirements.

### Software Developers

### Software Maintainers

### Server and Kubernetes Cluster Administrators

### Organization
In this case the university.

## Functional Requirements
Derive more detailed list of requirements from the stakeholder analysis. This list of requirements represents the test cases for later evaluation.

## Non-Functional Requirements

## General Design Decisions
Based on the derived requirements, discussing possible design alternatives. This lays the foundation for the following chapter.

# Architecture

## Preconditions
Preconditions that must be met by the environment for the installation of the app. The following architecture builds up on these assumptions.

- Kubernetes cluster set up with:
  - Ingress Controller (in this case Nginx)
  - cert-manager and lets-encrypt
  - ServiceAccount created with the right privileges (for the scaffolder app)
  - RBAC enabled
  - Correct Admission Controllers enabled
  - DefaultStorageClass admission controller turned on and a cluster-wide default StorageClass defined ([Info 1](https://kubernetes.io/docs/reference/access-authn-authz/admission-controllers/#defaultstorageclass), [Info 2](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#class-1), [Info 3](https://kubernetes.io/docs/tasks/administer-cluster/change-default-storage-class/))
- GitLab Runners, Jobs and Container Registry activated for projects
- [Authorize the Scaffolder application](https://docs.gitlab.com/ee/integration/oauth_provider.html) to use GitLab as an OAuth2 provider ([GitLab API Docs](https://docs.gitlab.com/ee/api/applications.html))


## System Architecture
Describing and visualizing all components and how they play together. This chapter is not limited to the components which are to be implemented.

## Software Architecture

### Frontend
Single Page Application

### Backend
REST API

#### Authentication through OAuth 2.0

#### Project Creation

##### Kubernetes Namespace Creation

##### GitLab Repository Creation

#### Project Scaffolding
Assuming the reader does not know what Scaffolding is

### Packaging as Helm Chart

#### Resources

#### Configuration Options
Also discussing appropriate default values.

# Implementation
Side note: The programming languages are partly given through the requirements (Backend: Python) and due to the fact that most frontend frameworks rely on Javascript.

This chapter is to be extended during the implementation phase.

Discussing and Reasoning about:

- Languages
- Frameworks/Libraries
- [Principles](https://en.wikipedia.org/wiki/List_of_software_development_philosophies)
- Tools Used
- Crucial Aspects
- Limitations
- Challenges
- How was the OAuth 2 Application Flow solved
- All the stuff I've moved to the 'Resolved' Column

## TODO

# Extensibility

## Open Application Programming Interface
Following open and standardized API principles which makes it easy for others to build or extend a Frontend or CLI.

## Supporting Multiple Git Hosting Providers
GitHub, Bitbucket

## Supporting Various Kubernetes Cluster Configurations
Maybe by reducing the preconditions or more configuration opportunities. This would lead to extending the project templates (the manifests in particular).

What are the differences between various K8s Distributions, except for different setup procedures and some additional (independent) features, which would have influence on the Scaffolder functionality?

## Deployment Environments

# Testing the Requirements Fulfillment
Integration and system testing happens continuously during development due to CI/CD and the continuous manual testing of newly implemented features.

## Methodology
Usually each requirement should represent a test case. Describing specific methodologies/implementations for each test case/category.

=> Hacker mentality in regard of the namespaces

## Test Results

# Conclusion

## Evaluation of the Outcome
Also mentioning/summarizing limitations.

## Outlook
