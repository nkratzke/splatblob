## Readme - Execution Order
```
kubectl apply -f ./namespace.yaml
kubectl apply -f ./resourcequota.yaml
kubectl apply -f ./limitrange.yaml
kubectl apply -f ./role.yaml
kubectl apply -f ./rolebinding.yaml

or

kubectl apply -f ./namespace-setup-merged.yaml
```

#### After that, get the CA certificate and the token and create a kubeconfig for the namespaced ServiceAccount.
```
kubectl get secret default-token-qwsft -n restricted-xample -o jsonpath='{.data.ca\.crt}'
kubectl get secret default-token-qwsft -n restricted-xample -o jsonpath='{.data.token}' | base64 --decode
```

The kubeconfig.yaml schema for a namespaced SA looks like the following:

```yaml
kind: Config
apiVersion: v1
clusters:
- name: kubernetes-cluster
  cluster:
    certificate-authority-data: {{ ca.crt }}
    server: https://scaffolder.th-luebeck.dev:16443
contexts:
- name: default-context
  context:
    cluster: kubernetes-cluster
    namespace: restricted-xample
    user: default
current-context: default-context
users:
- name: default
  user:
    token: {{ token }} # decoded
```

#### Set the new context in kubectl for the default ServiceAccount of the restricted-xample namespace.

#### Create a secret for logging into a private docker-registry (Must be created first as deploy token in GitLab):
```
kubectl create secret docker-registry registry-credentials --docker-server=<your-registry-server> --docker-username=<your-name> --docker-password=<your-pword> --docker-email=<your-email>
kubectl create secret docker-registry registry-credentials --docker-server= --docker-username= --docker-password=
```

#### Create the deployment:
```
kubectl apply -f ./deployment.yaml
kubectl apply -f ./service.yaml
kubectl apply -f ./ingress.yaml

or

kubectl apply -f ./deployment-merged.yaml
```
