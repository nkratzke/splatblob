START TRANSACTION;

CREATE DATABASE IF NOT EXISTS `names_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;

USE `names_db`;

/*
  You don't need to create a new table at startup time if you use ORM or other tools which initialize your database structure.
  In this case, just delete the next step.
*/
CREATE TABLE IF NOT EXISTS `some_names` (
  `name_id` int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

COMMIT;
