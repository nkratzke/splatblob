In the production environment, the `mysql-root-secret` should be automatically applied with a random password by the scaffolder app.
Also, the deploy token and the registry-credentials secret must be issued and created beforehand.

```
kubectl create secret docker-registry registry-credentials --docker-server= --docker-username= --docker-password=
```

## Execution Order - Data Storage Layer
```
kubectl apply -f ./config.yaml (deprecated, now with create --dry-run and apply, look gitlab-ci.yml)
kubectl apply -f ./persistentvolumeclaim.yaml
kubectl apply -f ./database.yaml
```
