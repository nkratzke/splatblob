const axios = require("axios").default
const prefix = process.env.APP_URL
const maximumLength = parseInt(process.env.MAXIMUM_LENGTH)

axios.get(prefix + "/api/names")
    .then(response => {
        response.data
            .slice(maximumLength)
            .forEach(async entry => await axios.delete(`${prefix}/api/names/${entry.name_id}`))
    })
    .catch(error => console.log(error))
