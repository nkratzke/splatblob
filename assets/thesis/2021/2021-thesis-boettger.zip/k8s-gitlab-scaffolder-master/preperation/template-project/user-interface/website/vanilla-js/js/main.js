const prefix = "https://names.scaffolder.th-luebeck.dev"
const namesTableBody = document.getElementById("namesTableBody")

function createTableEntry(id, name) {
    return `<tr>
        <td>${id}</td>
        <td><input type="text" id="name-${id}" value="${name}" /></td>
        <td>
            <button class="update" onclick="updateName(${id})" type="button">
                Update
            </button>
        </td>
        <td>
            <button class="delete" onclick="deleteName(${id})" type="button">
                Delete
            </button>
        </td>
    </tr>
    `
}

function createName() {
    let newName = document.getElementById("newNameInput").value;
    if (newName !== "") {
        let myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        let raw = JSON.stringify({ "name": newName });

        let requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw
        };

        fetch(prefix + "/api/names", requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result)
                readNames()
            })
            .catch(error => console.log("error", error));
    }
}

function createManyNames() {
    fetch(prefix + "/api/names/createMany", { method: "GET" })
        .then(response => response.json())
        .then(result => document.getElementById("createManyNamesOutput").innerHTML = result.message)
        .catch(error => console.log("error", error));
}

function readNames() {
    let content = ""
    fetch(prefix + "/api/names", { method: "GET" })
        .then(response => response.json())
        .then(data => {
            data.forEach(entry => {
                content = content + createTableEntry(entry.name_id, entry.name)
            })
            namesTableBody.innerHTML = content
        })
        .catch(error => console.log("error", error));
}

function deleteName(id) {
    fetch(`${prefix}/api/names/${id}`, { method: "DELETE" })
        .then(response => response.text())
        .then(result => {
            console.log(result)
            readNames()
        })
        .catch(error => console.log("error", error));
}

function updateName(id) {
    let updatedName = document.getElementById("name-" + id).value;
    if (updatedName !== "") {
        let myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        let raw = JSON.stringify({ "name": updatedName });

        let requestOptions = {
            method: "PUT",
            headers: myHeaders,
            body: raw
        };

        fetch(`${prefix}/api/names/${id}`, requestOptions)
            .then(response => response.text())
            .then(result => {
                console.log(result)
                readNames()
            })
            .catch(error => console.log("error", error));
    }
}

readNames();
