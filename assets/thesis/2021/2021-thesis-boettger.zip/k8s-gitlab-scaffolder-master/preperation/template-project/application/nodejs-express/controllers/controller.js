const namesService = new (require("../services/service"))
const model = new (require("../models/mysql")) // You can change the data storage layer here (e.g. in-memory, mysql or another database)
const job = new (require("../jobs/add-names"))
const express = require("express")


const ingressBaseUri = "/api" // necessary so that the Kubernetes Ingress rule must not be rewritten


async function init(app) {
    app.use(express.json()) // middleware for parsing application/json body

    console.log("Initialize database connection")
    await model.connect()

    console.log("Initialize kubernetes batch API connection")
    await job.connect()

    console.log("Initialize each route with a controller") // A controller is just a request handler for one route
    app.post(ingressBaseUri + "/names", create)
    app.get(ingressBaseUri + "/names", read)
    app.put(ingressBaseUri + "/names/:id", update)
    app.delete(ingressBaseUri + "/names/:id", delete_)
    app.get(ingressBaseUri + "/names/createMany", createMany)
}

async function create(request, response) {
    try {
        responseBody = await namesService.create(model, request.body.name)
        response.status(201).send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

async function read(request, response) {
    try {
        responseBody = await namesService.read(model)
        response.send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

async function update(request, response) {
    try {
        await namesService.update(model, parseInt(request.params.id), request.body.name)
        response.status(204).send()
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

async function delete_(request, response) {
    try {
        await namesService.delete(model, parseInt(request.params.id))
        response.status(204).send()
    } catch (error) {
        response.status(500).send({ message: error })
    }
}

async function createMany(request, response) {
    try {
        responseBody = await namesService.createMany(job, request.query.number ? parseInt(request.query.number) : 20)
        response.send(responseBody)
    } catch (error) {
        response.status(500).send({ message: error })
    }
}


module.exports.init = init
