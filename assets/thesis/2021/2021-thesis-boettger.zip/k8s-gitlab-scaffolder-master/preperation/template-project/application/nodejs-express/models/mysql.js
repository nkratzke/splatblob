var mysql = require("mysql2/promise");


class MySqlDatabase {
    async add(name) {
        const response = await this.database.query(`INSERT INTO some_names (name) VALUES ("${name}");`)
        return { name_id: response[0]["insertId"], name: name }
    }

    async getAll() {
        return (await this.database.query("SELECT * FROM some_names;"))[0]
    }

    async update(id, name) {
        await this.database.query(`UPDATE some_names SET name = "${name}" WHERE name_id = ${id};`)
    }

    async delete(id) {
        await this.database.query(`DELETE FROM some_names WHERE name_id = ${id};`)
    }

    async connect() {
        try {
            this.database = await mysql.createConnection({
                host: process.env.DATABASE_HOSTNAME,
                user: "root",
                password: process.env.MYSQL_ROOT_PASSWORD,
                database: "names_db"
            })
            console.log("Successfully connected to database 'names_db'")

            setInterval(this.getAll.bind(this), 28000000) // Prevent wait timeout for non-interactive connection
            // https://dev.mysql.com/doc/refman/5.7/en/server-system-variables.html#sysvar_wait_timeout
            // SHOW VARIABLES LIKE '%timeout'
        } catch (error) {
            console.log(error)
        }
    }

    async shutdown() {
        try {
            await this.database.end()
        } catch (error) {
            console.log(error)
        }
    }
}

module.exports = MySqlDatabase
