
class InMemoryDatabase {
    constructor() {
        this.database = new Map()
        this.highestId = 0
    }

    async add(name) {
        this.highestId = this.highestId + 1
        this.database.set(this.highestId, name)
        return { name_id: this.highestId, name: name }
    }

    async getAll() {
        const entries = Array.from(this.database.entries())
        return entries.map(value => { return { name_id: value[0], name: value[1] } })
    }

    async update(id, name) {
        this.database.set(id, name)
    }

    async delete(id) {
        this.database.delete(id)
    }

    async connect() {
        return // nothing to do here
    }

    async shutdown() {
        return // nothing to do here
    }
}

module.exports = InMemoryDatabase
