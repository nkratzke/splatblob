const k8s = require('@kubernetes/client-node');

class AddNamesJob {
    async createMany(numberOfNewNames) {
        let message = ""

        try {
            const response = await this.batch.createNamespacedJob(process.env.POD_NAMESPACE, {
                "apiVersion": "batch/v1",
                "kind": "Job",
                "metadata": {
                    "name": "add-names-" + Math.floor(Math.random() * 100000)
                },
                "spec": {
                    "backoffLimit": 1,
                    "activeDeadlineSeconds": 60,
                    "template": {
                        "spec": {
                            "containers": [
                                {
                                    "name": "add-names",
                                    "image": "curlimages/curl:7.72.0",
                                    "command": [
                                        "sh",
                                        "-c",
                                        "i=1; while [ $i -le $NUMBER ]; do curl --request POST \"$API_URL\" --header \"Content-Type: application/json\" --data-raw \"{\\\"name\\\":\\\"Aladeen the $i.\\\"}\"; i=$((i + 1)); done"
                                    ],
                                    "env": [
                                        {
                                            "name": "API_URL",
                                            "value": process.env.APP_URL + "/api/names"
                                        },
                                        {
                                            "name": "NUMBER",
                                            "value": numberOfNewNames.toString()
                                        }
                                    ],
                                    "resources": {
                                        "limits": {
                                            "cpu": "100m",
                                            "memory": "10Mi"
                                        }
                                    }
                                }
                            ],
                            "restartPolicy": "Never"
                        }
                    }
                }
            })
            console.log(response.body)
            message = "Your job was successfully scheduled and is now working as '" + response.response.body.metadata.name + "'. Try to reload the page in a moment."
        } catch (error) {
            console.log(error.response.body)
            message = "Internal error. Error message from the K8s server:\n" + error.response.body.message
        }
        console.log(message)

        return { message: message }
    }

    async connect() {
        this.kc = new k8s.KubeConfig();
        this.kc.loadFromDefault();

        console.log("Pod's Current Namespace:", process.env.POD_NAMESPACE)

        this.batch = this.kc.makeApiClient(k8s.BatchV1Api)
    }

    async shutdown() {
        return // Nothing to do here
    }
}

module.exports = AddNamesJob
