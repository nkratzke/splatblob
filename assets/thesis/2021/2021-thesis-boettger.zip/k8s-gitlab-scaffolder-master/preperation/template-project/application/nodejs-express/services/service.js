
class NamesService {
    async create(model, newName) {
        return await model.add(newName)
    }

    async read(model) {
        return await model.getAll()
    }

    async update(model, id, updatedName) {
        return await model.update(id, updatedName)
    }

    async delete(model, id) {
        return await model.delete(id)
    }

    async createMany(job, number) {
        return await job.createMany(number)
    }
}

module.exports = NamesService
