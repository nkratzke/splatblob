"use strict"

const express = require("express")
const controller = require("./controllers/controller")

async function startServer() {

    const app = express()

    await controller.init(app)

    app.listen(80, err => {
        if (err) {
            console.log(err)
            return
        }
        console.log("Listening on port 80")
    })
}

startServer()
