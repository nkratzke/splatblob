## Readme - Execution Order
Complete the `secret.yaml` with your own configuration. Then run the following commands:

```
kubectl apply -f ./secret.yaml
kubectl apply -f ./persistentvolumeclaim.yaml
kubectl apply -f ./mysql-deployment.yaml
kubectl apply -f ./myadmin-deployment.yaml
```