Put the slides for the presentation at the colloquium here.
Use the original format which has been used to generate the presentation (e.g. Powerpoint),
but also an additional pdf version.

Three template files are provided. You can choose based on your preferences.

