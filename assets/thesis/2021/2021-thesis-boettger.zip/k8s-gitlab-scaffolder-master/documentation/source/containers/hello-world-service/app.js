const express = require('express')
const fs = require('fs')
const app = express()
const port = 80
const greetName = process.env.GREET_NAME

app.get('/', (req, res) => { // Hello World! endpoint
    const logEntry = `${Date.now()}: {${req.ip}: ${greetName}}\n`
    fs.appendFile('data/log.txt', logEntry, function (err) {
        if (err) throw err
        console.log(`Saved log: ${logEntry}`)
    })
    res.send(`Hello ${greetName}!`)
})

app.get('/log', (req, res) => { // log endpoint
    fs.readFile('data/log.txt', function (err, data) {
        if (err) throw err;
        res.send(data.toString())
    })
})

app.listen(port, () => {console.log(`App listening on port:${port}`)})