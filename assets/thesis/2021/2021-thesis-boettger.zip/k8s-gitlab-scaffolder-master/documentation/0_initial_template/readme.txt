Use of the template
-------------------

The main file of the template is /documentation/thesis.tex

The template is optimized for PDFLaTex.
For usual LaTeX convert graphics files into .ps or .eps and do not
include the hyperref package using the usepackage command

History
-------

Template from MNM-Team M�nchen (Michael Brenner), 
adopted for TH L�beck by Andreas Hanemann